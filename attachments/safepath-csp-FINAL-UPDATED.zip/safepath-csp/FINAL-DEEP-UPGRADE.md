# SafePath CSP — Deep Final UX Upgrade

This package is the current SafePath CSP baseline with the requested commercial-grade UX pass layered onto the existing application.

## Included
- Persistent XP/level/streak HUD and theme customization already present in the app.
- Planner strategy controls: Adaptive, Auto Mix, Domain by Domain, My Choice.
- Every D1–D7 domain remains visible in the weekly plan, with scheduled class links and daily pacing targets.
- Public CSP preparation SEO library with per-domain and per-class pages and semantic keyword clusters.
- Improved lesson visual language and formula/TI-30XS terminal presentation.
- CSP Eligibility Wizard with persistent profile storage for registered users and session storage for demo users.
- Public eligibility route for discovery/SEO; saving the result requires authentication.
- Next.js App Router / Next 15-compatible async searchParams usage in the self-assessment area.

## Eligibility basis
The wizard is a screening aid based on the current BCSP CSP requirements: minimum bachelor's degree, four years of SH&E experience, at least 50% preventative professional-level work with breadth/depth, and a BCSP-qualified credential/pathway. Final eligibility remains with BCSP after application/document review.

## Local start
```powershell
npm ci
npx prisma generate
npx prisma db push
npm run db:seed
npm run dev
```
Or use `START-SAFEPATH.bat` on Windows.

## Build validation
The execution environment available for this package could not complete `npm ci` within the transport window, so a dependency-backed Next.js production build was not claimed as verified here. Source parser validation across the TypeScript/TSX tree completed without parser diagnostics.

## Lesson delivery polish — final pass

- Lesson study notes now support `Focus one block` and `Scan all` presentation. The underlying study material is preserved; delivery is progressive and easier to scan.
- Added persistent `LessonNote` records so candidates can create timestamped, class-specific personal study notes.
- Added `/api/lesson-notes` GET/POST/DELETE route with authenticated ownership checks and demo-safe local fallback behavior.
- Lesson header now exposes a persistent personal-notes action and a movable TI-30XS practice calculator.
- Calculator windows are draggable by their header, keyboard-closeable, mobile-friendly, and remember their last position per mode in local storage.
- Lesson section navigation is horizontally scrollable on narrow screens so labels remain readable instead of collapsing into tiny cards.
