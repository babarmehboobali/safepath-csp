export { EXTRA_QUESTIONS } from "./extra-questions";
export { WHY_WRONG_QUESTIONS } from "./why-wrong";
export { ALGEBRA_QUESTIONS } from "./algebra";
export { EXTRA_FORMULAS } from "./extra-formulas";
export { TOX_DEFS, TOX_ABBREVS, TOX_FOUNDATION, TOX_EXAM } from "./tox-reference";
export { EXTRA_CARDS } from "./extra-cards";
export { DIAGNOSTIC_EXTRAS } from "./diagnostic-extras";
export { TOPIC_MODULES } from "./topic-map";
export { SESSION_MAP } from "./session-map";
export { CHALLENGE_D1 } from "./challenge-d1";
export { CHALLENGE_D2 } from "./challenge-d2";
export { CHALLENGE_D3 } from "./challenge-d3";
export { CHALLENGE_D4 } from "./challenge-d4";
export { CHALLENGE_D5 } from "./challenge-d5";
export { CHALLENGE_D6 } from "./challenge-d6";
export { CHALLENGE_D7 } from "./challenge-d7";

import { CHALLENGE_D1 } from "./challenge-d1";
import { CHALLENGE_D2 } from "./challenge-d2";
import { CHALLENGE_D3 } from "./challenge-d3";
import { CHALLENGE_D4 } from "./challenge-d4";
import { CHALLENGE_D5 } from "./challenge-d5";
import { CHALLENGE_D6 } from "./challenge-d6";
import { CHALLENGE_D7 } from "./challenge-d7";
import type { GymQuestion } from "./types";

export const CHALLENGE_QUESTIONS: GymQuestion[] = [
  ...CHALLENGE_D1,
  ...CHALLENGE_D2,
  ...CHALLENGE_D3,
  ...CHALLENGE_D4,
  ...CHALLENGE_D5,
  ...CHALLENGE_D6,
  ...CHALLENGE_D7,
];
