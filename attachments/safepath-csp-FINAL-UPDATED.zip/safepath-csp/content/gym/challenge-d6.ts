import { exam } from "../classes/types";
import type { GymQuestion } from "./types";

export const CHALLENGE_D6: GymQuestion[] = [
  {
    classId: 61,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.61",
      "IH at North pier tank farm skipped anticipation; respirators after the first illness. AREC. Best?",
      [
      "Control-first is AREC.",
      "Anticipate/recognize/evaluate then control; respirators last if higher controls were open.",
      "TRIR first.",
      "FTA first.",
      ],
      1,
      "AREC order.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 62,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.62",
      "One grab at lunch used as the 8-hour TWA at Line 4 stamping cell for a varying 8-step task. Error?",
      [
      "Grab is TWA.",
      "Sampling strategy must represent the TWA asked.",
      "PELTLV only.",
      "FIN.",
      ],
      1,
      "Strategy vs convenience.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 63,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.63",
      "Silica at Building C autoclave: wet method still open; team issues N95 only. Pick?",
      [
      "N95 as PtD.",
      "Wet method/LEV/Table-1 equivalent before respirator-only.",
      "DART.",
      "ROI.",
      ],
      1,
      "Silica hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 64,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.64",
      "OSHA noise stem at Night-shift warehouse mezzanine; candidate uses NIOSH 3 dB times at 15 dBA. Error?",
      [
      "Always NIOSH.",
      "Matched 90/5 vs 85/3 pairs.",
      "PELTLV only.",
      "FIN.",
      ],
      1,
      "Do not mix exchange rates.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 65,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.65",
      "Point source 18 mR/h at 2 m at Unit 7 hydrotreater. Intensity at 4 m?",
      [
      "Half.",
      "Quarter: inverse square.",
      "Double.",
      "Zero.",
      ],
      1,
      "I2 = I1 (d1/d2)².",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 66,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.66",
      "Indoor heat at Clinic sterile processing. Candidate adds 0.1 Tdb solar term to WBGT. Error?",
      [
      "Always outdoor formula.",
      "Indoor/no sun is 0.7 nwb + 0.3 g.",
      "UNIT.",
      "PELTLV.",
      ],
      1,
      "Match indoor vs outdoor.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 67,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.67",
      "Bloodborne at Foundry shakeout: two-hand recap as the procedure. Safer devices still open. Pick?",
      [
      "Two-hand recap as PtD.",
      "Safer devices/sharps containers; two-hand recap is not the design.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Bio hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 68,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.68",
      "Written silica plan skipped at Cold-storage dock because 'we have SDS' (36 pages). Error?",
      [
      "SDS is the exposure plan.",
      "Exposure plans are written programs the standard triggers.",
      "FIN.",
      "TIME fatality clock.",
      ],
      1,
      "Plan ≠ SDS.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 69,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.69",
      "LI 1.4 at Paint kitchen mezzanine and a lift table still purchasable. Pick?",
      [
      "Belt.",
      "Install the table if still open; LI is a flag.",
      "51 lb rule of thumb.",
      "Insurance.",
      ],
      1,
      "Ergo design.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 70,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.70",
      "Hood 48 ft from a point source at Substation yard; 'dilution will capture.' Best?",
      [
      "Dilution is capture.",
      "Move the hood to the source; capture is local.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Capture ≠ dilution.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 71,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.71",
      "Auditor cites a TLV miss at Grain silo catwalk as OSHA noncompliance while under the PEL. Error?",
      [
      "TLV is OSHA.",
      "TLV miss can be a program finding; citation basis is the PEL unless incorporated.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "Legal vs advisory.",
      "PELTLV",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 72,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.72",
      "Asymmetry ignored on a 90° twist lift at Hospital loading dock. RWL too high. Error?",
      [
      "AM always 1.",
      "Include AM when the stem gives a twist.",
      "UNIT 7.48.",
      "PELTLV.",
      ],
      1,
      "All six multipliers.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 81,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.81",
      "CO 90 ppm at Battery formation room called 90 mg/m³. MW 28, 25 °C. Error?",
      [
      "ppm always equals mg/m³.",
      "Need (ppm×MW)/24.45; 1:1 is UNIT.",
      "FORM TRIR.",
      "TIME.",
      ],
      1,
      "Not 1:1.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 83,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.83",
      "SEG ignored at Sawmill green chain; one favorite operator sampled. Last sentence: group exposure. Risk?",
      [
      "Favorite is always worst-case.",
      "Strategy should represent the group named.",
      "PELTLV only.",
      "FIN.",
      ],
      1,
      "Representativeness.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 84,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.84",
      "Noise at Compressor shelter: cartoon poster only; press engineering still open. Pick?",
      [
      "Cartoon as engineering.",
      "Engineer the noise if still open.",
      "DART.",
      "ROI only.",
      ],
      1,
      "Noise hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 61,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.61",
      "BEI exceeded at Railcar unloading rack; air TWA 40% of PEL. Best read?",
      [
      "Air PEL automatically exceeded.",
      "Other routes/overtime possible; BEI is not the air PEL.",
      "Ignore BEI forever.",
      "Convert BEI with 24.45.",
      ],
      1,
      "Biomarker vs air limit.",
      "PELTLV",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 62,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.62",
      "Additive solvents at Plating line 2: 0.6 + 0.55 of PEL, stem says additive. Status?",
      [
      "Each under so mixture under.",
      "Em=1.15 over unity.",
      "Use TLV of the larger only.",
      "Convert to TRIR.",
      ],
      1,
      "Unity rule.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 63,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.63",
      "Fibers 0.2 f/cc at Roof chiller deck 'converted' to ppm with MW 60. Error?",
      [
      "OK.",
      "f/cc does not go through 24.45.",
      "Q=VA.",
      "FIN.",
      ],
      1,
      "Fibers stay fibers.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 64,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.64",
      "OSHA 95 dBA at Mud-logging shack allowed time vs a candidate's NIOSH 3 dB answer of ~1 h. OSHA T?",
      [
      "1 h.",
      "4 h on OSHA 5 dB / 90.",
      "8 h.",
      "15 min.",
      ],
      1,
      "OSHA 95 → 4 h.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 65,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.65",
      "Q at Die-change bay is correct; last sentence still allows a low-emission substitute. Pick?",
      [
      "Ship the Q as the winner.",
      "Substitution still open beats a perfect dilution number.",
      "Bigger fan only.",
      "Cite TLV.",
      ],
      1,
      "Math then hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 66,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.66",
      "IH at Aqueous washer cell skipped anticipation; respirators after the first illness. AREC. Best?",
      [
      "Control-first is AREC.",
      "Anticipate/recognize/evaluate then control; respirators last if higher controls were open.",
      "TRIR first.",
      "FTA first.",
      ],
      1,
      "AREC order.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 67,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.67",
      "One grab at lunch used as the 8-hour TWA at Flare knockout pad for a varying 30-step task. Error?",
      [
      "Grab is TWA.",
      "Sampling strategy must represent the TWA asked.",
      "PELTLV only.",
      "FIN.",
      ],
      1,
      "Strategy vs convenience.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 68,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.68",
      "Silica at Pharmacy compounding hood: wet method still open; team issues N95 only. Pick?",
      [
      "N95 as PtD.",
      "Wet method/LEV/Table-1 equivalent before respirator-only.",
      "DART.",
      "ROI.",
      ],
      1,
      "Silica hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 69,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.69",
      "OSHA noise stem at Concrete batch tower; candidate uses NIOSH 3 dB times at 45 dBA. Error?",
      [
      "Always NIOSH.",
      "Matched 90/5 vs 85/3 pairs.",
      "PELTLV only.",
      "FIN.",
      ],
      1,
      "Do not mix exchange rates.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 70,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.70",
      "Point source 48 mR/h at 2 m at Fiber layup room. Intensity at 4 m?",
      [
      "Half.",
      "Quarter: inverse square.",
      "Double.",
      "Zero.",
      ],
      1,
      "I2 = I1 (d1/d2)².",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 71,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.71",
      "Indoor heat at Quench pit. Candidate adds 0.1 Tdb solar term to WBGT. Error?",
      [
      "Always outdoor formula.",
      "Indoor/no sun is 0.7 nwb + 0.3 g.",
      "UNIT.",
      "PELTLV.",
      ],
      1,
      "Match indoor vs outdoor.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 72,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.72",
      "Bloodborne at Lab solvent crib: two-hand recap as the procedure. Safer devices still open. Pick?",
      [
      "Two-hand recap as PtD.",
      "Safer devices/sharps containers; two-hand recap is not the design.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Bio hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 81,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.81",
      "Written silica plan skipped at Shipyard dry dock because 'we have SDS' (90 pages). Error?",
      [
      "SDS is the exposure plan.",
      "Exposure plans are written programs the standard triggers.",
      "FIN.",
      "TIME fatality clock.",
      ],
      1,
      "Plan ≠ SDS.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 83,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.83",
      "LI 1.4 at Data-center generator hall and a lift table still purchasable. Pick?",
      [
      "Belt.",
      "Install the table if still open; LI is a flag.",
      "51 lb rule of thumb.",
      "Insurance.",
      ],
      1,
      "Ergo design.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 84,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.84",
      "Hood 120 ft from a point source at Mine shop welding bay; 'dilution will capture.' Best?",
      [
      "Dilution is capture.",
      "Move the hood to the source; capture is local.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Capture ≠ dilution.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 61,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.61",
      "Auditor cites a TLV miss at North pier tank farm as OSHA noncompliance while under the PEL. Error?",
      [
      "TLV is OSHA.",
      "TLV miss can be a program finding; citation basis is the PEL unless incorporated.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "Legal vs advisory.",
      "PELTLV",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 62,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.62",
      "Asymmetry ignored on a 90° twist lift at Line 4 stamping cell. RWL too high. Error?",
      [
      "AM always 1.",
      "Include AM when the stem gives a twist.",
      "UNIT 7.48.",
      "PELTLV.",
      ],
      1,
      "All six multipliers.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 63,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.63",
      "CO 12 ppm at Building C autoclave called 12 mg/m³. MW 28, 25 °C. Error?",
      [
      "ppm always equals mg/m³.",
      "Need (ppm×MW)/24.45; 1:1 is UNIT.",
      "FORM TRIR.",
      "TIME.",
      ],
      1,
      "Not 1:1.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 64,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.64",
      "SEG ignored at Night-shift warehouse mezzanine; one favorite operator sampled. Last sentence: group exposure. Risk?",
      [
      "Favorite is always worst-case.",
      "Strategy should represent the group named.",
      "PELTLV only.",
      "FIN.",
      ],
      1,
      "Representativeness.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 65,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.65",
      "Noise at Unit 7 hydrotreater: cartoon poster only; press engineering still open. Pick?",
      [
      "Cartoon as engineering.",
      "Engineer the noise if still open.",
      "DART.",
      "ROI only.",
      ],
      1,
      "Noise hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 66,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.66",
      "BEI exceeded at Clinic sterile processing; air TWA 40% of PEL. Best read?",
      [
      "Air PEL automatically exceeded.",
      "Other routes/overtime possible; BEI is not the air PEL.",
      "Ignore BEI forever.",
      "Convert BEI with 24.45.",
      ],
      1,
      "Biomarker vs air limit.",
      "PELTLV",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 67,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.67",
      "Additive solvents at Foundry shakeout: 0.6 + 0.55 of PEL, stem says additive. Status?",
      [
      "Each under so mixture under.",
      "Em=1.15 over unity.",
      "Use TLV of the larger only.",
      "Convert to TRIR.",
      ],
      1,
      "Unity rule.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 68,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.68",
      "Fibers 0.2 f/cc at Cold-storage dock 'converted' to ppm with MW 60. Error?",
      [
      "OK.",
      "f/cc does not go through 24.45.",
      "Q=VA.",
      "FIN.",
      ],
      1,
      "Fibers stay fibers.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 69,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.69",
      "OSHA 95 dBA at Paint kitchen mezzanine allowed time vs a candidate's NIOSH 3 dB answer of ~1 h. OSHA T?",
      [
      "1 h.",
      "4 h on OSHA 5 dB / 90.",
      "8 h.",
      "15 min.",
      ],
      1,
      "OSHA 95 → 4 h.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 70,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.70",
      "Q at Substation yard is correct; last sentence still allows a low-emission substitute. Pick?",
      [
      "Ship the Q as the winner.",
      "Substitution still open beats a perfect dilution number.",
      "Bigger fan only.",
      "Cite TLV.",
      ],
      1,
      "Math then hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 71,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.71",
      "IH at Grain silo catwalk skipped anticipation; respirators after the first illness. AREC. Best?",
      [
      "Control-first is AREC.",
      "Anticipate/recognize/evaluate then control; respirators last if higher controls were open.",
      "TRIR first.",
      "FTA first.",
      ],
      1,
      "AREC order.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 72,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.72",
      "One grab at lunch used as the 8-hour TWA at Hospital loading dock for a varying 75-step task. Error?",
      [
      "Grab is TWA.",
      "Sampling strategy must represent the TWA asked.",
      "PELTLV only.",
      "FIN.",
      ],
      1,
      "Strategy vs convenience.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 81,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.81",
      "Silica at Battery formation room: wet method still open; team issues N95 only. Pick?",
      [
      "N95 as PtD.",
      "Wet method/LEV/Table-1 equivalent before respirator-only.",
      "DART.",
      "ROI.",
      ],
      1,
      "Silica hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 83,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.83",
      "OSHA noise stem at Sawmill green chain; candidate uses NIOSH 3 dB times at 95 dBA. Error?",
      [
      "Always NIOSH.",
      "Matched 90/5 vs 85/3 pairs.",
      "PELTLV only.",
      "FIN.",
      ],
      1,
      "Do not mix exchange rates.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 84,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.84",
      "Point source 120 mR/h at 2 m at Compressor shelter. Intensity at 4 m?",
      [
      "Half.",
      "Quarter: inverse square.",
      "Double.",
      "Zero.",
      ],
      1,
      "I2 = I1 (d1/d2)².",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 61,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.61",
      "Indoor heat at Railcar unloading rack. Candidate adds 0.1 Tdb solar term to WBGT. Error?",
      [
      "Always outdoor formula.",
      "Indoor/no sun is 0.7 nwb + 0.3 g.",
      "UNIT.",
      "PELTLV.",
      ],
      1,
      "Match indoor vs outdoor.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 62,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.62",
      "Bloodborne at Plating line 2: two-hand recap as the procedure. Safer devices still open. Pick?",
      [
      "Two-hand recap as PtD.",
      "Safer devices/sharps containers; two-hand recap is not the design.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Bio hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 63,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.63",
      "Written silica plan skipped at Roof chiller deck because 'we have SDS' (12 pages). Error?",
      [
      "SDS is the exposure plan.",
      "Exposure plans are written programs the standard triggers.",
      "FIN.",
      "TIME fatality clock.",
      ],
      1,
      "Plan ≠ SDS.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 64,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.64",
      "LI 1.4 at Mud-logging shack and a lift table still purchasable. Pick?",
      [
      "Belt.",
      "Install the table if still open; LI is a flag.",
      "51 lb rule of thumb.",
      "Insurance.",
      ],
      1,
      "Ergo design.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 65,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.65",
      "Hood 18 ft from a point source at Die-change bay; 'dilution will capture.' Best?",
      [
      "Dilution is capture.",
      "Move the hood to the source; capture is local.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Capture ≠ dilution.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 66,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.66",
      "Auditor cites a TLV miss at Aqueous washer cell as OSHA noncompliance while under the PEL. Error?",
      [
      "TLV is OSHA.",
      "TLV miss can be a program finding; citation basis is the PEL unless incorporated.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "Legal vs advisory.",
      "PELTLV",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 67,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.67",
      "Asymmetry ignored on a 90° twist lift at Flare knockout pad. RWL too high. Error?",
      [
      "AM always 1.",
      "Include AM when the stem gives a twist.",
      "UNIT 7.48.",
      "PELTLV.",
      ],
      1,
      "All six multipliers.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 68,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.68",
      "CO 36 ppm at Pharmacy compounding hood called 36 mg/m³. MW 28, 25 °C. Error?",
      [
      "ppm always equals mg/m³.",
      "Need (ppm×MW)/24.45; 1:1 is UNIT.",
      "FORM TRIR.",
      "TIME.",
      ],
      1,
      "Not 1:1.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 69,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.69",
      "SEG ignored at Concrete batch tower; one favorite operator sampled. Last sentence: group exposure. Risk?",
      [
      "Favorite is always worst-case.",
      "Strategy should represent the group named.",
      "PELTLV only.",
      "FIN.",
      ],
      1,
      "Representativeness.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 70,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.70",
      "Noise at Fiber layup room: cartoon poster only; press engineering still open. Pick?",
      [
      "Cartoon as engineering.",
      "Engineer the noise if still open.",
      "DART.",
      "ROI only.",
      ],
      1,
      "Noise hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 71,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.71",
      "BEI exceeded at Quench pit; air TWA 40% of PEL. Best read?",
      [
      "Air PEL automatically exceeded.",
      "Other routes/overtime possible; BEI is not the air PEL.",
      "Ignore BEI forever.",
      "Convert BEI with 24.45.",
      ],
      1,
      "Biomarker vs air limit.",
      "PELTLV",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 72,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.72",
      "Additive solvents at Lab solvent crib: 0.6 + 0.55 of PEL, stem says additive. Status?",
      [
      "Each under so mixture under.",
      "Em=1.15 over unity.",
      "Use TLV of the larger only.",
      "Convert to TRIR.",
      ],
      1,
      "Unity rule.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 81,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.81",
      "Fibers 0.2 f/cc at Shipyard dry dock 'converted' to ppm with MW 60. Error?",
      [
      "OK.",
      "f/cc does not go through 24.45.",
      "Q=VA.",
      "FIN.",
      ],
      1,
      "Fibers stay fibers.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 83,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.83",
      "OSHA 95 dBA at Data-center generator hall allowed time vs a candidate's NIOSH 3 dB answer of ~1 h. OSHA T?",
      [
      "1 h.",
      "4 h on OSHA 5 dB / 90.",
      "8 h.",
      "15 min.",
      ],
      1,
      "OSHA 95 → 4 h.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 84,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.84",
      "Q at Mine shop welding bay is correct; last sentence still allows a low-emission substitute. Pick?",
      [
      "Ship the Q as the winner.",
      "Substitution still open beats a perfect dilution number.",
      "Bigger fan only.",
      "Cite TLV.",
      ],
      1,
      "Math then hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 61,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.61",
      "IH at North pier tank farm skipped anticipation; respirators after the first illness. AREC. Best Tag 60.",
      [
      "Control-first is AREC.",
      "Anticipate/recognize/evaluate then control; respirators last if higher controls were open.",
      "TRIR first.",
      "FTA first.",
      ],
      1,
      "AREC order.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 62,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.62",
      "One grab at lunch used as the 8-hour TWA at Line 4 stamping cell for a varying 8-step task. Error Tag 61.",
      [
      "Grab is TWA.",
      "Sampling strategy must represent the TWA asked.",
      "PELTLV only.",
      "FIN.",
      ],
      1,
      "Strategy vs convenience.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 63,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.63",
      "Silica at Building C autoclave: wet method still open; team issues N95 only. Pick Tag 62.",
      [
      "N95 as PtD.",
      "Wet method/LEV/Table-1 equivalent before respirator-only.",
      "DART.",
      "ROI.",
      ],
      1,
      "Silica hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 64,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.64",
      "OSHA noise stem at Night-shift warehouse mezzanine; candidate uses NIOSH 3 dB times at 15 dBA. Error Tag 63.",
      [
      "Always NIOSH.",
      "Matched 90/5 vs 85/3 pairs.",
      "PELTLV only.",
      "FIN.",
      ],
      1,
      "Do not mix exchange rates.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 65,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.65",
      "Point source 18 mR/h at 2 m at Unit 7 hydrotreater. Intensity at 4 m Tag 64.",
      [
      "Half.",
      "Quarter: inverse square.",
      "Double.",
      "Zero.",
      ],
      1,
      "I2 = I1 (d1/d2)².",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 66,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.66",
      "Indoor heat at Clinic sterile processing. Candidate adds 0.1 Tdb solar term to WBGT. Error Tag 65.",
      [
      "Always outdoor formula.",
      "Indoor/no sun is 0.7 nwb + 0.3 g.",
      "UNIT.",
      "PELTLV.",
      ],
      1,
      "Match indoor vs outdoor.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 67,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.67",
      "Bloodborne at Foundry shakeout: two-hand recap as the procedure. Safer devices still open. Pick Tag 66.",
      [
      "Two-hand recap as PtD.",
      "Safer devices/sharps containers; two-hand recap is not the design.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Bio hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 68,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.68",
      "Written silica plan skipped at Cold-storage dock because 'we have SDS' (36 pages). Error Tag 67.",
      [
      "SDS is the exposure plan.",
      "Exposure plans are written programs the standard triggers.",
      "FIN.",
      "TIME fatality clock.",
      ],
      1,
      "Plan ≠ SDS.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 69,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.69",
      "LI 1.4 at Paint kitchen mezzanine and a lift table still purchasable. Pick Tag 68.",
      [
      "Belt.",
      "Install the table if still open; LI is a flag.",
      "51 lb rule of thumb.",
      "Insurance.",
      ],
      1,
      "Ergo design.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 70,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.70",
      "Hood 48 ft from a point source at Substation yard; 'dilution will capture.' Best Tag 69.",
      [
      "Dilution is capture.",
      "Move the hood to the source; capture is local.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Capture ≠ dilution.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 71,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.71",
      "Auditor cites a TLV miss at Grain silo catwalk as OSHA noncompliance while under the PEL. Error Tag 70.",
      [
      "TLV is OSHA.",
      "TLV miss can be a program finding; citation basis is the PEL unless incorporated.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "Legal vs advisory.",
      "PELTLV",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 72,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.72",
      "Asymmetry ignored on a 90° twist lift at Hospital loading dock. RWL too high. Error Tag 71.",
      [
      "AM always 1.",
      "Include AM when the stem gives a twist.",
      "UNIT 7.48.",
      "PELTLV.",
      ],
      1,
      "All six multipliers.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 81,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.81",
      "CO 90 ppm at Battery formation room called 90 mg/m³. MW 28, 25 °C. Error Tag 72.",
      [
      "ppm always equals mg/m³.",
      "Need (ppm×MW)/24.45; 1:1 is UNIT.",
      "FORM TRIR.",
      "TIME.",
      ],
      1,
      "Not 1:1.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 83,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.83",
      "SEG ignored at Sawmill green chain; one favorite operator sampled. Last sentence: group exposure. Risk Tag 73.",
      [
      "Favorite is always worst-case.",
      "Strategy should represent the group named.",
      "PELTLV only.",
      "FIN.",
      ],
      1,
      "Representativeness.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 84,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.84",
      "Noise at Compressor shelter: cartoon poster only; press engineering still open. Pick Tag 74.",
      [
      "Cartoon as engineering.",
      "Engineer the noise if still open.",
      "DART.",
      "ROI only.",
      ],
      1,
      "Noise hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 61,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.61",
      "BEI exceeded at Railcar unloading rack; air TWA 40% of PEL. Best read Tag 75.",
      [
      "Air PEL automatically exceeded.",
      "Other routes/overtime possible; BEI is not the air PEL.",
      "Ignore BEI forever.",
      "Convert BEI with 24.45.",
      ],
      1,
      "Biomarker vs air limit.",
      "PELTLV",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 62,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.62",
      "Additive solvents at Plating line 2: 0.6 + 0.55 of PEL, stem says additive. Status Tag 76.",
      [
      "Each under so mixture under.",
      "Em=1.15 over unity.",
      "Use TLV of the larger only.",
      "Convert to TRIR.",
      ],
      1,
      "Unity rule.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 63,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.63",
      "Fibers 0.2 f/cc at Roof chiller deck 'converted' to ppm with MW 60. Error Tag 77.",
      [
      "OK.",
      "f/cc does not go through 24.45.",
      "Q=VA.",
      "FIN.",
      ],
      1,
      "Fibers stay fibers.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 64,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.64",
      "OSHA 95 dBA at Mud-logging shack allowed time vs a candidate's NIOSH 3 dB answer of ~1 h. OSHA T Tag 78.",
      [
      "1 h.",
      "4 h on OSHA 5 dB / 90.",
      "8 h.",
      "15 min.",
      ],
      1,
      "OSHA 95 → 4 h.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 65,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.65",
      "Q at Die-change bay is correct; last sentence still allows a low-emission substitute. Pick Tag 79.",
      [
      "Ship the Q as the winner.",
      "Substitution still open beats a perfect dilution number.",
      "Bigger fan only.",
      "Cite TLV.",
      ],
      1,
      "Math then hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 66,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.66",
      "IH at Aqueous washer cell skipped anticipation; respirators after the first illness. AREC. Best Tag 80.",
      [
      "Control-first is AREC.",
      "Anticipate/recognize/evaluate then control; respirators last if higher controls were open.",
      "TRIR first.",
      "FTA first.",
      ],
      1,
      "AREC order.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 67,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.67",
      "One grab at lunch used as the 8-hour TWA at Flare knockout pad for a varying 30-step task. Error Tag 81.",
      [
      "Grab is TWA.",
      "Sampling strategy must represent the TWA asked.",
      "PELTLV only.",
      "FIN.",
      ],
      1,
      "Strategy vs convenience.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 68,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.68",
      "Silica at Pharmacy compounding hood: wet method still open; team issues N95 only. Pick Tag 82.",
      [
      "N95 as PtD.",
      "Wet method/LEV/Table-1 equivalent before respirator-only.",
      "DART.",
      "ROI.",
      ],
      1,
      "Silica hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 69,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.69",
      "OSHA noise stem at Concrete batch tower; candidate uses NIOSH 3 dB times at 45 dBA. Error Tag 83.",
      [
      "Always NIOSH.",
      "Matched 90/5 vs 85/3 pairs.",
      "PELTLV only.",
      "FIN.",
      ],
      1,
      "Do not mix exchange rates.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 70,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.70",
      "Point source 48 mR/h at 2 m at Fiber layup room. Intensity at 4 m Tag 84.",
      [
      "Half.",
      "Quarter: inverse square.",
      "Double.",
      "Zero.",
      ],
      1,
      "I2 = I1 (d1/d2)².",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 71,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.71",
      "Indoor heat at Quench pit. Candidate adds 0.1 Tdb solar term to WBGT. Error Tag 85.",
      [
      "Always outdoor formula.",
      "Indoor/no sun is 0.7 nwb + 0.3 g.",
      "UNIT.",
      "PELTLV.",
      ],
      1,
      "Match indoor vs outdoor.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 72,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.72",
      "Bloodborne at Lab solvent crib: two-hand recap as the procedure. Safer devices still open. Pick Tag 86.",
      [
      "Two-hand recap as PtD.",
      "Safer devices/sharps containers; two-hand recap is not the design.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Bio hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 81,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.81",
      "Written silica plan skipped at Shipyard dry dock because 'we have SDS' (90 pages). Error Tag 87.",
      [
      "SDS is the exposure plan.",
      "Exposure plans are written programs the standard triggers.",
      "FIN.",
      "TIME fatality clock.",
      ],
      1,
      "Plan ≠ SDS.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 83,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.83",
      "LI 1.4 at Data-center generator hall and a lift table still purchasable. Pick Tag 88.",
      [
      "Belt.",
      "Install the table if still open; LI is a flag.",
      "51 lb rule of thumb.",
      "Insurance.",
      ],
      1,
      "Ergo design.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 84,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.84",
      "Hood 120 ft from a point source at Mine shop welding bay; 'dilution will capture.' Best Tag 89.",
      [
      "Dilution is capture.",
      "Move the hood to the source; capture is local.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Capture ≠ dilution.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 61,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.61",
      "Auditor cites a TLV miss at North pier tank farm as OSHA noncompliance while under the PEL. Error Tag 90.",
      [
      "TLV is OSHA.",
      "TLV miss can be a program finding; citation basis is the PEL unless incorporated.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "Legal vs advisory.",
      "PELTLV",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 62,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.62",
      "Asymmetry ignored on a 90° twist lift at Line 4 stamping cell. RWL too high. Error Tag 91.",
      [
      "AM always 1.",
      "Include AM when the stem gives a twist.",
      "UNIT 7.48.",
      "PELTLV.",
      ],
      1,
      "All six multipliers.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 63,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.63",
      "CO 12 ppm at Building C autoclave called 12 mg/m³. MW 28, 25 °C. Error Tag 92.",
      [
      "ppm always equals mg/m³.",
      "Need (ppm×MW)/24.45; 1:1 is UNIT.",
      "FORM TRIR.",
      "TIME.",
      ],
      1,
      "Not 1:1.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 64,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.64",
      "SEG ignored at Night-shift warehouse mezzanine; one favorite operator sampled. Last sentence: group exposure. Risk Tag 93.",
      [
      "Favorite is always worst-case.",
      "Strategy should represent the group named.",
      "PELTLV only.",
      "FIN.",
      ],
      1,
      "Representativeness.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 65,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.65",
      "Noise at Unit 7 hydrotreater: cartoon poster only; press engineering still open. Pick Tag 94.",
      [
      "Cartoon as engineering.",
      "Engineer the noise if still open.",
      "DART.",
      "ROI only.",
      ],
      1,
      "Noise hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 66,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.66",
      "BEI exceeded at Clinic sterile processing; air TWA 40% of PEL. Best read Tag 95.",
      [
      "Air PEL automatically exceeded.",
      "Other routes/overtime possible; BEI is not the air PEL.",
      "Ignore BEI forever.",
      "Convert BEI with 24.45.",
      ],
      1,
      "Biomarker vs air limit.",
      "PELTLV",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 67,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.67",
      "Additive solvents at Foundry shakeout: 0.6 + 0.55 of PEL, stem says additive. Status Tag 96.",
      [
      "Each under so mixture under.",
      "Em=1.15 over unity.",
      "Use TLV of the larger only.",
      "Convert to TRIR.",
      ],
      1,
      "Unity rule.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 68,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.68",
      "Fibers 0.2 f/cc at Cold-storage dock 'converted' to ppm with MW 60. Error Tag 97.",
      [
      "OK.",
      "f/cc does not go through 24.45.",
      "Q=VA.",
      "FIN.",
      ],
      1,
      "Fibers stay fibers.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 69,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.69",
      "OSHA 95 dBA at Paint kitchen mezzanine allowed time vs a candidate's NIOSH 3 dB answer of ~1 h. OSHA T Tag 98.",
      [
      "1 h.",
      "4 h on OSHA 5 dB / 90.",
      "8 h.",
      "15 min.",
      ],
      1,
      "OSHA 95 → 4 h.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 70,
    kind: "challenge",
    topic: "d6",
    ...exam(
      "CHAL.D6.70",
      "Q at Substation yard is correct; last sentence still allows a low-emission substitute. Pick Tag 99.",
      [
      "Ship the Q as the winner.",
      "Substitution still open beats a perfect dilution number.",
      "Bigger fan only.",
      "Cite TLV.",
      ],
      1,
      "Math then hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  }
];
