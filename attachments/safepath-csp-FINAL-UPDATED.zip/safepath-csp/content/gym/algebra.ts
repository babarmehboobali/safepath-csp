import { exam } from "../classes/types";
import type { GymQuestion } from "./types";

export const ALGEBRA_QUESTIONS: GymQuestion[] = [
  {
    classId: 72,
    kind: "math",
    topic: "algebra",
    ...exam(
      "MATH.algebra",
      "Order of operations. Evaluate 2 + 3 × 4. Closest listed value?",
      [
        "20 — add 2 and 3 first, then multiply by 4.",
        "14 — multiply 3 × 4 = 12, then add 2.",
        "24 — multiply all three numbers.",
        "9 — add all three numbers.",
      ],
      1,
      "Multiply and divide before add and subtract unless parentheses say otherwise. 3 × 4 = 12; 2 + 12 = 14.",
      "FORM",
      "Foundation",
      [
        "Left-to-right adding first ignores PEMDAS. 5 × 4 = 20 is the classic trap.",
        "Key: multiplication binds tighter than addition, so 2 + 12 = 14.",
        "There is no 'multiply everything' rule here. 2 × 3 × 4 would be 24.",
        "Adding 2 + 3 + 4 = 9 drops the operator that was actually ×.",
      ],
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 72,
    kind: "math",
    topic: "algebra",
    ...exam(
      "MATH.algebra",
      "Parentheses change the order. What is (8 + 2) × 3 versus 8 + 2 × 3?",
      [
        "Both equal 30.",
        "Both equal 14.",
        "(8 + 2) × 3 = 30 and 8 + 2 × 3 = 14.",
        "(8 + 2) × 3 = 13 and 8 + 2 × 3 = 30.",
      ],
      2,
      "Parentheses first: 10 × 3 = 30. Without them, 2 × 3 = 6 then 8 + 6 = 14.",
      "FORM",
      "Foundation",
      [
        "Only the parenthesized form is 30. Bare 8 + 2 × 3 is not.",
        "Only the bare form is 14. Parentheses force the add first.",
        "Key: parentheses first, then multiply. Two different values.",
        "Swaps the two results. (8+2)×3 cannot be 13.",
      ],
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 72,
    kind: "math",
    topic: "algebra",
    ...exam(
      "MATH.algebra",
      "Scientific notation. 3.2 × 10^4 equals which listed value?",
      [
        "12.8 (3.2 × 4).",
        "320 (move the decimal two places).",
        "32,000.",
        "0.00032.",
      ],
      2,
      "10^4 = 10,000. 3.2 × 10,000 = 32,000. The exponent is a power of ten, not a multiplier of 4.",
      "UNIT",
      "Foundation",
      [
        "Treating 10^4 as the integer 4. Exponent 4 means four tens multiplied, not ×4.",
        "Two places is 10^2. The stem is 10^4 — four places.",
        "Key: 3.2 with the decimal moved four places right is 32,000.",
        "Negative exponent 10^-4 would be 0.00032. The stem is positive.",
      ],
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 72,
    kind: "math",
    topic: "algebra",
    ...exam(
      "MATH.algebra",
      "A lab result is 4.5 × 10^-3 mg/m³. Which is the same number in decimal form?",
      [
        "4,500 mg/m³.",
        "0.0045 mg/m³.",
        "0.45 mg/m³.",
        "45 mg/m³.",
      ],
      1,
      "10^-3 = 0.001. 4.5 × 0.001 = 0.0045. Moving the decimal three places left.",
      "UNIT",
      "Foundation",
      [
        "Positive 10^3 would be 4,500. The exponent is negative.",
        "Key: three places left from 4.5 is 0.0045.",
        "That is one place left (× 10^-1), not three.",
        "That is 4.5 × 10^1. Sign and magnitude of the exponent both matter.",
      ],
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 81,
    kind: "math",
    topic: "algebra",
    ...exam(
      "MATH.algebra",
      "Q = V × A. A duct flows 1,600 cfm through 0.80 ft². Velocity V?",
      [
        "1,280 fpm (multiply 1,600 × 0.80).",
        "2,000 fpm (V = Q / A = 1,600 / 0.80).",
        "0.0005 fpm (A / Q).",
        "1,600 fpm (velocity equals Q when A is 'close to 1').",
      ],
      1,
      "Rearrange: V = Q / A. 1,600 ÷ 0.80 = 2,000 fpm. Multiplying Q by A is the inverse operation.",
      "FORM",
      "Foundation",
      [
        "Multiplying instead of dividing. That computes Q × A, not V.",
        "Key: divide flow by area. 1600 / 0.8 = 2000 fpm.",
        "A / Q is the reciprocal of velocity, not velocity.",
        "A is 0.80, not 1. Do not skip the division.",
      ],
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 81,
    kind: "math",
    topic: "algebra",
    ...exam(
      "MATH.algebra",
      "Q = V × A. Velocity is 2,500 fpm and flow is 1,250 cfm. Area A?",
      [
        "3,125,000 ft² (multiply V × Q).",
        "2.0 ft² (A = Q / V is inverted here as V / Q = 2).",
        "0.50 ft² (A = Q / V = 1,250 / 2,500).",
        "1,250 ft² (area equals the cfm number).",
      ],
      2,
      "A = Q / V = 1,250 / 2,500 = 0.50 ft². Keep cfm and fpm so area lands in ft².",
      "FORM",
      "Foundation",
      [
        "V × Q is not a rearrangement of Q = VA.",
        "V / Q = 2, which is 1/A, not A.",
        "Key: A = Q/V = 0.50 ft².",
        "Dropping V treats cfm as if it were already an area.",
      ],
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 81,
    kind: "math",
    topic: "algebra",
    ...exam(
      "MATH.algebra",
      "Round duct, 12-inch diameter, 2,000 fpm. Area uses radius in feet. Which setup is correct before Q = VA?",
      [
        "A = π × 12² ft² (diameter in inches treated as feet).",
        "A = π × 1.0² ft² (radius = diameter).",
        "r = 12/12/2 = 0.50 ft; A = π(0.50)² ≈ 0.785 ft².",
        "A = 12 × 2,000 ft².",
      ],
      2,
      "Inches to feet (÷12), then diameter to radius (÷2). r = 0.50 ft. A = πr² ≈ 0.785 ft². Then Q = 2,000 × 0.785.",
      "UNIT",
      "Exam",
      [
        "12 inches is 1 foot diameter, not 12 feet. π×144 is the diameter-as-feet trap.",
        "Radius is half the diameter. Using 1.0 ft as radius squares to 1.0 instead of 0.25.",
        "Key: convert, then half, then square. 0.785 ft² is the area.",
        "12 × 2000 mixes a length with a velocity and is not an area.",
      ],
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 72,
    kind: "math",
    topic: "algebra",
    ...exam(
      "MATH.algebra",
      "You are the CSP reviewing a live decision at a hospital utility plant shutdown. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Combined. 6 + 2 × 10^3. Closest listed value.",
      [
        "8,000 (add 6 + 2 first, then × 1000).",
        "2,006 (2 × 1000 = 2000, then add 6).",
        "60,000 (6 × 2 × 10^3).",
        "6.002 × 10^3.",
      ],
      1,
      "Exponent first: 10^3 = 1,000. Then multiply: 2 × 1,000 = 2,000. Then add 6 → 2,006.",
      "FORM",
      "Exam",
      [
        "Adding before the power/multiply pair is the PEMDAS miss that yields 8 × 1000.",
        "Key: powers, then multiply, then add. 2000 + 6 = 2006.",
        "There is no 6 × 2 unless the stem grouped them.",
        "That would be 6.002 × 10^3 = 6,002, not 2,006.",
      ],
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
];
