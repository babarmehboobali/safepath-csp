import { exam } from "../classes/types";
import type { GymQuestion } from "./types";

export const CHALLENGE_D4: GymQuestion[] = [
  {
    classId: 47,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.47",
      "ERP at North pier tank farm has a glossy cover, no roles, no comms, no maps. After a 6-minute release, nobody knows who calls whom. Error?",
      [
      "Cover is contents.",
      "ERP contents: roles, comms, maps, shutdown, medical, accountability.",
      "TLV.",
      "TRIR.",
      ],
      1,
      "Contents, not cover.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 48,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.48",
      "ICS at Line 4 stamping cell: 8 people titled Incident Commander 'for balance.' Error?",
      [
      "More IC is better.",
      "One IC; sections under IC.",
      "FIN.",
      "PELTLV.",
      ],
      1,
      "Unity of command.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 49,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.49",
      "Flood at Building C autoclave stops invoicing for 12 weeks. Team says the fire ERP is the BCP. Error?",
      [
      "ERP is BCP.",
      "BCP keeps critical functions running; ERP is the emergency response.",
      "UNIT.",
      "HIER.",
      ],
      1,
      "BCP vs ERP.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 50,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.50",
      "Fire prevention at Night-shift warehouse mezzanine: fuel/ignition still open. Option: 15 more extinguishers only. Pick?",
      [
      "Extinguishers as prevention.",
      "Prevent ignition/fuel first; extinguishers are protection/reduction.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Prevention vs protection.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 51,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.51",
      "Sprinkler valve at Unit 7 hydrotreater shut for 18 months, no impairment program. Best?",
      [
      "Assume it works.",
      "Impairment control, restore protection, compensatory measures.",
      "A new poster.",
      "Gloves.",
      ],
      1,
      "Protection must be on.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 52,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.52",
      "Unknown drum leaking in a tunnel from Clinic sterile processing. Team will 'google it' with no ERG/ID. Best?",
      [
      "Google without ID.",
      "Identify and use the ERG/plan.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "ID then guide.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 53,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.53",
      "Workplace violence at Foundry shakeout: poster only. Access control and a response plan still open. Pick?",
      [
      "Poster as the design.",
      "Access control, procedures, training, aftercare.",
      "TLV.",
      "FTA RPN.",
      ],
      1,
      "System vs poster.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 54,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.54",
      "Drill never run at Cold-storage dock; binder on a shelf for 36 years. Last sentence: exercise the plan. Pick?",
      [
      "The binder is a drill.",
      "Run the drill, evaluate, fix the plan.",
      "Insurance.",
      "PEL.",
      ],
      1,
      "A binder is not a drill.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 88,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.88",
      "OT ransomware can freeze ESD at Paint kitchen mezzanine. ERP has no cyber initiator. Last sentence leaves adding it open. Pick?",
      [
      "Cyber is never an emergency.",
      "Put OT/IT failure in the ERP if the stem leaves it open.",
      "Buy gloves.",
      "TRIR.",
      ],
      1,
      "Cyber as initiator.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 47,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.47",
      "ICS Finance/Admin asked to run rescue at Substation yard. Error?",
      [
      "Any section can be rescue.",
      "Operations runs tactical work.",
      "PELTLV.",
      "FORM.",
      ],
      1,
      "ICS sections.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 48,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.48",
      "Accountability list missing from ERP at Grain silo catwalk. After a drill, 60 people unaccounted. Best?",
      [
      "Skip accountability.",
      "Add accountability and drill it.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Who is still inside.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 49,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.49",
      "Drill success at Hospital loading dock defined as 'we finished pizza.' No objectives. Best?",
      [
      "Pizza is the objective.",
      "Set objectives, inject, evaluate against them.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Evaluate the drill.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 50,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.50",
      "Fire watch skipped at Battery formation room after hot work because the welder has 90 years. Combustibles remain. Pick?",
      [
      "Years replace the watch.",
      "Fire watch/permit as required; tenure is not a watch.",
      "A cone.",
      "A TLV.",
      ],
      1,
      "Watch vs tenure.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 51,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.51",
      "Hazmat security plan at Sawmill green chain is a sticky note. Last sentence: security as named for the listed material. Best?",
      [
      "Sticky note is a security plan.",
      "Written security controls proportionate to the material.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Security is a system.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 52,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.52",
      "BCP at Compressor shelter recovers IT in 120 hours but never names a safety-critical OT function. Last sentence: critical functions. Best?",
      [
      "Email is the only critical function.",
      "Include the safety-critical functions the stem named.",
      "A hard hat.",
      "A BEI.",
      ],
      1,
      "Name the critical work.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 53,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.53",
      "Assembly occupancy at Railcar unloading rack: more marshals vs unlocking a chained exit. Last sentence: egress still chained. Pick?",
      [
      "Marshals as the design.",
      "Unchain/restore egress; marshals do not replace an exit.",
      "A poster.",
      "Insurance.",
      ],
      1,
      "Life safety hardware first.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 54,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.54",
      "Incident command radio at Plating line 2 uses slang only the day shift knows. Night mutual aid arrives. Best?",
      [
      "Slang is ICS.",
      "Common terminology / plain language as ICS expects.",
      "TRIR.",
      "ROI.",
      ],
      1,
      "Common terms.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 88,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.88",
      "Hospitalization from an incident at Roof chiller deck at 10:00. OSHA notified 48 hours later. Clock named is the 24-hour hospitalization rule. Error?",
      [
      "48 hours is always OK.",
      "Certain hospitalizations: 24 hours. Fatalities: 8 hours.",
      "PELTLV.",
      "FORM.",
      ],
      1,
      "24-hour hospitalization clock.",
      "TIME",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 47,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.47",
      "ERP shutdown steps at Mud-logging shack contradict the process SOP on valve 15. Last sentence: which wins in an emergency. Best?",
      [
      "Ignore both.",
      "Reconcile via MOC so emergency and process documents agree; do not ad-lib.",
      "Buy PPE.",
      "A DART goal.",
      ],
      1,
      "Documents must not fight.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 48,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.48",
      "Protection at Die-change bay: fire pump records blank 18 months. Option: new sticker on an extinguisher. Pick?",
      [
      "Sticker proves the pump.",
      "Test/impairment program; blank records mean unknown protection.",
      "ROI.",
      "TLV.",
      ],
      1,
      "Proof of protection.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 49,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.49",
      "ERP at Aqueous washer cell has a glossy cover, no roles, no comms, no maps. After a 24-minute release, nobody knows who calls whom. Error?",
      [
      "Cover is contents.",
      "ERP contents: roles, comms, maps, shutdown, medical, accountability.",
      "TLV.",
      "TRIR.",
      ],
      1,
      "Contents, not cover.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 50,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.50",
      "ICS at Flare knockout pad: 30 people titled Incident Commander 'for balance.' Error?",
      [
      "More IC is better.",
      "One IC; sections under IC.",
      "FIN.",
      "PELTLV.",
      ],
      1,
      "Unity of command.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 51,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.51",
      "Flood at Pharmacy compounding hood stops invoicing for 36 weeks. Team says the fire ERP is the BCP. Error?",
      [
      "ERP is BCP.",
      "BCP keeps critical functions running; ERP is the emergency response.",
      "UNIT.",
      "HIER.",
      ],
      1,
      "BCP vs ERP.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 52,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.52",
      "Fire prevention at Concrete batch tower: fuel/ignition still open. Option: 45 more extinguishers only. Pick?",
      [
      "Extinguishers as prevention.",
      "Prevent ignition/fuel first; extinguishers are protection/reduction.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Prevention vs protection.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 53,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.53",
      "Sprinkler valve at Fiber layup room shut for 48 months, no impairment program. Best?",
      [
      "Assume it works.",
      "Impairment control, restore protection, compensatory measures.",
      "A new poster.",
      "Gloves.",
      ],
      1,
      "Protection must be on.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 54,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.54",
      "Unknown drum leaking in a tunnel from Quench pit. Team will 'google it' with no ERG/ID. Best?",
      [
      "Google without ID.",
      "Identify and use the ERG/plan.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "ID then guide.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 88,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.88",
      "Workplace violence at Lab solvent crib: poster only. Access control and a response plan still open. Pick?",
      [
      "Poster as the design.",
      "Access control, procedures, training, aftercare.",
      "TLV.",
      "FTA RPN.",
      ],
      1,
      "System vs poster.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 47,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.47",
      "Drill never run at Shipyard dry dock; binder on a shelf for 90 years. Last sentence: exercise the plan. Pick?",
      [
      "The binder is a drill.",
      "Run the drill, evaluate, fix the plan.",
      "Insurance.",
      "PEL.",
      ],
      1,
      "A binder is not a drill.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 48,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.48",
      "OT ransomware can freeze ESD at Data-center generator hall. ERP has no cyber initiator. Last sentence leaves adding it open. Pick?",
      [
      "Cyber is never an emergency.",
      "Put OT/IT failure in the ERP if the stem leaves it open.",
      "Buy gloves.",
      "TRIR.",
      ],
      1,
      "Cyber as initiator.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 49,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.49",
      "ICS Finance/Admin asked to run rescue at Mine shop welding bay. Error?",
      [
      "Any section can be rescue.",
      "Operations runs tactical work.",
      "PELTLV.",
      "FORM.",
      ],
      1,
      "ICS sections.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 50,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.50",
      "Accountability list missing from ERP at North pier tank farm. After a drill, 6 people unaccounted. Best?",
      [
      "Skip accountability.",
      "Add accountability and drill it.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Who is still inside.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 51,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.51",
      "Drill success at Line 4 stamping cell defined as 'we finished pizza.' No objectives. Best?",
      [
      "Pizza is the objective.",
      "Set objectives, inject, evaluate against them.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Evaluate the drill.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 52,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.52",
      "Fire watch skipped at Building C autoclave after hot work because the welder has 12 years. Combustibles remain. Pick?",
      [
      "Years replace the watch.",
      "Fire watch/permit as required; tenure is not a watch.",
      "A cone.",
      "A TLV.",
      ],
      1,
      "Watch vs tenure.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 53,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.53",
      "Hazmat security plan at Night-shift warehouse mezzanine is a sticky note. Last sentence: security as named for the listed material. Best?",
      [
      "Sticky note is a security plan.",
      "Written security controls proportionate to the material.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Security is a system.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 54,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.54",
      "BCP at Unit 7 hydrotreater recovers IT in 18 hours but never names a safety-critical OT function. Last sentence: critical functions. Best?",
      [
      "Email is the only critical function.",
      "Include the safety-critical functions the stem named.",
      "A hard hat.",
      "A BEI.",
      ],
      1,
      "Name the critical work.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 88,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.88",
      "Assembly occupancy at Clinic sterile processing: more marshals vs unlocking a chained exit. Last sentence: egress still chained. Pick?",
      [
      "Marshals as the design.",
      "Unchain/restore egress; marshals do not replace an exit.",
      "A poster.",
      "Insurance.",
      ],
      1,
      "Life safety hardware first.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 47,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.47",
      "Incident command radio at Foundry shakeout uses slang only the day shift knows. Night mutual aid arrives. Best?",
      [
      "Slang is ICS.",
      "Common terminology / plain language as ICS expects.",
      "TRIR.",
      "ROI.",
      ],
      1,
      "Common terms.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 48,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.48",
      "Hospitalization from an incident at Cold-storage dock at 10:00. OSHA notified 48 hours later. Clock named is the 24-hour hospitalization rule. Error?",
      [
      "48 hours is always OK.",
      "Certain hospitalizations: 24 hours. Fatalities: 8 hours.",
      "PELTLV.",
      "FORM.",
      ],
      1,
      "24-hour hospitalization clock.",
      "TIME",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 49,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.49",
      "ERP shutdown steps at Paint kitchen mezzanine contradict the process SOP on valve 45. Last sentence: which wins in an emergency. Best?",
      [
      "Ignore both.",
      "Reconcile via MOC so emergency and process documents agree; do not ad-lib.",
      "Buy PPE.",
      "A DART goal.",
      ],
      1,
      "Documents must not fight.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 50,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.50",
      "Protection at Substation yard: fire pump records blank 48 months. Option: new sticker on an extinguisher. Pick?",
      [
      "Sticker proves the pump.",
      "Test/impairment program; blank records mean unknown protection.",
      "ROI.",
      "TLV.",
      ],
      1,
      "Proof of protection.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 51,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.51",
      "ERP at Grain silo catwalk has a glossy cover, no roles, no comms, no maps. After a 60-minute release, nobody knows who calls whom. Error?",
      [
      "Cover is contents.",
      "ERP contents: roles, comms, maps, shutdown, medical, accountability.",
      "TLV.",
      "TRIR.",
      ],
      1,
      "Contents, not cover.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 52,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.52",
      "ICS at Hospital loading dock: 75 people titled Incident Commander 'for balance.' Error?",
      [
      "More IC is better.",
      "One IC; sections under IC.",
      "FIN.",
      "PELTLV.",
      ],
      1,
      "Unity of command.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 53,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.53",
      "Flood at Battery formation room stops invoicing for 90 weeks. Team says the fire ERP is the BCP. Error?",
      [
      "ERP is BCP.",
      "BCP keeps critical functions running; ERP is the emergency response.",
      "UNIT.",
      "HIER.",
      ],
      1,
      "BCP vs ERP.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 54,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.54",
      "Fire prevention at Sawmill green chain: fuel/ignition still open. Option: 95 more extinguishers only. Pick?",
      [
      "Extinguishers as prevention.",
      "Prevent ignition/fuel first; extinguishers are protection/reduction.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Prevention vs protection.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 88,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.88",
      "Sprinkler valve at Compressor shelter shut for 120 months, no impairment program. Best?",
      [
      "Assume it works.",
      "Impairment control, restore protection, compensatory measures.",
      "A new poster.",
      "Gloves.",
      ],
      1,
      "Protection must be on.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 47,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.47",
      "Unknown drum leaking in a tunnel from Railcar unloading rack. Team will 'google it' with no ERG/ID. Best?",
      [
      "Google without ID.",
      "Identify and use the ERG/plan.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "ID then guide.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 48,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.48",
      "Workplace violence at Plating line 2: poster only. Access control and a response plan still open. Pick?",
      [
      "Poster as the design.",
      "Access control, procedures, training, aftercare.",
      "TLV.",
      "FTA RPN.",
      ],
      1,
      "System vs poster.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 49,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.49",
      "Drill never run at Roof chiller deck; binder on a shelf for 12 years. Last sentence: exercise the plan. Pick?",
      [
      "The binder is a drill.",
      "Run the drill, evaluate, fix the plan.",
      "Insurance.",
      "PEL.",
      ],
      1,
      "A binder is not a drill.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 50,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.50",
      "OT ransomware can freeze ESD at Mud-logging shack. ERP has no cyber initiator. Last sentence leaves adding it open. Pick?",
      [
      "Cyber is never an emergency.",
      "Put OT/IT failure in the ERP if the stem leaves it open.",
      "Buy gloves.",
      "TRIR.",
      ],
      1,
      "Cyber as initiator.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 51,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.51",
      "ICS Finance/Admin asked to run rescue at Die-change bay. Error?",
      [
      "Any section can be rescue.",
      "Operations runs tactical work.",
      "PELTLV.",
      "FORM.",
      ],
      1,
      "ICS sections.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 52,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.52",
      "Accountability list missing from ERP at Aqueous washer cell. After a drill, 24 people unaccounted. Best?",
      [
      "Skip accountability.",
      "Add accountability and drill it.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Who is still inside.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 53,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.53",
      "Drill success at Flare knockout pad defined as 'we finished pizza.' No objectives. Best?",
      [
      "Pizza is the objective.",
      "Set objectives, inject, evaluate against them.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Evaluate the drill.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 54,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.54",
      "Fire watch skipped at Pharmacy compounding hood after hot work because the welder has 36 years. Combustibles remain. Pick?",
      [
      "Years replace the watch.",
      "Fire watch/permit as required; tenure is not a watch.",
      "A cone.",
      "A TLV.",
      ],
      1,
      "Watch vs tenure.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 88,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.88",
      "Hazmat security plan at Concrete batch tower is a sticky note. Last sentence: security as named for the listed material. Best?",
      [
      "Sticky note is a security plan.",
      "Written security controls proportionate to the material.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Security is a system.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 47,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.47",
      "BCP at Fiber layup room recovers IT in 48 hours but never names a safety-critical OT function. Last sentence: critical functions. Best?",
      [
      "Email is the only critical function.",
      "Include the safety-critical functions the stem named.",
      "A hard hat.",
      "A BEI.",
      ],
      1,
      "Name the critical work.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 48,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.48",
      "Assembly occupancy at Quench pit: more marshals vs unlocking a chained exit. Last sentence: egress still chained. Pick?",
      [
      "Marshals as the design.",
      "Unchain/restore egress; marshals do not replace an exit.",
      "A poster.",
      "Insurance.",
      ],
      1,
      "Life safety hardware first.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 49,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.49",
      "Incident command radio at Lab solvent crib uses slang only the day shift knows. Night mutual aid arrives. Best?",
      [
      "Slang is ICS.",
      "Common terminology / plain language as ICS expects.",
      "TRIR.",
      "ROI.",
      ],
      1,
      "Common terms.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 50,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.50",
      "Hospitalization from an incident at Shipyard dry dock at 10:00. OSHA notified 48 hours later. Clock named is the 24-hour hospitalization rule. Error?",
      [
      "48 hours is always OK.",
      "Certain hospitalizations: 24 hours. Fatalities: 8 hours.",
      "PELTLV.",
      "FORM.",
      ],
      1,
      "24-hour hospitalization clock.",
      "TIME",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 51,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.51",
      "ERP shutdown steps at Data-center generator hall contradict the process SOP on valve 95. Last sentence: which wins in an emergency. Best?",
      [
      "Ignore both.",
      "Reconcile via MOC so emergency and process documents agree; do not ad-lib.",
      "Buy PPE.",
      "A DART goal.",
      ],
      1,
      "Documents must not fight.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 52,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.52",
      "Protection at Mine shop welding bay: fire pump records blank 120 months. Option: new sticker on an extinguisher. Pick?",
      [
      "Sticker proves the pump.",
      "Test/impairment program; blank records mean unknown protection.",
      "ROI.",
      "TLV.",
      ],
      1,
      "Proof of protection.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 53,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.53",
      "ERP at North pier tank farm has a glossy cover, no roles, no comms, no maps. After a 6-minute release, nobody knows who calls whom. Error Tag 60.",
      [
      "Cover is contents.",
      "ERP contents: roles, comms, maps, shutdown, medical, accountability.",
      "TLV.",
      "TRIR.",
      ],
      1,
      "Contents, not cover.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 54,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.54",
      "ICS at Line 4 stamping cell: 8 people titled Incident Commander 'for balance.' Error Tag 61.",
      [
      "More IC is better.",
      "One IC; sections under IC.",
      "FIN.",
      "PELTLV.",
      ],
      1,
      "Unity of command.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 88,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.88",
      "Flood at Building C autoclave stops invoicing for 12 weeks. Team says the fire ERP is the BCP. Error Tag 62.",
      [
      "ERP is BCP.",
      "BCP keeps critical functions running; ERP is the emergency response.",
      "UNIT.",
      "HIER.",
      ],
      1,
      "BCP vs ERP.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 47,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.47",
      "Fire prevention at Night-shift warehouse mezzanine: fuel/ignition still open. Option: 15 more extinguishers only. Pick Tag 63.",
      [
      "Extinguishers as prevention.",
      "Prevent ignition/fuel first; extinguishers are protection/reduction.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Prevention vs protection.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 48,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.48",
      "Sprinkler valve at Unit 7 hydrotreater shut for 18 months, no impairment program. Best Tag 64.",
      [
      "Assume it works.",
      "Impairment control, restore protection, compensatory measures.",
      "A new poster.",
      "Gloves.",
      ],
      1,
      "Protection must be on.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 49,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.49",
      "Unknown drum leaking in a tunnel from Clinic sterile processing. Team will 'google it' with no ERG/ID. Best Tag 65.",
      [
      "Google without ID.",
      "Identify and use the ERG/plan.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "ID then guide.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 50,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.50",
      "Workplace violence at Foundry shakeout: poster only. Access control and a response plan still open. Pick Tag 66.",
      [
      "Poster as the design.",
      "Access control, procedures, training, aftercare.",
      "TLV.",
      "FTA RPN.",
      ],
      1,
      "System vs poster.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 51,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.51",
      "Drill never run at Cold-storage dock; binder on a shelf for 36 years. Last sentence: exercise the plan. Pick Tag 67.",
      [
      "The binder is a drill.",
      "Run the drill, evaluate, fix the plan.",
      "Insurance.",
      "PEL.",
      ],
      1,
      "A binder is not a drill.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 52,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.52",
      "OT ransomware can freeze ESD at Paint kitchen mezzanine. ERP has no cyber initiator. Last sentence leaves adding it open. Pick Tag 68.",
      [
      "Cyber is never an emergency.",
      "Put OT/IT failure in the ERP if the stem leaves it open.",
      "Buy gloves.",
      "TRIR.",
      ],
      1,
      "Cyber as initiator.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 53,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.53",
      "ICS Finance/Admin asked to run rescue at Substation yard. Error Tag 69.",
      [
      "Any section can be rescue.",
      "Operations runs tactical work.",
      "PELTLV.",
      "FORM.",
      ],
      1,
      "ICS sections.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 54,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.54",
      "Accountability list missing from ERP at Grain silo catwalk. After a drill, 60 people unaccounted. Best Tag 70.",
      [
      "Skip accountability.",
      "Add accountability and drill it.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Who is still inside.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 88,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.88",
      "Drill success at Hospital loading dock defined as 'we finished pizza.' No objectives. Best Tag 71.",
      [
      "Pizza is the objective.",
      "Set objectives, inject, evaluate against them.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Evaluate the drill.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 47,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.47",
      "Fire watch skipped at Battery formation room after hot work because the welder has 90 years. Combustibles remain. Pick Tag 72.",
      [
      "Years replace the watch.",
      "Fire watch/permit as required; tenure is not a watch.",
      "A cone.",
      "A TLV.",
      ],
      1,
      "Watch vs tenure.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 48,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.48",
      "Hazmat security plan at Sawmill green chain is a sticky note. Last sentence: security as named for the listed material. Best Tag 73.",
      [
      "Sticky note is a security plan.",
      "Written security controls proportionate to the material.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Security is a system.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 49,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.49",
      "BCP at Compressor shelter recovers IT in 120 hours but never names a safety-critical OT function. Last sentence: critical functions. Best Tag 74.",
      [
      "Email is the only critical function.",
      "Include the safety-critical functions the stem named.",
      "A hard hat.",
      "A BEI.",
      ],
      1,
      "Name the critical work.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 50,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.50",
      "Assembly occupancy at Railcar unloading rack: more marshals vs unlocking a chained exit. Last sentence: egress still chained. Pick Tag 75.",
      [
      "Marshals as the design.",
      "Unchain/restore egress; marshals do not replace an exit.",
      "A poster.",
      "Insurance.",
      ],
      1,
      "Life safety hardware first.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 51,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.51",
      "Incident command radio at Plating line 2 uses slang only the day shift knows. Night mutual aid arrives. Best Tag 76.",
      [
      "Slang is ICS.",
      "Common terminology / plain language as ICS expects.",
      "TRIR.",
      "ROI.",
      ],
      1,
      "Common terms.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 52,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.52",
      "Hospitalization from an incident at Roof chiller deck at 10:00. OSHA notified 48 hours later. Clock named is the 24-hour hospitalization rule. Error Tag 77.",
      [
      "48 hours is always OK.",
      "Certain hospitalizations: 24 hours. Fatalities: 8 hours.",
      "PELTLV.",
      "FORM.",
      ],
      1,
      "24-hour hospitalization clock.",
      "TIME",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 53,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.53",
      "ERP shutdown steps at Mud-logging shack contradict the process SOP on valve 15. Last sentence: which wins in an emergency. Best Tag 78.",
      [
      "Ignore both.",
      "Reconcile via MOC so emergency and process documents agree; do not ad-lib.",
      "Buy PPE.",
      "A DART goal.",
      ],
      1,
      "Documents must not fight.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 54,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.54",
      "Protection at Die-change bay: fire pump records blank 18 months. Option: new sticker on an extinguisher. Pick Tag 79.",
      [
      "Sticker proves the pump.",
      "Test/impairment program; blank records mean unknown protection.",
      "ROI.",
      "TLV.",
      ],
      1,
      "Proof of protection.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 88,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.88",
      "ERP at Aqueous washer cell has a glossy cover, no roles, no comms, no maps. After a 24-minute release, nobody knows who calls whom. Error Tag 80.",
      [
      "Cover is contents.",
      "ERP contents: roles, comms, maps, shutdown, medical, accountability.",
      "TLV.",
      "TRIR.",
      ],
      1,
      "Contents, not cover.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 47,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.47",
      "ICS at Flare knockout pad: 30 people titled Incident Commander 'for balance.' Error Tag 81.",
      [
      "More IC is better.",
      "One IC; sections under IC.",
      "FIN.",
      "PELTLV.",
      ],
      1,
      "Unity of command.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 48,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.48",
      "Flood at Pharmacy compounding hood stops invoicing for 36 weeks. Team says the fire ERP is the BCP. Error Tag 82.",
      [
      "ERP is BCP.",
      "BCP keeps critical functions running; ERP is the emergency response.",
      "UNIT.",
      "HIER.",
      ],
      1,
      "BCP vs ERP.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 49,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.49",
      "Fire prevention at Concrete batch tower: fuel/ignition still open. Option: 45 more extinguishers only. Pick Tag 83.",
      [
      "Extinguishers as prevention.",
      "Prevent ignition/fuel first; extinguishers are protection/reduction.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Prevention vs protection.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 50,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.50",
      "Sprinkler valve at Fiber layup room shut for 48 months, no impairment program. Best Tag 84.",
      [
      "Assume it works.",
      "Impairment control, restore protection, compensatory measures.",
      "A new poster.",
      "Gloves.",
      ],
      1,
      "Protection must be on.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 51,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.51",
      "Unknown drum leaking in a tunnel from Quench pit. Team will 'google it' with no ERG/ID. Best Tag 85.",
      [
      "Google without ID.",
      "Identify and use the ERG/plan.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "ID then guide.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 52,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.52",
      "Workplace violence at Lab solvent crib: poster only. Access control and a response plan still open. Pick Tag 86.",
      [
      "Poster as the design.",
      "Access control, procedures, training, aftercare.",
      "TLV.",
      "FTA RPN.",
      ],
      1,
      "System vs poster.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 53,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.53",
      "Drill never run at Shipyard dry dock; binder on a shelf for 90 years. Last sentence: exercise the plan. Pick Tag 87.",
      [
      "The binder is a drill.",
      "Run the drill, evaluate, fix the plan.",
      "Insurance.",
      "PEL.",
      ],
      1,
      "A binder is not a drill.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 54,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.54",
      "OT ransomware can freeze ESD at Data-center generator hall. ERP has no cyber initiator. Last sentence leaves adding it open. Pick Tag 88.",
      [
      "Cyber is never an emergency.",
      "Put OT/IT failure in the ERP if the stem leaves it open.",
      "Buy gloves.",
      "TRIR.",
      ],
      1,
      "Cyber as initiator.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 88,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.88",
      "ICS Finance/Admin asked to run rescue at Mine shop welding bay. Error Tag 89.",
      [
      "Any section can be rescue.",
      "Operations runs tactical work.",
      "PELTLV.",
      "FORM.",
      ],
      1,
      "ICS sections.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 47,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.47",
      "Accountability list missing from ERP at North pier tank farm. After a drill, 6 people unaccounted. Best Tag 90.",
      [
      "Skip accountability.",
      "Add accountability and drill it.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Who is still inside.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 48,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.48",
      "Drill success at Line 4 stamping cell defined as 'we finished pizza.' No objectives. Best Tag 91.",
      [
      "Pizza is the objective.",
      "Set objectives, inject, evaluate against them.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Evaluate the drill.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 49,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.49",
      "Fire watch skipped at Building C autoclave after hot work because the welder has 12 years. Combustibles remain. Pick Tag 92.",
      [
      "Years replace the watch.",
      "Fire watch/permit as required; tenure is not a watch.",
      "A cone.",
      "A TLV.",
      ],
      1,
      "Watch vs tenure.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 50,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.50",
      "Hazmat security plan at Night-shift warehouse mezzanine is a sticky note. Last sentence: security as named for the listed material. Best Tag 93.",
      [
      "Sticky note is a security plan.",
      "Written security controls proportionate to the material.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Security is a system.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 51,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.51",
      "BCP at Unit 7 hydrotreater recovers IT in 18 hours but never names a safety-critical OT function. Last sentence: critical functions. Best Tag 94.",
      [
      "Email is the only critical function.",
      "Include the safety-critical functions the stem named.",
      "A hard hat.",
      "A BEI.",
      ],
      1,
      "Name the critical work.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 52,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.52",
      "Assembly occupancy at Clinic sterile processing: more marshals vs unlocking a chained exit. Last sentence: egress still chained. Pick Tag 95.",
      [
      "Marshals as the design.",
      "Unchain/restore egress; marshals do not replace an exit.",
      "A poster.",
      "Insurance.",
      ],
      1,
      "Life safety hardware first.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 53,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.53",
      "Incident command radio at Foundry shakeout uses slang only the day shift knows. Night mutual aid arrives. Best Tag 96.",
      [
      "Slang is ICS.",
      "Common terminology / plain language as ICS expects.",
      "TRIR.",
      "ROI.",
      ],
      1,
      "Common terms.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 54,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.54",
      "Hospitalization from an incident at Cold-storage dock at 10:00. OSHA notified 48 hours later. Clock named is the 24-hour hospitalization rule. Error Tag 97.",
      [
      "48 hours is always OK.",
      "Certain hospitalizations: 24 hours. Fatalities: 8 hours.",
      "PELTLV.",
      "FORM.",
      ],
      1,
      "24-hour hospitalization clock.",
      "TIME",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 88,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.88",
      "ERP shutdown steps at Paint kitchen mezzanine contradict the process SOP on valve 45. Last sentence: which wins in an emergency. Best Tag 98.",
      [
      "Ignore both.",
      "Reconcile via MOC so emergency and process documents agree; do not ad-lib.",
      "Buy PPE.",
      "A DART goal.",
      ],
      1,
      "Documents must not fight.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 47,
    kind: "challenge",
    topic: "d4",
    ...exam(
      "CHAL.D4.47",
      "Protection at Substation yard: fire pump records blank 48 months. Option: new sticker on an extinguisher. Pick Tag 99.",
      [
      "Sticker proves the pump.",
      "Test/impairment program; blank records mean unknown protection.",
      "ROI.",
      "TLV.",
      ],
      1,
      "Proof of protection.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  }
];
