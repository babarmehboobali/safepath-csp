import { exam } from "../classes/types";
import type { GymQuestion } from "./types";

export const CHALLENGE_D1: GymQuestion[] = [
  {
    classId: 1,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.1",
      "At North pier tank farm, a new 6-gpm solvent washer is still on the drawings. Package includes LEL heads, a fire watch roster, and supplied-air hoods. Aqueous cleaning is still qualified. Last sentence: design freeze is next month. Best move?",
      [
      "Order the hoods now because PPE is PtD if it is on a drawing.",
      "Keep substitution/enclosure in the design; sensors and respirators wait until the solvent must remain.",
      "Freeze the flammable solvent to protect 'quality' and add a poster.",
      "Transfer the residual to a contractor and stop design review.",
      ],
      1,
      "PtD is the still-open material/process choice, not add-on PPE on a drawing.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 2,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.2",
      "Line 4 stamping cell can still specify a guard interlock that is defeat-resistant. The team prefers a laminated 'do not mute' sticker and a new pair of cut gloves. Two answers 'work.' Pick?",
      [
      "Sticker plus gloves — faster than engineering.",
      "The guard/interlock if it is still open; sticker/gloves are lower.",
      "A toolbox talk as the entire control.",
      "An insurance deductible change as elimination.",
      ],
      1,
      "If two work, take higher hierarchy / system / design.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 3,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.3",
      "LOTO at Building C autoclave: electrical disconnect locked. A 12-psig pneumatic reservoir can still stroke the ram. Last sentence: verify zero energy. Error if they stop at the disconnect?",
      [
      "None — electrical LOTO covers stored air.",
      "Stored/residual energy must be isolated and verified too.",
      "UNIT — they used bar.",
      "TIME — 12 psig is an 8-hour clock.",
      ],
      1,
      "Multi-source energy. Last sentence said verify zero energy.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 4,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.4",
      "Fall at Night-shift warehouse mezzanine: deck 15 ft above lower level, 6-ft lanyard, no deceleration/harness/D-ring/margin in the note. Candidate says 6 < 15 so it is fine. Error?",
      [
      "None — lanyard length is clearance.",
      "Clearance is the sum of the pieces the stem requires; 6-ft lanyard is not 15-ft clearance.",
      "FORM — they needed TRIR.",
      "PELTLV — 6 ft is a TLV.",
      ],
      1,
      "Lanyard length ≠ clearance.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 5,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.5",
      "Excavation at Unit 7 hydrotreater, 18 ft, Type C, spoils at the lip. Option set leads with new high-viz and a cone. Protective system still open. Pick?",
      [
      "Cone and vest as the protective system.",
      "Slope/bench/shield as required, spoils set back, competent person — PPE is not the trench.",
      "A DART goal.",
      "A TLV for soil.",
      ],
      1,
      "Cave-in control is a system.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 6,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.6",
      "Permit space at Clinic sterile processing: O2 35%, nitrogen purge. Team issues organic-vapor cartridges 'for the nitrogen.' Error?",
      [
      "None — OV cartridges fix oxygen deficiency.",
      "Oxygen-deficient / simple asphyxiant atmosphere is not an OV-cartridge problem; do not enter on APR folklore.",
      "UNIT — 35 is ppm.",
      "FIN — they needed ROI.",
      ],
      1,
      "Cartridges do not add oxygen.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 7,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.7",
      "Two-leg sling at Foundry shakeout, load 8000 lb, 30° to horizontal, calculator left in RAD. Closest tension each leg if they stay in RAD vs DEG?",
      [
      "RAD is required for slings.",
      "Switch to DEG; sin(30°) then T=(W/2)/sinθ. RAD produces a nonsense attractive number.",
      "Use mean of the options.",
      "Tension is always W/4.",
      ],
      1,
      "DEG for construction angles.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 8,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.8",
      "Combustible dust at Cold-storage dock: layered powder, collector pulsing, no isolation. Option: new coveralls and a beard-net policy. Pentagon still open. Pick?",
      [
      "Coveralls as explosion protection.",
      "Housekeeping that does not disperse, ignition control, isolation/venting as needed — clothing is not Kst control.",
      "A TRIR target.",
      "A BEI for dust.",
      ],
      1,
      "Dust pentagon over PPE.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 9,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.9",
      "Hot work on a formerly flammable tank at Paint kitchen mezzanine. Welder is certified. Team skips gas test and fire watch because certification 'is the permit.' Error?",
      [
      "None — certification replaces the permit.",
      "Permit, test, combustibles, fire watch — certification is not a gas test.",
      "UNIT.",
      "PELTLV.",
      ],
      1,
      "Hot-work system vs a card in a wallet.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 10,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.10",
      "PSM at Substation yard: mechanic changes a relief set point from 48 to 100 psig on a Saturday. No MOC/PHA. Best read?",
      [
      "Saturday work is exempt from 1910.119.",
      "Set-point change is a process change — MOC/PHA as required. PPE after the release is not MOC.",
      "A 15th PPE element covers it.",
      "TIME — Saturday is the 24-hour clock.",
      ],
      1,
      "No weekend exemption from MOC.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 11,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.11",
      "Robot teach mode at Grain silo catwalk: full auto speed, no enabling device. Option: hard hat and a buddy. Pick?",
      [
      "Hat + buddy is teach-mode safeguarding.",
      "Reduced speed, enabling device, clearances — PPE/buddy is not the teach-mode design.",
      "A DART poster.",
      "A TLV for robots.",
      ],
      1,
      "Teach-mode engineering.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 12,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.12",
      "Fleet night runs from Hospital loading dock, 75-hour tours, no journey plan. Option: brighter cones in the yard. Fatigue/spec still open. Pick?",
      [
      "Cones as journey management.",
      "Hours, journey management, vehicle spec — cones are not the system.",
      "A noise TWA.",
      "Insurance as elimination.",
      ],
      1,
      "System before yard props.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 13,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.13",
      "Life safety at Battery formation room: required egress blocked by seasonal pallets for 90 weeks 'temporarily.' Occupant load unchanged. Best?",
      [
      "Temporary storage is always allowed in the path.",
      "Restore the occupant path; temporary is not a code exemption in the stem.",
      "Issue flashlights as the design.",
      "A TRIR goal.",
      ],
      1,
      "Egress is the object.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 14,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.14",
      "PIT/pedestrian mix at Sawmill green chain. Engineering can still add exclusion and speed control. Option: sticker on the overhead guard. Pick?",
      [
      "Sticker as PtD.",
      "Separate people from the truck energy; sticker is admin.",
      "First-aid kits closer.",
      "A BEI.",
      ],
      1,
      "Design the flow.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 15,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.15",
      "Machine at Compressor shelter: presence sensing muted so a reach-in can clear jams during auto. LOTO still open for the jam task. Pick?",
      [
      "Muted curtain equals LOTO.",
      "Guarding ≠ isolation. For the entry named, isolate/verify; redesign jam clearing if still open.",
      "GFCI equals LOTO.",
      "A glove as isolation.",
      ],
      1,
      "Sensing is not lockout.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 16,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.16",
      "Water work at Railcar unloading rack from a platform that can still get guardrails. Option set leads with more PFDs as PtD. Pick?",
      [
      "PFDs are PtD by definition.",
      "Eliminate/engineer the over-water exposure; PFDs last.",
      "A dike calculation.",
      "A REL for water.",
      ],
      1,
      "Hierarchy over water.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 79,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.79",
      "Load 500 lb, two-leg, 30° to horizontal, DEG. Tension each leg?",
      [
      "Half the load.",
      "(W/2)/sin30 = W. So 500 lb each if W=500.",
      "RAD answer.",
      "W/4.",
      ],
      1,
      "sin30=0.5 so each leg equals the load.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 80,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.80",
      "Manual handling at Roof chiller deck: lift table still purchasable, LI 1.3 on the current lift. Option: back belt policy. Pick?",
      [
      "Belt as elimination.",
      "Redesign the lift/path; belt is not PtD and RWL is a check.",
      "51 lb is always allowed.",
      "Transfer via insurance.",
      ],
      1,
      "Ergo hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 82,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.82",
      "Electrical at Mud-logging shack: unqualified helper steps to the 15 V starter 'because leather gloves.' Last sentence: approach boundary. Pick?",
      [
      "Leather qualifies the helper.",
      "Unqualified stay outside the boundary; gloves do not qualify.",
      "GFCI is the boundary.",
      "TRIR is the boundary.",
      ],
      1,
      "Qualification + distance.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 87,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.87",
      "Caught-in at Die-change bay: stored energy in a flywheel after the motor disconnect. Team removes the guard and reaches in. Best?",
      [
      "Disconnect is enough.",
      "Guard plus isolation of stored energy; a disconnected motor may not be a stopped flywheel.",
      "A cone.",
      "A TLV.",
      ],
      1,
      "Stored mechanical energy.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 1,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.1",
      "At Aqueous washer cell, a new 24-gpm solvent washer is still on the drawings. Package includes LEL heads, a fire watch roster, and supplied-air hoods. Aqueous cleaning is still qualified. Last sentence: design freeze is next month. Best move?",
      [
      "Order the hoods now because PPE is PtD if it is on a drawing.",
      "Keep substitution/enclosure in the design; sensors and respirators wait until the solvent must remain.",
      "Freeze the flammable solvent to protect 'quality' and add a poster.",
      "Transfer the residual to a contractor and stop design review.",
      ],
      1,
      "PtD is the still-open material/process choice, not add-on PPE on a drawing.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 2,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.2",
      "Flare knockout pad can still specify a guard interlock that is defeat-resistant. The team prefers a laminated 'do not mute' sticker and a new pair of cut gloves. Two answers 'work.' Pick?",
      [
      "Sticker plus gloves — faster than engineering.",
      "The guard/interlock if it is still open; sticker/gloves are lower.",
      "A toolbox talk as the entire control.",
      "An insurance deductible change as elimination.",
      ],
      1,
      "If two work, take higher hierarchy / system / design.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 3,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.3",
      "LOTO at Pharmacy compounding hood: electrical disconnect locked. A 36-psig pneumatic reservoir can still stroke the ram. Last sentence: verify zero energy. Error if they stop at the disconnect?",
      [
      "None — electrical LOTO covers stored air.",
      "Stored/residual energy must be isolated and verified too.",
      "UNIT — they used bar.",
      "TIME — 36 psig is an 8-hour clock.",
      ],
      1,
      "Multi-source energy. Last sentence said verify zero energy.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 4,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.4",
      "Fall at Concrete batch tower: deck 45 ft above lower level, 6-ft lanyard, no deceleration/harness/D-ring/margin in the note. Candidate says 6 < 45 so it is fine. Error?",
      [
      "None — lanyard length is clearance.",
      "Clearance is the sum of the pieces the stem requires; 6-ft lanyard is not 45-ft clearance.",
      "FORM — they needed TRIR.",
      "PELTLV — 6 ft is a TLV.",
      ],
      1,
      "Lanyard length ≠ clearance.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 5,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.5",
      "Excavation at Fiber layup room, 48 ft, Type C, spoils at the lip. Option set leads with new high-viz and a cone. Protective system still open. Pick?",
      [
      "Cone and vest as the protective system.",
      "Slope/bench/shield as required, spoils set back, competent person — PPE is not the trench.",
      "A DART goal.",
      "A TLV for soil.",
      ],
      1,
      "Cave-in control is a system.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 6,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.6",
      "Permit space at Quench pit: O2 35%, nitrogen purge. Team issues organic-vapor cartridges 'for the nitrogen.' Error?",
      [
      "None — OV cartridges fix oxygen deficiency.",
      "Oxygen-deficient / simple asphyxiant atmosphere is not an OV-cartridge problem; do not enter on APR folklore.",
      "UNIT — 35 is ppm.",
      "FIN — they needed ROI.",
      ],
      1,
      "Cartridges do not add oxygen.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 7,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.7",
      "Two-leg sling at Lab solvent crib, load 1200 lb, 75° to horizontal, calculator left in RAD. Closest tension each leg if they stay in RAD vs DEG?",
      [
      "RAD is required for slings.",
      "Switch to DEG; sin(75°) then T=(W/2)/sinθ. RAD produces a nonsense attractive number.",
      "Use mean of the options.",
      "Tension is always W/4.",
      ],
      1,
      "DEG for construction angles.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 8,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.8",
      "Combustible dust at Shipyard dry dock: layered powder, collector pulsing, no isolation. Option: new coveralls and a beard-net policy. Pentagon still open. Pick?",
      [
      "Coveralls as explosion protection.",
      "Housekeeping that does not disperse, ignition control, isolation/venting as needed — clothing is not Kst control.",
      "A TRIR target.",
      "A BEI for dust.",
      ],
      1,
      "Dust pentagon over PPE.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 9,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.9",
      "Hot work on a formerly flammable tank at Data-center generator hall. Welder is certified. Team skips gas test and fire watch because certification 'is the permit.' Error?",
      [
      "None — certification replaces the permit.",
      "Permit, test, combustibles, fire watch — certification is not a gas test.",
      "UNIT.",
      "PELTLV.",
      ],
      1,
      "Hot-work system vs a card in a wallet.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 10,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.10",
      "PSM at Mine shop welding bay: mechanic changes a relief set point from 120 to 100 psig on a Saturday. No MOC/PHA. Best read?",
      [
      "Saturday work is exempt from 1910.119.",
      "Set-point change is a process change — MOC/PHA as required. PPE after the release is not MOC.",
      "A 15th PPE element covers it.",
      "TIME — Saturday is the 24-hour clock.",
      ],
      1,
      "No weekend exemption from MOC.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 11,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.11",
      "Robot teach mode at North pier tank farm: full auto speed, no enabling device. Option: hard hat and a buddy. Pick?",
      [
      "Hat + buddy is teach-mode safeguarding.",
      "Reduced speed, enabling device, clearances — PPE/buddy is not the teach-mode design.",
      "A DART poster.",
      "A TLV for robots.",
      ],
      1,
      "Teach-mode engineering.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 12,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.12",
      "Fleet night runs from Line 4 stamping cell, 8-hour tours, no journey plan. Option: brighter cones in the yard. Fatigue/spec still open. Pick?",
      [
      "Cones as journey management.",
      "Hours, journey management, vehicle spec — cones are not the system.",
      "A noise TWA.",
      "Insurance as elimination.",
      ],
      1,
      "System before yard props.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 13,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.13",
      "Life safety at Building C autoclave: required egress blocked by seasonal pallets for 12 weeks 'temporarily.' Occupant load unchanged. Best?",
      [
      "Temporary storage is always allowed in the path.",
      "Restore the occupant path; temporary is not a code exemption in the stem.",
      "Issue flashlights as the design.",
      "A TRIR goal.",
      ],
      1,
      "Egress is the object.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 14,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.14",
      "PIT/pedestrian mix at Night-shift warehouse mezzanine. Engineering can still add exclusion and speed control. Option: sticker on the overhead guard. Pick?",
      [
      "Sticker as PtD.",
      "Separate people from the truck energy; sticker is admin.",
      "First-aid kits closer.",
      "A BEI.",
      ],
      1,
      "Design the flow.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 15,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.15",
      "Machine at Unit 7 hydrotreater: presence sensing muted so a reach-in can clear jams during auto. LOTO still open for the jam task. Pick?",
      [
      "Muted curtain equals LOTO.",
      "Guarding ≠ isolation. For the entry named, isolate/verify; redesign jam clearing if still open.",
      "GFCI equals LOTO.",
      "A glove as isolation.",
      ],
      1,
      "Sensing is not lockout.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 16,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.16",
      "Water work at Clinic sterile processing from a platform that can still get guardrails. Option set leads with more PFDs as PtD. Pick?",
      [
      "PFDs are PtD by definition.",
      "Eliminate/engineer the over-water exposure; PFDs last.",
      "A dike calculation.",
      "A REL for water.",
      ],
      1,
      "Hierarchy over water.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 79,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.79",
      "Load 2500 lb, two-leg, 30° to horizontal, DEG. Tension each leg?",
      [
      "Half the load.",
      "(W/2)/sin30 = W. So 2500 lb each if W=2500.",
      "RAD answer.",
      "W/4.",
      ],
      1,
      "sin30=0.5 so each leg equals the load.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 80,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.80",
      "Manual handling at Cold-storage dock: lift table still purchasable, LI 1.3 on the current lift. Option: back belt policy. Pick?",
      [
      "Belt as elimination.",
      "Redesign the lift/path; belt is not PtD and RWL is a check.",
      "51 lb is always allowed.",
      "Transfer via insurance.",
      ],
      1,
      "Ergo hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 82,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.82",
      "Electrical at Paint kitchen mezzanine: unqualified helper steps to the 45 V starter 'because leather gloves.' Last sentence: approach boundary. Pick?",
      [
      "Leather qualifies the helper.",
      "Unqualified stay outside the boundary; gloves do not qualify.",
      "GFCI is the boundary.",
      "TRIR is the boundary.",
      ],
      1,
      "Qualification + distance.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 87,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.87",
      "Caught-in at Substation yard: stored energy in a flywheel after the motor disconnect. Team removes the guard and reaches in. Best?",
      [
      "Disconnect is enough.",
      "Guard plus isolation of stored energy; a disconnected motor may not be a stopped flywheel.",
      "A cone.",
      "A TLV.",
      ],
      1,
      "Stored mechanical energy.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 1,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.1",
      "At Grain silo catwalk, a new 60-gpm solvent washer is still on the drawings. Package includes LEL heads, a fire watch roster, and supplied-air hoods. Aqueous cleaning is still qualified. Last sentence: design freeze is next month. Best move?",
      [
      "Order the hoods now because PPE is PtD if it is on a drawing.",
      "Keep substitution/enclosure in the design; sensors and respirators wait until the solvent must remain.",
      "Freeze the flammable solvent to protect 'quality' and add a poster.",
      "Transfer the residual to a contractor and stop design review.",
      ],
      1,
      "PtD is the still-open material/process choice, not add-on PPE on a drawing.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 2,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.2",
      "Hospital loading dock can still specify a guard interlock that is defeat-resistant. The team prefers a laminated 'do not mute' sticker and a new pair of cut gloves. Two answers 'work.' Pick?",
      [
      "Sticker plus gloves — faster than engineering.",
      "The guard/interlock if it is still open; sticker/gloves are lower.",
      "A toolbox talk as the entire control.",
      "An insurance deductible change as elimination.",
      ],
      1,
      "If two work, take higher hierarchy / system / design.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 3,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.3",
      "LOTO at Battery formation room: electrical disconnect locked. A 90-psig pneumatic reservoir can still stroke the ram. Last sentence: verify zero energy. Error if they stop at the disconnect?",
      [
      "None — electrical LOTO covers stored air.",
      "Stored/residual energy must be isolated and verified too.",
      "UNIT — they used bar.",
      "TIME — 90 psig is an 8-hour clock.",
      ],
      1,
      "Multi-source energy. Last sentence said verify zero energy.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 4,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.4",
      "Fall at Sawmill green chain: deck 95 ft above lower level, 6-ft lanyard, no deceleration/harness/D-ring/margin in the note. Candidate says 6 < 95 so it is fine. Error?",
      [
      "None — lanyard length is clearance.",
      "Clearance is the sum of the pieces the stem requires; 6-ft lanyard is not 95-ft clearance.",
      "FORM — they needed TRIR.",
      "PELTLV — 6 ft is a TLV.",
      ],
      1,
      "Lanyard length ≠ clearance.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 5,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.5",
      "Excavation at Compressor shelter, 120 ft, Type C, spoils at the lip. Option set leads with new high-viz and a cone. Protective system still open. Pick?",
      [
      "Cone and vest as the protective system.",
      "Slope/bench/shield as required, spoils set back, competent person — PPE is not the trench.",
      "A DART goal.",
      "A TLV for soil.",
      ],
      1,
      "Cave-in control is a system.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 6,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.6",
      "Permit space at Railcar unloading rack: O2 35%, nitrogen purge. Team issues organic-vapor cartridges 'for the nitrogen.' Error?",
      [
      "None — OV cartridges fix oxygen deficiency.",
      "Oxygen-deficient / simple asphyxiant atmosphere is not an OV-cartridge problem; do not enter on APR folklore.",
      "UNIT — 35 is ppm.",
      "FIN — they needed ROI.",
      ],
      1,
      "Cartridges do not add oxygen.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 7,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.7",
      "Two-leg sling at Plating line 2, load 8000 lb, 8° to horizontal, calculator left in RAD. Closest tension each leg if they stay in RAD vs DEG?",
      [
      "RAD is required for slings.",
      "Switch to DEG; sin(8°) then T=(W/2)/sinθ. RAD produces a nonsense attractive number.",
      "Use mean of the options.",
      "Tension is always W/4.",
      ],
      1,
      "DEG for construction angles.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 8,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.8",
      "Combustible dust at Roof chiller deck: layered powder, collector pulsing, no isolation. Option: new coveralls and a beard-net policy. Pentagon still open. Pick?",
      [
      "Coveralls as explosion protection.",
      "Housekeeping that does not disperse, ignition control, isolation/venting as needed — clothing is not Kst control.",
      "A TRIR target.",
      "A BEI for dust.",
      ],
      1,
      "Dust pentagon over PPE.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 9,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.9",
      "Hot work on a formerly flammable tank at Mud-logging shack. Welder is certified. Team skips gas test and fire watch because certification 'is the permit.' Error?",
      [
      "None — certification replaces the permit.",
      "Permit, test, combustibles, fire watch — certification is not a gas test.",
      "UNIT.",
      "PELTLV.",
      ],
      1,
      "Hot-work system vs a card in a wallet.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 10,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.10",
      "PSM at Die-change bay: mechanic changes a relief set point from 18 to 100 psig on a Saturday. No MOC/PHA. Best read?",
      [
      "Saturday work is exempt from 1910.119.",
      "Set-point change is a process change — MOC/PHA as required. PPE after the release is not MOC.",
      "A 15th PPE element covers it.",
      "TIME — Saturday is the 24-hour clock.",
      ],
      1,
      "No weekend exemption from MOC.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 11,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.11",
      "Robot teach mode at Aqueous washer cell: full auto speed, no enabling device. Option: hard hat and a buddy. Pick?",
      [
      "Hat + buddy is teach-mode safeguarding.",
      "Reduced speed, enabling device, clearances — PPE/buddy is not the teach-mode design.",
      "A DART poster.",
      "A TLV for robots.",
      ],
      1,
      "Teach-mode engineering.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 12,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.12",
      "Fleet night runs from Flare knockout pad, 30-hour tours, no journey plan. Option: brighter cones in the yard. Fatigue/spec still open. Pick?",
      [
      "Cones as journey management.",
      "Hours, journey management, vehicle spec — cones are not the system.",
      "A noise TWA.",
      "Insurance as elimination.",
      ],
      1,
      "System before yard props.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 13,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.13",
      "Life safety at Pharmacy compounding hood: required egress blocked by seasonal pallets for 36 weeks 'temporarily.' Occupant load unchanged. Best?",
      [
      "Temporary storage is always allowed in the path.",
      "Restore the occupant path; temporary is not a code exemption in the stem.",
      "Issue flashlights as the design.",
      "A TRIR goal.",
      ],
      1,
      "Egress is the object.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 14,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.14",
      "PIT/pedestrian mix at Concrete batch tower. Engineering can still add exclusion and speed control. Option: sticker on the overhead guard. Pick?",
      [
      "Sticker as PtD.",
      "Separate people from the truck energy; sticker is admin.",
      "First-aid kits closer.",
      "A BEI.",
      ],
      1,
      "Design the flow.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 15,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.15",
      "Machine at Fiber layup room: presence sensing muted so a reach-in can clear jams during auto. LOTO still open for the jam task. Pick?",
      [
      "Muted curtain equals LOTO.",
      "Guarding ≠ isolation. For the entry named, isolate/verify; redesign jam clearing if still open.",
      "GFCI equals LOTO.",
      "A glove as isolation.",
      ],
      1,
      "Sensing is not lockout.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 16,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.16",
      "Water work at Quench pit from a platform that can still get guardrails. Option set leads with more PFDs as PtD. Pick?",
      [
      "PFDs are PtD by definition.",
      "Eliminate/engineer the over-water exposure; PFDs last.",
      "A dike calculation.",
      "A REL for water.",
      ],
      1,
      "Hierarchy over water.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 79,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.79",
      "Load 500 lb, two-leg, 30° to horizontal, DEG. Tension each leg Tag 56.",
      [
      "Half the load.",
      "(W/2)/sin30 = W. So 500 lb each if W=500.",
      "RAD answer.",
      "W/4.",
      ],
      1,
      "sin30=0.5 so each leg equals the load.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 80,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.80",
      "Manual handling at Shipyard dry dock: lift table still purchasable, LI 1.3 on the current lift. Option: back belt policy. Pick?",
      [
      "Belt as elimination.",
      "Redesign the lift/path; belt is not PtD and RWL is a check.",
      "51 lb is always allowed.",
      "Transfer via insurance.",
      ],
      1,
      "Ergo hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 82,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.82",
      "Electrical at Data-center generator hall: unqualified helper steps to the 95 V starter 'because leather gloves.' Last sentence: approach boundary. Pick?",
      [
      "Leather qualifies the helper.",
      "Unqualified stay outside the boundary; gloves do not qualify.",
      "GFCI is the boundary.",
      "TRIR is the boundary.",
      ],
      1,
      "Qualification + distance.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 87,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.87",
      "Caught-in at Mine shop welding bay: stored energy in a flywheel after the motor disconnect. Team removes the guard and reaches in. Best?",
      [
      "Disconnect is enough.",
      "Guard plus isolation of stored energy; a disconnected motor may not be a stopped flywheel.",
      "A cone.",
      "A TLV.",
      ],
      1,
      "Stored mechanical energy.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 1,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.1",
      "At North pier tank farm, a new 6-gpm solvent washer is still on the drawings. Package includes LEL heads, a fire watch roster, and supplied-air hoods. Aqueous cleaning is still qualified. Last sentence: design freeze is next month. Best move Tag 60.",
      [
      "Order the hoods now because PPE is PtD if it is on a drawing.",
      "Keep substitution/enclosure in the design; sensors and respirators wait until the solvent must remain.",
      "Freeze the flammable solvent to protect 'quality' and add a poster.",
      "Transfer the residual to a contractor and stop design review.",
      ],
      1,
      "PtD is the still-open material/process choice, not add-on PPE on a drawing.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 2,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.2",
      "Line 4 stamping cell can still specify a guard interlock that is defeat-resistant. The team prefers a laminated 'do not mute' sticker and a new pair of cut gloves. Two answers 'work.' Pick Tag 61.",
      [
      "Sticker plus gloves — faster than engineering.",
      "The guard/interlock if it is still open; sticker/gloves are lower.",
      "A toolbox talk as the entire control.",
      "An insurance deductible change as elimination.",
      ],
      1,
      "If two work, take higher hierarchy / system / design.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 3,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.3",
      "LOTO at Building C autoclave: electrical disconnect locked. A 12-psig pneumatic reservoir can still stroke the ram. Last sentence: verify zero energy. Error if they stop at the disconnect Tag 62.",
      [
      "None — electrical LOTO covers stored air.",
      "Stored/residual energy must be isolated and verified too.",
      "UNIT — they used bar.",
      "TIME — 12 psig is an 8-hour clock.",
      ],
      1,
      "Multi-source energy. Last sentence said verify zero energy.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 4,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.4",
      "Fall at Night-shift warehouse mezzanine: deck 15 ft above lower level, 6-ft lanyard, no deceleration/harness/D-ring/margin in the note. Candidate says 6 < 15 so it is fine. Error Tag 63.",
      [
      "None — lanyard length is clearance.",
      "Clearance is the sum of the pieces the stem requires; 6-ft lanyard is not 15-ft clearance.",
      "FORM — they needed TRIR.",
      "PELTLV — 6 ft is a TLV.",
      ],
      1,
      "Lanyard length ≠ clearance.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 5,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.5",
      "Excavation at Unit 7 hydrotreater, 18 ft, Type C, spoils at the lip. Option set leads with new high-viz and a cone. Protective system still open. Pick Tag 64.",
      [
      "Cone and vest as the protective system.",
      "Slope/bench/shield as required, spoils set back, competent person — PPE is not the trench.",
      "A DART goal.",
      "A TLV for soil.",
      ],
      1,
      "Cave-in control is a system.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 6,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.6",
      "Permit space at Clinic sterile processing: O2 35%, nitrogen purge. Team issues organic-vapor cartridges 'for the nitrogen.' Error Tag 65.",
      [
      "None — OV cartridges fix oxygen deficiency.",
      "Oxygen-deficient / simple asphyxiant atmosphere is not an OV-cartridge problem; do not enter on APR folklore.",
      "UNIT — 35 is ppm.",
      "FIN — they needed ROI.",
      ],
      1,
      "Cartridges do not add oxygen.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 7,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.7",
      "Two-leg sling at Foundry shakeout, load 1200 lb, 30° to horizontal, calculator left in RAD. Closest tension each leg if they stay in RAD vs DEG?",
      [
      "RAD is required for slings.",
      "Switch to DEG; sin(30°) then T=(W/2)/sinθ. RAD produces a nonsense attractive number.",
      "Use mean of the options.",
      "Tension is always W/4.",
      ],
      1,
      "DEG for construction angles.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 8,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.8",
      "Combustible dust at Cold-storage dock: layered powder, collector pulsing, no isolation. Option: new coveralls and a beard-net policy. Pentagon still open. Pick Tag 67.",
      [
      "Coveralls as explosion protection.",
      "Housekeeping that does not disperse, ignition control, isolation/venting as needed — clothing is not Kst control.",
      "A TRIR target.",
      "A BEI for dust.",
      ],
      1,
      "Dust pentagon over PPE.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 9,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.9",
      "Hot work on a formerly flammable tank at Paint kitchen mezzanine. Welder is certified. Team skips gas test and fire watch because certification 'is the permit.' Error Tag 68.",
      [
      "None — certification replaces the permit.",
      "Permit, test, combustibles, fire watch — certification is not a gas test.",
      "UNIT.",
      "PELTLV.",
      ],
      1,
      "Hot-work system vs a card in a wallet.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 10,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.10",
      "PSM at Substation yard: mechanic changes a relief set point from 48 to 100 psig on a Saturday. No MOC/PHA. Best read Tag 69.",
      [
      "Saturday work is exempt from 1910.119.",
      "Set-point change is a process change — MOC/PHA as required. PPE after the release is not MOC.",
      "A 15th PPE element covers it.",
      "TIME — Saturday is the 24-hour clock.",
      ],
      1,
      "No weekend exemption from MOC.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 11,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.11",
      "Robot teach mode at Grain silo catwalk: full auto speed, no enabling device. Option: hard hat and a buddy. Pick Tag 70.",
      [
      "Hat + buddy is teach-mode safeguarding.",
      "Reduced speed, enabling device, clearances — PPE/buddy is not the teach-mode design.",
      "A DART poster.",
      "A TLV for robots.",
      ],
      1,
      "Teach-mode engineering.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 12,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.12",
      "Fleet night runs from Hospital loading dock, 75-hour tours, no journey plan. Option: brighter cones in the yard. Fatigue/spec still open. Pick Tag 71.",
      [
      "Cones as journey management.",
      "Hours, journey management, vehicle spec — cones are not the system.",
      "A noise TWA.",
      "Insurance as elimination.",
      ],
      1,
      "System before yard props.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 13,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.13",
      "Life safety at Battery formation room: required egress blocked by seasonal pallets for 90 weeks 'temporarily.' Occupant load unchanged. Best Tag 72.",
      [
      "Temporary storage is always allowed in the path.",
      "Restore the occupant path; temporary is not a code exemption in the stem.",
      "Issue flashlights as the design.",
      "A TRIR goal.",
      ],
      1,
      "Egress is the object.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 14,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.14",
      "PIT/pedestrian mix at Sawmill green chain. Engineering can still add exclusion and speed control. Option: sticker on the overhead guard. Pick Tag 73.",
      [
      "Sticker as PtD.",
      "Separate people from the truck energy; sticker is admin.",
      "First-aid kits closer.",
      "A BEI.",
      ],
      1,
      "Design the flow.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 15,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.15",
      "Machine at Compressor shelter: presence sensing muted so a reach-in can clear jams during auto. LOTO still open for the jam task. Pick Tag 74.",
      [
      "Muted curtain equals LOTO.",
      "Guarding ≠ isolation. For the entry named, isolate/verify; redesign jam clearing if still open.",
      "GFCI equals LOTO.",
      "A glove as isolation.",
      ],
      1,
      "Sensing is not lockout.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 16,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.16",
      "Water work at Railcar unloading rack from a platform that can still get guardrails. Option set leads with more PFDs as PtD. Pick Tag 75.",
      [
      "PFDs are PtD by definition.",
      "Eliminate/engineer the over-water exposure; PFDs last.",
      "A dike calculation.",
      "A REL for water.",
      ],
      1,
      "Hierarchy over water.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 79,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.79",
      "Load 2500 lb, two-leg, 30° to horizontal, DEG. Tension each leg Tag 76.",
      [
      "Half the load.",
      "(W/2)/sin30 = W. So 2500 lb each if W=2500.",
      "RAD answer.",
      "W/4.",
      ],
      1,
      "sin30=0.5 so each leg equals the load.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 80,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.80",
      "Manual handling at Roof chiller deck: lift table still purchasable, LI 1.3 on the current lift. Option: back belt policy. Pick Tag 77.",
      [
      "Belt as elimination.",
      "Redesign the lift/path; belt is not PtD and RWL is a check.",
      "51 lb is always allowed.",
      "Transfer via insurance.",
      ],
      1,
      "Ergo hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 82,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.82",
      "Electrical at Mud-logging shack: unqualified helper steps to the 15 V starter 'because leather gloves.' Last sentence: approach boundary. Pick Tag 78.",
      [
      "Leather qualifies the helper.",
      "Unqualified stay outside the boundary; gloves do not qualify.",
      "GFCI is the boundary.",
      "TRIR is the boundary.",
      ],
      1,
      "Qualification + distance.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 87,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.87",
      "Caught-in at Die-change bay: stored energy in a flywheel after the motor disconnect. Team removes the guard and reaches in. Best Tag 79.",
      [
      "Disconnect is enough.",
      "Guard plus isolation of stored energy; a disconnected motor may not be a stopped flywheel.",
      "A cone.",
      "A TLV.",
      ],
      1,
      "Stored mechanical energy.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 1,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.1",
      "At Aqueous washer cell, a new 24-gpm solvent washer is still on the drawings. Package includes LEL heads, a fire watch roster, and supplied-air hoods. Aqueous cleaning is still qualified. Last sentence: design freeze is next month. Best move Tag 80.",
      [
      "Order the hoods now because PPE is PtD if it is on a drawing.",
      "Keep substitution/enclosure in the design; sensors and respirators wait until the solvent must remain.",
      "Freeze the flammable solvent to protect 'quality' and add a poster.",
      "Transfer the residual to a contractor and stop design review.",
      ],
      1,
      "PtD is the still-open material/process choice, not add-on PPE on a drawing.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 2,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.2",
      "Flare knockout pad can still specify a guard interlock that is defeat-resistant. The team prefers a laminated 'do not mute' sticker and a new pair of cut gloves. Two answers 'work.' Pick Tag 81.",
      [
      "Sticker plus gloves — faster than engineering.",
      "The guard/interlock if it is still open; sticker/gloves are lower.",
      "A toolbox talk as the entire control.",
      "An insurance deductible change as elimination.",
      ],
      1,
      "If two work, take higher hierarchy / system / design.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 3,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.3",
      "LOTO at Pharmacy compounding hood: electrical disconnect locked. A 36-psig pneumatic reservoir can still stroke the ram. Last sentence: verify zero energy. Error if they stop at the disconnect Tag 82.",
      [
      "None — electrical LOTO covers stored air.",
      "Stored/residual energy must be isolated and verified too.",
      "UNIT — they used bar.",
      "TIME — 36 psig is an 8-hour clock.",
      ],
      1,
      "Multi-source energy. Last sentence said verify zero energy.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 4,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.4",
      "Fall at Concrete batch tower: deck 45 ft above lower level, 6-ft lanyard, no deceleration/harness/D-ring/margin in the note. Candidate says 6 < 45 so it is fine. Error Tag 83.",
      [
      "None — lanyard length is clearance.",
      "Clearance is the sum of the pieces the stem requires; 6-ft lanyard is not 45-ft clearance.",
      "FORM — they needed TRIR.",
      "PELTLV — 6 ft is a TLV.",
      ],
      1,
      "Lanyard length ≠ clearance.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 5,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.5",
      "Excavation at Fiber layup room, 48 ft, Type C, spoils at the lip. Option set leads with new high-viz and a cone. Protective system still open. Pick Tag 84.",
      [
      "Cone and vest as the protective system.",
      "Slope/bench/shield as required, spoils set back, competent person — PPE is not the trench.",
      "A DART goal.",
      "A TLV for soil.",
      ],
      1,
      "Cave-in control is a system.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 6,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.6",
      "Permit space at Quench pit: O2 35%, nitrogen purge. Team issues organic-vapor cartridges 'for the nitrogen.' Error Tag 85.",
      [
      "None — OV cartridges fix oxygen deficiency.",
      "Oxygen-deficient / simple asphyxiant atmosphere is not an OV-cartridge problem; do not enter on APR folklore.",
      "UNIT — 35 is ppm.",
      "FIN — they needed ROI.",
      ],
      1,
      "Cartridges do not add oxygen.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 7,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.7",
      "Two-leg sling at Lab solvent crib, load 8000 lb, 75° to horizontal, calculator left in RAD. Closest tension each leg if they stay in RAD vs DEG?",
      [
      "RAD is required for slings.",
      "Switch to DEG; sin(75°) then T=(W/2)/sinθ. RAD produces a nonsense attractive number.",
      "Use mean of the options.",
      "Tension is always W/4.",
      ],
      1,
      "DEG for construction angles.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 8,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.8",
      "Combustible dust at Shipyard dry dock: layered powder, collector pulsing, no isolation. Option: new coveralls and a beard-net policy. Pentagon still open. Pick Tag 87.",
      [
      "Coveralls as explosion protection.",
      "Housekeeping that does not disperse, ignition control, isolation/venting as needed — clothing is not Kst control.",
      "A TRIR target.",
      "A BEI for dust.",
      ],
      1,
      "Dust pentagon over PPE.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 9,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.9",
      "Hot work on a formerly flammable tank at Data-center generator hall. Welder is certified. Team skips gas test and fire watch because certification 'is the permit.' Error Tag 88.",
      [
      "None — certification replaces the permit.",
      "Permit, test, combustibles, fire watch — certification is not a gas test.",
      "UNIT.",
      "PELTLV.",
      ],
      1,
      "Hot-work system vs a card in a wallet.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 10,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.10",
      "PSM at Mine shop welding bay: mechanic changes a relief set point from 120 to 100 psig on a Saturday. No MOC/PHA. Best read Tag 89.",
      [
      "Saturday work is exempt from 1910.119.",
      "Set-point change is a process change — MOC/PHA as required. PPE after the release is not MOC.",
      "A 15th PPE element covers it.",
      "TIME — Saturday is the 24-hour clock.",
      ],
      1,
      "No weekend exemption from MOC.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 11,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.11",
      "Robot teach mode at North pier tank farm: full auto speed, no enabling device. Option: hard hat and a buddy. Pick Tag 90.",
      [
      "Hat + buddy is teach-mode safeguarding.",
      "Reduced speed, enabling device, clearances — PPE/buddy is not the teach-mode design.",
      "A DART poster.",
      "A TLV for robots.",
      ],
      1,
      "Teach-mode engineering.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 12,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.12",
      "Fleet night runs from Line 4 stamping cell, 8-hour tours, no journey plan. Option: brighter cones in the yard. Fatigue/spec still open. Pick Tag 91.",
      [
      "Cones as journey management.",
      "Hours, journey management, vehicle spec — cones are not the system.",
      "A noise TWA.",
      "Insurance as elimination.",
      ],
      1,
      "System before yard props.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 13,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.13",
      "Life safety at Building C autoclave: required egress blocked by seasonal pallets for 12 weeks 'temporarily.' Occupant load unchanged. Best Tag 92.",
      [
      "Temporary storage is always allowed in the path.",
      "Restore the occupant path; temporary is not a code exemption in the stem.",
      "Issue flashlights as the design.",
      "A TRIR goal.",
      ],
      1,
      "Egress is the object.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 14,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.14",
      "PIT/pedestrian mix at Night-shift warehouse mezzanine. Engineering can still add exclusion and speed control. Option: sticker on the overhead guard. Pick Tag 93.",
      [
      "Sticker as PtD.",
      "Separate people from the truck energy; sticker is admin.",
      "First-aid kits closer.",
      "A BEI.",
      ],
      1,
      "Design the flow.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 15,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.15",
      "Machine at Unit 7 hydrotreater: presence sensing muted so a reach-in can clear jams during auto. LOTO still open for the jam task. Pick Tag 94.",
      [
      "Muted curtain equals LOTO.",
      "Guarding ≠ isolation. For the entry named, isolate/verify; redesign jam clearing if still open.",
      "GFCI equals LOTO.",
      "A glove as isolation.",
      ],
      1,
      "Sensing is not lockout.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 16,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.16",
      "Water work at Clinic sterile processing from a platform that can still get guardrails. Option set leads with more PFDs as PtD. Pick Tag 95.",
      [
      "PFDs are PtD by definition.",
      "Eliminate/engineer the over-water exposure; PFDs last.",
      "A dike calculation.",
      "A REL for water.",
      ],
      1,
      "Hierarchy over water.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 79,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.79",
      "Load 500 lb, two-leg, 30° to horizontal, DEG. Tension each leg Tag 96.",
      [
      "Half the load.",
      "(W/2)/sin30 = W. So 500 lb each if W=500.",
      "RAD answer.",
      "W/4.",
      ],
      1,
      "sin30=0.5 so each leg equals the load.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 80,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.80",
      "Manual handling at Cold-storage dock: lift table still purchasable, LI 1.3 on the current lift. Option: back belt policy. Pick Tag 97.",
      [
      "Belt as elimination.",
      "Redesign the lift/path; belt is not PtD and RWL is a check.",
      "51 lb is always allowed.",
      "Transfer via insurance.",
      ],
      1,
      "Ergo hierarchy.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 82,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.82",
      "Electrical at Paint kitchen mezzanine: unqualified helper steps to the 45 V starter 'because leather gloves.' Last sentence: approach boundary. Pick Tag 98.",
      [
      "Leather qualifies the helper.",
      "Unqualified stay outside the boundary; gloves do not qualify.",
      "GFCI is the boundary.",
      "TRIR is the boundary.",
      ],
      1,
      "Qualification + distance.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 87,
    kind: "challenge",
    topic: "d1",
    ...exam(
      "CHAL.D1.87",
      "Caught-in at Substation yard: stored energy in a flywheel after the motor disconnect. Team removes the guard and reaches in. Best Tag 99.",
      [
      "Disconnect is enough.",
      "Guard plus isolation of stored energy; a disconnected motor may not be a stopped flywheel.",
      "A cone.",
      "A TLV.",
      ],
      1,
      "Stored mechanical energy.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  }
];
