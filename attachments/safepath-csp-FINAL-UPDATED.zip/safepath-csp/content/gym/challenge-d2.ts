import { exam } from "../classes/types";
import type { GymQuestion } from "./types";

export const CHALLENGE_D2: GymQuestion[] = [
  {
    classId: 17,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.17",
      "Gap analysis at North pier tank farm starts with branded mugs and a new slogan. Clause 6 of the adopted MSS is still unmet. Error?",
      [
      "Slogan is the gap analysis.",
      "Gap is current vs required; merch is not the analysis.",
      "UNIT.",
      "PELTLV.",
      ],
      1,
      "Diagnose before merch.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 18,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.18",
      "Line 4 stamping cell highlighted an ISO clause in yellow. No owner, no procedure, no date. Standards-to-plan. Best?",
      [
      "Highlighting is implementation.",
      "Translate the clause into a site plan with an owner and a date.",
      "FTA on the highlighter.",
      "A TLV for ISO.",
      ],
      1,
      "Clause → owned plan.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 19,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.19",
      "Poster at Building C autoclave says safety first; night leads reward only 12 units/hour. Culture stem. Best read?",
      [
      "The poster is the culture.",
      "Culture is what is rewarded and tolerated.",
      "TRIR is culture by definition.",
      "TLV is culture.",
      ],
      1,
      "Lived vs laminated.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 20,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.20",
      "Investigation at Night-shift warehouse mezzanine names 'careless worker' before the scene is preserved. Error?",
      [
      "Blame is root cause.",
      "Preserve, collect, analyze; do not skip to blame.",
      "FORM TRIR.",
      "UNIT 24.45.",
      ],
      1,
      "Method before verdict.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 21,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.21",
      "CAPA at Unit 7 hydrotreater: 'be more careful' after a 18-stitch laceration. Sister line still open. Best?",
      [
      "Add 'please' to the memo.",
      "Change the system that allowed the cut; preventive for the sister line.",
      "A slogan.",
      "Insurance as the only CA.",
      ],
      1,
      "CAPA is a system change.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 22,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.22",
      "Temporary hose in a covered process at Clinic sterile processing for 24 months. No MOC. Error?",
      [
      "Temporary never needs MOC.",
      "Duration does not erase MOC. Change the process then the procedure.",
      "TIME as fatality clock.",
      "PELTLV.",
      ],
      1,
      "Temporary can still be MOC.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 23,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.23",
      "Top event 'overfill' at Foundry shakeout drawn as a fault tree. Team computes RPN = 30. Error?",
      [
      "RPN is the FTA probability.",
      "FTA is logic/cut sets; RPN is FMEA.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "Wrong tool.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 24,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.24",
      "FMEA at Cold-storage dock: S=36 O=4 D=5. Product used as P(top event) on a tree. Error?",
      [
      "RPN is P(top).",
      "RPN prioritizes rows; it is not FTA probability.",
      "HIER.",
      "TIME.",
      ],
      1,
      "RPN ≠ P(top).",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 25,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.25",
      "Safety case at Paint kitchen mezzanine = a 45-inch stack of unused JHAs. Error?",
      [
      "Volume is the argument.",
      "Argument plus evidence that risk is tolerated, not a pile.",
      "UNIT.",
      "TIME.",
      ],
      1,
      "Safety case ≠ stack.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 26,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.26",
      "Only lagging TRIR 100.48 is on the board at Substation yard. Leading inspections died. Best?",
      [
      "TRIR is sufficient leading.",
      "Pair leading activities with lagging outcomes.",
      "TLV.",
      "ROI only.",
      ],
      1,
      "Leading vs lagging.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 27,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.27",
      "Team at Grain silo catwalk audits OH&S using ISO 14001 as the OH&S MSS. Error?",
      [
      "14001 is the OH&S MSS.",
      "45001 is OH&S; 14001 is environmental; 19011 is audit guidance.",
      "TOOL FTA.",
      "PELTLV.",
      ],
      1,
      "Do not swap MSS families.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 28,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.28",
      "Z10 treated as word-for-word 45001 at Hospital loading dock for every clause including clause 75. Best?",
      [
      "They are the same exam object in every word.",
      "Related family — do not assume identity; read the stem.",
      "Z10 is a noise PEL.",
      "Z10 is RCRA.",
      ],
      1,
      "Rhyme ≠ identical.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 29,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.29",
      "Audit at Battery formation room is a new hire walking around once with no competence criteria. 19011 flavor. Error?",
      [
      "A walk is automatically an audit.",
      "Audit principles, competence, evidence.",
      "PELTLV.",
      "FIN.",
      ],
      1,
      "Audit ≠ tour.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 30,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.30",
      "Policy at Sawmill green chain: 'we care.' No who/when/how. Pick?",
      [
      "Policy is the plan.",
      "Policy is intent; plan is who/when/how.",
      "A slogan as a procedure.",
      "Insurance as a policy owner.",
      ],
      1,
      "Do not swap policy and plan.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 31,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.31",
      "Medical diagnosis posted beside the OSHA log at Compressor shelter. Error?",
      [
      "Full medical detail is required on the wall.",
      "Keep required records for the clock; do not post medical details.",
      "UNIT.",
      "HIER.",
      ],
      1,
      "Privacy.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 32,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.32",
      "Control at Railcar unloading rack with no budget line and no owner. 'We will find $15000 later.' Error?",
      [
      "Goodwill is a budget.",
      "A control needs a funded owner.",
      "TLV.",
      "FTA.",
      ],
      1,
      "Budget is part of the control.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 33,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.33",
      "Leadership at Plating line 2: one speech per year, no resources, no accountability after a 8-day outage. Best?",
      [
      "The speech is leadership.",
      "Resource, accountability, presence.",
      "A poster.",
      "DART as leadership.",
      ],
      1,
      "Lived leadership.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 34,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.34",
      "RACI at Roof chiller deck marks 12 people Accountable for the same permit-space program. Error?",
      [
      "More Accountable is better.",
      "One Accountable; many may be Responsible.",
      "RACI is a PEL.",
      "RACI is TRIR.",
      ],
      1,
      "A = one.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 35,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.35",
      "Skewed cost set at Mud-logging shack. Stem asks median. Candidate reports the mean pulled by one $1200k lawsuit. Error?",
      [
      "Mean always.",
      "Median for skew when asked.",
      "UNIT.",
      "PELTLV.",
      ],
      1,
      "Mean vs median.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 36,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.36",
      "95% CI around a mean used as if it were a PEL at Die-change bay. Error?",
      [
      "CI is a PEL.",
      "A confidence interval is not an OEL.",
      "HIER.",
      "TIME.",
      ],
      1,
      "CI ≠ PEL.",
      "PELTLV",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 37,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.37",
      "Unsorted bars at Aqueous washer cell. 'Pareto' by coloring the shortest bar. Error?",
      [
      "Shortest is vital few.",
      "Sort contribution descending.",
      "UNIT.",
      "HIER.",
      ],
      1,
      "Pareto is a sort.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 38,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.38",
      "Fatality at Flare knockout pad at 09:00 Monday. OSHA notified 22:00 Tuesday. Clock?",
      [
      "OK — 24 hours for fatalities.",
      "Fatalities: 8-hour clock. Certain hospitalizations/amputations/loss of eye: 24 hours.",
      "PELTLV.",
      "FORM TRIR.",
      ],
      1,
      "8-hour fatality clock.",
      "TIME",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 85,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.85",
      "14001 aspect register empty at Pharmacy compounding hood; 45001 binder is 36 cm thick. Environmental MSS stem. Best?",
      [
      "The 45001 binder covers 14001.",
      "14001 needs environmental aspects/impacts.",
      "A hard hat.",
      "TRIR.",
      ],
      1,
      "Different MSS object.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 17,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.17",
      "Internal audit at Concrete batch tower: only the line lead grades their own 45001 clauses. Independence named in the last sentence. Error?",
      [
      "Self-grade is independence.",
      "Objectivity/independence proportional to the stem.",
      "PELTLV.",
      "RWL.",
      ],
      1,
      "Independence.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 18,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.18",
      "OSHA logs at Fiber layup room shredded at 48 days to 'help privacy,' still inside the keep period. Error?",
      [
      "Privacy always wins over retention.",
      "Keep required records for the statutory clock; privacy is not a shredder for legal logs.",
      "HIER.",
      "FORM.",
      ],
      1,
      "Retention clock.",
      "TIME",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 19,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.19",
      "Gap analysis at Quench pit starts with branded mugs and a new slogan. Clause 60 of the adopted MSS is still unmet. Error?",
      [
      "Slogan is the gap analysis.",
      "Gap is current vs required; merch is not the analysis.",
      "UNIT.",
      "PELTLV.",
      ],
      1,
      "Diagnose before merch.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 20,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.20",
      "Lab solvent crib highlighted an ISO clause in yellow. No owner, no procedure, no date. Standards-to-plan. Best?",
      [
      "Highlighting is implementation.",
      "Translate the clause into a site plan with an owner and a date.",
      "FTA on the highlighter.",
      "A TLV for ISO.",
      ],
      1,
      "Clause → owned plan.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 21,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.21",
      "Poster at Shipyard dry dock says safety first; night leads reward only 90 units/hour. Culture stem. Best read?",
      [
      "The poster is the culture.",
      "Culture is what is rewarded and tolerated.",
      "TRIR is culture by definition.",
      "TLV is culture.",
      ],
      1,
      "Lived vs laminated.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 22,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.22",
      "Investigation at Data-center generator hall names 'careless worker' before the scene is preserved. Error?",
      [
      "Blame is root cause.",
      "Preserve, collect, analyze; do not skip to blame.",
      "FORM TRIR.",
      "UNIT 24.45.",
      ],
      1,
      "Method before verdict.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 23,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.23",
      "CAPA at Mine shop welding bay: 'be more careful' after a 120-stitch laceration. Sister line still open. Best?",
      [
      "Add 'please' to the memo.",
      "Change the system that allowed the cut; preventive for the sister line.",
      "A slogan.",
      "Insurance as the only CA.",
      ],
      1,
      "CAPA is a system change.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 24,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.24",
      "Temporary hose in a covered process at North pier tank farm for 6 months. No MOC. Error?",
      [
      "Temporary never needs MOC.",
      "Duration does not erase MOC. Change the process then the procedure.",
      "TIME as fatality clock.",
      "PELTLV.",
      ],
      1,
      "Temporary can still be MOC.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 25,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.25",
      "Top event 'overfill' at Line 4 stamping cell drawn as a fault tree. Team computes RPN = 8. Error?",
      [
      "RPN is the FTA probability.",
      "FTA is logic/cut sets; RPN is FMEA.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "Wrong tool.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 26,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.26",
      "FMEA at Building C autoclave: S=12 O=4 D=5. Product used as P(top event) on a tree. Error?",
      [
      "RPN is P(top).",
      "RPN prioritizes rows; it is not FTA probability.",
      "HIER.",
      "TIME.",
      ],
      1,
      "RPN ≠ P(top).",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 27,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.27",
      "Safety case at Night-shift warehouse mezzanine = a 15-inch stack of unused JHAs. Error?",
      [
      "Volume is the argument.",
      "Argument plus evidence that risk is tolerated, not a pile.",
      "UNIT.",
      "TIME.",
      ],
      1,
      "Safety case ≠ stack.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 28,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.28",
      "Only lagging TRIR 28.18 is on the board at Unit 7 hydrotreater. Leading inspections died. Best?",
      [
      "TRIR is sufficient leading.",
      "Pair leading activities with lagging outcomes.",
      "TLV.",
      "ROI only.",
      ],
      1,
      "Leading vs lagging.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 29,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.29",
      "Team at Clinic sterile processing audits OH&S using ISO 14001 as the OH&S MSS. Error?",
      [
      "14001 is the OH&S MSS.",
      "45001 is OH&S; 14001 is environmental; 19011 is audit guidance.",
      "TOOL FTA.",
      "PELTLV.",
      ],
      1,
      "Do not swap MSS families.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 30,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.30",
      "Z10 treated as word-for-word 45001 at Foundry shakeout for every clause including clause 30. Best?",
      [
      "They are the same exam object in every word.",
      "Related family — do not assume identity; read the stem.",
      "Z10 is a noise PEL.",
      "Z10 is RCRA.",
      ],
      1,
      "Rhyme ≠ identical.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 31,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.31",
      "Audit at Cold-storage dock is a new hire walking around once with no competence criteria. 19011 flavor. Error?",
      [
      "A walk is automatically an audit.",
      "Audit principles, competence, evidence.",
      "PELTLV.",
      "FIN.",
      ],
      1,
      "Audit ≠ tour.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 32,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.32",
      "Policy at Paint kitchen mezzanine: 'we care.' No who/when/how. Pick?",
      [
      "Policy is the plan.",
      "Policy is intent; plan is who/when/how.",
      "A slogan as a procedure.",
      "Insurance as a policy owner.",
      ],
      1,
      "Do not swap policy and plan.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 33,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.33",
      "Medical diagnosis posted beside the OSHA log at Substation yard. Error?",
      [
      "Full medical detail is required on the wall.",
      "Keep required records for the clock; do not post medical details.",
      "UNIT.",
      "HIER.",
      ],
      1,
      "Privacy.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 34,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.34",
      "Control at Grain silo catwalk with no budget line and no owner. 'We will find $500 later.' Error?",
      [
      "Goodwill is a budget.",
      "A control needs a funded owner.",
      "TLV.",
      "FTA.",
      ],
      1,
      "Budget is part of the control.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 35,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.35",
      "Leadership at Hospital loading dock: one speech per year, no resources, no accountability after a 75-day outage. Best?",
      [
      "The speech is leadership.",
      "Resource, accountability, presence.",
      "A poster.",
      "DART as leadership.",
      ],
      1,
      "Lived leadership.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 36,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.36",
      "RACI at Battery formation room marks 90 people Accountable for the same permit-space program. Error?",
      [
      "More Accountable is better.",
      "One Accountable; many may be Responsible.",
      "RACI is a PEL.",
      "RACI is TRIR.",
      ],
      1,
      "A = one.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 37,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.37",
      "Skewed cost set at Sawmill green chain. Stem asks median. Candidate reports the mean pulled by one $2000k lawsuit. Error?",
      [
      "Mean always.",
      "Median for skew when asked.",
      "UNIT.",
      "PELTLV.",
      ],
      1,
      "Mean vs median.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 38,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.38",
      "95% CI around a mean used as if it were a PEL at Compressor shelter. Error?",
      [
      "CI is a PEL.",
      "A confidence interval is not an OEL.",
      "HIER.",
      "TIME.",
      ],
      1,
      "CI ≠ PEL.",
      "PELTLV",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 85,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.85",
      "Unsorted bars at Railcar unloading rack. 'Pareto' by coloring the shortest bar. Error?",
      [
      "Shortest is vital few.",
      "Sort contribution descending.",
      "UNIT.",
      "HIER.",
      ],
      1,
      "Pareto is a sort.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 17,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.17",
      "Fatality at Plating line 2 at 09:00 Monday. OSHA notified 22:00 Tuesday. Clock?",
      [
      "OK — 24 hours for fatalities.",
      "Fatalities: 8-hour clock. Certain hospitalizations/amputations/loss of eye: 24 hours.",
      "PELTLV.",
      "FORM TRIR.",
      ],
      1,
      "8-hour fatality clock.",
      "TIME",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 18,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.18",
      "14001 aspect register empty at Roof chiller deck; 45001 binder is 12 cm thick. Environmental MSS stem. Best?",
      [
      "The 45001 binder covers 14001.",
      "14001 needs environmental aspects/impacts.",
      "A hard hat.",
      "TRIR.",
      ],
      1,
      "Different MSS object.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 19,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.19",
      "Internal audit at Mud-logging shack: only the line lead grades their own 45001 clauses. Independence named in the last sentence. Error?",
      [
      "Self-grade is independence.",
      "Objectivity/independence proportional to the stem.",
      "PELTLV.",
      "RWL.",
      ],
      1,
      "Independence.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 20,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.20",
      "OSHA logs at Die-change bay shredded at 18 days to 'help privacy,' still inside the keep period. Error?",
      [
      "Privacy always wins over retention.",
      "Keep required records for the statutory clock; privacy is not a shredder for legal logs.",
      "HIER.",
      "FORM.",
      ],
      1,
      "Retention clock.",
      "TIME",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 21,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.21",
      "Gap analysis at Aqueous washer cell starts with branded mugs and a new slogan. Clause 24 of the adopted MSS is still unmet. Error?",
      [
      "Slogan is the gap analysis.",
      "Gap is current vs required; merch is not the analysis.",
      "UNIT.",
      "PELTLV.",
      ],
      1,
      "Diagnose before merch.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 22,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.22",
      "Flare knockout pad highlighted an ISO clause in yellow. No owner, no procedure, no date. Standards-to-plan. Best?",
      [
      "Highlighting is implementation.",
      "Translate the clause into a site plan with an owner and a date.",
      "FTA on the highlighter.",
      "A TLV for ISO.",
      ],
      1,
      "Clause → owned plan.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 23,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.23",
      "Poster at Pharmacy compounding hood says safety first; night leads reward only 36 units/hour. Culture stem. Best read?",
      [
      "The poster is the culture.",
      "Culture is what is rewarded and tolerated.",
      "TRIR is culture by definition.",
      "TLV is culture.",
      ],
      1,
      "Lived vs laminated.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 24,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.24",
      "Investigation at Concrete batch tower names 'careless worker' before the scene is preserved. Error?",
      [
      "Blame is root cause.",
      "Preserve, collect, analyze; do not skip to blame.",
      "FORM TRIR.",
      "UNIT 24.45.",
      ],
      1,
      "Method before verdict.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 25,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.25",
      "CAPA at Fiber layup room: 'be more careful' after a 48-stitch laceration. Sister line still open. Best?",
      [
      "Add 'please' to the memo.",
      "Change the system that allowed the cut; preventive for the sister line.",
      "A slogan.",
      "Insurance as the only CA.",
      ],
      1,
      "CAPA is a system change.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 26,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.26",
      "Temporary hose in a covered process at Quench pit for 60 months. No MOC. Error?",
      [
      "Temporary never needs MOC.",
      "Duration does not erase MOC. Change the process then the procedure.",
      "TIME as fatality clock.",
      "PELTLV.",
      ],
      1,
      "Temporary can still be MOC.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 27,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.27",
      "Top event 'overfill' at Lab solvent crib drawn as a fault tree. Team computes RPN = 75. Error?",
      [
      "RPN is the FTA probability.",
      "FTA is logic/cut sets; RPN is FMEA.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "Wrong tool.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 28,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.28",
      "FMEA at Shipyard dry dock: S=90 O=4 D=5. Product used as P(top event) on a tree. Error?",
      [
      "RPN is P(top).",
      "RPN prioritizes rows; it is not FTA probability.",
      "HIER.",
      "TIME.",
      ],
      1,
      "RPN ≠ P(top).",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 29,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.29",
      "Safety case at Data-center generator hall = a 95-inch stack of unused JHAs. Error?",
      [
      "Volume is the argument.",
      "Argument plus evidence that risk is tolerated, not a pile.",
      "UNIT.",
      "TIME.",
      ],
      1,
      "Safety case ≠ stack.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 30,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.30",
      "Only lagging TRIR 100.120 is on the board at Mine shop welding bay. Leading inspections died. Best?",
      [
      "TRIR is sufficient leading.",
      "Pair leading activities with lagging outcomes.",
      "TLV.",
      "ROI only.",
      ],
      1,
      "Leading vs lagging.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 31,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.31",
      "Team at North pier tank farm audits OH&S using ISO 14001 as the OH&S MSS. Error?",
      [
      "14001 is the OH&S MSS.",
      "45001 is OH&S; 14001 is environmental; 19011 is audit guidance.",
      "TOOL FTA.",
      "PELTLV.",
      ],
      1,
      "Do not swap MSS families.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 32,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.32",
      "Z10 treated as word-for-word 45001 at Line 4 stamping cell for every clause including clause 8. Best?",
      [
      "They are the same exam object in every word.",
      "Related family — do not assume identity; read the stem.",
      "Z10 is a noise PEL.",
      "Z10 is RCRA.",
      ],
      1,
      "Rhyme ≠ identical.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 33,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.33",
      "Audit at Building C autoclave is a new hire walking around once with no competence criteria. 19011 flavor. Error?",
      [
      "A walk is automatically an audit.",
      "Audit principles, competence, evidence.",
      "PELTLV.",
      "FIN.",
      ],
      1,
      "Audit ≠ tour.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 34,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.34",
      "Policy at Night-shift warehouse mezzanine: 'we care.' No who/when/how. Pick?",
      [
      "Policy is the plan.",
      "Policy is intent; plan is who/when/how.",
      "A slogan as a procedure.",
      "Insurance as a policy owner.",
      ],
      1,
      "Do not swap policy and plan.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 35,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.35",
      "Medical diagnosis posted beside the OSHA log at Unit 7 hydrotreater. Error?",
      [
      "Full medical detail is required on the wall.",
      "Keep required records for the clock; do not post medical details.",
      "UNIT.",
      "HIER.",
      ],
      1,
      "Privacy.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 36,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.36",
      "Control at Clinic sterile processing with no budget line and no owner. 'We will find $800 later.' Error?",
      [
      "Goodwill is a budget.",
      "A control needs a funded owner.",
      "TLV.",
      "FTA.",
      ],
      1,
      "Budget is part of the control.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 37,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.37",
      "Leadership at Foundry shakeout: one speech per year, no resources, no accountability after a 30-day outage. Best?",
      [
      "The speech is leadership.",
      "Resource, accountability, presence.",
      "A poster.",
      "DART as leadership.",
      ],
      1,
      "Lived leadership.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 38,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.38",
      "RACI at Cold-storage dock marks 36 people Accountable for the same permit-space program. Error?",
      [
      "More Accountable is better.",
      "One Accountable; many may be Responsible.",
      "RACI is a PEL.",
      "RACI is TRIR.",
      ],
      1,
      "A = one.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 85,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.85",
      "Skewed cost set at Paint kitchen mezzanine. Stem asks median. Candidate reports the mean pulled by one $2500k lawsuit. Error?",
      [
      "Mean always.",
      "Median for skew when asked.",
      "UNIT.",
      "PELTLV.",
      ],
      1,
      "Mean vs median.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 17,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.17",
      "95% CI around a mean used as if it were a PEL at Substation yard. Error?",
      [
      "CI is a PEL.",
      "A confidence interval is not an OEL.",
      "HIER.",
      "TIME.",
      ],
      1,
      "CI ≠ PEL.",
      "PELTLV",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 18,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.18",
      "Unsorted bars at Grain silo catwalk. 'Pareto' by coloring the shortest bar. Error?",
      [
      "Shortest is vital few.",
      "Sort contribution descending.",
      "UNIT.",
      "HIER.",
      ],
      1,
      "Pareto is a sort.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 19,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.19",
      "Fatality at Hospital loading dock at 09:00 Monday. OSHA notified 22:00 Tuesday. Clock?",
      [
      "OK — 24 hours for fatalities.",
      "Fatalities: 8-hour clock. Certain hospitalizations/amputations/loss of eye: 24 hours.",
      "PELTLV.",
      "FORM TRIR.",
      ],
      1,
      "8-hour fatality clock.",
      "TIME",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 20,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.20",
      "14001 aspect register empty at Battery formation room; 45001 binder is 90 cm thick. Environmental MSS stem. Best?",
      [
      "The 45001 binder covers 14001.",
      "14001 needs environmental aspects/impacts.",
      "A hard hat.",
      "TRIR.",
      ],
      1,
      "Different MSS object.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 21,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.21",
      "Internal audit at Sawmill green chain: only the line lead grades their own 45001 clauses. Independence named in the last sentence. Error?",
      [
      "Self-grade is independence.",
      "Objectivity/independence proportional to the stem.",
      "PELTLV.",
      "RWL.",
      ],
      1,
      "Independence.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 22,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.22",
      "OSHA logs at Compressor shelter shredded at 120 days to 'help privacy,' still inside the keep period. Error?",
      [
      "Privacy always wins over retention.",
      "Keep required records for the statutory clock; privacy is not a shredder for legal logs.",
      "HIER.",
      "FORM.",
      ],
      1,
      "Retention clock.",
      "TIME",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 23,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.23",
      "Gap analysis at Railcar unloading rack starts with branded mugs and a new slogan. Clause 6 of the adopted MSS is still unmet. Error?",
      [
      "Slogan is the gap analysis.",
      "Gap is current vs required; merch is not the analysis.",
      "UNIT.",
      "PELTLV.",
      ],
      1,
      "Diagnose before merch.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 24,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.24",
      "Plating line 2 highlighted an ISO clause in yellow. No owner, no procedure, no date. Standards-to-plan. Best?",
      [
      "Highlighting is implementation.",
      "Translate the clause into a site plan with an owner and a date.",
      "FTA on the highlighter.",
      "A TLV for ISO.",
      ],
      1,
      "Clause → owned plan.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 25,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.25",
      "Poster at Roof chiller deck says safety first; night leads reward only 12 units/hour. Culture stem. Best read?",
      [
      "The poster is the culture.",
      "Culture is what is rewarded and tolerated.",
      "TRIR is culture by definition.",
      "TLV is culture.",
      ],
      1,
      "Lived vs laminated.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 26,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.26",
      "Investigation at Mud-logging shack names 'careless worker' before the scene is preserved. Error?",
      [
      "Blame is root cause.",
      "Preserve, collect, analyze; do not skip to blame.",
      "FORM TRIR.",
      "UNIT 24.45.",
      ],
      1,
      "Method before verdict.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 27,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.27",
      "CAPA at Die-change bay: 'be more careful' after a 18-stitch laceration. Sister line still open. Best?",
      [
      "Add 'please' to the memo.",
      "Change the system that allowed the cut; preventive for the sister line.",
      "A slogan.",
      "Insurance as the only CA.",
      ],
      1,
      "CAPA is a system change.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 28,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.28",
      "Temporary hose in a covered process at Aqueous washer cell for 24 months. No MOC. Error?",
      [
      "Temporary never needs MOC.",
      "Duration does not erase MOC. Change the process then the procedure.",
      "TIME as fatality clock.",
      "PELTLV.",
      ],
      1,
      "Temporary can still be MOC.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 29,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.29",
      "Top event 'overfill' at Flare knockout pad drawn as a fault tree. Team computes RPN = 30. Error?",
      [
      "RPN is the FTA probability.",
      "FTA is logic/cut sets; RPN is FMEA.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "Wrong tool.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 30,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.30",
      "FMEA at Pharmacy compounding hood: S=36 O=4 D=5. Product used as P(top event) on a tree. Error?",
      [
      "RPN is P(top).",
      "RPN prioritizes rows; it is not FTA probability.",
      "HIER.",
      "TIME.",
      ],
      1,
      "RPN ≠ P(top).",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 31,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.31",
      "Safety case at Concrete batch tower = a 45-inch stack of unused JHAs. Error?",
      [
      "Volume is the argument.",
      "Argument plus evidence that risk is tolerated, not a pile.",
      "UNIT.",
      "TIME.",
      ],
      1,
      "Safety case ≠ stack.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 32,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.32",
      "Only lagging TRIR 28.48 is on the board at Fiber layup room. Leading inspections died. Best?",
      [
      "TRIR is sufficient leading.",
      "Pair leading activities with lagging outcomes.",
      "TLV.",
      "ROI only.",
      ],
      1,
      "Leading vs lagging.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 33,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.33",
      "Team at Quench pit audits OH&S using ISO 14001 as the OH&S MSS. Error?",
      [
      "14001 is the OH&S MSS.",
      "45001 is OH&S; 14001 is environmental; 19011 is audit guidance.",
      "TOOL FTA.",
      "PELTLV.",
      ],
      1,
      "Do not swap MSS families.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 34,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.34",
      "Z10 treated as word-for-word 45001 at Lab solvent crib for every clause including clause 75. Best?",
      [
      "They are the same exam object in every word.",
      "Related family — do not assume identity; read the stem.",
      "Z10 is a noise PEL.",
      "Z10 is RCRA.",
      ],
      1,
      "Rhyme ≠ identical.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 35,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.35",
      "Audit at Shipyard dry dock is a new hire walking around once with no competence criteria. 19011 flavor. Error?",
      [
      "A walk is automatically an audit.",
      "Audit principles, competence, evidence.",
      "PELTLV.",
      "FIN.",
      ],
      1,
      "Audit ≠ tour.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 36,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.36",
      "Policy at Data-center generator hall: 'we care.' No who/when/how. Pick?",
      [
      "Policy is the plan.",
      "Policy is intent; plan is who/when/how.",
      "A slogan as a procedure.",
      "Insurance as a policy owner.",
      ],
      1,
      "Do not swap policy and plan.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 37,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.37",
      "Medical diagnosis posted beside the OSHA log at Mine shop welding bay. Error?",
      [
      "Full medical detail is required on the wall.",
      "Keep required records for the clock; do not post medical details.",
      "UNIT.",
      "HIER.",
      ],
      1,
      "Privacy.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 38,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.38",
      "Control at North pier tank farm with no budget line and no owner. 'We will find $1200 later.' Error?",
      [
      "Goodwill is a budget.",
      "A control needs a funded owner.",
      "TLV.",
      "FTA.",
      ],
      1,
      "Budget is part of the control.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 85,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.85",
      "Leadership at Line 4 stamping cell: one speech per year, no resources, no accountability after a 8-day outage. Best?",
      [
      "The speech is leadership.",
      "Resource, accountability, presence.",
      "A poster.",
      "DART as leadership.",
      ],
      1,
      "Lived leadership.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 17,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.17",
      "RACI at Building C autoclave marks 12 people Accountable for the same permit-space program. Error?",
      [
      "More Accountable is better.",
      "One Accountable; many may be Responsible.",
      "RACI is a PEL.",
      "RACI is TRIR.",
      ],
      1,
      "A = one.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 18,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.18",
      "Skewed cost set at Night-shift warehouse mezzanine. Stem asks median. Candidate reports the mean pulled by one $4000k lawsuit. Error?",
      [
      "Mean always.",
      "Median for skew when asked.",
      "UNIT.",
      "PELTLV.",
      ],
      1,
      "Mean vs median.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 19,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.19",
      "95% CI around a mean used as if it were a PEL at Unit 7 hydrotreater. Error?",
      [
      "CI is a PEL.",
      "A confidence interval is not an OEL.",
      "HIER.",
      "TIME.",
      ],
      1,
      "CI ≠ PEL.",
      "PELTLV",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 20,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.20",
      "Unsorted bars at Clinic sterile processing. 'Pareto' by coloring the shortest bar. Error?",
      [
      "Shortest is vital few.",
      "Sort contribution descending.",
      "UNIT.",
      "HIER.",
      ],
      1,
      "Pareto is a sort.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 21,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.21",
      "Fatality at Foundry shakeout at 09:00 Monday. OSHA notified 22:00 Tuesday. Clock?",
      [
      "OK — 24 hours for fatalities.",
      "Fatalities: 8-hour clock. Certain hospitalizations/amputations/loss of eye: 24 hours.",
      "PELTLV.",
      "FORM TRIR.",
      ],
      1,
      "8-hour fatality clock.",
      "TIME",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 22,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.22",
      "14001 aspect register empty at Cold-storage dock; 45001 binder is 36 cm thick. Environmental MSS stem. Best?",
      [
      "The 45001 binder covers 14001.",
      "14001 needs environmental aspects/impacts.",
      "A hard hat.",
      "TRIR.",
      ],
      1,
      "Different MSS object.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 23,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.23",
      "Internal audit at Paint kitchen mezzanine: only the line lead grades their own 45001 clauses. Independence named in the last sentence. Error?",
      [
      "Self-grade is independence.",
      "Objectivity/independence proportional to the stem.",
      "PELTLV.",
      "RWL.",
      ],
      1,
      "Independence.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 24,
    kind: "challenge",
    topic: "d2",
    ...exam(
      "CHAL.D2.24",
      "OSHA logs at Substation yard shredded at 48 days to 'help privacy,' still inside the keep period. Error?",
      [
      "Privacy always wins over retention.",
      "Keep required records for the statutory clock; privacy is not a shredder for legal logs.",
      "HIER.",
      "FORM.",
      ],
      1,
      "Retention clock.",
      "TIME",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  }
];
