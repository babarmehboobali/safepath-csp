/** Searchable EHS topic map → existing catalog classes (no new class numbers). */
export type TopicModule = {
  id: number;
  title: string;
  category: string;
  blurb: string;
  domain: number;
  classIds: number[];
  extraHrefs?: { href: string; label: string }[];
};

export const TOPIC_MODULES: TopicModule[] = [
  { id: 1, title: "Applied mathematics & physics", category: "Sciences", blurb: "Energy, tension, fluid and load checks.", domain: 1, classIds: [72, 90, 105, 130], extraHrefs: [{ href: "/math", label: "Math solvers" }] },
  { id: 2, title: "Occupational statistics & probability", category: "Sciences", blurb: "Descriptive stats, CI, and probability language.", domain: 2, classIds: [26, 36, 37, 38, 85, 92, 106] },
  { id: 3, title: "Industrial toxicology principles", category: "Health", blurb: "Dose–response, OELs, ADME.", domain: 6, classIds: [63, 68, 84], extraHrefs: [{ href: "/tox", label: "Tox lab" }] },
  { id: 4, title: "Target-organ pathology", category: "Health", blurb: "Hepato / nephro / neuro / hemo / pulmonary targets.", domain: 6, classIds: [68, 98], extraHrefs: [{ href: "/tox", label: "Tox panels" }] },
  { id: 5, title: "Industrial hygiene air sampling", category: "Health", blurb: "AREC path and sampling strategy.", domain: 6, classIds: [61, 62, 69, 92] },
  { id: 6, title: "Dilution & local exhaust ventilation", category: "Engineering", blurb: "Q=VA, capture, dilution airflow.", domain: 6, classIds: [81, 101, 124], extraHrefs: [{ href: "/math", label: "Dilution solver" }] },
  { id: 7, title: "Occupational noise & audiometry", category: "Health", blurb: "OSHA 5 dB vs NIOSH 3 dB, dose, TWA.", domain: 6, classIds: [64, 83, 125], extraHrefs: [{ href: "/math", label: "Noise solver" }] },
  { id: 8, title: "Ionizing radiation & shielding", category: "Health", blurb: "Inverse square, HVL, ionizing agents.", domain: 6, classIds: [65] },
  { id: 9, title: "Non-ionizing radiation & lasers", category: "Health", blurb: "Laser classes and exposure control ideas.", domain: 6, classIds: [65] },
  { id: 10, title: "Heat stress & WBGT", category: "Health", blurb: "WBGT, workload, acclimatization.", domain: 6, classIds: [66] },
  { id: 11, title: "Microbiology & biological agents", category: "Health", blurb: "Bloodborne, aerosols, BSL teaching bands.", domain: 6, classIds: [67] },
  { id: 12, title: "Ergonomics & MSDs", category: "Ergonomics", blurb: "Posture risk language and CTDs.", domain: 6, classIds: [15, 70], extraHrefs: [{ href: "/ergo", label: "RULA/REBA" }] },
  { id: 13, title: "NIOSH manual lifting equation", category: "Ergonomics", blurb: "RWL, LI, six multipliers.", domain: 6, classIds: [15, 70, 108], extraHrefs: [{ href: "/math?topic=rwl", label: "RWL topic" }] },
  { id: 14, title: "Fire dynamics & explosion physics", category: "Fire", blurb: "Deflagration, ignition energy, BLEVE lore.", domain: 4, classIds: [50, 80, 82] },
  { id: 15, title: "Flammable & combustible liquids", category: "Fire", blurb: "NFPA 30 classes and storage controls.", domain: 5, classIds: [56, 50, 80] },
  { id: 16, title: "Fire protection & suppression", category: "Fire", blurb: "Sprinklers, agents, protection systems.", domain: 4, classIds: [51, 103, 122] },
  { id: 17, title: "Life safety & egress", category: "Fire", blurb: "Means of egress and occupant protection.", domain: 1, classIds: [10, 11, 102] },
  { id: 18, title: "Electrical safety & arc flash", category: "Electrical", blurb: "Boundaries, incident energy, PPE categories.", domain: 1, classIds: [4, 93] },
  { id: 19, title: "Hazardous locations classification", category: "Electrical", blurb: "Class/Division language for gases and dusts.", domain: 1, classIds: [4, 80] },
  { id: 20, title: "Lockout/tagout & hazardous energy", category: "Safety", blurb: "Zero energy, group LOTO, verification.", domain: 1, classIds: [5, 117] },
  { id: 21, title: "Confined space entry", category: "Safety", blurb: "PRCS testing order, ventilation, rescue.", domain: 1, classIds: [9] },
  { id: 22, title: "Machine guarding & kinetic hazards", category: "Engineering", blurb: "Guards, presence sensing, caught-in energy.", domain: 1, classIds: [8, 16, 79, 109] },
  { id: 23, title: "Rigging, cranes & material handling", category: "Safety", blurb: "Load charts, sling angles, PIT interfaces.", domain: 1, classIds: [13, 14, 114], extraHrefs: [{ href: "/math", label: "Sling solver" }] },
  { id: 24, title: "Fall protection & prevention", category: "Safety", blurb: "Anchors, clearance, leading edge.", domain: 1, classIds: [6, 7, 116] },
  { id: 25, title: "Process safety management", category: "Process Safety", blurb: "PSM elements and engineering controls.", domain: 1, classIds: [3, 22, 87, 94, 118] },
  { id: 26, title: "HAZOP guide words", category: "Process Safety", blurb: "Guide-word deviations on process parameters.", domain: 3, classIds: [39, 41] },
  { id: 27, title: "FMEA", category: "Risk", blurb: "Failure modes, effects, and RPN discipline.", domain: 2, classIds: [24, 86] },
  { id: 28, title: "Fault tree & event tree", category: "Risk", blurb: "FTA/ETA logic and cut sets.", domain: 2, classIds: [23, 91, 113, 120] },
  { id: 29, title: "Safety instrumented systems", category: "Process Safety", blurb: "Instrumented layers inside process safety.", domain: 1, classIds: [3, 94] },
  { id: 30, title: "Prevention through Design", category: "Engineering", blurb: "Eliminate early in the lifecycle.", domain: 1, classIds: [1, 2, 42] },
  { id: 31, title: "Safety management systems", category: "Management", blurb: "ISO 45001 / Z10 style systems.", domain: 2, classIds: [17, 18, 27, 28, 29, 30, 31, 112] },
  { id: 32, title: "Organizational culture & human performance", category: "Management", blurb: "What is rewarded and tolerated.", domain: 2, classIds: [19, 32, 35] },
  { id: 33, title: "Behavior-based safety & HOP", category: "Management", blurb: "Observation programs inside a system.", domain: 2, classIds: [19, 34] },
  { id: 34, title: "Incident investigation & root cause", category: "Management", blurb: "Preserve, collect, analyze, CAPA.", domain: 2, classIds: [20, 21, 104, 105, 119] },
  { id: 35, title: "Emergency management & ICS", category: "Emergency", blurb: "ERP contents and incident command.", domain: 4, classIds: [47, 48, 53, 54, 88] },
  { id: 36, title: "Fleet safety & motor vehicles", category: "Safety", blurb: "Journey management and vehicle risk.", domain: 1, classIds: [12] },
  { id: 37, title: "Hazardous materials transport", category: "HazMat", blurb: "DOT transport and security interface.", domain: 4, classIds: [52] },
  { id: 38, title: "RCRA hazardous waste", category: "Environmental", blurb: "Waste determination, clocks, TSDF path.", domain: 5, classIds: [57, 58, 123] },
  { id: 39, title: "Air & water environmental programs", category: "Environmental", blurb: "Air/asbestos and stormwater-style controls.", domain: 5, classIds: [59, 60, 110, 111] },
  { id: 40, title: "SPCC & secondary containment", category: "Environmental", blurb: "Largest container plus freeboard — not autopilot 110%.", domain: 5, classIds: [55, 71, 107], extraHrefs: [{ href: "/challenge?n=10&d=5", label: "D5 challenge" }] },
  { id: 41, title: "Business continuity & risk financing", category: "Business", blurb: "BCP plus avoid/retain/share/transfer.", domain: 4, classIds: [33, 40, 43, 44, 45, 46, 49, 97, 115, 121] },
  { id: 42, title: "Adult learning & training design", category: "Training", blurb: "Needs assessment through effectiveness.", domain: 7, classIds: [73, 74, 75, 76, 77, 78, 89, 99, 100, 126, 127] },
  { id: 43, title: "Professional ethics & law", category: "Ethics", blurb: "BCSP canons and legal framing.", domain: 7, classIds: [25, 95, 96, 128, 129] },
];
