import { exam } from "../classes/types";
import type { GymQuestion } from "./types";

export const CHALLENGE_D5: GymQuestion[] = [
  {
    classId: 55,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.55",
      "Process at North pier tank farm can still not make the waste. Team celebrates a $500k scrubber as P2. Pick?",
      [
      "Scrubber is P2 by purchase price.",
      "Source reduction first if still open; end-of-pipe is not P2.",
      "A new drum.",
      "DART.",
      ],
      1,
      "P2 beats end-of-pipe when open.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 56,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.56",
      "Oxidizer stored with fuels at Line 4 stamping cell, alphabetical-only because the letters look neat. Best?",
      [
      "Alphabet is compatibility.",
      "Compatibility, containment, labels — not alphabet-only.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Storage chemistry.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 57,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.57",
      "Listed hazardous waste in an open unlabeled drum in the rain at Building C autoclave for 12 days. Best?",
      [
      "Rain is treatment.",
      "Contain, label, close, time limits, proper TSDF path.",
      "Pour to storm sewer as P2.",
      "Hard hat.",
      ],
      1,
      "Hazardous waste controls.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 58,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.58",
      "Spent lamps in a food-waste dumpster at Night-shift warehouse mezzanine. Universal waste path still open. Pick?",
      [
      "Dumpster is fine.",
      "Manage as universal waste (or hazardous if they do not qualify).",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Universal waste path.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 59,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.59",
      "Sustainability report at Unit 7 hydrotreater with no legal air-permit work. Stem asks the legal control first. Pick?",
      [
      "The report is the permit.",
      "Meet the legal environmental controls; the report is not a permit.",
      "Gloves.",
      "FTA.",
      ],
      1,
      "Legal vs brochure.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 60,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.60",
      "Dry ACM demo at Clinic sterile processing with a shop-vac. Option: more dust masks. Best?",
      [
      "Shop-vac + mask is NESHAPs-style control.",
      "Wet methods, containment, competent work — not dry shop-vac on ACM.",
      "TRIR.",
      "ROI only.",
      ],
      1,
      "Do not dry-grind ACM.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 55,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.55",
      "Empty drum that held listed waste at Foundry shakeout, valves open, no marks. 'Empty so trash.' Error?",
      [
      "Empty always means trash.",
      "Residue/empty-container rules still apply.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Empty drums can still be regulated.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 56,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.56",
      "GHS label removed at Cold-storage dock so the drum 'looks cleaner' after 36 weeks. Error?",
      [
      "Cleaner is safer.",
      "Keep identity/hazard labels.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Labels stay.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 57,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.57",
      "Net-zero poster at Paint kitchen mezzanine; solvent still dumped to the sink 45 times this month. Pick?",
      [
      "Poster is P2.",
      "Stop the illegal dump; poster is not a control.",
      "FTA.",
      "BEI.",
      ],
      1,
      "Legal baseline.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 58,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.58",
      "Satellite accumulation at Substation yard exceeds the time/volume the stem named. Option: a new slogan. Best?",
      [
      "Slogan resets the clock.",
      "Comply with the accumulation rules named; slogan is not RCRA.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Accumulation limits.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 59,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.59",
      "Spill kit at Grain silo catwalk is empty. Last sentence: P2/spills response. Best?",
      [
      "Empty kit is a plan.",
      "Stock, train, and use spill controls; empty is not ready.",
      "A poster.",
      "DART.",
      ],
      1,
      "Response capability.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 60,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.60",
      "Asbestos floor tile at Hospital loading dock can be left intact under a new floor. Option: dry grind to 'get it over with.' Pick?",
      [
      "Dry grind as P2.",
      "Avoid disturbing ACM if the stem leaves that open; do not dry grind.",
      "Shop-vac.",
      "A cone.",
      ],
      1,
      "Do not create the fiber.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 55,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.55",
      "Air permit limit at Battery formation room vs a glossy ESG chart that uses a different averaging time. Last sentence: legal limit. Pick?",
      [
      "ESG chart is the permit.",
      "The legal averaging time and limit win.",
      "PELTLV only.",
      "FIN only.",
      ],
      1,
      "Legal clock vs brochure.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 56,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.56",
      "Universal waste box at Sawmill green chain open, unlabeled, 95 months old. Best?",
      [
      "Open is required.",
      "Close, label, time limits as the universal-waste rules named.",
      "Food dumpster.",
      "TRIR.",
      ],
      1,
      "UW container rules.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 57,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.57",
      "Wastewater at Compressor shelter can be avoided by a dry process still open. Team specifies a larger clarifier. Pick?",
      [
      "Larger clarifier is P2.",
      "Dry/source reduction if still open.",
      "A new drum.",
      "A hard hat.",
      ],
      1,
      "Source first.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 58,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.58",
      "Manifest signed at Railcar unloading rack by someone with no authority, destination 'TBD.' Error?",
      [
      "TBD is a TSDF.",
      "Proper documentation/authorized signer/designated facility.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Paper path is part of the control.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 59,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.59",
      "Incompatible compressed gases at Plating line 2 stored nose-to-nose because the cage is pretty. Best?",
      [
      "Pretty cage is compatibility.",
      "Separate incompatibles; cage looks are not chemistry.",
      "BEI.",
      "FTA.",
      ],
      1,
      "Compatibility.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 60,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.60",
      "Fugitive solvent at Roof chiller deck. Substitution still open; team only buys a bigger stack. Pick?",
      [
      "Stack as P2.",
      "Substitute/reduce at source if still open.",
      "A poster.",
      "DART.",
      ],
      1,
      "Stack is not source reduction.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 55,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.55",
      "Used oil dumped on road dust at Mud-logging shack 'for control of silica.' Error?",
      [
      "Oil on dirt is a silica Table 1 method.",
      "Do not create an environmental release as a fake dust control.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Illegal dump is not silica control.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 56,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.56",
      "ESG slide at Die-change bay claims 'zero waste' while 18 drums of listed waste ship each week. Last sentence: legal truth. Pick?",
      [
      "The slide is the record.",
      "Legal waste still ships; the slide is not the record.",
      "A hard hat.",
      "A BEI.",
      ],
      1,
      "Do not let slides overwrite drums.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 57,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.57",
      "Process at Aqueous washer cell can still not make the waste. Team celebrates a $2500k scrubber as P2. Pick?",
      [
      "Scrubber is P2 by purchase price.",
      "Source reduction first if still open; end-of-pipe is not P2.",
      "A new drum.",
      "DART.",
      ],
      1,
      "P2 beats end-of-pipe when open.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 58,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.58",
      "Oxidizer stored with fuels at Flare knockout pad, alphabetical-only because the letters look neat. Best?",
      [
      "Alphabet is compatibility.",
      "Compatibility, containment, labels — not alphabet-only.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Storage chemistry.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 59,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.59",
      "Listed hazardous waste in an open unlabeled drum in the rain at Pharmacy compounding hood for 36 days. Best?",
      [
      "Rain is treatment.",
      "Contain, label, close, time limits, proper TSDF path.",
      "Pour to storm sewer as P2.",
      "Hard hat.",
      ],
      1,
      "Hazardous waste controls.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 60,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.60",
      "Spent lamps in a food-waste dumpster at Concrete batch tower. Universal waste path still open. Pick?",
      [
      "Dumpster is fine.",
      "Manage as universal waste (or hazardous if they do not qualify).",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Universal waste path.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 55,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.55",
      "Sustainability report at Fiber layup room with no legal air-permit work. Stem asks the legal control first. Pick?",
      [
      "The report is the permit.",
      "Meet the legal environmental controls; the report is not a permit.",
      "Gloves.",
      "FTA.",
      ],
      1,
      "Legal vs brochure.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 56,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.56",
      "Dry ACM demo at Quench pit with a shop-vac. Option: more dust masks. Best?",
      [
      "Shop-vac + mask is NESHAPs-style control.",
      "Wet methods, containment, competent work — not dry shop-vac on ACM.",
      "TRIR.",
      "ROI only.",
      ],
      1,
      "Do not dry-grind ACM.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 57,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.57",
      "Empty drum that held listed waste at Lab solvent crib, valves open, no marks. 'Empty so trash.' Error?",
      [
      "Empty always means trash.",
      "Residue/empty-container rules still apply.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Empty drums can still be regulated.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 58,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.58",
      "GHS label removed at Shipyard dry dock so the drum 'looks cleaner' after 90 weeks. Error?",
      [
      "Cleaner is safer.",
      "Keep identity/hazard labels.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Labels stay.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 59,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.59",
      "Net-zero poster at Data-center generator hall; solvent still dumped to the sink 95 times this month. Pick?",
      [
      "Poster is P2.",
      "Stop the illegal dump; poster is not a control.",
      "FTA.",
      "BEI.",
      ],
      1,
      "Legal baseline.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 60,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.60",
      "Satellite accumulation at Mine shop welding bay exceeds the time/volume the stem named. Option: a new slogan. Best?",
      [
      "Slogan resets the clock.",
      "Comply with the accumulation rules named; slogan is not RCRA.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Accumulation limits.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 55,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.55",
      "Spill kit at North pier tank farm is empty. Last sentence: P2/spills response. Best?",
      [
      "Empty kit is a plan.",
      "Stock, train, and use spill controls; empty is not ready.",
      "A poster.",
      "DART.",
      ],
      1,
      "Response capability.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 56,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.56",
      "Asbestos floor tile at Line 4 stamping cell can be left intact under a new floor. Option: dry grind to 'get it over with.' Pick?",
      [
      "Dry grind as P2.",
      "Avoid disturbing ACM if the stem leaves that open; do not dry grind.",
      "Shop-vac.",
      "A cone.",
      ],
      1,
      "Do not create the fiber.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 57,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.57",
      "Air permit limit at Building C autoclave vs a glossy ESG chart that uses a different averaging time. Last sentence: legal limit. Pick?",
      [
      "ESG chart is the permit.",
      "The legal averaging time and limit win.",
      "PELTLV only.",
      "FIN only.",
      ],
      1,
      "Legal clock vs brochure.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 58,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.58",
      "Universal waste box at Night-shift warehouse mezzanine open, unlabeled, 15 months old. Best?",
      [
      "Open is required.",
      "Close, label, time limits as the universal-waste rules named.",
      "Food dumpster.",
      "TRIR.",
      ],
      1,
      "UW container rules.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 59,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.59",
      "Wastewater at Unit 7 hydrotreater can be avoided by a dry process still open. Team specifies a larger clarifier. Pick?",
      [
      "Larger clarifier is P2.",
      "Dry/source reduction if still open.",
      "A new drum.",
      "A hard hat.",
      ],
      1,
      "Source first.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 60,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.60",
      "Manifest signed at Clinic sterile processing by someone with no authority, destination 'TBD.' Error?",
      [
      "TBD is a TSDF.",
      "Proper documentation/authorized signer/designated facility.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Paper path is part of the control.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 55,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.55",
      "Incompatible compressed gases at Foundry shakeout stored nose-to-nose because the cage is pretty. Best?",
      [
      "Pretty cage is compatibility.",
      "Separate incompatibles; cage looks are not chemistry.",
      "BEI.",
      "FTA.",
      ],
      1,
      "Compatibility.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 56,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.56",
      "Fugitive solvent at Cold-storage dock. Substitution still open; team only buys a bigger stack. Pick?",
      [
      "Stack as P2.",
      "Substitute/reduce at source if still open.",
      "A poster.",
      "DART.",
      ],
      1,
      "Stack is not source reduction.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 57,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.57",
      "Used oil dumped on road dust at Paint kitchen mezzanine 'for control of silica.' Error?",
      [
      "Oil on dirt is a silica Table 1 method.",
      "Do not create an environmental release as a fake dust control.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Illegal dump is not silica control.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 58,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.58",
      "ESG slide at Substation yard claims 'zero waste' while 48 drums of listed waste ship each week. Last sentence: legal truth. Pick?",
      [
      "The slide is the record.",
      "Legal waste still ships; the slide is not the record.",
      "A hard hat.",
      "A BEI.",
      ],
      1,
      "Do not let slides overwrite drums.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 59,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.59",
      "Process at Grain silo catwalk can still not make the waste. Team celebrates a $500k scrubber as P2. Pick?",
      [
      "Scrubber is P2 by purchase price.",
      "Source reduction first if still open; end-of-pipe is not P2.",
      "A new drum.",
      "DART.",
      ],
      1,
      "P2 beats end-of-pipe when open.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 60,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.60",
      "Oxidizer stored with fuels at Hospital loading dock, alphabetical-only because the letters look neat. Best?",
      [
      "Alphabet is compatibility.",
      "Compatibility, containment, labels — not alphabet-only.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Storage chemistry.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 55,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.55",
      "Listed hazardous waste in an open unlabeled drum in the rain at Battery formation room for 90 days. Best?",
      [
      "Rain is treatment.",
      "Contain, label, close, time limits, proper TSDF path.",
      "Pour to storm sewer as P2.",
      "Hard hat.",
      ],
      1,
      "Hazardous waste controls.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 56,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.56",
      "Spent lamps in a food-waste dumpster at Sawmill green chain. Universal waste path still open. Pick?",
      [
      "Dumpster is fine.",
      "Manage as universal waste (or hazardous if they do not qualify).",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Universal waste path.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 57,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.57",
      "Sustainability report at Compressor shelter with no legal air-permit work. Stem asks the legal control first. Pick?",
      [
      "The report is the permit.",
      "Meet the legal environmental controls; the report is not a permit.",
      "Gloves.",
      "FTA.",
      ],
      1,
      "Legal vs brochure.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 58,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.58",
      "Dry ACM demo at Railcar unloading rack with a shop-vac. Option: more dust masks. Best?",
      [
      "Shop-vac + mask is NESHAPs-style control.",
      "Wet methods, containment, competent work — not dry shop-vac on ACM.",
      "TRIR.",
      "ROI only.",
      ],
      1,
      "Do not dry-grind ACM.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 59,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.59",
      "Empty drum that held listed waste at Plating line 2, valves open, no marks. 'Empty so trash.' Error?",
      [
      "Empty always means trash.",
      "Residue/empty-container rules still apply.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Empty drums can still be regulated.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 60,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.60",
      "GHS label removed at Roof chiller deck so the drum 'looks cleaner' after 12 weeks. Error?",
      [
      "Cleaner is safer.",
      "Keep identity/hazard labels.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Labels stay.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 55,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.55",
      "Net-zero poster at Mud-logging shack; solvent still dumped to the sink 15 times this month. Pick?",
      [
      "Poster is P2.",
      "Stop the illegal dump; poster is not a control.",
      "FTA.",
      "BEI.",
      ],
      1,
      "Legal baseline.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 56,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.56",
      "Satellite accumulation at Die-change bay exceeds the time/volume the stem named. Option: a new slogan. Best?",
      [
      "Slogan resets the clock.",
      "Comply with the accumulation rules named; slogan is not RCRA.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Accumulation limits.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 57,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.57",
      "Spill kit at Aqueous washer cell is empty. Last sentence: P2/spills response. Best?",
      [
      "Empty kit is a plan.",
      "Stock, train, and use spill controls; empty is not ready.",
      "A poster.",
      "DART.",
      ],
      1,
      "Response capability.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 58,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.58",
      "Asbestos floor tile at Flare knockout pad can be left intact under a new floor. Option: dry grind to 'get it over with.' Pick?",
      [
      "Dry grind as P2.",
      "Avoid disturbing ACM if the stem leaves that open; do not dry grind.",
      "Shop-vac.",
      "A cone.",
      ],
      1,
      "Do not create the fiber.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 59,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.59",
      "Air permit limit at Pharmacy compounding hood vs a glossy ESG chart that uses a different averaging time. Last sentence: legal limit. Pick?",
      [
      "ESG chart is the permit.",
      "The legal averaging time and limit win.",
      "PELTLV only.",
      "FIN only.",
      ],
      1,
      "Legal clock vs brochure.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 60,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.60",
      "Universal waste box at Concrete batch tower open, unlabeled, 45 months old. Best?",
      [
      "Open is required.",
      "Close, label, time limits as the universal-waste rules named.",
      "Food dumpster.",
      "TRIR.",
      ],
      1,
      "UW container rules.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 55,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.55",
      "Wastewater at Fiber layup room can be avoided by a dry process still open. Team specifies a larger clarifier. Pick?",
      [
      "Larger clarifier is P2.",
      "Dry/source reduction if still open.",
      "A new drum.",
      "A hard hat.",
      ],
      1,
      "Source first.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 56,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.56",
      "Manifest signed at Quench pit by someone with no authority, destination 'TBD.' Error?",
      [
      "TBD is a TSDF.",
      "Proper documentation/authorized signer/designated facility.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Paper path is part of the control.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 57,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.57",
      "Incompatible compressed gases at Lab solvent crib stored nose-to-nose because the cage is pretty. Best?",
      [
      "Pretty cage is compatibility.",
      "Separate incompatibles; cage looks are not chemistry.",
      "BEI.",
      "FTA.",
      ],
      1,
      "Compatibility.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 58,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.58",
      "Fugitive solvent at Shipyard dry dock. Substitution still open; team only buys a bigger stack. Pick?",
      [
      "Stack as P2.",
      "Substitute/reduce at source if still open.",
      "A poster.",
      "DART.",
      ],
      1,
      "Stack is not source reduction.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 59,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.59",
      "Used oil dumped on road dust at Data-center generator hall 'for control of silica.' Error?",
      [
      "Oil on dirt is a silica Table 1 method.",
      "Do not create an environmental release as a fake dust control.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Illegal dump is not silica control.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 60,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.60",
      "ESG slide at Mine shop welding bay claims 'zero waste' while 120 drums of listed waste ship each week. Last sentence: legal truth. Pick?",
      [
      "The slide is the record.",
      "Legal waste still ships; the slide is not the record.",
      "A hard hat.",
      "A BEI.",
      ],
      1,
      "Do not let slides overwrite drums.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 55,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.55",
      "Process at North pier tank farm can still not make the waste. Team celebrates a $2500k scrubber as P2. Pick?",
      [
      "Scrubber is P2 by purchase price.",
      "Source reduction first if still open; end-of-pipe is not P2.",
      "A new drum.",
      "DART.",
      ],
      1,
      "P2 beats end-of-pipe when open.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 56,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.56",
      "Oxidizer stored with fuels at Line 4 stamping cell, alphabetical-only because the letters look neat. Best Tag 61.",
      [
      "Alphabet is compatibility.",
      "Compatibility, containment, labels — not alphabet-only.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Storage chemistry.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 57,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.57",
      "Listed hazardous waste in an open unlabeled drum in the rain at Building C autoclave for 12 days. Best Tag 62.",
      [
      "Rain is treatment.",
      "Contain, label, close, time limits, proper TSDF path.",
      "Pour to storm sewer as P2.",
      "Hard hat.",
      ],
      1,
      "Hazardous waste controls.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 58,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.58",
      "Spent lamps in a food-waste dumpster at Night-shift warehouse mezzanine. Universal waste path still open. Pick Tag 63.",
      [
      "Dumpster is fine.",
      "Manage as universal waste (or hazardous if they do not qualify).",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Universal waste path.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 59,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.59",
      "Sustainability report at Unit 7 hydrotreater with no legal air-permit work. Stem asks the legal control first. Pick Tag 64.",
      [
      "The report is the permit.",
      "Meet the legal environmental controls; the report is not a permit.",
      "Gloves.",
      "FTA.",
      ],
      1,
      "Legal vs brochure.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 60,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.60",
      "Dry ACM demo at Clinic sterile processing with a shop-vac. Option: more dust masks. Best Tag 65.",
      [
      "Shop-vac + mask is NESHAPs-style control.",
      "Wet methods, containment, competent work — not dry shop-vac on ACM.",
      "TRIR.",
      "ROI only.",
      ],
      1,
      "Do not dry-grind ACM.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 55,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.55",
      "Empty drum that held listed waste at Foundry shakeout, valves open, no marks. 'Empty so trash.' Error Tag 66.",
      [
      "Empty always means trash.",
      "Residue/empty-container rules still apply.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Empty drums can still be regulated.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 56,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.56",
      "GHS label removed at Cold-storage dock so the drum 'looks cleaner' after 36 weeks. Error Tag 67.",
      [
      "Cleaner is safer.",
      "Keep identity/hazard labels.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Labels stay.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 57,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.57",
      "Net-zero poster at Paint kitchen mezzanine; solvent still dumped to the sink 45 times this month. Pick Tag 68.",
      [
      "Poster is P2.",
      "Stop the illegal dump; poster is not a control.",
      "FTA.",
      "BEI.",
      ],
      1,
      "Legal baseline.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 58,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.58",
      "Satellite accumulation at Substation yard exceeds the time/volume the stem named. Option: a new slogan. Best Tag 69.",
      [
      "Slogan resets the clock.",
      "Comply with the accumulation rules named; slogan is not RCRA.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Accumulation limits.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 59,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.59",
      "Spill kit at Grain silo catwalk is empty. Last sentence: P2/spills response. Best Tag 70.",
      [
      "Empty kit is a plan.",
      "Stock, train, and use spill controls; empty is not ready.",
      "A poster.",
      "DART.",
      ],
      1,
      "Response capability.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 60,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.60",
      "Asbestos floor tile at Hospital loading dock can be left intact under a new floor. Option: dry grind to 'get it over with.' Pick Tag 71.",
      [
      "Dry grind as P2.",
      "Avoid disturbing ACM if the stem leaves that open; do not dry grind.",
      "Shop-vac.",
      "A cone.",
      ],
      1,
      "Do not create the fiber.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 55,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.55",
      "Air permit limit at Battery formation room vs a glossy ESG chart that uses a different averaging time. Last sentence: legal limit. Pick Tag 72.",
      [
      "ESG chart is the permit.",
      "The legal averaging time and limit win.",
      "PELTLV only.",
      "FIN only.",
      ],
      1,
      "Legal clock vs brochure.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 56,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.56",
      "Universal waste box at Sawmill green chain open, unlabeled, 95 months old. Best Tag 73.",
      [
      "Open is required.",
      "Close, label, time limits as the universal-waste rules named.",
      "Food dumpster.",
      "TRIR.",
      ],
      1,
      "UW container rules.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 57,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.57",
      "Wastewater at Compressor shelter can be avoided by a dry process still open. Team specifies a larger clarifier. Pick Tag 74.",
      [
      "Larger clarifier is P2.",
      "Dry/source reduction if still open.",
      "A new drum.",
      "A hard hat.",
      ],
      1,
      "Source first.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 58,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.58",
      "Manifest signed at Railcar unloading rack by someone with no authority, destination 'TBD.' Error Tag 75.",
      [
      "TBD is a TSDF.",
      "Proper documentation/authorized signer/designated facility.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Paper path is part of the control.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 59,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.59",
      "Incompatible compressed gases at Plating line 2 stored nose-to-nose because the cage is pretty. Best Tag 76.",
      [
      "Pretty cage is compatibility.",
      "Separate incompatibles; cage looks are not chemistry.",
      "BEI.",
      "FTA.",
      ],
      1,
      "Compatibility.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 60,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.60",
      "Fugitive solvent at Roof chiller deck. Substitution still open; team only buys a bigger stack. Pick Tag 77.",
      [
      "Stack as P2.",
      "Substitute/reduce at source if still open.",
      "A poster.",
      "DART.",
      ],
      1,
      "Stack is not source reduction.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 55,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.55",
      "Used oil dumped on road dust at Mud-logging shack 'for control of silica.' Error Tag 78.",
      [
      "Oil on dirt is a silica Table 1 method.",
      "Do not create an environmental release as a fake dust control.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Illegal dump is not silica control.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 56,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.56",
      "ESG slide at Die-change bay claims 'zero waste' while 18 drums of listed waste ship each week. Last sentence: legal truth. Pick Tag 79.",
      [
      "The slide is the record.",
      "Legal waste still ships; the slide is not the record.",
      "A hard hat.",
      "A BEI.",
      ],
      1,
      "Do not let slides overwrite drums.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 57,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.57",
      "Process at Aqueous washer cell can still not make the waste. Team celebrates a $500k scrubber as P2. Pick?",
      [
      "Scrubber is P2 by purchase price.",
      "Source reduction first if still open; end-of-pipe is not P2.",
      "A new drum.",
      "DART.",
      ],
      1,
      "P2 beats end-of-pipe when open.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 58,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.58",
      "Oxidizer stored with fuels at Flare knockout pad, alphabetical-only because the letters look neat. Best Tag 81.",
      [
      "Alphabet is compatibility.",
      "Compatibility, containment, labels — not alphabet-only.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Storage chemistry.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 59,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.59",
      "Listed hazardous waste in an open unlabeled drum in the rain at Pharmacy compounding hood for 36 days. Best Tag 82.",
      [
      "Rain is treatment.",
      "Contain, label, close, time limits, proper TSDF path.",
      "Pour to storm sewer as P2.",
      "Hard hat.",
      ],
      1,
      "Hazardous waste controls.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 60,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.60",
      "Spent lamps in a food-waste dumpster at Concrete batch tower. Universal waste path still open. Pick Tag 83.",
      [
      "Dumpster is fine.",
      "Manage as universal waste (or hazardous if they do not qualify).",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Universal waste path.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 55,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.55",
      "Sustainability report at Fiber layup room with no legal air-permit work. Stem asks the legal control first. Pick Tag 84.",
      [
      "The report is the permit.",
      "Meet the legal environmental controls; the report is not a permit.",
      "Gloves.",
      "FTA.",
      ],
      1,
      "Legal vs brochure.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 56,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.56",
      "Dry ACM demo at Quench pit with a shop-vac. Option: more dust masks. Best Tag 85.",
      [
      "Shop-vac + mask is NESHAPs-style control.",
      "Wet methods, containment, competent work — not dry shop-vac on ACM.",
      "TRIR.",
      "ROI only.",
      ],
      1,
      "Do not dry-grind ACM.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 57,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.57",
      "Empty drum that held listed waste at Lab solvent crib, valves open, no marks. 'Empty so trash.' Error Tag 86.",
      [
      "Empty always means trash.",
      "Residue/empty-container rules still apply.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Empty drums can still be regulated.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 58,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.58",
      "GHS label removed at Shipyard dry dock so the drum 'looks cleaner' after 90 weeks. Error Tag 87.",
      [
      "Cleaner is safer.",
      "Keep identity/hazard labels.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Labels stay.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 59,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.59",
      "Net-zero poster at Data-center generator hall; solvent still dumped to the sink 95 times this month. Pick Tag 88.",
      [
      "Poster is P2.",
      "Stop the illegal dump; poster is not a control.",
      "FTA.",
      "BEI.",
      ],
      1,
      "Legal baseline.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 60,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.60",
      "Satellite accumulation at Mine shop welding bay exceeds the time/volume the stem named. Option: a new slogan. Best Tag 89.",
      [
      "Slogan resets the clock.",
      "Comply with the accumulation rules named; slogan is not RCRA.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Accumulation limits.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 55,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.55",
      "Spill kit at North pier tank farm is empty. Last sentence: P2/spills response. Best Tag 90.",
      [
      "Empty kit is a plan.",
      "Stock, train, and use spill controls; empty is not ready.",
      "A poster.",
      "DART.",
      ],
      1,
      "Response capability.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 56,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.56",
      "Asbestos floor tile at Line 4 stamping cell can be left intact under a new floor. Option: dry grind to 'get it over with.' Pick Tag 91.",
      [
      "Dry grind as P2.",
      "Avoid disturbing ACM if the stem leaves that open; do not dry grind.",
      "Shop-vac.",
      "A cone.",
      ],
      1,
      "Do not create the fiber.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 57,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.57",
      "Air permit limit at Building C autoclave vs a glossy ESG chart that uses a different averaging time. Last sentence: legal limit. Pick Tag 92.",
      [
      "ESG chart is the permit.",
      "The legal averaging time and limit win.",
      "PELTLV only.",
      "FIN only.",
      ],
      1,
      "Legal clock vs brochure.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 58,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.58",
      "Universal waste box at Night-shift warehouse mezzanine open, unlabeled, 15 months old. Best Tag 93.",
      [
      "Open is required.",
      "Close, label, time limits as the universal-waste rules named.",
      "Food dumpster.",
      "TRIR.",
      ],
      1,
      "UW container rules.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 59,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.59",
      "Wastewater at Unit 7 hydrotreater can be avoided by a dry process still open. Team specifies a larger clarifier. Pick Tag 94.",
      [
      "Larger clarifier is P2.",
      "Dry/source reduction if still open.",
      "A new drum.",
      "A hard hat.",
      ],
      1,
      "Source first.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 60,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.60",
      "Manifest signed at Clinic sterile processing by someone with no authority, destination 'TBD.' Error Tag 95.",
      [
      "TBD is a TSDF.",
      "Proper documentation/authorized signer/designated facility.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Paper path is part of the control.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 55,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.55",
      "Incompatible compressed gases at Foundry shakeout stored nose-to-nose because the cage is pretty. Best Tag 96.",
      [
      "Pretty cage is compatibility.",
      "Separate incompatibles; cage looks are not chemistry.",
      "BEI.",
      "FTA.",
      ],
      1,
      "Compatibility.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 56,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.56",
      "Fugitive solvent at Cold-storage dock. Substitution still open; team only buys a bigger stack. Pick Tag 97.",
      [
      "Stack as P2.",
      "Substitute/reduce at source if still open.",
      "A poster.",
      "DART.",
      ],
      1,
      "Stack is not source reduction.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 57,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.57",
      "Used oil dumped on road dust at Paint kitchen mezzanine 'for control of silica.' Error Tag 98.",
      [
      "Oil on dirt is a silica Table 1 method.",
      "Do not create an environmental release as a fake dust control.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Illegal dump is not silica control.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 58,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.58",
      "ESG slide at Substation yard claims 'zero waste' while 48 drums of listed waste ship each week. Last sentence: legal truth. Pick Tag 99.",
      [
      "The slide is the record.",
      "Legal waste still ships; the slide is not the record.",
      "A hard hat.",
      "A BEI.",
      ],
      1,
      "Do not let slides overwrite drums.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 107,
    kind: "challenge",
    topic: "d5",
    ...exam(
      "CHAL.D5.SPCC.storm",
      "Weather-exposed dike: largest tank 35,000 gal; floor 6,000 ft²; design storm 4.8 in on the floor. Teaching model wants largest container plus precipitation freeboard (ignore displacements). Best containment volume?",
      [
        "35,000 gal — tank only.",
        "38,500 gal — 110% of tank, rain ignored.",
        "≈52,950 gal — tank plus storm volume (6,000×0.4 ft×7.48).",
        "70,000 gal — double the tank.",
      ],
      2,
      "4.8 in = 0.4 ft; 6,000×0.4=2,400 ft³; ×7.48≈17,952 gal; +35,000≈52,952. Autopilot 110% loses when rain freeboard is in the stem.",
      "FORM",
      "Expert",
      [
        "Tank-only skips freeboard the stem requires.",
        "110% myth understates specified rain.",
        "Key: largest + precipitation volume.",
        "200% invents a factor the teaching model does not use.",
      ],
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
];
