import { exam } from "../classes/types";
import type { GymQuestion } from "./types";

export const CHALLENGE_D3: GymQuestion[] = [
  {
    classId: 39,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.39",
      "Risk workshop at North pier tank farm produced a colored matrix, no owners, no treatment, no review. Best?",
      [
      "The workshop is the whole process.",
      "Identify, analyze, evaluate, treat, monitor — with owners.",
      "A glove.",
      "A TLV.",
      ],
      1,
      "Process, not a poster.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 40,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.40",
      "Covered process at Line 4 stamping cell used a JHA as the PHA. Last sentence asked HAZOP/what-if. Error?",
      [
      "JHA = PHA.",
      "JHA is job-based; PHA is process-based.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "Wrong tool.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 41,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.41",
      "HAZOP at Building C autoclave asked for nodes/deviations. Team fills FMEA RPNs = 12 and stops. Error?",
      [
      "RPN is HAZOP.",
      "HAZOP uses nodes and guidewords; RPN is FMEA.",
      "HIER.",
      "TIME.",
      ],
      1,
      "PHA method named.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 42,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.42",
      "Treatment register at Night-shift warehouse mezzanine lists a new glove as 'elimination' because it 'eliminates the cut.' Error?",
      [
      "PPE can be elimination if the poster says so.",
      "Elimination removes the hazard; PPE is last.",
      "FIN.",
      "UNIT.",
      ],
      1,
      "Do not relabel PPE.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 43,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.43",
      "Hazard register at Unit 7 hydrotreater has no owner and no review date, last update 18 years ago. Best?",
      [
      "A one-time poster is a register.",
      "Living register: owner, review, status.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Living document.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 44,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.44",
      "Stem at Clinic sterile processing: retain the $4000 deductible, transfer the tail. Candidate 'avoids' by buying gloves. Error?",
      [
      "Gloves are transfer.",
      "Retain vs share/transfer vs avoid vs reduce — gloves are a control, not insurance.",
      "HIER only.",
      "TOOL.",
      ],
      1,
      "Financial four language.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 45,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.45",
      "Fuel still next to ignition at Foundry shakeout; prevention still open. Team buys insurance and calls it prevention. Error?",
      [
      "Insurance is prevention.",
      "Prevention stops the event; insurance is transfer; reduction shrinks severity after it starts.",
      "PPE as transfer.",
      "FTA RPN.",
      ],
      1,
      "Prevention vs transfer.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 46,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.46",
      "Control installed at Cold-storage dock 36 months ago, never inspected. Monitoring stem. Best?",
      [
      "Install is monitor.",
      "Ask whether the control still works.",
      "A slogan.",
      "DART as the only monitor.",
      ],
      1,
      "Monitoring is ongoing.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 86,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.86",
      "Last sentence at Paint kitchen mezzanine names FTA. Options include FMEA RPN 45, JHA, and a fashionable bowtie. Pick?",
      [
      "RPN.",
      "The fault tree for the named top event.",
      "JHA automatically.",
      "Bowtie because it is new.",
      ],
      1,
      "Tool follows the last sentence.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 39,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.39",
      "Risk score 4×4=48 treated as a probability of 48%. Error?",
      [
      "Matrix scores are always percents.",
      "A matrix score is not automatically P=0.48.",
      "PELTLV.",
      "TIME.",
      ],
      1,
      "Scores ≠ probabilities unless named.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 40,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.40",
      "Register at Grain silo catwalk lists 'meteor strike' and nothing about the actual 60-ton press. Best?",
      [
      "Meteors first.",
      "Register actual workplace risks with owners.",
      "TLV of meteors.",
      "RPN of meteors on FTA.",
      ],
      1,
      "Relevant register.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 41,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.41",
      "Two treatments at Hospital loading dock: a procedure and a design change still open. Last sentence: treat the risk. Pick?",
      [
      "The procedure, because admin is faster.",
      "The design change if still open.",
      "Insurance only.",
      "A poster only.",
      ],
      1,
      "Hierarchy in treatment.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 42,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.42",
      "What-if PHA at Battery formation room replaced by a 5-why on a single incident. Last sentence asked process hazards. Error?",
      [
      "5-why is always the PHA.",
      "Incident 5-why is not a substitute for a process PHA method.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "PHA vs incident tool.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 43,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.43",
      "Loss-reduction sprinkler celebrated at Sawmill green chain while fuel can still be removed. Last sentence: prevention open. Pick?",
      [
      "Sprinkler as prevention.",
      "Remove/control fuel/ignition if still open; sprinkler reduces severity after ignition.",
      "Insurance only.",
      "TLV.",
      ],
      1,
      "Prevention vs reduction.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 44,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.44",
      "JHA at Compressor shelter from 120 years ago still posted; the job now uses a different tool every hour. Best?",
      [
      "Old JHA is eternal.",
      "Update the JHA when the job changes.",
      "Always replace JHA with HAZOP.",
      "RPN the JHA.",
      ],
      1,
      "Living JHA.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 45,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.45",
      "Bowtie drawn at Railcar unloading rack then used as if it produced an OSHA PEL. Error?",
      [
      "Bowtie is a PEL.",
      "A diagram is not an OEL (PELTLV/TOOL).",
      "HIER.",
      "TIME.",
      ],
      1,
      "Tool ≠ limit.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 46,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.46",
      "Risk acceptance at Plating line 2 by an intern with no authority. Last sentence: who may accept. Pick?",
      [
      "Whoever colored the matrix.",
      "The named authority/owner; intern coloring is not acceptance.",
      "The insurer only.",
      "The TLV committee.",
      ],
      1,
      "Authority to accept.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 86,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.86",
      "Monitoring finds the guard defeated 12 times this month at Roof chiller deck. Option: longer procedure. Design still open. Pick?",
      [
      "Longer procedure as the design.",
      "Defeat-resistant design/interlock if still open; counting defeats is a signal.",
      "A slogan.",
      "A BEI.",
      ],
      1,
      "Monitoring should drive design.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 39,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.39",
      "Share/transfer via a contract at Mud-logging shack that still leaves employees exposed to the unguarded nip. Last sentence: employees remain on the job. Pick?",
      [
      "Contract eliminates the nip.",
      "Transfer does not remove the physical hazard for people still there; guard/eliminate.",
      "A poster.",
      "A DART target.",
      ],
      1,
      "Transfer ≠ elimination.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 40,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.40",
      "Last sentence: FMEA detection rating. Candidate changes severity on paper without changing the hazard at Die-change bay. Best read?",
      [
      "Detection is severity.",
      "Detection is how likely we notice; it does not make the hazard smaller.",
      "UNIT.",
      "TIME.",
      ],
      1,
      "S vs D.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 41,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.41",
      "Risk workshop at Aqueous washer cell produced a colored matrix, no owners, no treatment, no review. Best?",
      [
      "The workshop is the whole process.",
      "Identify, analyze, evaluate, treat, monitor — with owners.",
      "A glove.",
      "A TLV.",
      ],
      1,
      "Process, not a poster.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 42,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.42",
      "Covered process at Flare knockout pad used a JHA as the PHA. Last sentence asked HAZOP/what-if. Error?",
      [
      "JHA = PHA.",
      "JHA is job-based; PHA is process-based.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "Wrong tool.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 43,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.43",
      "HAZOP at Pharmacy compounding hood asked for nodes/deviations. Team fills FMEA RPNs = 36 and stops. Error?",
      [
      "RPN is HAZOP.",
      "HAZOP uses nodes and guidewords; RPN is FMEA.",
      "HIER.",
      "TIME.",
      ],
      1,
      "PHA method named.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 44,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.44",
      "Treatment register at Concrete batch tower lists a new glove as 'elimination' because it 'eliminates the cut.' Error?",
      [
      "PPE can be elimination if the poster says so.",
      "Elimination removes the hazard; PPE is last.",
      "FIN.",
      "UNIT.",
      ],
      1,
      "Do not relabel PPE.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 45,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.45",
      "Hazard register at Fiber layup room has no owner and no review date, last update 48 years ago. Best?",
      [
      "A one-time poster is a register.",
      "Living register: owner, review, status.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Living document.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 46,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.46",
      "Stem at Quench pit: retain the $800 deductible, transfer the tail. Candidate 'avoids' by buying gloves. Error?",
      [
      "Gloves are transfer.",
      "Retain vs share/transfer vs avoid vs reduce — gloves are a control, not insurance.",
      "HIER only.",
      "TOOL.",
      ],
      1,
      "Financial four language.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 86,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.86",
      "Fuel still next to ignition at Lab solvent crib; prevention still open. Team buys insurance and calls it prevention. Error?",
      [
      "Insurance is prevention.",
      "Prevention stops the event; insurance is transfer; reduction shrinks severity after it starts.",
      "PPE as transfer.",
      "FTA RPN.",
      ],
      1,
      "Prevention vs transfer.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 39,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.39",
      "Control installed at Shipyard dry dock 90 months ago, never inspected. Monitoring stem. Best?",
      [
      "Install is monitor.",
      "Ask whether the control still works.",
      "A slogan.",
      "DART as the only monitor.",
      ],
      1,
      "Monitoring is ongoing.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 40,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.40",
      "Last sentence at Data-center generator hall names FTA. Options include FMEA RPN 95, JHA, and a fashionable bowtie. Pick?",
      [
      "RPN.",
      "The fault tree for the named top event.",
      "JHA automatically.",
      "Bowtie because it is new.",
      ],
      1,
      "Tool follows the last sentence.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 41,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.41",
      "Risk score 4×4=120 treated as a probability of 120%. Error?",
      [
      "Matrix scores are always percents.",
      "A matrix score is not automatically P=0.120.",
      "PELTLV.",
      "TIME.",
      ],
      1,
      "Scores ≠ probabilities unless named.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 42,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.42",
      "Register at North pier tank farm lists 'meteor strike' and nothing about the actual 6-ton press. Best?",
      [
      "Meteors first.",
      "Register actual workplace risks with owners.",
      "TLV of meteors.",
      "RPN of meteors on FTA.",
      ],
      1,
      "Relevant register.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 43,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.43",
      "Two treatments at Line 4 stamping cell: a procedure and a design change still open. Last sentence: treat the risk. Pick?",
      [
      "The procedure, because admin is faster.",
      "The design change if still open.",
      "Insurance only.",
      "A poster only.",
      ],
      1,
      "Hierarchy in treatment.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 44,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.44",
      "What-if PHA at Building C autoclave replaced by a 5-why on a single incident. Last sentence asked process hazards. Error?",
      [
      "5-why is always the PHA.",
      "Incident 5-why is not a substitute for a process PHA method.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "PHA vs incident tool.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 45,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.45",
      "Loss-reduction sprinkler celebrated at Night-shift warehouse mezzanine while fuel can still be removed. Last sentence: prevention open. Pick?",
      [
      "Sprinkler as prevention.",
      "Remove/control fuel/ignition if still open; sprinkler reduces severity after ignition.",
      "Insurance only.",
      "TLV.",
      ],
      1,
      "Prevention vs reduction.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 46,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.46",
      "JHA at Unit 7 hydrotreater from 18 years ago still posted; the job now uses a different tool every hour. Best?",
      [
      "Old JHA is eternal.",
      "Update the JHA when the job changes.",
      "Always replace JHA with HAZOP.",
      "RPN the JHA.",
      ],
      1,
      "Living JHA.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 86,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.86",
      "Bowtie drawn at Clinic sterile processing then used as if it produced an OSHA PEL. Error?",
      [
      "Bowtie is a PEL.",
      "A diagram is not an OEL (PELTLV/TOOL).",
      "HIER.",
      "TIME.",
      ],
      1,
      "Tool ≠ limit.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 39,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.39",
      "Risk acceptance at Foundry shakeout by an intern with no authority. Last sentence: who may accept. Pick?",
      [
      "Whoever colored the matrix.",
      "The named authority/owner; intern coloring is not acceptance.",
      "The insurer only.",
      "The TLV committee.",
      ],
      1,
      "Authority to accept.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 40,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.40",
      "Monitoring finds the guard defeated 36 times this month at Cold-storage dock. Option: longer procedure. Design still open. Pick?",
      [
      "Longer procedure as the design.",
      "Defeat-resistant design/interlock if still open; counting defeats is a signal.",
      "A slogan.",
      "A BEI.",
      ],
      1,
      "Monitoring should drive design.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 41,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.41",
      "Share/transfer via a contract at Paint kitchen mezzanine that still leaves employees exposed to the unguarded nip. Last sentence: employees remain on the job. Pick?",
      [
      "Contract eliminates the nip.",
      "Transfer does not remove the physical hazard for people still there; guard/eliminate.",
      "A poster.",
      "A DART target.",
      ],
      1,
      "Transfer ≠ elimination.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 42,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.42",
      "Last sentence: FMEA detection rating. Candidate changes severity on paper without changing the hazard at Substation yard. Best read?",
      [
      "Detection is severity.",
      "Detection is how likely we notice; it does not make the hazard smaller.",
      "UNIT.",
      "TIME.",
      ],
      1,
      "S vs D.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 43,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.43",
      "Risk workshop at Grain silo catwalk produced a colored matrix, no owners, no treatment, no review. Best?",
      [
      "The workshop is the whole process.",
      "Identify, analyze, evaluate, treat, monitor — with owners.",
      "A glove.",
      "A TLV.",
      ],
      1,
      "Process, not a poster.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 44,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.44",
      "Covered process at Hospital loading dock used a JHA as the PHA. Last sentence asked HAZOP/what-if. Error?",
      [
      "JHA = PHA.",
      "JHA is job-based; PHA is process-based.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "Wrong tool.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 45,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.45",
      "HAZOP at Battery formation room asked for nodes/deviations. Team fills FMEA RPNs = 90 and stops. Error?",
      [
      "RPN is HAZOP.",
      "HAZOP uses nodes and guidewords; RPN is FMEA.",
      "HIER.",
      "TIME.",
      ],
      1,
      "PHA method named.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 46,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.46",
      "Treatment register at Sawmill green chain lists a new glove as 'elimination' because it 'eliminates the cut.' Error?",
      [
      "PPE can be elimination if the poster says so.",
      "Elimination removes the hazard; PPE is last.",
      "FIN.",
      "UNIT.",
      ],
      1,
      "Do not relabel PPE.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 86,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.86",
      "Hazard register at Compressor shelter has no owner and no review date, last update 120 years ago. Best?",
      [
      "A one-time poster is a register.",
      "Living register: owner, review, status.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Living document.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 39,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.39",
      "Stem at Railcar unloading rack: retain the $4000 deductible, transfer the tail. Candidate 'avoids' by buying gloves. Error?",
      [
      "Gloves are transfer.",
      "Retain vs share/transfer vs avoid vs reduce — gloves are a control, not insurance.",
      "HIER only.",
      "TOOL.",
      ],
      1,
      "Financial four language.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 40,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.40",
      "Fuel still next to ignition at Plating line 2; prevention still open. Team buys insurance and calls it prevention. Error?",
      [
      "Insurance is prevention.",
      "Prevention stops the event; insurance is transfer; reduction shrinks severity after it starts.",
      "PPE as transfer.",
      "FTA RPN.",
      ],
      1,
      "Prevention vs transfer.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 41,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.41",
      "Control installed at Roof chiller deck 12 months ago, never inspected. Monitoring stem. Best?",
      [
      "Install is monitor.",
      "Ask whether the control still works.",
      "A slogan.",
      "DART as the only monitor.",
      ],
      1,
      "Monitoring is ongoing.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 42,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.42",
      "Last sentence at Mud-logging shack names FTA. Options include FMEA RPN 15, JHA, and a fashionable bowtie. Pick?",
      [
      "RPN.",
      "The fault tree for the named top event.",
      "JHA automatically.",
      "Bowtie because it is new.",
      ],
      1,
      "Tool follows the last sentence.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 43,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.43",
      "Risk score 4×4=18 treated as a probability of 18%. Error?",
      [
      "Matrix scores are always percents.",
      "A matrix score is not automatically P=0.18.",
      "PELTLV.",
      "TIME.",
      ],
      1,
      "Scores ≠ probabilities unless named.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 44,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.44",
      "Register at Aqueous washer cell lists 'meteor strike' and nothing about the actual 24-ton press. Best?",
      [
      "Meteors first.",
      "Register actual workplace risks with owners.",
      "TLV of meteors.",
      "RPN of meteors on FTA.",
      ],
      1,
      "Relevant register.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 45,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.45",
      "Two treatments at Flare knockout pad: a procedure and a design change still open. Last sentence: treat the risk. Pick?",
      [
      "The procedure, because admin is faster.",
      "The design change if still open.",
      "Insurance only.",
      "A poster only.",
      ],
      1,
      "Hierarchy in treatment.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 46,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.46",
      "What-if PHA at Pharmacy compounding hood replaced by a 5-why on a single incident. Last sentence asked process hazards. Error?",
      [
      "5-why is always the PHA.",
      "Incident 5-why is not a substitute for a process PHA method.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "PHA vs incident tool.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 86,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.86",
      "Loss-reduction sprinkler celebrated at Concrete batch tower while fuel can still be removed. Last sentence: prevention open. Pick?",
      [
      "Sprinkler as prevention.",
      "Remove/control fuel/ignition if still open; sprinkler reduces severity after ignition.",
      "Insurance only.",
      "TLV.",
      ],
      1,
      "Prevention vs reduction.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 39,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.39",
      "JHA at Fiber layup room from 48 years ago still posted; the job now uses a different tool every hour. Best?",
      [
      "Old JHA is eternal.",
      "Update the JHA when the job changes.",
      "Always replace JHA with HAZOP.",
      "RPN the JHA.",
      ],
      1,
      "Living JHA.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 40,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.40",
      "Bowtie drawn at Quench pit then used as if it produced an OSHA PEL. Error?",
      [
      "Bowtie is a PEL.",
      "A diagram is not an OEL (PELTLV/TOOL).",
      "HIER.",
      "TIME.",
      ],
      1,
      "Tool ≠ limit.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 41,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.41",
      "Risk acceptance at Lab solvent crib by an intern with no authority. Last sentence: who may accept. Pick?",
      [
      "Whoever colored the matrix.",
      "The named authority/owner; intern coloring is not acceptance.",
      "The insurer only.",
      "The TLV committee.",
      ],
      1,
      "Authority to accept.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 42,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.42",
      "Monitoring finds the guard defeated 90 times this month at Shipyard dry dock. Option: longer procedure. Design still open. Pick?",
      [
      "Longer procedure as the design.",
      "Defeat-resistant design/interlock if still open; counting defeats is a signal.",
      "A slogan.",
      "A BEI.",
      ],
      1,
      "Monitoring should drive design.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 43,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.43",
      "Share/transfer via a contract at Data-center generator hall that still leaves employees exposed to the unguarded nip. Last sentence: employees remain on the job. Pick?",
      [
      "Contract eliminates the nip.",
      "Transfer does not remove the physical hazard for people still there; guard/eliminate.",
      "A poster.",
      "A DART target.",
      ],
      1,
      "Transfer ≠ elimination.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 44,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.44",
      "Last sentence: FMEA detection rating. Candidate changes severity on paper without changing the hazard at Mine shop welding bay. Best read?",
      [
      "Detection is severity.",
      "Detection is how likely we notice; it does not make the hazard smaller.",
      "UNIT.",
      "TIME.",
      ],
      1,
      "S vs D.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 45,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.45",
      "Risk workshop at North pier tank farm produced a colored matrix, no owners, no treatment, no review. Best Tag 60.",
      [
      "The workshop is the whole process.",
      "Identify, analyze, evaluate, treat, monitor — with owners.",
      "A glove.",
      "A TLV.",
      ],
      1,
      "Process, not a poster.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 46,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.46",
      "Covered process at Line 4 stamping cell used a JHA as the PHA. Last sentence asked HAZOP/what-if. Error Tag 61.",
      [
      "JHA = PHA.",
      "JHA is job-based; PHA is process-based.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "Wrong tool.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 86,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.86",
      "HAZOP at Building C autoclave asked for nodes/deviations. Team fills FMEA RPNs = 12 and stops. Error Tag 62.",
      [
      "RPN is HAZOP.",
      "HAZOP uses nodes and guidewords; RPN is FMEA.",
      "HIER.",
      "TIME.",
      ],
      1,
      "PHA method named.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 39,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.39",
      "Treatment register at Night-shift warehouse mezzanine lists a new glove as 'elimination' because it 'eliminates the cut.' Error Tag 63.",
      [
      "PPE can be elimination if the poster says so.",
      "Elimination removes the hazard; PPE is last.",
      "FIN.",
      "UNIT.",
      ],
      1,
      "Do not relabel PPE.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 40,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.40",
      "Hazard register at Unit 7 hydrotreater has no owner and no review date, last update 18 years ago. Best Tag 64.",
      [
      "A one-time poster is a register.",
      "Living register: owner, review, status.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Living document.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 41,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.41",
      "Stem at Clinic sterile processing: retain the $800 deductible, transfer the tail. Candidate 'avoids' by buying gloves. Error?",
      [
      "Gloves are transfer.",
      "Retain vs share/transfer vs avoid vs reduce — gloves are a control, not insurance.",
      "HIER only.",
      "TOOL.",
      ],
      1,
      "Financial four language.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 42,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.42",
      "Fuel still next to ignition at Foundry shakeout; prevention still open. Team buys insurance and calls it prevention. Error Tag 66.",
      [
      "Insurance is prevention.",
      "Prevention stops the event; insurance is transfer; reduction shrinks severity after it starts.",
      "PPE as transfer.",
      "FTA RPN.",
      ],
      1,
      "Prevention vs transfer.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 43,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.43",
      "Control installed at Cold-storage dock 36 months ago, never inspected. Monitoring stem. Best Tag 67.",
      [
      "Install is monitor.",
      "Ask whether the control still works.",
      "A slogan.",
      "DART as the only monitor.",
      ],
      1,
      "Monitoring is ongoing.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 44,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.44",
      "Last sentence at Paint kitchen mezzanine names FTA. Options include FMEA RPN 45, JHA, and a fashionable bowtie. Pick Tag 68.",
      [
      "RPN.",
      "The fault tree for the named top event.",
      "JHA automatically.",
      "Bowtie because it is new.",
      ],
      1,
      "Tool follows the last sentence.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 45,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.45",
      "Risk score 4×4=48 treated as a probability of 48%. Error Tag 69.",
      [
      "Matrix scores are always percents.",
      "A matrix score is not automatically P=0.48.",
      "PELTLV.",
      "TIME.",
      ],
      1,
      "Scores ≠ probabilities unless named.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 46,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.46",
      "Register at Grain silo catwalk lists 'meteor strike' and nothing about the actual 60-ton press. Best Tag 70.",
      [
      "Meteors first.",
      "Register actual workplace risks with owners.",
      "TLV of meteors.",
      "RPN of meteors on FTA.",
      ],
      1,
      "Relevant register.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 86,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.86",
      "Two treatments at Hospital loading dock: a procedure and a design change still open. Last sentence: treat the risk. Pick Tag 71.",
      [
      "The procedure, because admin is faster.",
      "The design change if still open.",
      "Insurance only.",
      "A poster only.",
      ],
      1,
      "Hierarchy in treatment.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 39,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.39",
      "What-if PHA at Battery formation room replaced by a 5-why on a single incident. Last sentence asked process hazards. Error Tag 72.",
      [
      "5-why is always the PHA.",
      "Incident 5-why is not a substitute for a process PHA method.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "PHA vs incident tool.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 40,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.40",
      "Loss-reduction sprinkler celebrated at Sawmill green chain while fuel can still be removed. Last sentence: prevention open. Pick Tag 73.",
      [
      "Sprinkler as prevention.",
      "Remove/control fuel/ignition if still open; sprinkler reduces severity after ignition.",
      "Insurance only.",
      "TLV.",
      ],
      1,
      "Prevention vs reduction.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 41,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.41",
      "JHA at Compressor shelter from 120 years ago still posted; the job now uses a different tool every hour. Best Tag 74.",
      [
      "Old JHA is eternal.",
      "Update the JHA when the job changes.",
      "Always replace JHA with HAZOP.",
      "RPN the JHA.",
      ],
      1,
      "Living JHA.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 42,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.42",
      "Bowtie drawn at Railcar unloading rack then used as if it produced an OSHA PEL. Error Tag 75.",
      [
      "Bowtie is a PEL.",
      "A diagram is not an OEL (PELTLV/TOOL).",
      "HIER.",
      "TIME.",
      ],
      1,
      "Tool ≠ limit.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 43,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.43",
      "Risk acceptance at Plating line 2 by an intern with no authority. Last sentence: who may accept. Pick Tag 76.",
      [
      "Whoever colored the matrix.",
      "The named authority/owner; intern coloring is not acceptance.",
      "The insurer only.",
      "The TLV committee.",
      ],
      1,
      "Authority to accept.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 44,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.44",
      "Monitoring finds the guard defeated 12 times this month at Roof chiller deck. Option: longer procedure. Design still open. Pick Tag 77.",
      [
      "Longer procedure as the design.",
      "Defeat-resistant design/interlock if still open; counting defeats is a signal.",
      "A slogan.",
      "A BEI.",
      ],
      1,
      "Monitoring should drive design.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 45,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.45",
      "Share/transfer via a contract at Mud-logging shack that still leaves employees exposed to the unguarded nip. Last sentence: employees remain on the job. Pick Tag 78.",
      [
      "Contract eliminates the nip.",
      "Transfer does not remove the physical hazard for people still there; guard/eliminate.",
      "A poster.",
      "A DART target.",
      ],
      1,
      "Transfer ≠ elimination.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 46,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.46",
      "Last sentence: FMEA detection rating. Candidate changes severity on paper without changing the hazard at Die-change bay. Best read Tag 79.",
      [
      "Detection is severity.",
      "Detection is how likely we notice; it does not make the hazard smaller.",
      "UNIT.",
      "TIME.",
      ],
      1,
      "S vs D.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 86,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.86",
      "Risk workshop at Aqueous washer cell produced a colored matrix, no owners, no treatment, no review. Best Tag 80.",
      [
      "The workshop is the whole process.",
      "Identify, analyze, evaluate, treat, monitor — with owners.",
      "A glove.",
      "A TLV.",
      ],
      1,
      "Process, not a poster.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 39,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.39",
      "Covered process at Flare knockout pad used a JHA as the PHA. Last sentence asked HAZOP/what-if. Error Tag 81.",
      [
      "JHA = PHA.",
      "JHA is job-based; PHA is process-based.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "Wrong tool.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 40,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.40",
      "HAZOP at Pharmacy compounding hood asked for nodes/deviations. Team fills FMEA RPNs = 36 and stops. Error Tag 82.",
      [
      "RPN is HAZOP.",
      "HAZOP uses nodes and guidewords; RPN is FMEA.",
      "HIER.",
      "TIME.",
      ],
      1,
      "PHA method named.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 41,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.41",
      "Treatment register at Concrete batch tower lists a new glove as 'elimination' because it 'eliminates the cut.' Error Tag 83.",
      [
      "PPE can be elimination if the poster says so.",
      "Elimination removes the hazard; PPE is last.",
      "FIN.",
      "UNIT.",
      ],
      1,
      "Do not relabel PPE.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 42,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.42",
      "Hazard register at Fiber layup room has no owner and no review date, last update 48 years ago. Best Tag 84.",
      [
      "A one-time poster is a register.",
      "Living register: owner, review, status.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Living document.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 43,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.43",
      "Stem at Quench pit: retain the $4000 deductible, transfer the tail. Candidate 'avoids' by buying gloves. Error?",
      [
      "Gloves are transfer.",
      "Retain vs share/transfer vs avoid vs reduce — gloves are a control, not insurance.",
      "HIER only.",
      "TOOL.",
      ],
      1,
      "Financial four language.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 44,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.44",
      "Fuel still next to ignition at Lab solvent crib; prevention still open. Team buys insurance and calls it prevention. Error Tag 86.",
      [
      "Insurance is prevention.",
      "Prevention stops the event; insurance is transfer; reduction shrinks severity after it starts.",
      "PPE as transfer.",
      "FTA RPN.",
      ],
      1,
      "Prevention vs transfer.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 45,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.45",
      "Control installed at Shipyard dry dock 90 months ago, never inspected. Monitoring stem. Best Tag 87.",
      [
      "Install is monitor.",
      "Ask whether the control still works.",
      "A slogan.",
      "DART as the only monitor.",
      ],
      1,
      "Monitoring is ongoing.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 46,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.46",
      "Last sentence at Data-center generator hall names FTA. Options include FMEA RPN 95, JHA, and a fashionable bowtie. Pick Tag 88.",
      [
      "RPN.",
      "The fault tree for the named top event.",
      "JHA automatically.",
      "Bowtie because it is new.",
      ],
      1,
      "Tool follows the last sentence.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 86,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.86",
      "Risk score 4×4=120 treated as a probability of 120%. Error Tag 89.",
      [
      "Matrix scores are always percents.",
      "A matrix score is not automatically P=0.120.",
      "PELTLV.",
      "TIME.",
      ],
      1,
      "Scores ≠ probabilities unless named.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 39,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.39",
      "Register at North pier tank farm lists 'meteor strike' and nothing about the actual 6-ton press. Best Tag 90.",
      [
      "Meteors first.",
      "Register actual workplace risks with owners.",
      "TLV of meteors.",
      "RPN of meteors on FTA.",
      ],
      1,
      "Relevant register.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 40,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.40",
      "Two treatments at Line 4 stamping cell: a procedure and a design change still open. Last sentence: treat the risk. Pick Tag 91.",
      [
      "The procedure, because admin is faster.",
      "The design change if still open.",
      "Insurance only.",
      "A poster only.",
      ],
      1,
      "Hierarchy in treatment.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 41,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.41",
      "What-if PHA at Building C autoclave replaced by a 5-why on a single incident. Last sentence asked process hazards. Error Tag 92.",
      [
      "5-why is always the PHA.",
      "Incident 5-why is not a substitute for a process PHA method.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "PHA vs incident tool.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 42,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.42",
      "Loss-reduction sprinkler celebrated at Night-shift warehouse mezzanine while fuel can still be removed. Last sentence: prevention open. Pick Tag 93.",
      [
      "Sprinkler as prevention.",
      "Remove/control fuel/ignition if still open; sprinkler reduces severity after ignition.",
      "Insurance only.",
      "TLV.",
      ],
      1,
      "Prevention vs reduction.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 43,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.43",
      "JHA at Unit 7 hydrotreater from 18 years ago still posted; the job now uses a different tool every hour. Best Tag 94.",
      [
      "Old JHA is eternal.",
      "Update the JHA when the job changes.",
      "Always replace JHA with HAZOP.",
      "RPN the JHA.",
      ],
      1,
      "Living JHA.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 44,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.44",
      "Bowtie drawn at Clinic sterile processing then used as if it produced an OSHA PEL. Error Tag 95.",
      [
      "Bowtie is a PEL.",
      "A diagram is not an OEL (PELTLV/TOOL).",
      "HIER.",
      "TIME.",
      ],
      1,
      "Tool ≠ limit.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 45,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.45",
      "Risk acceptance at Foundry shakeout by an intern with no authority. Last sentence: who may accept. Pick Tag 96.",
      [
      "Whoever colored the matrix.",
      "The named authority/owner; intern coloring is not acceptance.",
      "The insurer only.",
      "The TLV committee.",
      ],
      1,
      "Authority to accept.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 46,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.46",
      "Monitoring finds the guard defeated 36 times this month at Cold-storage dock. Option: longer procedure. Design still open. Pick Tag 97.",
      [
      "Longer procedure as the design.",
      "Defeat-resistant design/interlock if still open; counting defeats is a signal.",
      "A slogan.",
      "A BEI.",
      ],
      1,
      "Monitoring should drive design.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 86,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.86",
      "Share/transfer via a contract at Paint kitchen mezzanine that still leaves employees exposed to the unguarded nip. Last sentence: employees remain on the job. Pick Tag 98.",
      [
      "Contract eliminates the nip.",
      "Transfer does not remove the physical hazard for people still there; guard/eliminate.",
      "A poster.",
      "A DART target.",
      ],
      1,
      "Transfer ≠ elimination.",
      "FIN",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 39,
    kind: "challenge",
    topic: "d3",
    ...exam(
      "CHAL.D3.39",
      "Last sentence: FMEA detection rating. Candidate changes severity on paper without changing the hazard at Substation yard. Best read Tag 99.",
      [
      "Detection is severity.",
      "Detection is how likely we notice; it does not make the hazard smaller.",
      "UNIT.",
      "TIME.",
      ],
      1,
      "S vs D.",
      "TOOL",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  }
];
