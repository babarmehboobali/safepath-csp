import { exam } from "../classes/types";
import type { GymQuestion } from "./types";

export const CHALLENGE_D7: GymQuestion[] = [
  {
    classId: 73,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.73",
      "Training at North pier tank farm bought because a vendor had a booth. No performance gap. Error?",
      [
      "Vendors are needs.",
      "Needs assessment starts with the performance gap.",
      "PELTLV.",
      "TRIR.",
      ],
      1,
      "Gap first.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 74,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.74",
      "8-slide deck at Line 4 stamping cell, no practice, no feedback. Adult learning. Best?",
      [
      "More slides.",
      "Prior knowledge, relevance, practice, feedback.",
      "A harder quiz only.",
      "Insurance.",
      ],
      1,
      "Adults need practice.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 75,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.75",
      "AI-drafted procedure at Building C autoclave posted with no SME check; it invented a 12 ppm PEL. Error?",
      [
      "AI is always accurate.",
      "CSP owns accuracy/bias/assessment; invented PELs are PELTLV/STEM.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "AI drafts; humans own.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 76,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.76",
      "Evaluation at Night-shift warehouse mezzanine shows bypass still. Fix = 15 extra slides. Error?",
      [
      "Slides fix bypass.",
      "Improve design/guards/practice from the data.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Improve the system.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 77,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.77",
      "Attendance 100% at Unit 7 hydrotreater called effectiveness. Behavior unchanged after 18 weeks. Error?",
      [
      "Attendance is results.",
      "Effectiveness is behavior/results, not seat time.",
      "PELTLV.",
      "FORM TRIR.",
      ],
      1,
      "Attendance ≠ effectiveness.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 78,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.78",
      "Competency at Clinic sterile processing = 24 chair hours. Observed cannot perform. Error?",
      [
      "Hours are competency.",
      "Competency is observed ability to perform.",
      "A poster.",
      "ROI.",
      ],
      1,
      "Show, not sit.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 89,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.89",
      "Z490-flavored stem at Foundry shakeout: no learning objectives, no evaluation, 30 people in seats. Pick?",
      [
      "Skip objectives if the room is full.",
      "Objectives, delivery, evaluation.",
      "TRIR as the objective.",
      "TLV as the objective.",
      ],
      1,
      "Training system.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 90,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.90",
      "Exam-attack at Cold-storage dock practice: calculator in RAD, stem is a 36° sling. First move?",
      [
      "Stay in RAD.",
      "DEG, then compute; closest rounded.",
      "Invent a formula sheet.",
      "Mean of the options.",
      ],
      1,
      "DEG.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 73,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.73",
      "Smile sheet 100% at Paint kitchen mezzanine. Stem asks whether the job changed. Pick?",
      [
      "Smile sheet = results.",
      "Need behavior/results evidence.",
      "TLV.",
      "TRIR as smile.",
      ],
      1,
      "Match evaluation level.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 74,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.74",
      "Sign-in sheet at Substation yard used to authorize a high-hazard task. Competency. Pick?",
      [
      "Sign-in is competency.",
      "Verify observed skill/authorization.",
      "A longer sheet.",
      "ROI.",
      ],
      1,
      "Authorization ≠ hours.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 75,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.75",
      "Needs assessment at Grain silo catwalk skipped because last year's course was popular (60 attendees). Error?",
      [
      "Popularity is a gap.",
      "Start from current performance gap, not last year's popularity.",
      "PELTLV.",
      "FIN.",
      ],
      1,
      "Current gap.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 76,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.76",
      "Training at Hospital loading dock used to compensate for a missing guard. Guard still purchasable. Pick?",
      [
      "Training as elimination.",
      "Install the guard if still open; training does not replace a missing guard.",
      "A longer quiz.",
      "Insurance.",
      ],
      1,
      "Training is not a guard.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 77,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.77",
      "Delivery at Battery formation room is 4 hours of reading PDFs on a phone at 90% zoom. No practice. Best add?",
      [
      "Smaller font.",
      "Practice, feedback, and a medium people can actually use.",
      "A harder PDF.",
      "A BEI.",
      ],
      1,
      "Delivery that works.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 78,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.78",
      "Effectiveness at Sawmill green chain measured only as 'we spent $4000.' Stem asks results. Pick?",
      [
      "Spend is results.",
      "Look at behavior/outcomes, not only spend.",
      "TLV.",
      "RWL.",
      ],
      1,
      "Spend ≠ results.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 89,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.89",
      "Competency sign-off at Compressor shelter by a supervisor who has never seen the task, 120 names in 10 minutes. Error?",
      [
      "Speed is competence.",
      "Observed performance by someone who knows the task.",
      "A stamp.",
      "ROI.",
      ],
      1,
      "Real observation.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 90,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.90",
      "Calculator lab: candidate uses LN for OSHA TWA-from-dose at Railcar unloading rack. D=200%. Error?",
      [
      "LN is correct.",
      "LOG10: 90+16.61 log10(2) ≈ 95 dBA.",
      "TRIR.",
      "7.48.",
      ],
      1,
      "LOG not LN.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 73,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.73",
      "Improve-training at Plating line 2: evaluation says vocabulary is fine, procedure on the floor is wrong. Option: more vocabulary slides. Pick?",
      [
      "More words.",
      "Fix the job aid/practice/design the evaluation pointed to.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Fix what the data named.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 74,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.74",
      "AI chatbot at Roof chiller deck used as the only assessor of live high-hazard performance. Last sentence: who is accountable. Pick?",
      [
      "The chatbot is the CSP.",
      "The CSP/organization still owns the assessment.",
      "The vendor only.",
      "The TLV.",
      ],
      1,
      "Accountability stays human.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 75,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.75",
      "Objectives at Mud-logging shack say 'understand safety.' Last sentence: observable competency. Pick?",
      [
      "Understand is observable.",
      "Write observable performance (show/do), not vague understand.",
      "A longer objective.",
      "ROI.",
      ],
      1,
      "Observable objectives.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 76,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.76",
      "Closest-value item in a Die-change bay calculator drill. Candidate invents extra sig figs and then picks at random. Best?",
      [
      "Always A.",
      "Compute full precision then pick the nearest listed option.",
      "Mean of options.",
      "RAD always.",
      ],
      1,
      "Closest rounded.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 77,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.77",
      "Training at Aqueous washer cell bought because a vendor had a booth. No performance gap. Error?",
      [
      "Vendors are needs.",
      "Needs assessment starts with the performance gap.",
      "PELTLV.",
      "TRIR.",
      ],
      1,
      "Gap first.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 78,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.78",
      "30-slide deck at Flare knockout pad, no practice, no feedback. Adult learning. Best?",
      [
      "More slides.",
      "Prior knowledge, relevance, practice, feedback.",
      "A harder quiz only.",
      "Insurance.",
      ],
      1,
      "Adults need practice.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 89,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.89",
      "AI-drafted procedure at Pharmacy compounding hood posted with no SME check; it invented a 36 ppm PEL. Error?",
      [
      "AI is always accurate.",
      "CSP owns accuracy/bias/assessment; invented PELs are PELTLV/STEM.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "AI drafts; humans own.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 90,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.90",
      "Evaluation at Concrete batch tower shows bypass still. Fix = 45 extra slides. Error?",
      [
      "Slides fix bypass.",
      "Improve design/guards/practice from the data.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Improve the system.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 73,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.73",
      "Attendance 100% at Fiber layup room called effectiveness. Behavior unchanged after 48 weeks. Error?",
      [
      "Attendance is results.",
      "Effectiveness is behavior/results, not seat time.",
      "PELTLV.",
      "FORM TRIR.",
      ],
      1,
      "Attendance ≠ effectiveness.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 74,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.74",
      "Competency at Quench pit = 60 chair hours. Observed cannot perform. Error?",
      [
      "Hours are competency.",
      "Competency is observed ability to perform.",
      "A poster.",
      "ROI.",
      ],
      1,
      "Show, not sit.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 75,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.75",
      "Z490-flavored stem at Lab solvent crib: no learning objectives, no evaluation, 75 people in seats. Pick?",
      [
      "Skip objectives if the room is full.",
      "Objectives, delivery, evaluation.",
      "TRIR as the objective.",
      "TLV as the objective.",
      ],
      1,
      "Training system.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 76,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.76",
      "Exam-attack at Shipyard dry dock practice: calculator in RAD, stem is a 90° sling. First move?",
      [
      "Stay in RAD.",
      "DEG, then compute; closest rounded.",
      "Invent a formula sheet.",
      "Mean of the options.",
      ],
      1,
      "DEG.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 77,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.77",
      "Smile sheet 100% at Data-center generator hall. Stem asks whether the job changed. Pick?",
      [
      "Smile sheet = results.",
      "Need behavior/results evidence.",
      "TLV.",
      "TRIR as smile.",
      ],
      1,
      "Match evaluation level.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 78,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.78",
      "Sign-in sheet at Mine shop welding bay used to authorize a high-hazard task. Competency. Pick?",
      [
      "Sign-in is competency.",
      "Verify observed skill/authorization.",
      "A longer sheet.",
      "ROI.",
      ],
      1,
      "Authorization ≠ hours.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 89,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.89",
      "Needs assessment at North pier tank farm skipped because last year's course was popular (6 attendees). Error?",
      [
      "Popularity is a gap.",
      "Start from current performance gap, not last year's popularity.",
      "PELTLV.",
      "FIN.",
      ],
      1,
      "Current gap.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 90,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.90",
      "Training at Line 4 stamping cell used to compensate for a missing guard. Guard still purchasable. Pick?",
      [
      "Training as elimination.",
      "Install the guard if still open; training does not replace a missing guard.",
      "A longer quiz.",
      "Insurance.",
      ],
      1,
      "Training is not a guard.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 73,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.73",
      "Delivery at Building C autoclave is 4 hours of reading PDFs on a phone at 12% zoom. No practice. Best add?",
      [
      "Smaller font.",
      "Practice, feedback, and a medium people can actually use.",
      "A harder PDF.",
      "A BEI.",
      ],
      1,
      "Delivery that works.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 74,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.74",
      "Effectiveness at Night-shift warehouse mezzanine measured only as 'we spent $800.' Stem asks results. Pick?",
      [
      "Spend is results.",
      "Look at behavior/outcomes, not only spend.",
      "TLV.",
      "RWL.",
      ],
      1,
      "Spend ≠ results.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 75,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.75",
      "Competency sign-off at Unit 7 hydrotreater by a supervisor who has never seen the task, 18 names in 10 minutes. Error?",
      [
      "Speed is competence.",
      "Observed performance by someone who knows the task.",
      "A stamp.",
      "ROI.",
      ],
      1,
      "Real observation.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 76,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.76",
      "Calculator lab: candidate uses LN for OSHA TWA-from-dose at Clinic sterile processing. D=200%. Error?",
      [
      "LN is correct.",
      "LOG10: 90+16.61 log10(2) ≈ 95 dBA.",
      "TRIR.",
      "7.48.",
      ],
      1,
      "LOG not LN.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 77,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.77",
      "Improve-training at Foundry shakeout: evaluation says vocabulary is fine, procedure on the floor is wrong. Option: more vocabulary slides. Pick?",
      [
      "More words.",
      "Fix the job aid/practice/design the evaluation pointed to.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Fix what the data named.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 78,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.78",
      "AI chatbot at Cold-storage dock used as the only assessor of live high-hazard performance. Last sentence: who is accountable. Pick?",
      [
      "The chatbot is the CSP.",
      "The CSP/organization still owns the assessment.",
      "The vendor only.",
      "The TLV.",
      ],
      1,
      "Accountability stays human.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 89,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.89",
      "Objectives at Paint kitchen mezzanine say 'understand safety.' Last sentence: observable competency. Pick?",
      [
      "Understand is observable.",
      "Write observable performance (show/do), not vague understand.",
      "A longer objective.",
      "ROI.",
      ],
      1,
      "Observable objectives.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 90,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.90",
      "Closest-value item in a Substation yard calculator drill. Candidate invents extra sig figs and then picks at random. Best?",
      [
      "Always A.",
      "Compute full precision then pick the nearest listed option.",
      "Mean of options.",
      "RAD always.",
      ],
      1,
      "Closest rounded.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 73,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.73",
      "Training at Grain silo catwalk bought because a vendor had a booth. No performance gap. Error?",
      [
      "Vendors are needs.",
      "Needs assessment starts with the performance gap.",
      "PELTLV.",
      "TRIR.",
      ],
      1,
      "Gap first.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 74,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.74",
      "75-slide deck at Hospital loading dock, no practice, no feedback. Adult learning. Best?",
      [
      "More slides.",
      "Prior knowledge, relevance, practice, feedback.",
      "A harder quiz only.",
      "Insurance.",
      ],
      1,
      "Adults need practice.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 75,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.75",
      "AI-drafted procedure at Battery formation room posted with no SME check; it invented a 90 ppm PEL. Error?",
      [
      "AI is always accurate.",
      "CSP owns accuracy/bias/assessment; invented PELs are PELTLV/STEM.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "AI drafts; humans own.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 76,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.76",
      "Evaluation at Sawmill green chain shows bypass still. Fix = 95 extra slides. Error?",
      [
      "Slides fix bypass.",
      "Improve design/guards/practice from the data.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Improve the system.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 77,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.77",
      "Attendance 100% at Compressor shelter called effectiveness. Behavior unchanged after 120 weeks. Error?",
      [
      "Attendance is results.",
      "Effectiveness is behavior/results, not seat time.",
      "PELTLV.",
      "FORM TRIR.",
      ],
      1,
      "Attendance ≠ effectiveness.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 78,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.78",
      "Competency at Railcar unloading rack = 6 chair hours. Observed cannot perform. Error?",
      [
      "Hours are competency.",
      "Competency is observed ability to perform.",
      "A poster.",
      "ROI.",
      ],
      1,
      "Show, not sit.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 89,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.89",
      "Z490-flavored stem at Plating line 2: no learning objectives, no evaluation, 8 people in seats. Pick?",
      [
      "Skip objectives if the room is full.",
      "Objectives, delivery, evaluation.",
      "TRIR as the objective.",
      "TLV as the objective.",
      ],
      1,
      "Training system.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 90,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.90",
      "Exam-attack at Roof chiller deck practice: calculator in RAD, stem is a 12° sling. First move?",
      [
      "Stay in RAD.",
      "DEG, then compute; closest rounded.",
      "Invent a formula sheet.",
      "Mean of the options.",
      ],
      1,
      "DEG.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 73,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.73",
      "Smile sheet 100% at Mud-logging shack. Stem asks whether the job changed. Pick?",
      [
      "Smile sheet = results.",
      "Need behavior/results evidence.",
      "TLV.",
      "TRIR as smile.",
      ],
      1,
      "Match evaluation level.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 74,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.74",
      "Sign-in sheet at Die-change bay used to authorize a high-hazard task. Competency. Pick?",
      [
      "Sign-in is competency.",
      "Verify observed skill/authorization.",
      "A longer sheet.",
      "ROI.",
      ],
      1,
      "Authorization ≠ hours.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 75,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.75",
      "Needs assessment at Aqueous washer cell skipped because last year's course was popular (24 attendees). Error?",
      [
      "Popularity is a gap.",
      "Start from current performance gap, not last year's popularity.",
      "PELTLV.",
      "FIN.",
      ],
      1,
      "Current gap.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 76,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.76",
      "Training at Flare knockout pad used to compensate for a missing guard. Guard still purchasable. Pick?",
      [
      "Training as elimination.",
      "Install the guard if still open; training does not replace a missing guard.",
      "A longer quiz.",
      "Insurance.",
      ],
      1,
      "Training is not a guard.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 77,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.77",
      "Delivery at Pharmacy compounding hood is 4 hours of reading PDFs on a phone at 36% zoom. No practice. Best add?",
      [
      "Smaller font.",
      "Practice, feedback, and a medium people can actually use.",
      "A harder PDF.",
      "A BEI.",
      ],
      1,
      "Delivery that works.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 78,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.78",
      "Effectiveness at Concrete batch tower measured only as 'we spent $4000.' Stem asks results. Pick?",
      [
      "Spend is results.",
      "Look at behavior/outcomes, not only spend.",
      "TLV.",
      "RWL.",
      ],
      1,
      "Spend ≠ results.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 89,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.89",
      "Competency sign-off at Fiber layup room by a supervisor who has never seen the task, 48 names in 10 minutes. Error?",
      [
      "Speed is competence.",
      "Observed performance by someone who knows the task.",
      "A stamp.",
      "ROI.",
      ],
      1,
      "Real observation.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 90,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.90",
      "Calculator lab: candidate uses LN for OSHA TWA-from-dose at Quench pit. D=200%. Error?",
      [
      "LN is correct.",
      "LOG10: 90+16.61 log10(2) ≈ 95 dBA.",
      "TRIR.",
      "7.48.",
      ],
      1,
      "LOG not LN.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 73,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.73",
      "Improve-training at Lab solvent crib: evaluation says vocabulary is fine, procedure on the floor is wrong. Option: more vocabulary slides. Pick?",
      [
      "More words.",
      "Fix the job aid/practice/design the evaluation pointed to.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Fix what the data named.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 74,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.74",
      "AI chatbot at Shipyard dry dock used as the only assessor of live high-hazard performance. Last sentence: who is accountable. Pick?",
      [
      "The chatbot is the CSP.",
      "The CSP/organization still owns the assessment.",
      "The vendor only.",
      "The TLV.",
      ],
      1,
      "Accountability stays human.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 75,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.75",
      "Objectives at Data-center generator hall say 'understand safety.' Last sentence: observable competency. Pick?",
      [
      "Understand is observable.",
      "Write observable performance (show/do), not vague understand.",
      "A longer objective.",
      "ROI.",
      ],
      1,
      "Observable objectives.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 76,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.76",
      "Closest-value item in a Mine shop welding bay calculator drill. Candidate invents extra sig figs and then picks at random. Best?",
      [
      "Always A.",
      "Compute full precision then pick the nearest listed option.",
      "Mean of options.",
      "RAD always.",
      ],
      1,
      "Closest rounded.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 77,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.77",
      "Training at North pier tank farm bought because a vendor had a booth. No performance gap. Error Tag 60.",
      [
      "Vendors are needs.",
      "Needs assessment starts with the performance gap.",
      "PELTLV.",
      "TRIR.",
      ],
      1,
      "Gap first.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 78,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.78",
      "8-slide deck at Line 4 stamping cell, no practice, no feedback. Adult learning. Best Tag 61.",
      [
      "More slides.",
      "Prior knowledge, relevance, practice, feedback.",
      "A harder quiz only.",
      "Insurance.",
      ],
      1,
      "Adults need practice.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 89,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.89",
      "AI-drafted procedure at Building C autoclave posted with no SME check; it invented a 12 ppm PEL. Error Tag 62.",
      [
      "AI is always accurate.",
      "CSP owns accuracy/bias/assessment; invented PELs are PELTLV/STEM.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "AI drafts; humans own.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 90,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.90",
      "Evaluation at Night-shift warehouse mezzanine shows bypass still. Fix = 15 extra slides. Error Tag 63.",
      [
      "Slides fix bypass.",
      "Improve design/guards/practice from the data.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Improve the system.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 73,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.73",
      "Attendance 100% at Unit 7 hydrotreater called effectiveness. Behavior unchanged after 18 weeks. Error Tag 64.",
      [
      "Attendance is results.",
      "Effectiveness is behavior/results, not seat time.",
      "PELTLV.",
      "FORM TRIR.",
      ],
      1,
      "Attendance ≠ effectiveness.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 74,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.74",
      "Competency at Clinic sterile processing = 24 chair hours. Observed cannot perform. Error Tag 65.",
      [
      "Hours are competency.",
      "Competency is observed ability to perform.",
      "A poster.",
      "ROI.",
      ],
      1,
      "Show, not sit.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 75,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.75",
      "Z490-flavored stem at Foundry shakeout: no learning objectives, no evaluation, 30 people in seats. Pick Tag 66.",
      [
      "Skip objectives if the room is full.",
      "Objectives, delivery, evaluation.",
      "TRIR as the objective.",
      "TLV as the objective.",
      ],
      1,
      "Training system.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 76,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.76",
      "Exam-attack at Cold-storage dock practice: calculator in RAD, stem is a 36° sling. First move Tag 67.",
      [
      "Stay in RAD.",
      "DEG, then compute; closest rounded.",
      "Invent a formula sheet.",
      "Mean of the options.",
      ],
      1,
      "DEG.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 77,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.77",
      "Smile sheet 100% at Paint kitchen mezzanine. Stem asks whether the job changed. Pick Tag 68.",
      [
      "Smile sheet = results.",
      "Need behavior/results evidence.",
      "TLV.",
      "TRIR as smile.",
      ],
      1,
      "Match evaluation level.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 78,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.78",
      "Sign-in sheet at Substation yard used to authorize a high-hazard task. Competency. Pick Tag 69.",
      [
      "Sign-in is competency.",
      "Verify observed skill/authorization.",
      "A longer sheet.",
      "ROI.",
      ],
      1,
      "Authorization ≠ hours.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 89,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.89",
      "Needs assessment at Grain silo catwalk skipped because last year's course was popular (60 attendees). Error Tag 70.",
      [
      "Popularity is a gap.",
      "Start from current performance gap, not last year's popularity.",
      "PELTLV.",
      "FIN.",
      ],
      1,
      "Current gap.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 90,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.90",
      "Training at Hospital loading dock used to compensate for a missing guard. Guard still purchasable. Pick Tag 71.",
      [
      "Training as elimination.",
      "Install the guard if still open; training does not replace a missing guard.",
      "A longer quiz.",
      "Insurance.",
      ],
      1,
      "Training is not a guard.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 73,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.73",
      "Delivery at Battery formation room is 4 hours of reading PDFs on a phone at 90% zoom. No practice. Best add Tag 72.",
      [
      "Smaller font.",
      "Practice, feedback, and a medium people can actually use.",
      "A harder PDF.",
      "A BEI.",
      ],
      1,
      "Delivery that works.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 74,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.74",
      "Effectiveness at Sawmill green chain measured only as 'we spent $800.' Stem asks results. Pick?",
      [
      "Spend is results.",
      "Look at behavior/outcomes, not only spend.",
      "TLV.",
      "RWL.",
      ],
      1,
      "Spend ≠ results.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 75,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.75",
      "Competency sign-off at Compressor shelter by a supervisor who has never seen the task, 120 names in 10 minutes. Error Tag 74.",
      [
      "Speed is competence.",
      "Observed performance by someone who knows the task.",
      "A stamp.",
      "ROI.",
      ],
      1,
      "Real observation.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 76,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.76",
      "Calculator lab: candidate uses LN for OSHA TWA-from-dose at Railcar unloading rack. D=200%. Error Tag 75.",
      [
      "LN is correct.",
      "LOG10: 90+16.61 log10(2) ≈ 95 dBA.",
      "TRIR.",
      "7.48.",
      ],
      1,
      "LOG not LN.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 77,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.77",
      "Improve-training at Plating line 2: evaluation says vocabulary is fine, procedure on the floor is wrong. Option: more vocabulary slides. Pick Tag 76.",
      [
      "More words.",
      "Fix the job aid/practice/design the evaluation pointed to.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Fix what the data named.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 78,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.78",
      "AI chatbot at Roof chiller deck used as the only assessor of live high-hazard performance. Last sentence: who is accountable. Pick Tag 77.",
      [
      "The chatbot is the CSP.",
      "The CSP/organization still owns the assessment.",
      "The vendor only.",
      "The TLV.",
      ],
      1,
      "Accountability stays human.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 89,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.89",
      "Objectives at Mud-logging shack say 'understand safety.' Last sentence: observable competency. Pick Tag 78.",
      [
      "Understand is observable.",
      "Write observable performance (show/do), not vague understand.",
      "A longer objective.",
      "ROI.",
      ],
      1,
      "Observable objectives.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 90,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.90",
      "Closest-value item in a Die-change bay calculator drill. Candidate invents extra sig figs and then picks at random. Best Tag 79.",
      [
      "Always A.",
      "Compute full precision then pick the nearest listed option.",
      "Mean of options.",
      "RAD always.",
      ],
      1,
      "Closest rounded.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 73,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.73",
      "Training at Aqueous washer cell bought because a vendor had a booth. No performance gap. Error Tag 80.",
      [
      "Vendors are needs.",
      "Needs assessment starts with the performance gap.",
      "PELTLV.",
      "TRIR.",
      ],
      1,
      "Gap first.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 74,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.74",
      "30-slide deck at Flare knockout pad, no practice, no feedback. Adult learning. Best Tag 81.",
      [
      "More slides.",
      "Prior knowledge, relevance, practice, feedback.",
      "A harder quiz only.",
      "Insurance.",
      ],
      1,
      "Adults need practice.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 75,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.75",
      "AI-drafted procedure at Pharmacy compounding hood posted with no SME check; it invented a 36 ppm PEL. Error Tag 82.",
      [
      "AI is always accurate.",
      "CSP owns accuracy/bias/assessment; invented PELs are PELTLV/STEM.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "AI drafts; humans own.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 76,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.76",
      "Evaluation at Concrete batch tower shows bypass still. Fix = 45 extra slides. Error Tag 83.",
      [
      "Slides fix bypass.",
      "Improve design/guards/practice from the data.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Improve the system.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 77,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.77",
      "Attendance 100% at Fiber layup room called effectiveness. Behavior unchanged after 48 weeks. Error Tag 84.",
      [
      "Attendance is results.",
      "Effectiveness is behavior/results, not seat time.",
      "PELTLV.",
      "FORM TRIR.",
      ],
      1,
      "Attendance ≠ effectiveness.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 78,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.78",
      "Competency at Quench pit = 60 chair hours. Observed cannot perform. Error Tag 85.",
      [
      "Hours are competency.",
      "Competency is observed ability to perform.",
      "A poster.",
      "ROI.",
      ],
      1,
      "Show, not sit.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 89,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.89",
      "Z490-flavored stem at Lab solvent crib: no learning objectives, no evaluation, 75 people in seats. Pick Tag 86.",
      [
      "Skip objectives if the room is full.",
      "Objectives, delivery, evaluation.",
      "TRIR as the objective.",
      "TLV as the objective.",
      ],
      1,
      "Training system.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 90,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.90",
      "Exam-attack at Shipyard dry dock practice: calculator in RAD, stem is a 90° sling. First move Tag 87.",
      [
      "Stay in RAD.",
      "DEG, then compute; closest rounded.",
      "Invent a formula sheet.",
      "Mean of the options.",
      ],
      1,
      "DEG.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 73,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.73",
      "Smile sheet 100% at Data-center generator hall. Stem asks whether the job changed. Pick Tag 88.",
      [
      "Smile sheet = results.",
      "Need behavior/results evidence.",
      "TLV.",
      "TRIR as smile.",
      ],
      1,
      "Match evaluation level.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 74,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.74",
      "Sign-in sheet at Mine shop welding bay used to authorize a high-hazard task. Competency. Pick Tag 89.",
      [
      "Sign-in is competency.",
      "Verify observed skill/authorization.",
      "A longer sheet.",
      "ROI.",
      ],
      1,
      "Authorization ≠ hours.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 75,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.75",
      "Needs assessment at North pier tank farm skipped because last year's course was popular (6 attendees). Error Tag 90.",
      [
      "Popularity is a gap.",
      "Start from current performance gap, not last year's popularity.",
      "PELTLV.",
      "FIN.",
      ],
      1,
      "Current gap.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 76,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.76",
      "Training at Line 4 stamping cell used to compensate for a missing guard. Guard still purchasable. Pick Tag 91.",
      [
      "Training as elimination.",
      "Install the guard if still open; training does not replace a missing guard.",
      "A longer quiz.",
      "Insurance.",
      ],
      1,
      "Training is not a guard.",
      "HIER",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 77,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.77",
      "Delivery at Building C autoclave is 4 hours of reading PDFs on a phone at 12% zoom. No practice. Best add Tag 92.",
      [
      "Smaller font.",
      "Practice, feedback, and a medium people can actually use.",
      "A harder PDF.",
      "A BEI.",
      ],
      1,
      "Delivery that works.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 78,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.78",
      "Effectiveness at Night-shift warehouse mezzanine measured only as 'we spent $4000.' Stem asks results. Pick?",
      [
      "Spend is results.",
      "Look at behavior/outcomes, not only spend.",
      "TLV.",
      "RWL.",
      ],
      1,
      "Spend ≠ results.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 89,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.89",
      "Competency sign-off at Unit 7 hydrotreater by a supervisor who has never seen the task, 18 names in 10 minutes. Error Tag 94.",
      [
      "Speed is competence.",
      "Observed performance by someone who knows the task.",
      "A stamp.",
      "ROI.",
      ],
      1,
      "Real observation.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 90,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.90",
      "Calculator lab: candidate uses LN for OSHA TWA-from-dose at Clinic sterile processing. D=200%. Error Tag 95.",
      [
      "LN is correct.",
      "LOG10: 90+16.61 log10(2) ≈ 95 dBA.",
      "TRIR.",
      "7.48.",
      ],
      1,
      "LOG not LN.",
      "UNIT",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 73,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.73",
      "Improve-training at Foundry shakeout: evaluation says vocabulary is fine, procedure on the floor is wrong. Option: more vocabulary slides. Pick Tag 96.",
      [
      "More words.",
      "Fix the job aid/practice/design the evaluation pointed to.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Fix what the data named.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 74,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.74",
      "AI chatbot at Cold-storage dock used as the only assessor of live high-hazard performance. Last sentence: who is accountable. Pick Tag 97.",
      [
      "The chatbot is the CSP.",
      "The CSP/organization still owns the assessment.",
      "The vendor only.",
      "The TLV.",
      ],
      1,
      "Accountability stays human.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 75,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.75",
      "Objectives at Paint kitchen mezzanine say 'understand safety.' Last sentence: observable competency. Pick Tag 98.",
      [
      "Understand is observable.",
      "Write observable performance (show/do), not vague understand.",
      "A longer objective.",
      "ROI.",
      ],
      1,
      "Observable objectives.",
      "STEM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 76,
    kind: "challenge",
    topic: "d7",
    ...exam(
      "CHAL.D7.76",
      "Closest-value item in a Substation yard calculator drill. Candidate invents extra sig figs and then picks at random. Best Tag 99.",
      [
      "Always A.",
      "Compute full precision then pick the nearest listed option.",
      "Mean of options.",
      "RAD always.",
      ],
      1,
      "Closest rounded.",
      "FORM",
      "Expert",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  }
];
