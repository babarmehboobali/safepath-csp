import { exam } from "../classes/types";
import type { GymQuestion } from "./types";

/** Short original diagnostic warm-up sample for /assess/warmup. */
export const DIAGNOSTIC_EXTRAS: GymQuestion[] = [
  {
    classId: 37,
    kind: "extra",
    topic: "diagnostic",
    ...exam(
      "DIAG.parallel",
      "A relief valve fails with probability 0.02 and an emergency interlock fails with probability 0.05. They are independent and arranged in active parallel redundancy. Combined probability both fail on demand?",
      [
        "0.0700 (add the probabilities).",
        "0.0010 (product of the two failure probabilities).",
        "0.0250 (average of 0.02 and 0.05).",
        "0.9310 (one minus the sum).",
      ],
      1,
      "Independent parallel: system fails only if both fail → Q = 0.02 × 0.05 = 0.0010.",
      "FORM",
      "Exam",
      [
        "Addition is for mutually exclusive single-path unions, not both-must-fail parallel.",
        "Key: independent parallel multiplies failure probabilities.",
        "Averaging does not model redundant failure.",
        "1 − (0.02+0.05) is not the both-fail probability.",
      ],
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 64,
    kind: "extra",
    topic: "diagnostic",
    ...exam(
      "DIAG.noise95",
      "Under OSHA 1910.95 with the 5 dB exchange rate and 90 dBA criterion, what is the maximum permissible duration at a continuous 95 dBA Leq before the 100% daily dose is reached?",
      [
        "8.0 hours",
        "4.0 hours",
        "2.0 hours",
        "1.0 hour",
      ],
      1,
      "T = 8 / 2^((L−90)/5). At 95 dBA, (95−90)/5 = 1 → T = 8/2 = 4 hours.",
      "FORM",
      "Exam",
      [
        "8 h is the criterion duration at 90 dBA, not 95.",
        "Key: one exchange step above 90 → half the time → 4 h.",
        "2 h is the 100 dBA OSHA duration.",
        "1 h is the 105 dBA OSHA duration.",
      ],
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 41,
    kind: "extra",
    topic: "diagnostic",
    ...exam(
      "DIAG.hazop",
      "Which analysis method applies guide words such as More, Less, No, and Reverse to process parameters (flow, pressure, temperature) to hunt deviations?",
      [
        "Failure Modes and Effects Analysis (FMEA)",
        "Hazard and Operability Study (HAZOP)",
        "Fault Tree Analysis (FTA)",
        "Job Safety Analysis (JSA)",
      ],
      1,
      "HAZOP is the guide-word method on process parameters. FMEA is failure modes; FTA is logic gates; JSA/JHA is job steps.",
      "TOOL",
      "Exam",
      [
        "FMEA lists component failure modes and effects — not guide words on parameters.",
        "Key: HAZOP = guide words × parameters.",
        "FTA builds top-event logic trees.",
        "JSA/JHA walks job steps and hazards.",
      ],
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 2,
    kind: "extra",
    topic: "diagnostic",
    ...exam(
      "DIAG.gdc",
      "Primary statutory objective of the OSHA General Duty Clause, Section 5(a)(1)?",
      [
        "Sets PELs for every known chemical automatically.",
        "Requires employers to furnish employment free from recognized hazards that are causing or are likely to cause death or serious physical harm.",
        "Lets any employee shut down a plant without supervision.",
        "Exempts employers with fewer than 50 workers from federal citations.",
      ],
      1,
      "5(a)(1) covers recognized serious hazards when no specific standard fully addresses them. It is not a universal PEL table or a headcount exemption.",
      "STEM",
      "Exam",
      [
        "PELs come from specific standards, not 5(a)(1) alone.",
        "Key: recognized serious hazard duty when specifics do not cover it.",
        "Shutdown authority is not the clause’s text.",
        "No blanket <50-worker exemption from the clause.",
      ],
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 14,
    kind: "extra",
    topic: "diagnostic",
    ...exam(
      "DIAG.bridle30",
      "A 10,000 lb symmetrical load hangs on a two-leg bridle. Horizontal sling angle θ = 30°. Tension in each leg?",
      [
        "5,000 lb (half the load, ignoring angle).",
        "7,071 lb (using 45° factor by habit).",
        "10,000 lb — (W/2)/sin(30°) = 5,000/0.5.",
        "20,000 lb (doubling the load).",
      ],
      2,
      "T = (W/2)/sin(θ). sin(30°)=0.5 → T = 5,000/0.5 = 10,000 lb per leg. Steep warning: low angles raise tension sharply.",
      "FORM",
      "Exam",
      [
        "Half the load ignores the angle factor.",
        "45° habit does not match a 30° stem.",
        "Key: (W/2)/sin(30°) = 10,000 lb.",
        "Doubling invents a factor the geometry does not require.",
      ],
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 1,
    kind: "extra",
    topic: "diagnostic",
    ...exam(
      "DIAG.ptd",
      "Under Prevention through Design thinking, when does hazard elimination usually cost the least and work the most?",
      [
        "Conceptual design and engineering.",
        "Construction and commissioning only.",
        "Routine operations after production starts.",
        "Decommissioning and demolition.",
      ],
      0,
      "PtD: eliminate early — conceptual/design phase — before steel and procedures lock the hazard in.",
      "HIER",
      "Exam",
      [
        "Key: earliest lifecycle phase.",
        "Construction still allows changes, but cost and constraints rise.",
        "Operations retrofit is expensive relative to design.",
        "Demolition is too late for elimination of the operating hazard.",
      ],
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 107,
    kind: "extra",
    topic: "diagnostic",
    ...exam(
      "DIAG.spcc.storm",
      "Aboveground tank holds 35,000 gal. Weather-exposed dike floor is 6,000 ft². Design storm depth on that floor is 4.8 in. Teaching SPCC idea: capacity for the largest tank plus precipitation freeboard (ignore displacements). Closest required containment volume?",
      [
        "35,000 gal (tank only).",
        "38,500 gal (110% of tank only).",
        "About 52,950 gal — 35,000 plus storm volume on the floor.",
        "70,000 gal (200% of tank).",
      ],
      2,
      "Storm depth 4.8/12 = 0.4 ft; 6,000×0.4 = 2,400 ft³; ×7.48 ≈ 17,952 gal. 35,000+17,952 ≈ 52,952 gal. Autopilot 110% (38,500) understates rain freeboard in this stem.",
      "FORM",
      "Expert",
      [
        "Tank-only ignores precipitation freeboard the stem requires.",
        "110% myth underestimates when rain volume is specified.",
        "Key: largest tank + (area × depth × 7.48).",
        "200% is not the federal teaching model here.",
      ],
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
];
