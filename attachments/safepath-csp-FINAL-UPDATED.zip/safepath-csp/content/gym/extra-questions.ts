import { exam } from "../classes/types";
import type { GymQuestion } from "./types";
import { TOX_FOUNDATION, TOX_EXAM } from "./tox-reference";
import { WHY_WRONG_QUESTIONS } from "./why-wrong";
import { ALGEBRA_QUESTIONS } from "./algebra";

export const MATH_QUESTIONS: GymQuestion[] = [
  {
    classId: 64,
    kind: "math",
    topic: "twa",
    ...exam(
      "MATH.twa",
      "IH sample: 90 ppm for 2 h and 30 ppm for 6 h. OSHA 8-hour TWA?",
      [
      "60 ppm (average of 90 and 30).",
      "45 ppm. (180 + 180)/8 = 45.",
      "90 ppm because the high period counts.",
      "36 ppm dividing by 10 hours.",
      ],
      1,
      "ΣCiTi/8 = 360/8 = 45. Not the unweighted mean of the two concentrations.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 64,
    kind: "math",
    topic: "twa",
    ...exam(
      "MATH.twa",
      "120 ppm for 1 h, 40 ppm for 3 h, 0 for the remaining 4 h of an 8-hour shift. TWA?",
      [
      "80 ppm averaging 120 and 40.",
      "30 ppm. (120 + 120 + 0)/8 = 30.",
      "40 ppm dividing by 4 hours of sampling.",
      "15 ppm using a 10-hour NIOSH day.",
      ],
      1,
      "(120×1 + 40×3 + 0×4)/8 = 240/8 = 30.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 64,
    kind: "math",
    topic: "twa",
    ...exam(
      "MATH.twa",
      "You are the CSP reviewing a live decision at a refinery coker outage. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Two 4-hour halves at 50 ppm and 70 ppm. TWA.",
      [
      "50 ppm.",
      "60 ppm. (200 + 280)/8 = 60. Equal times make this look like a simple mean — coincidence.",
      "120 ppm adding the concentrations.",
      "10 ppm using STEL rules.",
      ],
      1,
      "Equal times make the mean work; that is coincidence, not a new formula.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 64,
    kind: "math",
    topic: "twa",
    ...exam(
      "MATH.twa",
      "Last sentence: 8-hour TWA. Samples cover 5 hours at 80 ppm; the other 3 hours were 0. A tech divides 400 by 5 = 80. Error?",
      [
      "None — always divide by elapsed sample time.",
      "FORM: 8-hour TWA denominator is 8: 400/8 = 50 ppm.",
      "PELTLV — 80 is a TLV.",
      "TIME — 5 hours is the fatality clock.",
      ],
      1,
      "Do not swap elapsed time for the 8-hour denominator when the stem asked 8-hour TWA.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 68,
    kind: "math",
    topic: "twa",
    ...exam(
      "MATH.twa",
      "You are the CSP reviewing a live decision at a pharma suite changeover. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: CO: 25 ppm for 6 h and 100 ppm for 2 h. 8-hour TWA.",
      [
      "62.5 ppm arithmetic mean.",
      "43.8 ppm. (150 + 200)/8 = 43.75.",
      "100 ppm using the peak as TWA.",
      "12.5 ppm dividing by 16.",
      ],
      1,
      "Weighted by time, divided by 8.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 64,
    kind: "math",
    topic: "twa",
    ...exam(
      "MATH.twa",
      "Three periods: 200 ppm × 0.5 h, 50 ppm × 3.5 h, 10 ppm × 4 h. 8-hour TWA, closest?",
      [
      "87 ppm (mean of 200, 50, and 10).",
      "39 ppm. (100 + 175 + 40)/8 = 39.4.",
      "63 ppm dividing 315 by 5 hours of interesting time.",
      "200 ppm treating the peak as the TWA.",
      ],
      1,
      "ΣCiTi = 315; /8 = 39.4.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 83,
    kind: "math",
    topic: "twa",
    ...exam(
      "MATH.twa",
      "Noise: 4 h at a level whose OSHA allowed time is 4 h, and 4 h at a level whose allowed time is 8 h. Dose D?",
      [
      "100%.",
      "150%. 100×(4/4 + 4/8) = 150%.",
      "50%.",
      "200% adding the dB values.",
      ],
      1,
      "Dose is 100 Σ(C/T), not a TWA shortcut.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 83,
    kind: "math",
    topic: "twa",
    ...exam(
      "MATH.twa",
      "You are the CSP reviewing a live decision at a hospital utility plant shutdown. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: OSHA noise dose 200%. TWA from dose.",
      [
      "100 dBA doubling folklore.",
      "95 dBA. 90 + 16.61 log10(2) ≈ 90 + 5.00 = 95.",
      "90 dBA.",
      "85 dBA NIOSH folklore.",
      ],
      1,
      "LOG not LN. D=200% → +5 dB on the 90 criterion.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 64,
    kind: "math",
    topic: "twa",
    ...exam(
      "MATH.twa",
      "A 12-hour extended shift stem asks for the 12-hour TWA of 60 ppm for 12 h. Candidate still divides by 8 getting 90. Error?",
      [
      "None — always divide by 8.",
      "STEM/FORM: last sentence named a 12-hour TWA. 60×12/12 = 60, not 90.",
      "UNIT — they used mg/m³.",
      "PELTLV — 90 is a TLV.",
      ],
      1,
      "Match the averaging time named.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 68,
    kind: "math",
    topic: "twa",
    ...exam(
      "MATH.twa",
      "You are the CSP reviewing a live decision at a semiconductor tool install. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Solvent A only: 80 ppm × 3 h + 20 ppm × 5 h. TWA of A.",
      [
      "50 ppm mean.",
      "42.5 ppm. (240 + 100)/8 = 42.5.",
      "100 ppm sum.",
      "8 ppm dividing by 40.",
      ],
      1,
      "Single-agent TWA first; mixture unity would be a different item.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 83,
    kind: "math",
    topic: "xchg",
    ...exam(
      "MATH.xchg",
      "OSHA criterion 90 dBA, 5 dB exchange. Allowed time at 100 dBA?",
      [
      "4 h (one doubling from 90).",
      "2 h. (100−90)/5 = 2 doublings; T = 8/4 = 2 h.",
      "8 h.",
      "15 min STEL folklore.",
      ],
      1,
      "Two exchange steps from 90 → divide by 4.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 83,
    kind: "math",
    topic: "xchg",
    ...exam(
      "MATH.xchg",
      "You are the CSP reviewing a live decision at a municipal water-plant retrofit. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: OSHA 95 dBA allowed duration.",
      [
      "8 h.",
      "4 h. One 5 dB step above 90.",
      "2 h.",
      "16 h.",
      ],
      1,
      "Classic OSHA 95 → 4 h.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 83,
    kind: "math",
    topic: "xchg",
    ...exam(
      "MATH.xchg",
      "NIOSH 85 dBA criterion, 3 dB exchange. Allowed time at 91 dBA?",
      [
      "4 h mixing OSHA 5 dB.",
      "2 h. (91−85)/3 = 2 doublings; T = 8/4 = 2 h.",
      "8 h.",
      "6 h linear interpolation folklore.",
      ],
      1,
      "Matched NIOSH pair.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 83,
    kind: "math",
    topic: "xchg",
    ...exam(
      "MATH.xchg",
      "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: NIOSH 88 dBA allowed duration.",
      [
      "8 h OSHA folklore.",
      "4 h. One 3 dB step above 85.",
      "2 h.",
      "15 min.",
      ],
      1,
      "88 = 85+3 → one doubling → 4 h.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 83,
    kind: "math",
    topic: "xchg",
    ...exam(
      "MATH.xchg",
      "A stem names OSHA. Candidate uses T = 8 / 2^((L−85)/3) at 90 dBA. Error?",
      [
      "None — NIOSH is always stricter so use it.",
      "UNIT: OSHA pair is 90 & 5 dB. At 90 dBA OSHA T = 8 h, not a NIOSH formula.",
      "PELTLV — 85 is the PEL.",
      "FORM — they needed TRIR.",
      ],
      1,
      "Never mix criterion and exchange.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 83,
    kind: "math",
    topic: "xchg",
    ...exam(
      "MATH.xchg",
      "You are the CSP reviewing a live decision at a bridge deck pour laydown yard. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: OSHA 85 dBA (below criterion). Allowed time.",
      [
      "8 h only.",
      "16 h. (85−90)/5 = −1 doubling; T = 8 / 0.5 = 16 h.",
      "0 h because 85 < 90.",
      "4 h NIOSH folklore pasted onto OSHA.",
      ],
      1,
      "Below criterion, allowed time is longer than 8 h on the OSHA formula.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 83,
    kind: "math",
    topic: "xchg",
    ...exam(
      "MATH.xchg",
      "You are the CSP reviewing a live decision at a pharma suite changeover. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: OSHA 105 dBA. Allowed T.",
      [
      "4 h.",
      "1 h. (105−90)/5 = 3 doublings; 8/8 = 1 h.",
      "2 h.",
      "8 h.",
      ],
      1,
      "Three 5 dB steps from 90.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 83,
    kind: "math",
    topic: "xchg",
    ...exam(
      "MATH.xchg",
      "Worker at OSHA 100 dBA for 2 h (allowed T=2 h) only. Dose?",
      [
      "50%.",
      "100%. C/T = 2/2 = 1; D = 100%.",
      "200%.",
      "25%.",
      ],
      1,
      "Full allowed time at that level → 100% dose from that period alone.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 83,
    kind: "math",
    topic: "xchg",
    ...exam(
      "MATH.xchg",
      "Last sentence: NIOSH REL comparison. Level 85 dBA for 8 h. OSHA-minded candidate says under 90, dose 0. Error?",
      [
      "None — OSHA is the only system.",
      "UNIT/PELTLV: NIOSH 85 dBA for 8 h is 100% of the REL T. OSHA being under 90 does not answer a NIOSH stem.",
      "FORM — they needed Q=VA.",
      "TIME — 8 h is the fatality clock.",
      ],
      1,
      "Answer the system named.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 64,
    kind: "math",
    topic: "xchg",
    ...exam(
      "MATH.xchg",
      "You are the CSP reviewing a live decision at a hospital utility plant shutdown. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: OSHA 90 dBA for 4 h and 95 dBA for 2 h. Dose.",
      [
      "75%.",
      "100%. 4 h at 90 (T=8) is 50%; 2 h at 95 (T=4) is 50%; D=100%.",
      "150%.",
      "50% using only the 95 dBA period.",
      ],
      1,
      "Σ(C/T)=0.5+0.5.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 70,
    kind: "math",
    topic: "rwl",
    ...exam(
      "MATH.rwl",
      "You are the CSP reviewing a live decision at a food packaging SKU change. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: All NIOSH lifting multipliers = 1.0. RWL.",
      [
      "23 lb (kg folklore without converting).",
      "51 lb. LC × 1 = 51.",
      "51 kg.",
      "25.5 lb always.",
      ],
      1,
      "LC is 51 lb when multipliers are 1.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 70,
    kind: "math",
    topic: "rwl",
    ...exam(
      "MATH.rwl",
      "You are the CSP reviewing a live decision at a semiconductor tool install. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: HM = 0.50, all other multipliers 1.0. RWL.",
      [
      "51 lb treating LC as RWL.",
      "25.5 lb. 51 × 0.50 = 25.5.",
      "102 lb doubling.",
      "23 kg pasted in.",
      ],
      1,
      "Multipliers scale LC down.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 70,
    kind: "math",
    topic: "rwl",
    ...exam(
      "MATH.rwl",
      "You are the CSP reviewing a live decision at an offshore fabrication night shift. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: HM = 0.80, VM = 0.90, others 1. RWL closest.",
      [
      "51.",
      "36.7 lb. 51 × 0.80 × 0.90 = 36.72.",
      "40.8 using only HM.",
      "0.72 lb multiplying without LC.",
      ],
      1,
      "51 × 0.72 = 36.72.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 70,
    kind: "math",
    topic: "rwl",
    ...exam(
      "MATH.rwl",
      "You are the CSP reviewing a live decision at a municipal water-plant retrofit. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Load 40 lb, RWL 25.5 lb. Lift index.",
      [
      "14.5 (subtraction).",
      "1.57. 40 / 25.5 ≈ 1.57.",
      "0.64 inverted.",
      "51.",
      ],
      1,
      "LI = Load/RWL, not a subtraction.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 70,
    kind: "math",
    topic: "rwl",
    ...exam(
      "MATH.rwl",
      "Metric stem: LC = 23 kg, all multipliers 1. Someone answers 51 lb without converting the load. Error?",
      [
      "None — always 51.",
      "UNIT: stay in the unit system the stem named (23 kg), or convert both load and LC.",
      "PELTLV.",
      "TIME.",
      ],
      1,
      "Do not mix 51 lb with a kg stem.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 70,
    kind: "math",
    topic: "rwl",
    ...exam(
      "MATH.rwl",
      "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Coupling multiplier CM = 0.90, others 1. RWL.",
      [
      "51.",
      "45.9 lb. 51 × 0.90 = 45.9.",
      "5.1.",
      "90 lb.",
      ],
      1,
      "Poor coupling reduces RWL.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 70,
    kind: "math",
    topic: "rwl",
    ...exam(
      "MATH.rwl",
      "You are the CSP reviewing a live decision at a refinery coker outage. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: LI = 0.80, RWL = 40 lb. Load.",
      [
      "50 lb.",
      "32 lb. Load = LI × RWL = 0.80 × 40.",
      "40 lb.",
      "51 lb.",
      ],
      1,
      "Rearrange LI = Load/RWL.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 70,
    kind: "math",
    topic: "rwl",
    ...exam(
      "MATH.rwl",
      "Two answers: (1) RWL calculation shows LI 1.2 (2) the line can still be lowered so the lift dies. Last sentence leaves redesign open. Pick?",
      [
      "Accept LI 1.2 and buy belts.",
      "Higher hierarchy: eliminate/redesign the lift if still open; RWL is a check not a license.",
      "Use 51 lb anyway.",
      "Transfer via insurance.",
      ],
      1,
      "Math then hierarchy.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 70,
    kind: "math",
    topic: "rwl",
    ...exam(
      "MATH.rwl",
      "Frequency multiplier FM = 0.45 because of a high pace; others 1. RWL closest?",
      [
      "51.",
      "23.0 lb. 51 × 0.45 = 22.95.",
      "45 lb.",
      "11.3 using LC 23 kg mixed.",
      ],
      1,
      "Pace cuts RWL hard.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 70,
    kind: "math",
    topic: "rwl",
    ...exam(
      "MATH.rwl",
      "Someone treats LC = 51 lb as the RWL even though HM = 0.63. Error?",
      [
      "None — LC is always RWL.",
      "FORM: RWL = 51 × 0.63 ≈ 32.1 lb, not 51.",
      "UNIT — they needed 7.48.",
      "TOOL — they needed FTA.",
      ],
      1,
      "LC is the starting constant.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 26,
    kind: "math",
    topic: "trir",
    ...exam(
      "MATH.trir",
      "You are the CSP reviewing a live decision at a grain elevator maintenance day. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: 4 OSHA recordables, 250,000 hours. TRIR.",
      [
      "1.6 using 100,000.",
      "3.2. (4 × 200,000) / 250,000 = 3.2.",
      "4.0 using headcount 100.",
      "0.0016 raw.",
      ],
      1,
      "200,000-hour base.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 26,
    kind: "math",
    topic: "trir",
    ...exam(
      "MATH.trir",
      "You are the CSP reviewing a live decision at a hospital utility plant shutdown. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: 8 recordables, 1,000,000 hours. TRIR.",
      [
      "0.8 using 100,000.",
      "1.6. (8 × 200,000) / 1,000,000 = 1.6.",
      "8.",
      "16.",
      ],
      1,
      "(1,600,000)/1e6 = 1.6.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 26,
    kind: "math",
    topic: "trir",
    ...exam(
      "MATH.trir",
      "You are the CSP reviewing a live decision at a food packaging SKU change. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: 2 DART cases, 250,000 hours. DART rate.",
      [
      "0.8 using 100,000.",
      "1.6. (2 × 200,000) / 250,000 = 1.6.",
      "2.0.",
      "3.2 confusing with TRIR from 4 cases.",
      ],
      1,
      "Same 200,000 base as TRIR.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 85,
    kind: "math",
    topic: "trir",
    ...exam(
      "MATH.trir",
      "Site had 3 first-aid cases and 1 recordable in 200,000 hours. TRIR?",
      [
      "4.0 counting first aid.",
      "1.0. Only the recordable is N. (1 × 200,000)/200,000 = 1.",
      "3.0.",
      "0.",
      ],
      1,
      "First aid is not a recordable.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 26,
    kind: "math",
    topic: "trir",
    ...exam(
      "MATH.trir",
      "Someone uses 100,000 as the base instead of 200,000. 6 cases, 300,000 h. Correct TRIR vs their report?",
      [
      "Both 4.0.",
      "Correct is (6×200,000)/300,000 = 4.0. A 100,000 base reports 2.0 and understates by half.",
      "Both 2.0.",
      "6.0.",
      ],
      1,
      "100,000 is the classic trap.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 26,
    kind: "math",
    topic: "trir",
    ...exam(
      "MATH.trir",
      "You are the CSP reviewing a live decision at a municipal water-plant retrofit. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: TRIR = 2.5, EH = 400,000. How many recordables N.",
      [
      "10.",
      "5. N = TRIR × EH / 200,000 = 2.5 × 400,000 / 200,000 = 5.",
      "1.",
      "2.5.",
      ],
      1,
      "Rearrange the TRIR formula.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 85,
    kind: "math",
    topic: "trir",
    ...exam(
      "MATH.trir",
      "A manager wants to use year-end headcount 80 instead of hours in TRIR. Error?",
      [
      "None — headcount is OSHA's N.",
      "FORM/UNIT: EH is hours worked, not headcount. 200,000 already encodes 100 × 40 × 50.",
      "PELTLV.",
      "HIER.",
      ],
      1,
      "Hours, not heads.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 26,
    kind: "math",
    topic: "trir",
    ...exam(
      "MATH.trir",
      "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: 12 recordables, 600,000 hours. TRIR.",
      [
      "2.0 using 100,000.",
      "4.0. (12 × 200,000) / 600,000 = 4.0.",
      "12.",
      "0.02.",
      ],
      1,
      "2,400,000 / 600,000 = 4.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 26,
    kind: "math",
    topic: "trir",
    ...exam(
      "MATH.trir",
      "TRIR 3.0 and DART 0.5 at the same hours. Interpretation?",
      [
      "Impossible because DART must equal TRIR.",
      "Most recordables were not DART (recordable without days away/restriction/transfer). DART ≤ TRIR.",
      "DART is always twice TRIR.",
      "First aid drove TRIR.",
      ],
      1,
      "DART is a subset of recordables.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 33,
    kind: "math",
    topic: "trir",
    ...exam(
      "MATH.trir",
      "5 recordables, 200,000 hours. Someone reports TRIR = 5 / 100 = 0.05 per person. Error?",
      [
      "None.",
      "FORM: (5 × 200,000) / 200,000 = 5.0 on the OSHA base. Per-person folklore is not TRIR.",
      "UNIT — they needed 24.45.",
      "FIN — they needed ROI.",
      ],
      1,
      "TRIR is not a per-capita fraction.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 81,
    kind: "math",
    topic: "qva",
    ...exam(
      "MATH.qva",
      "You are the CSP reviewing a live decision at a pharma suite changeover. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: 10-inch round duct, V = 1,800 fpm. Closest Q (cfm).",
      [
      "3927 using diameter as radius.",
      "982. A=π(5/12)²≈0.545; Q≈982.",
      "1,800 ignoring area.",
      "5,400 using A=3.",
      ],
      1,
      "r = 5/12 ft, not 10/12. Q≈982 cfm.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 81,
    kind: "math",
    topic: "qva",
    ...exam(
      "MATH.qva",
      "You are the CSP reviewing a live decision at a warehouse second-shift startup. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: 18-inch round duct at 1,200 fpm. Closest Q.",
      [
      "3,054 using D as radius.",
      "2,121. A=π(0.75)²≈1.767; Q≈2,121 cfm.",
      "1,200.",
      "18,000.",
      ],
      1,
      "r = 9/12 = 0.75 ft.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 72,
    kind: "math",
    topic: "qva",
    ...exam(
      "MATH.qva",
      "You are the CSP reviewing a live decision at a grain elevator maintenance day. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Rectangular duct 2.0 ft × 1.5 ft, V = 800 fpm. Q.",
      [
      "1,200.",
      "2,400. A=3.0 ft²; Q=2,400 cfm.",
      "800.",
      "π×800.",
      ],
      1,
      "Rectangle: A = L×W, no π.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 81,
    kind: "math",
    topic: "qva",
    ...exam(
      "MATH.qva",
      "Q = 3,140 cfm, V = 2,000 fpm, round duct. Closest diameter?",
      [
      "2 in.",
      "17 in. A=Q/V=1.57 ft²; r=√(1.57/π)≈0.707 ft → D≈17 in.",
      "12 in using r=D.",
      "6 in.",
      ],
      1,
      "A = Q/V then D = 2√(A/π).",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 81,
    kind: "math",
    topic: "qva",
    ...exam(
      "MATH.qva",
      "You are the CSP reviewing a live decision at a food packaging SKU change. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: 8-inch round, 2,500 fpm. Closest Q.",
      [
      "3,491 using D as radius.",
      "873. A=π(4/12)²≈0.349; Q≈873 cfm.",
      "2,500.",
      "201.",
      ],
      1,
      "r = 4/12 ft.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 72,
    kind: "math",
    topic: "qva",
    ...exam(
      "MATH.qva",
      "Someone computes A with D = 12 in as 12 ft. V = 1,000 fpm. Error?",
      [
      "None.",
      "UNIT: 12 inches is 1.0 ft diameter, r = 0.5 ft, A≈0.785, Q≈785 cfm — not 12,000.",
      "FORM — they needed TRIR.",
      "STEM — 12 is a STEL.",
      ],
      1,
      "Inches are not feet.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 81,
    kind: "math",
    topic: "qva",
    ...exam(
      "MATH.qva",
      "Capture velocity 100 fpm through a 2 ft × 2 ft opening. Q?",
      [
      "100.",
      "400 cfm. A=4; Q=400.",
      "1,257 using π.",
      "25.",
      ],
      1,
      "Q = VA for the opening named.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 81,
    kind: "math",
    topic: "qva",
    ...exam(
      "MATH.qva",
      "You are the CSP reviewing a live decision at a municipal water-plant retrofit. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Metric: 0.30 m diameter, 10 m/s. Q closest.",
      [
      "3.0 m³/s using D as radius.",
      "0.71 m³/s. A=π(0.15)²≈0.0707; Q≈0.707 m³/s.",
      "10 m³/s.",
      "π×10.",
      ],
      1,
      "Stay metric; r = 0.15 m.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 72,
    kind: "math",
    topic: "qva",
    ...exam(
      "MATH.qva",
      "Branch carries 1,200 cfm; main already has 2,000 cfm. Combined Q if they join with no leak?",
      [
      "800 (subtraction).",
      "3,200 cfm. Flows add.",
      "2,000.",
      "1,200.",
      ],
      1,
      "Conservation of volume flow if density is constant.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 81,
    kind: "math",
    topic: "qva",
    ...exam(
      "MATH.qva",
      "Last sentence asks Q in cfm. Area was left in in² (113 in²) and V = 2,000 fpm. Candidate does 113×2000. Error?",
      [
      "None.",
      "UNIT: 113 in² = 113/144 ft² ≈ 0.785 ft²; Q≈1,571 cfm, not 226,000.",
      "FORM — they needed 7.48.",
      "PELTLV.",
      ],
      1,
      "Area must be ft² for fpm → cfm.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 71,
    kind: "math",
    topic: "dike",
    ...exam(
      "MATH.dike",
      "You are the CSP reviewing a live decision at a refinery coker outage. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Cylinder tank r = 3 ft, h = 8 ft. Volume closest.",
      [
      "904 ft³ using D as radius.",
      "226 ft³. π×9×8 ≈ 226.2.",
      "75 ft³ using 3×8.",
      "1,692 treating the result as gallons already.",
      ],
      1,
      "V = πr²h ≈ 226 ft³. Gallons would be ×7.48 next if asked.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 71,
    kind: "math",
    topic: "dike",
    ...exam(
      "MATH.dike",
      "You are the CSP reviewing a live decision at a bridge deck pour laydown yard. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Same tank 226 ft³. Gallons, closest.",
      [
      "226.",
      "1,691. 226 × 7.48 ≈ 1,690.",
      "7.48.",
      "1,808 using 8.0 gal/ft³ folklore.",
      ],
      1,
      "US gallons = ft³ × 7.48.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 71,
    kind: "math",
    topic: "dike",
    ...exam(
      "MATH.dike",
      "You are the CSP reviewing a live decision at a pharma suite changeover. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Dike 40 ft × 30 ft × 1.5 ft liquid height. Volume.",
      [
      "1,200 ft³ forgetting height.",
      "1,800 ft³. 40×30×1.5 = 1,800.",
      "180 ft³.",
      "13,464 treating ft³ as gallons already.",
      ],
      1,
      "LWH first, then convert if asked.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 71,
    kind: "math",
    topic: "dike",
    ...exam(
      "MATH.dike",
      "You are the CSP reviewing a live decision at a warehouse second-shift startup. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: 1,800 ft³ dike in gallons, closest.",
      [
      "1,800.",
      "13,464. 1,800 × 7.48 = 13,464.",
      "240.",
      "7,480 using 4.156.",
      ],
      1,
      "× 7.48.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 71,
    kind: "math",
    topic: "dike",
    ...exam(
      "MATH.dike",
      "Dike 20 × 20 × 2 ft. Tank footprint 10 × 10 ft sits in the dike; stem says subtract displacement of the tank walls occupying the floor. Net liquid volume?",
      [
      "800 ft³ ignoring footprint.",
      "600 ft³. (400 − 100)×2 = 600.",
      "200 ft³ subtracting 10×10×2 wrongly as 400.",
      "8,976 gallons without converting first.",
      ],
      1,
      "STEM: subtract the footprint × liquid height.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 71,
    kind: "math",
    topic: "dike",
    ...exam(
      "MATH.dike",
      "Cylinder D = 6 ft, h = 10 ft. Someone uses r = 6. Volume they get vs correct?",
      [
      "Both 283.",
      "Wrong ≈ 1,131 ft³ (4× too big); correct r=3, V=π×9×10 ≈ 283 ft³.",
      "Both 1,131.",
      "Correct is 60 ft³.",
      ],
      1,
      "Diameter as radius inflates ×4.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 71,
    kind: "math",
    topic: "dike",
    ...exam(
      "MATH.dike",
      "Wall height 4 ft but freeboard required 1 ft. L=25, W=10. Usable volume?",
      [
      "1,000 ft³ using 4 ft.",
      "750 ft³. 25×10×3 = 750.",
      "250.",
      "5,610 gallons as the first step.",
      ],
      1,
      "STEM: usable H = 4 − 1 = 3 ft.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 71,
    kind: "math",
    topic: "dike",
    ...exam(
      "MATH.dike",
      "Sphere r = 2 ft (stem says sphere, not cylinder). Volume closest?",
      [
      "25.1 ft³ using πr²h with h=2.",
      "33.5 ft³. (4/3)π×8 ≈ 33.51.",
      "16.8.",
      "4.2.",
      ],
      1,
      "Sphere is (4/3)πr³.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 71,
    kind: "math",
    topic: "dike",
    ...exam(
      "MATH.dike",
      "You are the CSP reviewing a live decision at an offshore fabrication night shift. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Box tank 8 × 4 × 3 ft. Gallons closest.",
      [
      "96.",
      "718. 96 × 7.48 ≈ 718.",
      "32.",
      "1,000.",
      ],
      1,
      "96 ft³ × 7.48.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 71,
    kind: "math",
    topic: "dike",
    ...exam(
      "MATH.dike",
      "Need 5,000 gal secondary. Dike 20 × 20 ft. Minimum liquid height, closest?",
      [
      "1.0 ft.",
      "1.67 ft. 5,000/7.48 ≈ 668 ft³; h = 668/400 ≈ 1.67 ft.",
      "12.5 ft using gallons as ft³.",
      "0.22 ft.",
      ],
      1,
      "Convert gallons to ft³ first.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 36,
    kind: "math",
    topic: "stats",
    ...exam(
      "MATH.stats",
      "You are the CSP reviewing a live decision at a plastics compounding turnaround. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Set 3, 7, 7, 9, 14. Mean.",
      [
      "7.",
      "8. Sum 40 / 5 = 8.",
      "9.",
      "11 range folklore.",
      ],
      1,
      "Σx/n = 8. Median would be 7.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 36,
    kind: "math",
    topic: "stats",
    ...exam(
      "MATH.stats",
      "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Set 3, 7, 7, 9, 14. Median.",
      [
      "8 (the mean).",
      "7. Ordered middle.",
      "14.",
      "3.",
      ],
      1,
      "Sort first; n odd → middle.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 36,
    kind: "math",
    topic: "stats",
    ...exam(
      "MATH.stats",
      "You are the CSP reviewing a live decision at a refinery coker outage. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Set 3, 7, 7, 9, 14. Mode.",
      [
      "8.",
      "7. Most frequent.",
      "No mode.",
      "14.",
      ],
      1,
      "7 appears twice.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 36,
    kind: "math",
    topic: "stats",
    ...exam(
      "MATH.stats",
      "You are the CSP reviewing a live decision at a bridge deck pour laydown yard. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: 4, 20, 8, 10. Median.",
      [
      "8 unsorted middle.",
      "9. Sort 4,8,10,20; (8+10)/2 = 9.",
      "10.5 mean.",
      "16 range/2.",
      ],
      1,
      "Even n: average the two middles after sorting.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 36,
    kind: "math",
    topic: "stats",
    ...exam(
      "MATH.stats",
      "You are the CSP reviewing a live decision at a pharma suite changeover. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: 12, 15, 18, 21. Mean.",
      [
      "15.",
      "16.5. Sum 66 / 4 = 16.5.",
      "18 median folklore.",
      "9.",
      ],
      1,
      "66/4 = 16.5.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 36,
    kind: "math",
    topic: "stats",
    ...exam(
      "MATH.stats",
      "You are the CSP reviewing a live decision at a warehouse second-shift startup. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Set 3, 7, 7, 9, 14. Range.",
      [
      "8 mean.",
      "11. 14 − 3 = 11.",
      "7.",
      "4.",
      ],
      1,
      "max − min.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 36,
    kind: "math",
    topic: "stats",
    ...exam(
      "MATH.stats",
      "You are the CSP reviewing a live decision at a grain elevator maintenance day. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Values 2, 4, 6. Sample s (n−1).",
      [
      "2 using /n giving 1.63.",
      "2. Mean 4; squared deviations 4+0+4=8; /2=4; s=2.",
      "√8 = 2.83 using /1.",
      "0.",
      ],
      1,
      "Sample uses n−1.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 36,
    kind: "math",
    topic: "stats",
    ...exam(
      "MATH.stats",
      "You are the CSP reviewing a live decision at a hospital utility plant shutdown. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: x=118, μ=100, σ=9. z.",
      [
      "18.",
      "2.0. (118−100)/9 = 2.",
      "0.5.",
      "9.",
      ],
      1,
      "z = (x−μ)/σ.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 38,
    kind: "math",
    topic: "stats",
    ...exam(
      "MATH.stats",
      "Defects: A 40, B 30, C 15, D 10, E 5 (n=100). First two categories are what percent (Pareto)?",
      [
      "50%.",
      "70%. 40+30.",
      "45% mean.",
      "100%.",
      ],
      1,
      "Vital few: 70% in A+B.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 37,
    kind: "math",
    topic: "stats",
    ...exam(
      "MATH.stats",
      "Independent P(A fail)=0.1, P(B fail)=0.1. P(both fail)?",
      [
      "0.2 adding.",
      "0.01. 0.1 × 0.1.",
      "0.19 OR formula.",
      "1.0.",
      ],
      1,
      "Independent AND is a product.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 68,
    kind: "math",
    topic: "ppm",
    ...exam(
      "MATH.ppm",
      "You are the CSP reviewing a live decision at an offshore fabrication night shift. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: CO MW=28, 50 ppm at 25 °C. mg/m³ closest.",
      [
      "50.",
      "57.3. (50×28)/24.45 ≈ 57.3.",
      "62.5 using 22.4.",
      "1.75 inverted.",
      ],
      1,
      "(ppm×MW)/24.45.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 68,
    kind: "math",
    topic: "ppm",
    ...exam(
      "MATH.ppm",
      "You are the CSP reviewing a live decision at a municipal water-plant retrofit. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: H2S MW=34, 10 ppm at 25 °C. mg/m³ closest.",
      [
      "10.",
      "13.9. (10×34)/24.45 ≈ 13.9.",
      "15.2 using 22.4.",
      "0.72.",
      ],
      1,
      "Correct molar conversion.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 68,
    kind: "math",
    topic: "ppm",
    ...exam(
      "MATH.ppm",
      "You are the CSP reviewing a live decision at a plastics compounding turnaround. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Benzene MW=78, 1 ppm at 25 °C. mg/m³ closest.",
      [
      "1.",
      "3.19. 78/24.45 ≈ 3.19.",
      "3.48 using 22.4.",
      "24.45.",
      ],
      1,
      "1 ppm of MW 78 is about 3.2 mg/m³.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 68,
    kind: "math",
    topic: "ppm",
    ...exam(
      "MATH.ppm",
      "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Acetone MW=58, 250 ppm at 25 °C. mg/m³ closest.",
      [
      "250.",
      "593. (250×58)/24.45 ≈ 593.",
      "647 using 22.4.",
      "0.42.",
      ],
      1,
      "14500/24.45.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 68,
    kind: "math",
    topic: "ppm",
    ...exam(
      "MATH.ppm",
      "You are the CSP reviewing a live decision at a refinery coker outage. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Toluene MW=92, 50 ppm at 25 °C. mg/m³ closest.",
      [
      "50.",
      "188. (50×92)/24.45 ≈ 188.",
      "206 using 22.4.",
      "2.65.",
      ],
      1,
      "Mass/volume from volume/volume.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 68,
    kind: "math",
    topic: "ppm",
    ...exam(
      "MATH.ppm",
      "You are the CSP reviewing a live decision at a bridge deck pour laydown yard. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: SO2 MW=64, 13 mg/m³ → ppm at 25 °C, closest.",
      [
      "13.",
      "5.0. (13×24.45)/64 ≈ 4.96.",
      "4.6 using 22.4.",
      "20.3.",
      ],
      1,
      "Reverse: ppm = (mg/m³ × 24.45)/MW.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 84,
    kind: "math",
    topic: "ppm",
    ...exam(
      "MATH.ppm",
      "You are the CSP reviewing a live decision at a pharma suite changeover. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: CO MW=28, 35 ppm → mg/m³ at 25 °C, closest.",
      [
      "35.",
      "40.1. (35×28)/24.45 ≈ 40.08.",
      "43.8 using 22.4.",
      "1.25.",
      ],
      1,
      "980/24.45.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 68,
    kind: "math",
    topic: "ppm",
    ...exam(
      "MATH.ppm",
      "Stem at 25 °C. Candidate uses 22.4 on CO 50 ppm MW 28. Their mg/m³ vs correct?",
      [
      "Both 57.3.",
      "Wrong 62.5; correct 57.3. UNIT on molar volume.",
      "Both 62.5.",
      "Correct is 50.",
      ],
      1,
      "22.4 is 0 °C.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 68,
    kind: "math",
    topic: "ppm",
    ...exam(
      "MATH.ppm",
      "Silica dust 0.05 mg/m³ 'converted' to ppm with MW 60. Error?",
      [
      "None.",
      "UNIT: particulates do not use 24.45 and MW. Stay in mg/m³.",
      "FORM — they needed Q=VA.",
      "PELTLV — silica has no PEL.",
      ],
      1,
      "Dusts are not gases.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 84,
    kind: "math",
    topic: "ppm",
    ...exam(
      "MATH.ppm",
      "ppm = (mg/m³ × 24.45)/MW. Chlorine MW=71, 1.5 mg/m³ → ppm closest?",
      [
      "1.5.",
      "0.52. (1.5×24.45)/71 ≈ 0.52.",
      "0.47 using 22.4.",
      "3.5.",
      ],
      1,
      "Reverse conversion.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 33,
    kind: "math",
    topic: "roi",
    ...exam(
      "MATH.roi",
      "You are the CSP reviewing a live decision at a food packaging SKU change. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Avoided loss $80,000, project cost $20,000. ROI.",
      [
      "25% (payback inverted).",
      "300%. (80,000−20,000)/20,000 = 3.0 → 300%.",
      "400% using Gain/Cost without subtracting.",
      "4 years labeled as percent.",
      ],
      1,
      "ROI = (Gain−Cost)/Cost.",
      "FIN",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 33,
    kind: "math",
    topic: "roi",
    ...exam(
      "MATH.roi",
      "You are the CSP reviewing a live decision at a semiconductor tool install. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Gain $45,000, cost $30,000. ROI.",
      [
      "67% using Gain/Cost.",
      "50%. (45,000−30,000)/30,000 = 0.50.",
      "150%.",
      "1.5 years.",
      ],
      1,
      "15,000/30,000 = 50%.",
      "FIN",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 33,
    kind: "math",
    topic: "roi",
    ...exam(
      "MATH.roi",
      "You are the CSP reviewing a live decision at an offshore fabrication night shift. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Cost $40,000, annual savings $10,000. Simple payback.",
      [
      "400% ROI folklore.",
      "4 years. 40,000/10,000 = 4.",
      "0.25 years inverted.",
      "10%.",
      ],
      1,
      "Payback is years, not percent.",
      "FIN",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 44,
    kind: "math",
    topic: "roi",
    ...exam(
      "MATH.roi",
      "You are the CSP reviewing a live decision at a municipal water-plant retrofit. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Someone labels 4-year payback as 4% ROI. Error.",
      [
      "None — they are the same.",
      "FIN/FORM: payback years ≠ ROI percent.",
      "UNIT — dollars vs hours.",
      "TOOL — they needed FMEA.",
      ],
      1,
      "Different objects.",
      "FIN",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 33,
    kind: "math",
    topic: "roi",
    ...exam(
      "MATH.roi",
      "You are the CSP reviewing a live decision at a plastics compounding turnaround. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: PV benefits $120,000, PV costs $80,000. BCR.",
      [
      "40,000 (subtraction).",
      "1.5. 120,000/80,000 = 1.5.",
      "67%.",
      "1.5%.",
      ],
      1,
      "BCR is a ratio, not ROI%.",
      "FIN",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 44,
    kind: "math",
    topic: "roi",
    ...exam(
      "MATH.roi",
      "Last sentence: transfer the residual via insurance. Option set includes a 200% ROI engineering project still open. Pick?",
      [
      "Buy insurance because FIN always wins.",
      "If loss prevention/engineering is still open and the stem did not forbid it, prevention outranks transfer. Insurance is share/transfer.",
      "ROI 200% is impossible.",
      "Cite the TLV.",
      ],
      1,
      "Financial four: avoid/prevent before transfer when still open.",
      "FIN",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 33,
    kind: "math",
    topic: "roi",
    ...exam(
      "MATH.roi",
      "You are the CSP reviewing a live decision at a refinery coker outage. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Gain $25,000, cost $25,000. ROI.",
      [
      "100%.",
      "0%. (25,000−25,000)/25,000 = 0.",
      "25,000%.",
      "1 year payback labeled ROI.",
      ],
      1,
      "Break-even on this simple ROI.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 33,
    kind: "math",
    topic: "roi",
    ...exam(
      "MATH.roi",
      "You are the CSP reviewing a live decision at a bridge deck pour laydown yard. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Cost $12,000, gain $18,000. ROI.",
      [
      "150% using Gain/Cost.",
      "50%. (18,000−12,000)/12,000 = 0.50.",
      "67%.",
      "6,000%.",
      ],
      1,
      "Do not skip subtracting cost.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 33,
    kind: "math",
    topic: "roi",
    ...exam(
      "MATH.roi",
      "Annual savings $8,000 for 5 years undiscounted, cost $20,000. Simple ROI using total gain 40,000?",
      [
      "40%.",
      "100%. (40,000−20,000)/20,000 = 1.0. Payback would be 2.5 years.",
      "250% using 40,000/20,000 without subtracting.",
      "8%.",
      ],
      1,
      "If the stem uses total gain, subtract cost then divide by cost.",
      "FIN",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 44,
    kind: "math",
    topic: "roi",
    ...exam(
      "MATH.roi",
      "Retention (pay from operating funds) is named. A vendor sells 'transfer' as a new glove program. Error?",
      [
      "None — gloves transfer risk.",
      "FIN: gloves are a control (and often PPE). Transfer is insurance/contract. Retention is keeping the loss.",
      "HIER only.",
      "UNIT.",
      ],
      1,
      "Financial four language is precise.",
      "FIN",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  }
];

export const EXTRA_DOMAIN: GymQuestion[] = [
  {
    classId: 1,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.1",
      "A new washer can still be specified aqueous. Package on the table: LEL sensors, fire watch, supplied-air. Last sentence: design is not frozen. Best control family?",
      [
      "Buy the supplied-air first — that is PtD.",
      "Substitute the cleaner / enclose only if solvent remains. Sensors and respirators wait.",
      "Keep the flammable solvent for 'quality' and add gloves.",
      "Transfer via insurance.",
      ],
      1,
      "PtD moves the decision to concept/material.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 2,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.2",
      "Two answers both reduce risk: a new glove and a guard that can still be designed in. Pick?",
      [
      "The glove because PPE is faster.",
      "The guard — higher on the hierarchy if it is still open.",
      "A toolbox talk.",
      "A poster.",
      ],
      1,
      "If two work, take higher hierarchy / system / design.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 3,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.3",
      "PSM-covered process. Team skips MOC because 'it is only a gasket material change.' Error?",
      [
      "None — gaskets are never MOC.",
      "STEM: composition/service changes can be MOC. PPE after the leak is not MOC.",
      "UNIT.",
      "TIME — gasket is a 24-hour clock.",
      ],
      1,
      "MOC is about change, not about gasket folklore.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 4,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.4",
      "Qualified electrical worker. Last sentence: LOTO of a 480 V starter. Option: GFCI on the drill is sufficient. Error?",
      [
      "None — GFCI is lockout.",
      "GFCI is not LOTO. Isolate and verify.",
      "PELTLV.",
      "FIN.",
      ],
      1,
      "GFCI ≠ lockout.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 5,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.5",
      "Stored pneumatic energy in a press. Locks on the electrical disconnect only. Residual air can still cycle the ram. Error?",
      [
      "None — electrical LOTO covers all energy.",
      "Isolate and verify ALL energy, including residual/stored.",
      "UNIT — psi vs bar.",
      "TOOL — they needed FMEA.",
      ],
      1,
      "Energy isolation is multi-source.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 6,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.6",
      "12-ft deck, 6-ft lanyard, no clearance math. Candidate says 'lanyard is 6 ft so deck is OK.' Error?",
      [
      "None.",
      "STEM: clearance is lanyard + deceleration + harness + D-ring + margin, often ≫ 6 ft.",
      "FORM — they needed TRIR.",
      "PELTLV.",
      ],
      1,
      "6-ft lanyard ≠ 6-ft clearance.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 7,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.7",
      "Excavation 6 ft, spoils at the lip, no protective system, Type C soil. Best immediate system move?",
      [
      "Hard hats at the lip.",
      "Protective system / bench/slope as required and move spoils back; competent person.",
      "A new cone.",
      "Insurance.",
      ],
      1,
      "Cave-in control is the system, not PPE-only.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 8,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.8",
      "Robot cell with a light curtain that can be muted during auto. Last sentence: stored energy still in the end effector. Best?",
      [
      "Mute the curtain and reach in.",
      "Guard/exclude, then LOTO stored energy before entry. A hard hat is not the design.",
      "First-aid kit closer.",
      "DART target.",
      ],
      1,
      "Separate people from energy.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 9,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.9",
      "Permit space: oxygen 19.2% from nitrogen. Team calls it chemical asphyxia like CO and issues air-purifying cartridges. Error?",
      [
      "None — cartridges fix argon/nitrogen.",
      "Simple asphyxiant / IDLH-class atmosphere: do not use APR cartridges for oxygen deficiency.",
      "UNIT — 19.2 is ppm.",
      "FIN.",
      ],
      1,
      "Displacement vs chemical asphyxiant; IDLH atmosphere.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 10,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.10",
      "Work over water from a platform that can still be redesigned with guardrails and a net. Option set leads with 'more PFDs.' Pick?",
      [
      "PFDs as PtD.",
      "Eliminate the over-water exposure or engineer the platform/net; PFDs last.",
      "A new poster.",
      "Transfer.",
      ],
      1,
      "Hierarchy over water too.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 11,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.11",
      "Egress path blocked by seasonal storage. Life-safety stem. Best?",
      [
      "Issue flashlights.",
      "Restore the occupant path / keep storage out of the required egress.",
      "A fire watch forever.",
      "DART.",
      ],
      1,
      "Life safety is occupant protection and egress.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 12,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.12",
      "Fleet: overnight drivers, no journey management. Option: buy brighter cones. Last sentence: fatigue and vehicle spec still open. Pick?",
      [
      "Cones as the design.",
      "Journey management, hours, vehicle spec — cones are not the system.",
      "A new TRIR target.",
      "TLV for diesel.",
      ],
      1,
      "System before yard props.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 13,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.13",
      "PIT pedestrian aisle unmarked; engineering can still add exclusion and speed control. Option: sticker on the forklift. Pick?",
      [
      "Sticker.",
      "Separate pedestrians and control energy; stickers are admin/PPE-adjacent.",
      "First aid.",
      "ROI only.",
      ],
      1,
      "Design the flow.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 14,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.14",
      "Two-leg sling, 30° to horizontal, load 2,000 lb. Tension each leg (DEG)?",
      [
      "1,000 lb forgetting /sin.",
      "2,000 lb. sin 30°=0.5; T=1000/0.5=2000.",
      "−988 using RAD.",
      "500 lb.",
      ],
      1,
      "Low angles inflate tension. DEG.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 15,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.15",
      "Load can be slid on a lift table. Option: back belt and 51 lb RWL as permission. Pick?",
      [
      "Belt as PtD.",
      "Redesign the path/height; RWL is a check, not a license; belts are not elimination.",
      "51 lb always OK.",
      "Insurance.",
      ],
      1,
      "Ergo hierarchy.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 16,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.16",
      "Interlock defeated with a magnet. Last sentence: guard can be redesigned to be defeat-resistant. Pick?",
      [
      "Retrain only.",
      "Fix the guard/interlock design; training alone leaves the magnet trick in place.",
      "A new glove.",
      "FMEA RPN on the magnet as FTA.",
      ],
      1,
      "Engineering over a memo.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 79,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.79",
      "Teach-mode robot, no reduced-speed / enabling device. Best?",
      [
      "Hard hat in the cell.",
      "Teach-mode safeguarding: reduced speed, enabling device, clearances — not PPE as the design.",
      "TRIR.",
      "TLV.",
      ],
      1,
      "Robotics deep is still hierarchy.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 80,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.80",
      "Dust collector: fuel, oxidizer, confinement, possible cloud, ignition sources not controlled. Option: new coveralls. Pick?",
      [
      "Coveralls as explosion control.",
      "Treat as combustible dust: ignition control, isolation, housekeeping that does not disperse, explosion protection as needed.",
      "A cone.",
      "DART.",
      ],
      1,
      "Dust pentagon, not PPE.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 82,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.82",
      "Hot work on a tank formerly flammable. Option: skip gas test because the welder is certified. Error?",
      [
      "None.",
      "Permit, test, combustibles, fire watch — certification is not a gas test.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "Hot work controls are the system.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 87,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.87",
      "PSM element list. Option adds 'buy better PPE' as a 15th element that replaces mechanical integrity. Error?",
      [
      "None — PPE is element 15.",
      "STEM: fourteen 1910.119 elements. PPE does not replace MI, MOC, PHA.",
      "PELTLV.",
      "TIME.",
      ],
      1,
      "No 15th PPE element.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 17,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.17",
      "Gap analysis starts with a new slogan and branded mugs. Required clause still unmet. Error?",
      [
      "None — culture first always.",
      "Gap is current vs required. Slogan is not the analysis.",
      "UNIT.",
      "FIN only.",
      ],
      1,
      "Diagnose before merch.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 18,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.18",
      "ISO clause highlighted; no owner, no procedure, no date. Error?",
      [
      "None — highlighting is the plan.",
      "Translate the clause into a site plan with an owner.",
      "TOOL — they needed FTA.",
      "PELTLV.",
      ],
      1,
      "Standards-to-plan.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 19,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.19",
      "Poster says safety first; supervisors reward only production. Culture stem. Best read?",
      [
      "The poster is the culture.",
      "Culture is what is rewarded and tolerated, not the poster.",
      "TRIR is culture.",
      "TLV.",
      ],
      1,
      "Lived vs laminated.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 20,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.20",
      "Investigation jumps to 'careless worker' before preserving the scene. Error?",
      [
      "None — blame is root cause.",
      "Preserve, collect, analyze; do not skip to blame.",
      "FORM.",
      "UNIT.",
      ],
      1,
      "Method before verdict.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 21,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.21",
      "Corrective action: 'be more careful.' Recurrence likely. Best?",
      [
      "Add a second 'be more careful.'",
      "CAPA that changes the system; preventive for sister units.",
      "A new slogan.",
      "Insurance as the only CA.",
      ],
      1,
      "Corrective is a system change.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 22,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.22",
      "Temporary hose in a PSM process left in place 8 months with no MOC. Error?",
      [
      "None — temporary never needs MOC.",
      "STEM: duration does not erase MOC. Change the process then the procedure.",
      "TIME as 8-hour fatality clock.",
      "PELTLV.",
      ],
      1,
      "Temporary can still be MOC.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 23,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.23",
      "Top event 'tank overfill' with AND/OR gates. Team computes RPN. Error?",
      [
      "None — RPN is for all trees.",
      "TOOL: FTA is logic/cut sets; RPN is FMEA.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "Wrong tool.",
      "TOOL",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 24,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.24",
      "FMEA row S=8 O=3 D=10. Team uses the product as a probability of the top event on a fault tree. Error?",
      [
      "None.",
      "TOOL: RPN prioritizes FMEA rows; it is not FTA probability.",
      "FORM — they needed TRIR.",
      "HIER.",
      ],
      1,
      "RPN ≠ P(top).",
      "TOOL",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 25,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.25",
      "Safety case = a stack of unused JHAs in a drawer. Error?",
      [
      "None — volume is the argument.",
      "A safety case is argument plus evidence that risk is tolerated, not a pile.",
      "UNIT.",
      "TIME.",
      ],
      1,
      "Argument + evidence.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 26,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.26",
      "Only lagging TRIR is on the board. Leading inspections died. Best?",
      [
      "TRIR is sufficient leading.",
      "Pair leading activities with lagging outcomes.",
      "TLV.",
      "ROI only.",
      ],
      1,
      "Leading vs lagging.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 27,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.27",
      "ISO 45001 vs 14001 vs 19011 mix-up: team audits OH&S using 14001 as the OH&S MSS. Error?",
      [
      "None — 14001 is safety.",
      "45001 is OH&S MSS; 14001 is environmental; 19011 is audit guidance.",
      "TOOL FTA.",
      "PELTLV.",
      ],
      1,
      "Do not swap MSS families.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 28,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.28",
      "Z10 treated as identical to 45001 in every clause. Best?",
      [
      "They are word-for-word the same exam object.",
      "Related OH&S MSS family — do not assume every clause is identical; read the stem.",
      "Z10 is a noise standard.",
      "Z10 is RCRA.",
      ],
      1,
      "Rhyme ≠ identical.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 29,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.29",
      "Environmental aspect register empty; 45001 binder is thick. 14001 stem. Best?",
      [
      "The 45001 binder covers 14001.",
      "14001 needs environmental aspects/impacts and those controls.",
      "A hard hat.",
      "TRIR.",
      ],
      1,
      "Different MSS object.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 30,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.30",
      "Audit competence ignored; a new hire 'does 19011' by walking around once. Error?",
      [
      "None.",
      "19011: audit principles and competence, evidence-based. A walk is not automatically an audit.",
      "PELTLV.",
      "FIN.",
      ],
      1,
      "Audit ≠ tour.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 31,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.31",
      "You are the CSP reviewing a live decision at a pharma suite changeover. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Policy 'we care' with no who/when/how plan. Pick.",
      [
      "Policy is enough.",
      "Policy is intent; plan is who/when/how. Write the plan.",
      "A slogan.",
      "Insurance.",
      ],
      1,
      "Do not swap policy and plan.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 32,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.32",
      "Medical diagnosis posted on the break-room OSHA log board. Error?",
      [
      "None — full medical detail is required on the wall.",
      "Privacy/retention: keep required records for the clock; do not post medical details.",
      "UNIT.",
      "HIER.",
      ],
      1,
      "Privacy on injury records.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 33,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.33",
      "Control with no budget line and no owner. 'We will find money later.' Error?",
      [
      "None — goodwill is a budget.",
      "A control needs a funded owner.",
      "TLV.",
      "FTA.",
      ],
      1,
      "Budget/ROI class.",
      "FIN",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 34,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.34",
      "Annual speech, no resources, no accountability. Leadership stem. Best?",
      [
      "The speech is leadership.",
      "Resource, accountability, presence — not a once-a-year speech.",
      "A poster.",
      "DART.",
      ],
      1,
      "Lived leadership.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 35,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.35",
      "Three people marked Accountable on a RACI for the same confined-space program. Error?",
      [
      "None — more Accountable is better.",
      "One Accountable; many may be Responsible.",
      "RACI is a formula.",
      "RACI is a PEL.",
      ],
      1,
      "A = one person.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 36,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.36",
      "Skewed injury-cost set. Stem asks median. Candidate reports mean pulled by one lawsuit. Error?",
      [
      "None — mean always.",
      "FORM/STEM: median for skew when asked.",
      "UNIT.",
      "FIN only.",
      ],
      1,
      "Mean vs median.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 37,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.37",
      "You are the CSP reviewing a live decision at an offshore fabrication night shift. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: CI around a mean used as if it were a PEL. Error.",
      [
      "None — CI is a PEL.",
      "A confidence interval is a statistics object, not an OEL (PELTLV/FORM).",
      "HIER.",
      "TIME.",
      ],
      1,
      "CI ≠ PEL.",
      "PELTLV",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 38,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.38",
      "Unsorted bar chart. Candidate 'Pareto' by coloring the shortest bar. Error?",
      [
      "None.",
      "Sort contribution descending; vital few vs trivial many.",
      "UNIT.",
      "HIER.",
      ],
      1,
      "Pareto is a sort.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 85,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.85",
      "Fatality at 09:00. Reported to OSHA at 22:00 next day. Clock?",
      [
      "OK — 24 hours for fatalities.",
      "TIME: fatalities are an 8-hour report clock. Hospitalizations/amputations/loss of eye: 24 hours.",
      "PELTLV.",
      "FORM TRIR.",
      ],
      1,
      "8-hour fatality clock.",
      "TIME",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 39,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.39",
      "Risk process skipped after a nice matrix workshop with no owners. Best?",
      [
      "The workshop is the whole process.",
      "Identify, analyze, evaluate, treat, monitor — with owners.",
      "A glove.",
      "TLV.",
      ],
      1,
      "Process, not a poster matrix.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 40,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.40",
      "JHA used as the PHA for a covered chemical process. Error?",
      [
      "None — JHA = PHA.",
      "TOOL: JHA is job-based; PHA is process-based (HAZOP/what-if).",
      "UNIT.",
      "FIN.",
      ],
      1,
      "Wrong tool.",
      "TOOL",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 41,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.41",
      "HAZOP on a process. Team fills FMEA RPNs and stops. Last sentence asked nodes/deviations. Error?",
      [
      "None.",
      "TOOL/STEM: HAZOP uses nodes and guidewords; RPN is FMEA.",
      "HIER.",
      "TIME.",
      ],
      1,
      "PHA method named.",
      "TOOL",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 42,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.42",
      "Hierarchy in risk treatment: PPE listed as 'elimination' because it eliminates the injury on paper. Error?",
      [
      "None.",
      "PPE is last; elimination removes the hazard.",
      "FIN.",
      "UNIT.",
      ],
      1,
      "Do not relabel PPE as elimination.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 43,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.43",
      "Hazard register with no owner and no review date. Best?",
      [
      "A one-time poster is a register.",
      "Living register: owner, review, status.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Living document.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 44,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.44",
      "Stem: retain the deductible, transfer the tail. Candidate 'avoids' by buying gloves. Error?",
      [
      "None — gloves are transfer.",
      "FIN: retain vs share/transfer vs avoid vs reduce — gloves are a control, not insurance.",
      "HIER only.",
      "TOOL.",
      ],
      1,
      "Financial four.",
      "FIN",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 45,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.45",
      "Sprinkler after ignition vs removing the fuel before. Last sentence: prevention still open. Pick?",
      [
      "Sprinkler as prevention.",
      "Loss prevention stops the event; reduction shrinks severity after it starts. Prefer prevention if open.",
      "Insurance only.",
      "TLV.",
      ],
      1,
      "Prevention vs reduction.",
      "FIN",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 46,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.46",
      "Control installed, never inspected. Monitoring stem. Best?",
      [
      "Install is monitor.",
      "Ask whether the control is still working — inspections, IH, leading indicators.",
      "A slogan.",
      "DART as the only monitor.",
      ],
      1,
      "Monitoring is ongoing.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 86,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.86",
      "Last sentence names FTA. Options include FMEA RPN, JHA, and a bowtie. Pick?",
      [
      "RPN.",
      "The fault tree for the named top event.",
      "JHA.",
      "Bowtie only because it is fashionable.",
      ],
      1,
      "Tool choice follows the last sentence.",
      "TOOL",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 47,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.47",
      "ERP with no roles, no comms, no maps. Pretty cover. Error?",
      [
      "Cover is contents.",
      "ERP contents: roles, comms, maps, shutdown, medical, accountability.",
      "TLV.",
      "TRIR.",
      ],
      1,
      "Contents, not cover.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 48,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.48",
      "ICS: three Incident Commanders on one scene 'for balance.' Error?",
      [
      "None — more IC is better.",
      "One IC; sections under IC. Unity of command.",
      "FIN.",
      "PELTLV.",
      ],
      1,
      "ICS unity.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 49,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.49",
      "BCP treated as identical to the fire ERP. Plant cannot invoice for 3 weeks after a flood. Error?",
      [
      "None — ERP is BCP.",
      "BCP keeps critical functions running; ERP is the emergency response. Both may be needed.",
      "UNIT.",
      "HIER.",
      ],
      1,
      "BCP vs ERP.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 50,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.50",
      "Fire prevention: fuel/ignition control still open. Option: more extinguishers only. Pick?",
      [
      "Extinguishers as prevention.",
      "Prevent ignition/fuel first; extinguishers are protection/reduction.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Prevention vs protection.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 51,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.51",
      "Sprinkler valve shut for a year, no impairment program. Protection stem. Best?",
      [
      "Assume it works.",
      "Impairment control, restore protection, compensatory measures.",
      "A new poster.",
      "Gloves.",
      ],
      1,
      "Protection must actually be on.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 52,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.52",
      "Placard/ERG vs 'we will google it in the tunnel.' Hazmat transport stem. Best?",
      [
      "Google in the tunnel.",
      "Identify the material and use the ERG/plan; security as named.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "ID then guide.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 53,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.53",
      "Workplace violence: only a poster. Engineering of access and a response plan still open. Pick?",
      [
      "Poster as the design.",
      "Access control, procedures, training, aftercare — poster is not the system.",
      "TLV.",
      "FTA RPN.",
      ],
      1,
      "System vs poster.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 54,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.54",
      "Drill never run; binder on a shelf. Last sentence: exercise the plan. Pick?",
      [
      "The binder is a drill.",
      "Run the drill, evaluate, fix the plan.",
      "Insurance.",
      "PEL.",
      ],
      1,
      "A binder is not a drill.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 88,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.88",
      "OT ransomware can shut down ESD. ERP has no cyber initiator. Last sentence leaves adding it open. Pick?",
      [
      "Cyber is never emergency.",
      "Put OT/IT failure in the ERP if the stem leaves it open.",
      "Buy gloves.",
      "TRIR.",
      ],
      1,
      "Cyber as emergency initiator.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 55,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.55",
      "End-of-pipe scrubber celebrated while the process can still not make the waste. P2 stem. Pick?",
      [
      "Scrubber as P2.",
      "Source reduction / P2 first if still open.",
      "A new drum.",
      "DART.",
      ],
      1,
      "P2 beats end-of-pipe when open.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 56,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.56",
      "Incompatible oxidizer stored with fuels, alphabetical-only. GHS storage. Best?",
      [
      "Alphabetical is enough.",
      "Compatibility, containment, labels — not alphabet-only.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Storage chemistry.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 57,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.57",
      "Listed hazardous waste in an open unlabeled drum in the rain. RCRA-flavored stem. Best?",
      [
      "Rain is a treatment.",
      "Contain, label, close, time limits, proper TSDF path.",
      "Pour it to the storm sewer as P2.",
      "Hard hat.",
      ],
      1,
      "Hazardous waste controls.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 58,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.58",
      "Spent lamps in a dumpster with food waste. Universal waste still available. Pick?",
      [
      "Dumpster is fine.",
      "Manage as universal waste (or hazardous if they do not qualify) — not mixed trash.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Universal waste path.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 59,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.59",
      "Sustainability report with no legal air permit work. Stem asks the legal control first. Pick?",
      [
      "The report is the permit.",
      "Meet the legal environmental controls; the report is not a permit.",
      "Gloves.",
      "FTA.",
      ],
      1,
      "Legal vs brochure.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 60,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.60",
      "Dry ACM demolition with a shop-vac. Exam-level asbestos/air. Best?",
      [
      "Shop-vac as NESHAPs control.",
      "Wet methods, containment, competent work practices — not dry shop-vac on ACM.",
      "TRIR.",
      "ROI only.",
      ],
      1,
      "Do not dry-grind ACM.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 61,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.61",
      "IH skipped anticipation; they bought respirators after the first illness. AREC order?",
      [
      "Control first is AREC.",
      "Anticipate/recognize/evaluate then control; respirators last if higher controls were open.",
      "TRIR first.",
      "FTA first.",
      ],
      1,
      "AREC order.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 62,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.62",
      "One grab sample at lunch used as the 8-hour TWA for a varying task. Error?",
      [
      "None — grab is TWA.",
      "STEM/FORM: sampling strategy must represent the TWA the stem asked.",
      "PELTLV only.",
      "FIN.",
      ],
      1,
      "Strategy vs a convenient grab.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 63,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.63",
      "Silica Table-1-style wet method still open; team issues N95 only. Pick?",
      [
      "N95 as PtD.",
      "Wet method / LEV / Table 1 equivalent before respirator-only.",
      "DART.",
      "ROI.",
      ],
      1,
      "Silica hierarchy.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 64,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.64",
      "OSHA noise stem; candidate uses NIOSH 3 dB times. Error?",
      [
      "None — always NIOSH.",
      "UNIT: matched 90/5 vs 85/3 pairs.",
      "PELTLV only.",
      "FIN.",
      ],
      1,
      "Do not mix exchange rates.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 65,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.65",
      "You are the CSP reviewing a live decision at a warehouse second-shift startup. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: Point source 4 mR/h at 2 m. At 4 m.",
      [
      "2 mR/h (halve distance, halve dose).",
      "1 mR/h. Inverse square: ×(2/4)² = ×1/4.",
      "8 mR/h.",
      "0.",
      ],
      1,
      "I2 = I1 (d1/d2)².",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 66,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.66",
      "Indoor heat stem. Candidate adds 0.1 Tdb solar term to WBGT. Error?",
      [
      "None — always outdoor formula.",
      "STEM: indoor/no sun is 0.7 nwb + 0.3 g.",
      "UNIT.",
      "PELTLV.",
      ],
      1,
      "Match indoor vs outdoor WBGT.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 67,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.67",
      "Bloodborne: needle recapping by two-hand as the 'procedure.' Engineering still open (sharps devices). Pick?",
      [
      "Two-hand recap as PtD.",
      "Safer devices / sharps containers; two-hand recap is not the design.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Bio hierarchy.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 69,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.69",
      "Written silica exposure plan skipped because 'we have SDS.' Error?",
      [
      "SDS is the exposure plan.",
      "Exposure plans are written programs the standard triggers — SDS is not the whole plan.",
      "FIN.",
      "TIME fatality clock.",
      ],
      1,
      "Plan ≠ SDS.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 70,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.70",
      "You are the CSP reviewing a live decision at a semiconductor tool install. Operations proposes a convenience path. Using the class rule, which option is strongest? Focus: LI 1.4 and a lift table still purchasable. Pick.",
      [
      "Belt.",
      "Buy/install the table if still open; LI 1.4 is a flag not a belt prescription.",
      "51 lb rule of thumb.",
      "Insurance.",
      ],
      1,
      "Ergo design.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 81,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.81",
      "Hood 8 ft from a point source, 'dilution will capture.' Capture stem. Best?",
      [
      "Dilution is capture.",
      "Move the hood to the source; capture velocity is a local object.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Capture ≠ dilution.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 84,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.84",
      "Auditor cites a TLV miss as 'OSHA noncompliance' while under the PEL. Error?",
      [
      "None — TLV is OSHA.",
      "PELTLV: TLV miss can be a program finding; OSHA citation basis is the PEL unless incorporated.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "Legal vs advisory.",
      "PELTLV",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 73,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.73",
      "Training picked because a vendor had a booth. No performance gap. Error?",
      [
      "None — vendors are needs.",
      "Needs assessment starts with the performance gap.",
      "PELTLV.",
      "TRIR.",
      ],
      1,
      "Gap first.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 74,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.74",
      "80 slides, no practice, no feedback. Adult learning stem. Best?",
      [
      "More slides.",
      "Prior knowledge, relevance, practice, feedback.",
      "A harder quiz only.",
      "Insurance.",
      ],
      1,
      "Adults need practice.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 75,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.75",
      "AI-drafted procedure posted with no SME check; it invented a PEL. Error?",
      [
      "None — AI is always accurate.",
      "CSP still owns accuracy/bias/assessment; invented PELs are PELTLV/STEM.",
      "UNIT.",
      "FIN.",
      ],
      1,
      "AI drafts; humans own.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 76,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.76",
      "Evaluation shows operators still bypass. Fix = two extra slides. Error?",
      [
      "Slides fix bypass.",
      "Improve design/guards/practice from the data, not only slides.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Improve the system.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 77,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.77",
      "Attendance 100% called 'effectiveness.' Behavior unchanged. Error?",
      [
      "Attendance is Kirkpatrick results.",
      "Effectiveness is behavior/results, not seat time.",
      "PELTLV.",
      "FORM TRIR.",
      ],
      1,
      "Attendance ≠ effectiveness.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 78,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.78",
      "Competency = hours in a chair. Observed cannot perform. Error?",
      [
      "Hours are competency.",
      "Competency is observed ability to perform.",
      "A poster.",
      "ROI.",
      ],
      1,
      "Show, not sit.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 89,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.89",
      "Z490.1-flavored stem: no learning objectives, no evaluation. Pick?",
      [
      "Skip objectives if the room is full.",
      "Accepted training practice: objectives, delivery, evaluation.",
      "TRIR as the objective.",
      "TLV as the objective.",
      ],
      1,
      "Training system, not a room.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 90,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.90",
      "Exam sitting: calculator in RAD, stem is a 30° sling. Best first move?",
      [
      "Stay in RAD.",
      "DEG, then compute; closest rounded option.",
      "Invent a formula sheet.",
      "Use mean of the options.",
      ],
      1,
      "Calculator lab: DEG.",
      "UNIT",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 2,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.2",
      "Ventilation specified while a water-based process is still open. Last sentence: drawings are not frozen. Pick?",
      [
      "LEV as PtD winner.",
      "Substitution still open beats add-on LEV.",
      "A new glove.",
      "A new TRIR goal.",
      ],
      1,
      "Hierarchy at design freeze.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 5,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.5",
      "Shift handover 'we usually don't lock that valve.' Energy still live. Best?",
      [
      "Follow the folklore.",
      "LOTO as written; isolate and verify. Folklore is not energy isolation.",
      "GFCI.",
      "A cone.",
      ],
      1,
      "Written isolation.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 9,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.9",
      "Atmospheric test order skipped; they test only LEL. O2 is 16%. Error?",
      [
      "LEL-only is enough.",
      "Test the atmosphere including oxygen; 16% is immediately dangerous regardless of LEL story.",
      "UNIT ppm.",
      "FIN.",
      ],
      1,
      "O2 then LEL/tox as the procedure named.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 20,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.20",
      "Five-why stopped at 'human error' with no condition that allowed it. Best?",
      [
      "Stop at human error.",
      "Keep going to the system condition; human error is a start not a root.",
      "Buy insurance.",
      "Cite TLV.",
      ],
      1,
      "System cause.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 27,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.27",
      "Internal audit uses only production supervisors grading themselves with no independence. 19011/45001 flavor. Error?",
      [
      "None — self-grade is independence.",
      "Audit needs independence/objectivity proportional to the stem.",
      "PELTLV.",
      "RWL.",
      ],
      1,
      "Independence.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 40,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.40",
      "Job changes every hour; JHA from 2011 still posted. Best?",
      [
      "2011 JHA is eternal.",
      "Update the JHA when the job changes.",
      "PHA instead always.",
      "RPN.",
      ],
      1,
      "Living JHA.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 48,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.48",
      "Finance/Admin section asked to run rescue. ICS stem. Error?",
      [
      "Any section can be rescue.",
      "Operations runs tactical work; Finance/Admin is not rescue.",
      "PELTLV.",
      "FORM.",
      ],
      1,
      "ICS sections.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 57,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.57",
      "Empty drum that held listed waste, valves open, no labels. 'It's empty so not waste.' Error?",
      [
      "Empty always means trash.",
      "Residue/empty-container rules still apply; do not assume trash.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Empty drums can still be regulated.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 64,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.64",
      "Hearing conservation triggered; they only post a cartoon. Engineering of the press still open. Pick?",
      [
      "Cartoon as engineering.",
      "Engineer the noise if still open; program elements are not a muffler.",
      "DART.",
      "ROI only.",
      ],
      1,
      "Noise hierarchy.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 74,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.74",
      "SME lecture, no retrieval practice, exam-only at day 90. Adult learning. Best add?",
      [
      "Longer lecture.",
      "Practice and feedback during training, not only a distant exam.",
      "A harder font.",
      "Insurance.",
      ],
      1,
      "Practice.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 4,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.4",
      "Approach boundary ignored because 'we have leather gloves.' Last sentence: unqualified worker. Pick?",
      [
      "Leather is qualification.",
      "Unqualified workers stay outside approach boundaries; gloves do not qualify.",
      "GFCI equals entry.",
      "TRIR.",
      ],
      1,
      "Qualification + distance.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 11,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.11",
      "Dead-end corridor used for pallet storage, occupancy load up. Life safety. Best?",
      [
      "Keep the pallets; add a bell.",
      "Keep required egress capacity/arrangement — storage is not an occupant path.",
      "A fire watch forever as the design.",
      "DART.",
      ],
      1,
      "Egress is the object.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 34,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.34",
      "Supervisor present on nights after a fatality only. Leadership as presence. Best read of 'before'?",
      [
      "Presence only after harm is the model.",
      "Leadership presence is a leading practice, not only a lagging visit.",
      "A speech.",
      "A TLV.",
      ],
      1,
      "Leading presence.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 45,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.45",
      "Insurance purchased; fuel still next to ignition with prevention open. Last sentence: treat the risk. Pick?",
      [
      "Insurance is prevention.",
      "Prevention/reduction of the event if still open; insurance is transfer.",
      "PPE as transfer.",
      "FTA RPN.",
      ],
      1,
      "FIN + hierarchy.",
      "FIN",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 51,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.51",
      "Fire pump test records blank for 18 months. Protection. Best?",
      [
      "Assume reliability.",
      "Test/impairment program; blank records mean unknown protection.",
      "A new extinguisher sticker.",
      "ROI.",
      ],
      1,
      "Proof of protection.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 56,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.56",
      "GHS label removed so the drum 'looks cleaner.' Storage. Error?",
      [
      "Cleaner is safer.",
      "Keep labels; identity/hazard is the control.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Labels stay.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 62,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.62",
      "Similar exposure group ignored; one favorite operator sampled. Evaluation stem. Risk?",
      [
      "Favorite is always worst-case.",
      "STEM: SEG/strategy should represent the group the last sentence named.",
      "PELTLV only.",
      "FIN.",
      ],
      1,
      "Representativeness.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 77,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.77",
      "Level-1 smile sheet 100%. Stem asks whether the job changed. Pick?",
      [
      "Smile sheet = results.",
      "Need behavior/results evidence; reaction is not performance.",
      "TLV.",
      "TRIR as smile.",
      ],
      1,
      "Evaluation level match.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 3,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.3",
      "Relief valve set points changed on a Saturday by a well-meaning mechanic. No PHA/MOC. PSM. Best?",
      [
      "Saturday exempts MOC.",
      "MOC/PHA as required; set point is a process change.",
      "Buy PPE.",
      "DART.",
      ],
      1,
      "Set points are change.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 13,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.13",
      "Aerial lift on a slope beyond the manual. Option: 'hold the controls tighter.' Pick?",
      [
      "Tighter grip is the design.",
      "Do not operate outside the manual; choose equipment/grade that fits.",
      "A hard hat.",
      "Insurance.",
      ],
      1,
      "Limits of the machine.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 21,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.21",
      "Sister plant has the same machine. CA only at the incident plant. Preventive still open. Pick?",
      [
      "Never tell sister plants.",
      "Preventive action for like equipment/sites when the stem leaves it open.",
      "A slogan.",
      "TLV.",
      ],
      1,
      "CAPA spread.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 39,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.39",
      "Risk score 4×4=16 treated as a probability of 16%. Error?",
      [
      "None — scores are probabilities.",
      "FORM/TOOL: a matrix score is not automatically P=0.16.",
      "PELTLV.",
      "TIME.",
      ],
      1,
      "Scores ≠ probabilities unless the stem says so.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a warehouse second-shift startup.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 47,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.47",
      "Accountability list missing from ERP. Fire drill then cannot find people. Best?",
      [
      "Skip accountability.",
      "ERP contents include accountability; add and drill it.",
      "TRIR.",
      "RWL.",
      ],
      1,
      "Who is still inside.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a grain elevator maintenance day.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 59,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.59",
      "Net-zero poster; solvent still dumped to sink. Sustainability vs legal. Pick?",
      [
      "Poster is P2.",
      "Stop the illegal dump; poster is not a control.",
      "FTA.",
      "BEI.",
      ],
      1,
      "Legal baseline.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a hospital utility plant shutdown.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 70,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.70",
      "Asymmetry multiplier ignored on a 90° twist lift. RWL too high. Error?",
      [
      "AM always 1.",
      "FORM: include AM when the stem gives a twist.",
      "UNIT 7.48.",
      "PELTLV.",
      ],
      1,
      "All six multipliers.",
      "FORM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a food packaging SKU change.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 78,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.78",
      "Sign-in sheet used to authorize a high-hazard task. Competency stem. Pick?",
      [
      "Sign-in is competency.",
      "Verify observed skill/authorization; attendance is not a permit to perform.",
      "A longer sheet.",
      "ROI.",
      ],
      1,
      "Authorization ≠ hours.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a semiconductor tool install.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 6,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.6",
      "Leading-edge work, 18-ft fall, SRL specified but anchored at the feet. Clearance/swing. Best?",
      [
      "Feet-level anchor always OK.",
      "Check clearance, swing, and compatible anchorage; feet-level can eat clearance.",
      "A 6-ft lanyard because 6 < 18.",
      "Insurance.",
      ],
      1,
      "Anchorage and clearance.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at an offshore fabrication night shift.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 16,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.16",
      "Presence sensing used as the LOTO for reaching into a live die area. Error?",
      [
      "Presence sensing is LOTO.",
      "Guarding ≠ isolation. LOTO for the entry the stem named.",
      "GFCI is LOTO.",
      "TRIR.",
      ],
      1,
      "Sensing is not lockout.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a municipal water-plant retrofit.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 32,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.32",
      "Records destroyed at 14 days to 'reduce privacy risk' including OSHA logs still in the required keep period. Error?",
      [
      "14 days is always enough.",
      "TIME/STEM: keep required records for the statutory clock; privacy is not a shredder for legal logs.",
      "HIER.",
      "FORM.",
      ],
      1,
      "Retention clock.",
      "TIME",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a plastics compounding turnaround.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 43,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.43",
      "Risk register lists 'meteor' and nothing about the actual press. Best?",
      [
      "Meteors first.",
      "Register the actual workplace risks with owners.",
      "TLV of meteors.",
      "RPN of meteors on FTA.",
      ],
      1,
      "Relevant register.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a Gulf Coast chemical terminal.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 54,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.54",
      "Drill success defined as 'we finished pizza.' No objectives. Best?",
      [
      "Pizza is the objective.",
      "Set drill objectives, inject, evaluate against them.",
      "TRIR.",
      "BEI.",
      ],
      1,
      "Evaluate the drill.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a refinery coker outage.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 81,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.81",
      "Q computed correctly; last sentence still allows substituting a low-emission process. Pick?",
      [
      "Ship the Q as the winner.",
      "If substitution is open, it still outranks a perfect dilution number.",
      "Buy a bigger fan only.",
      "Cite TLV.",
      ],
      1,
      "Math then hierarchy.",
      "HIER",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a bridge deck pour laydown yard.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  },
  {
    classId: 90,
    kind: "extra",
    topic: "extra",
    ...exam(
      "CSP-11 D-extra.90",
      "Closest-value stem. Candidate invents extra sig figs and picks nothing, then guesses A. Best?",
      [
      "Always A.",
      "Compute full precision then pick the nearest listed option.",
      "Mean of options.",
      "RAD mode always.",
      ],
      1,
      "Closest rounded.",
      "STEM",
      "Exam",
    {
      scenarioText: "You are the CSP reviewing a live decision at a pharma suite changeover.",
      standardReference: "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem",
      fieldTakeaway: "Prefer higher hierarchy and verify the critical step. Verify the critical step before accepting a lower-tier control.",
    }
  ),
  }
];

export const EXTRA_QUESTIONS: GymQuestion[] = [
  ...MATH_QUESTIONS,
  ...ALGEBRA_QUESTIONS,
  ...TOX_FOUNDATION,
  ...TOX_EXAM,
  ...EXTRA_DOMAIN,
  ...WHY_WRONG_QUESTIONS,
];
