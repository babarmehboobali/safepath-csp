import type { ClassItem } from "../classes/types";

export type GymKind = "math" | "tox" | "extra" | "challenge";

export type GymQuestion = ClassItem & {
  classId: number;
  kind: GymKind;
  topic: string;
};

export type FormulaSeed = {
  slug: string;
  name: string;
  expression: string;
  variables: string;
  whenToUse: string;
  pitfall: string;
  pitfallCode: string;
  workedExample: string;
  units: string;
};

export type TermSeed = {
  kind: "def" | "abbr";
  term: string;
  meaning: string;
  topic: "tox" | "general";
};

export type CardSeed = {
  deck: "class" | "tox" | "formula" | "vocab";
  front: string;
  back: string;
  classId?: number | null;
};

export type SessionBlock = {
  id: number;
  title: string;
  blurb: string;
  classIds: number[];
  domains: number[];
};
