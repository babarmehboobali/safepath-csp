import { PrismaClient } from "@prisma/client";
import { hash } from "bcryptjs";
import { CLASS_PACKS } from "../content/classes";
import { CATALOG } from "../lib/catalog";
import { ERROR_CODES } from "../lib/constants";
import {
  EXTRA_FORMULAS,
  EXTRA_QUESTIONS,
  EXTRA_CARDS,
  TOX_DEFS,
  TOX_ABBREVS,
  CHALLENGE_QUESTIONS,
  DIAGNOSTIC_EXTRAS,
} from "../content/gym";
import { letterCounts, shuffleOptions } from "../lib/shuffle-options";

const prisma = new PrismaClient();

const PLACEHOLDER = {
  hook: "Workplace decision for this task will be written in a later domain pack.",
  rule: "One reusable rule will sit here. Until then, if two answers work, take higher hierarchy / system / design.",
  modelCaption: "Drawable model placeholder — Prompt G will wire the SVG.",
  workedCase: "Worked case placeholder.",
  trapsJson: JSON.stringify(["Trap 1 placeholder", "Trap 2 placeholder", "Trap 3 placeholder"]),
  contrastJson: JSON.stringify([{ looksLike: "Looks-like placeholder", actually: "Actually placeholder" }]),
  brief: "Brief notes for this blueprint task will land in a later pack.",
  standard: "Standard notes placeholder.",
  deep: "Deep notes placeholder.",
  cardFront: "Card front placeholder",
  cardBack: "Card back placeholder — memory schedule 1 / 3 / 7 / 21 days once this class ships.",
  teachBackKey: "Teach-back key placeholder.",
  mustScoreJson: "[]",
  stemIfThenJson: "[]",
};

function distractorsJsonFor(
  q: { distractors?: string[]; options: string[]; answerIndex: number; explanation: string },
  sample: boolean,
): string | null {
  if (q.distractors && q.distractors.length === 4) return JSON.stringify(q.distractors);
  if (!sample) return null;
  return JSON.stringify(
    q.options.map((opt, i) =>
      i === q.answerIndex
        ? `Key: ${q.explanation.slice(0, 120)}`
        : `Not this option (${opt.slice(0, 70)}). The stored explanation is the rule.`,
    ),
  );
}


function optionTrapsJsonFor(q: {
  optionTraps?: string[];
  distractors?: string[];
}): string | null {
  const traps = q.optionTraps && q.optionTraps.length === 4 ? q.optionTraps : null;
  if (traps) return JSON.stringify(traps);
  if (q.distractors && q.distractors.length === 4) return JSON.stringify(q.distractors);
  return null;
}

function mathJsonFor(q: { stepByStepMath?: unknown }): string | null {
  if (!q.stepByStepMath) return null;
  return JSON.stringify(q.stepByStepMath);
}

function difficultyLevelFor(q: {
  difficultyLevel?: string;
  difficulty: string;
}): string {
  if (q.difficultyLevel) return q.difficultyLevel;
  if (q.difficulty === "Foundation") return "Fundamental";
  if (q.difficulty === "Expert") return "Advanced Engineering";
  return "Applied Scenario";
}

async function main() {
  // Upgrade-safe catalog refresh. Re-running seed after git pull upserts class
  // rows by id and replaces class/gym questions so new catalog ids appear
  // without duplicates. User accounts, sessions, AUTH_SECRET, and .env stay.
  // Do not use prisma migrate reset as the default path.

  const passwordHash = await hash("Demo1234!", 12);
  await prisma.user.upsert({
    where: { email: "demo@cspcoach.app" },
    update: { passwordHash, isDemo: true, name: "Demo candidate" },
    create: {
      email: "demo@cspcoach.app",
      passwordHash,
      name: "Demo candidate",
      isDemo: true,
      onboardingComplete: false,
      industrySkin: "manufacturing",
      track: "recommended",
      depth: "standard",
      difficulty: "exam",
    },
  });

  for (const code of ERROR_CODES) {
    await prisma.errorCode.upsert({
      where: { code: code.code },
      update: { meaning: code.meaning },
      create: code,
    });
  }

  await prisma.formula.deleteMany();
  for (const f of EXTRA_FORMULAS) {
    await prisma.formula.create({ data: f });
  }

  for (const entry of CATALOG) {
    const base = {
      id: entry.id,
      domain: entry.domain,
      title: entry.title,
      taskCode: entry.taskCode,
      isMaximum: entry.isMaximum,
    };
    const pack = CLASS_PACKS[entry.id];
    const classData = pack
      ? (() => {
          const { formulaSlug, mustScoreJson, stemIfThenJson, ...fields } = pack.classFields;
          return {
            ...base,
            ...fields,
            formulaSlug: formulaSlug ?? null,
            mustScoreJson: mustScoreJson ?? "[]",
            stemIfThenJson: stemIfThenJson ?? "[]",
          };
        })()
      : { ...base, ...PLACEHOLDER };

    const { id: classId, ...classUpdate } = classData;
    await prisma.class.upsert({
      where: { id: classId },
      update: classUpdate,
      create: classData,
    });

    await prisma.question.deleteMany({ where: { classId: entry.id, kind: "class" } });
    if (pack?.items.length) {
      await prisma.question.createMany({
        data: pack.items.map((q) => ({
          classId: entry.id,
          stem: q.stem,
          optionsJson: JSON.stringify(q.options),
          answerIndex: q.answerIndex,
          explanation: q.authoritativeRationale ?? q.explanation,
          errorCode: q.errorCode,
          taskCode: q.taskCode,
          difficulty: q.difficulty,
          kind: "class",
          distractorsJson: distractorsJsonFor(q, false),
          scenarioText: q.scenarioText ?? null,
          standardReference: q.standardReference ?? null,
          difficultyLevel: difficultyLevelFor(q),
          optionTrapsJson: optionTrapsJsonFor(q),
          fieldTakeaway: q.fieldTakeaway ?? null,
          mathJson: mathJsonFor(q),
        })) as never,
      });
    }
  }

  await prisma.question.deleteMany({ where: { kind: { not: "class" } } });
  const gymItems = [...EXTRA_QUESTIONS, ...CHALLENGE_QUESTIONS, ...DIAGNOSTIC_EXTRAS];
  const chunk = 200;
  let extraSample = 0;
  for (let i = 0; i < gymItems.length; i += chunk) {
    const slice = gymItems.slice(i, i + chunk);
    await prisma.question.createMany({
      data: slice.map((q) => {
        const has = Boolean(q.distractors && q.distractors.length === 4);
        const sample = !has && q.kind === "extra" && extraSample < 40;
        if (sample) extraSample += 1;
        return {
          classId: q.classId,
          stem: q.stem,
          optionsJson: JSON.stringify(q.options),
          answerIndex: q.answerIndex,
          explanation: q.authoritativeRationale ?? q.explanation,
          errorCode: q.errorCode,
          taskCode: q.taskCode,
          difficulty: q.difficulty,
          kind: q.kind,
          distractorsJson: distractorsJsonFor(q, sample),
          scenarioText: q.scenarioText ?? null,
          standardReference: q.standardReference ?? null,
          difficultyLevel: difficultyLevelFor(q),
          optionTrapsJson: optionTrapsJsonFor(q),
          fieldTakeaway: q.fieldTakeaway ?? null,
          mathJson: mathJsonFor(q),
        };
      }) as never,
    });
  }

  await prisma.card.deleteMany();
  if (EXTRA_CARDS.length) {
    await prisma.card.createMany({
      data: EXTRA_CARDS.map((c) => ({
        deck: c.deck,
        front: c.front,
        back: c.back,
        classId: c.classId ?? null,
      })),
    });
  }

  await prisma.referenceTerm.deleteMany();
  const terms = [...TOX_DEFS, ...TOX_ABBREVS];
  if (terms.length) {
    await prisma.referenceTerm.createMany({
      data: terms.map((t) => ({
        kind: t.kind,
        term: t.term,
        meaning: t.meaning,
        topic: t.topic,
      })),
    });
  }

  const filled = Object.keys(CLASS_PACKS).length;
  const questions = await prisma.question.count();
  const byKind = await prisma.question.groupBy({ by: ["kind"], _count: { _all: true } });
  const formulas = await prisma.formula.count();
  const cards = await prisma.card.count();
  const classCards = await prisma.class.count({ where: { cardFront: { not: "" } } });
  const defs = await prisma.referenceTerm.count({ where: { kind: "def" } });
  const abbrs = await prisma.referenceTerm.count({ where: { kind: "abbr" } });
  console.log(
    `Seed complete: demo user, ${CATALOG.length} classes, ${filled} gold packs, ${questions} items, ${formulas} formulas, ${cards} extra cards, ${classCards} class cards, ${defs} defs, ${abbrs} abbrevs.`,
  );
  const withWhy = await prisma.question.count({ where: { distractorsJson: { not: null } } });
  console.log("By kind:", Object.fromEntries(byKind.map((k) => [k.kind, k._count._all])));
  console.log("Items with why-wrong distractorsJson:", withWhy);
  // Counts use unchecked filters so seed typechecks before `prisma generate` refreshes client types.
  const q = prisma.question as unknown as {
    count: (args: { where: Record<string, unknown> }) => Promise<number>;
  };
  const withTraps = await q.count({ where: { optionTrapsJson: { not: null } } });
  const withMath = await q.count({ where: { mathJson: { not: null } } });
  const withTakeaway = await q.count({ where: { fieldTakeaway: { not: null } } });
  console.log(`Enhanced fields: optionTraps=${withTraps} mathJson=${withMath} fieldTakeaway=${withTakeaway}`);

  const sample = await prisma.question.findMany({
    take: 200,
    select: { id: true, optionsJson: true, answerIndex: true },
  });
  const served = sample.map((q) => {
    let options: string[] = [];
    try {
      const parsed = JSON.parse(q.optionsJson) as unknown;
      if (Array.isArray(parsed)) options = parsed.map(String);
    } catch {
      options = [];
    }
    return shuffleOptions({ id: q.id, options, answerIndex: q.answerIndex }).answerIndex;
  });
  const mix = letterCounts(served);
  console.log(
    `Serve-time shuffle (n=${served.length}): A=${mix.A} B=${mix.B} C=${mix.C} D=${mix.D}`,
  );
  if (served.length >= 80) {
    const n = served.length;
    for (const [L, c] of Object.entries(mix)) {
      const pct = (c / n) * 100;
      if (pct < 10 || pct > 45) {
        console.warn(`Shuffle mix warning: ${L} is ${pct.toFixed(1)}%`);
      }
    }
    if (served.every((i) => i === 1)) {
      throw new Error("Serve-time shuffle left every sampled key on B");
    }
  }
}

main()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
