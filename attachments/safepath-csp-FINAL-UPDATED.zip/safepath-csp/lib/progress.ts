import { prisma } from "./prisma";
import { CARD_INTERVALS } from "./constants";

export type ReadyGate = {
  mockCountAt70: number;
  mocksNeeded: number;
  domainFloors: Record<number, number | null>;
  weakDomains: number[];
  ready: boolean;
  reason: string;
};

export async function domainScoresForUser(userId: string, isDemo: boolean): Promise<Record<number, number | null>> {
  const scores: Record<number, number | null> = { 1: null, 2: null, 3: null, 4: null, 5: null, 6: null, 7: null };
  if (isDemo) return scores;

  // Self-assessments are the strongest signal for the planner because they
  // are explicitly designed to diagnose the learner. Fall back to recent
  // mock-run domain averages when no self-assessment exists yet.
  const diagnostic = await prisma.gymRun.findFirst({
    where: {
      userId,
      gym: { in: ["self-assessment", "assess"] },
      NOT: { slug: { in: ["pre", "post"] } },
    },
    orderBy: { createdAt: "desc" },
    select: { answersJson: true },
  });

  if (diagnostic) {
    try {
      const payload = JSON.parse(diagnostic.answersJson) as { domainScores?: Record<string, number> };
      const parsed = payload.domainScores || {};
      let found = false;
      for (const d of [1, 2, 3, 4, 5, 6, 7]) {
        const value = parsed[String(d)];
        if (typeof value === "number") {
          scores[d] = value;
          found = true;
        }
      }
      if (found) return scores;
    } catch {
      // Fall through to mock history if the diagnostic payload is malformed.
    }
  }

  const runs = await prisma.mockRun.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
    take: 8,
  });
  const acc: Record<number, number[]> = { 1: [], 2: [], 3: [], 4: [], 5: [], 6: [], 7: [] };
  for (const run of runs) {
    try {
      const parsed = JSON.parse(run.domainScores) as Record<string, number>;
      for (const [k, v] of Object.entries(parsed)) {
        const d = Number(k);
        if (acc[d] && typeof v === "number") acc[d].push(v);
      }
    } catch {
      /* ignore */
    }
  }
  for (const d of [1, 2, 3, 4, 5, 6, 7]) {
    const list = acc[d];
    scores[d] = list.length ? list.reduce((a, b) => a + b, 0) / list.length : null;
  }
  return scores;
}

export async function readyGate(userId: string, isDemo: boolean): Promise<ReadyGate> {
  const empty: ReadyGate = {
    mockCountAt70: 0,
    mocksNeeded: 2,
    domainFloors: { 1: null, 2: null, 3: null, 4: null, 5: null, 6: null, 7: null },
    weakDomains: [],
    ready: false,
    reason: isDemo
      ? "Demo activity is not stored, so the ready gate cannot be earned on this account."
      : "Take two mocks at 70% or higher with no domain below 60%.",
  };
  if (isDemo) return empty;

  const runs = await prisma.mockRun.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
  });
  const mockCountAt70 = runs.filter((r) => r.score >= 70).length;
  const domainFloors = await domainScoresForUser(userId, false);
  const weakDomains = Object.entries(domainFloors)
    .filter(([, v]) => v != null && v < 60)
    .map(([k]) => Number(k));
  const missing = Object.entries(domainFloors)
    .filter(([, v]) => v == null)
    .map(([k]) => Number(k));
  const ready = mockCountAt70 >= 2 && weakDomains.length === 0 && missing.length === 0;
  let reason: string;
  if (ready) reason = "Ready gate met: two mocks at or above 70% and no domain below 60%.";
  else if (mockCountAt70 < 2) reason = `Need ${2 - mockCountAt70} more mock(s) at 70% or higher.`;
  else if (missing.length) reason = `Domains without mock coverage yet: ${missing.join(", ")}.`;
  else reason = `Domains below 60%: ${weakDomains.join(", ")}.`;
  return { mockCountAt70, mocksNeeded: 2, domainFloors, weakDomains, ready, reason };
}

export function nextCardInterval(currentDays: number, remembered: boolean): number {
  if (!remembered) return CARD_INTERVALS[0];
  const idx = CARD_INTERVALS.indexOf(currentDays as (typeof CARD_INTERVALS)[number]);
  if (idx < 0) return CARD_INTERVALS[0];
  return CARD_INTERVALS[Math.min(idx + 1, CARD_INTERVALS.length - 1)];
}

export async function upcomingReviews(userId: string, isDemo: boolean) {
  if (isDemo) return [];
  return prisma.cardReview.findMany({
    where: { userId, dueAt: { lte: new Date(Date.now() + 7 * 86400000) } },
    orderBy: { dueAt: "asc" },
    take: 8,
  });
}

export function mockDomainQuota(length: number): Record<number, number> {
  const weights: Record<number, number> = { 1: 25, 2: 25, 3: 15, 4: 9, 5: 6, 6: 10, 7: 10 };
  const raw = Object.fromEntries(
    Object.entries(weights).map(([d, w]) => [Number(d), (w / 100) * length]),
  ) as Record<number, number>;
  const rounded: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0, 7: 0 };
  let allocated = 0;
  const parts = Object.entries(raw)
    .map(([d, v]) => ({ d: Number(d), frac: v - Math.floor(v), base: Math.floor(v) }))
    .sort((a, b) => b.frac - a.frac);
  for (const p of parts) {
    rounded[p.d] = p.base;
    allocated += p.base;
  }
  let i = 0;
  while (allocated < length) {
    rounded[parts[i % parts.length].d] += 1;
    allocated += 1;
    i += 1;
  }
  return rounded;
}
