import { DOMAIN_NAMES } from "./constants";

export type CertificateGate = {
  eligible: boolean;
  scoreOk: boolean;
  weakDomains: number[];
  missingDomains: number[];
};

/** Same bar as the ready-gate for a single sitting: ≥70% overall and no domain below 60%. */
export function practiceCertificateGate(
  score: number,
  domainScores: Record<number, number>,
): CertificateGate {
  const weakDomains: number[] = [];
  const missingDomains: number[] = [];
  for (const d of [1, 2, 3, 4, 5, 6, 7]) {
    const v = domainScores[d];
    if (v == null || Number.isNaN(v)) missingDomains.push(d);
    else if (v < 60) weakDomains.push(d);
  }
  const scoreOk = score >= 70;
  return {
    eligible: scoreOk && weakDomains.length === 0 && missingDomains.length === 0,
    scoreOk,
    weakDomains,
    missingDomains,
  };
}

export function domainLabel(d: number): string {
  return DOMAIN_NAMES[d] ?? `Domain ${d}`;
}

export function formatSittingDate(iso: string | Date): string {
  const d = typeof iso === "string" ? new Date(iso) : iso;
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleDateString("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
    timeZone: "Asia/Karachi",
  });
}
