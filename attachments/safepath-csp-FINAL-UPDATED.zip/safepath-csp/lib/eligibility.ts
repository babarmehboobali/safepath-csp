export const ELIGIBILITY_CREDENTIALS = [
  { id: "ASP", label: "ASP — Associate Safety Professional" },
  { id: "GSP", label: "GSP — Graduate Safety Practitioner" },
  { id: "TSP", label: "TSP — Transitional Safety Practitioner" },
  { id: "NEBOSH-ID", label: "NEBOSH National or International Diploma in Occupational Health and Safety" },
  { id: "CIH", label: "CIH — Certified Industrial Hygienist" },
  { id: "CMIOSH", label: "CMIOSH — Chartered Member of IOSH" },
  { id: "CFIOSH", label: "CFIOSH — Chartered Fellow of IOSH" },
  { id: "CRSP", label: "CRSP — Canadian Registered Safety Professional" },
  { id: "OTHER", label: "Other BCSP-qualified credential (verify on BCSP)" },
] as const;

export const EDUCATION_OPTIONS = [
  { id: "none", label: "No bachelor's degree" },
  { id: "associate", label: "Associate degree / below bachelor's" },
  { id: "bachelor", label: "Bachelor's degree" },
  { id: "master", label: "Master's degree" },
  { id: "doctorate", label: "Doctorate / higher" },
] as const;

export type EligibilityInput = {
  education: string;
  experienceYears: number;
  preventativePct: number;
  credential: string;
};

export type EligibilityCheck = {
  eligible: boolean;
  confidence: "high" | "review" | "not-ready";
  headline: string;
  summary: string;
  checks: Array<{ key: string; label: string; passed: boolean; detail: string }>;
  nextSteps: string[];
};

const bachelorOrHigher = new Set(["bachelor", "master", "doctorate"]);
const validCredentialIds = new Set(ELIGIBILITY_CREDENTIALS.map((item) => item.id));

export function evaluateEligibility(input: EligibilityInput): EligibilityCheck {
  const educationPassed = bachelorOrHigher.has(input.education);
  const experiencePassed = input.experienceYears >= 4;
  const preventativePassed = input.preventativePct >= 50;
  const credentialPassed = validCredentialIds.has(input.credential);

  const checks = [
    {
      key: "education",
      label: "Education",
      passed: educationPassed,
      detail: educationPassed
        ? "Bachelor's degree or higher reported."
        : "The CSP minimum education requirement is a bachelor's degree."
    },
    {
      key: "experience",
      label: "SH&E experience",
      passed: experiencePassed,
      detail: experiencePassed
        ? `${input.experienceYears} years reported; minimum is 4 years.`
        : `${input.experienceYears} years reported; 4 years are required.`
    },
    {
      key: "preventative",
      label: "Preventative professional work",
      passed: preventativePassed,
      detail: preventativePassed
        ? `${input.preventativePct}% reported as preventative professional-level work; minimum is 50%.`
        : `${input.preventativePct}% reported; at least 50% is required.`
    },
    {
      key: "credential",
      label: "BCSP-qualified credential",
      passed: credentialPassed,
      detail: credentialPassed
        ? "A credential/pathway option supported by BCSP's CSP requirements is selected."
        : "Select a credential that BCSP currently recognizes for the CSP pathway."
    },
  ];

  const eligible = checks.every((item) => item.passed);
  const confidence = eligible ? "review" : "not-ready";

  if (eligible) {
    return {
      eligible: true,
      confidence,
      headline: "You appear to meet the core CSP eligibility gates",
      summary: "Your answers match the four major screening conditions used in the current BCSP CSP requirements. Final eligibility still depends on BCSP's application review and supporting documentation.",
      checks,
      nextSteps: [
        "Confirm your degree is from an appropriately recognized/accredited institution; non-U.S. education may require equivalency review.",
        "Document the breadth and depth of your SH&E duties and the preventative portion of your work experience.",
        "Verify your exact credential and current status against BCSP's approved credential list before applying.",
        "Use SafePath's study planner to set your target date and begin a baseline self-assessment.",
      ],
    };
  }

  const nextSteps = [
    "Resolve each failed gate shown above before relying on a 'CSP-ready' conclusion.",
    "Use the BCSP CSP requirements page to verify your exact pathway and documentation.",
  ];

  return {
    eligible: false,
    confidence,
    headline: "More preparation or eligibility work is needed",
    summary: "At least one core screening gate is not currently satisfied by the information you entered. This is a guidance tool, not an official BCSP eligibility determination.",
    checks,
    nextSteps,
  };
}
