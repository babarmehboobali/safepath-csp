import type { Question } from "@prisma/client";
import { mockDomainQuota } from "./progress";

export type BankQuestion = Question & { class?: { domain: number } | null; domain?: number };

export type SampleResult<T = BankQuestion> = {
  items: T[];
  withReplacement: boolean;
};

function domainOf(q: BankQuestion): number {
  return q.domain ?? q.class?.domain ?? 1;
}

export function shuffle<T>(list: T[]): T[] {
  const a = [...list];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j]!, a[i]!];
  }
  return a;
}

export function sampleWithReplacement<T>(bank: T[], length: number): T[] {
  if (!bank.length) return [];
  const out: T[] = [];
  for (let i = 0; i < length; i++) {
    out.push(bank[Math.floor(Math.random() * bank.length)]!);
  }
  return out;
}

export function sampleWithoutReplacement<T>(bank: T[], length: number): SampleResult<T> {
  if (!bank.length) return { items: [], withReplacement: false };
  if (bank.length >= length) {
    return { items: shuffle(bank).slice(0, length), withReplacement: false };
  }
  return { items: sampleWithReplacement(bank, length), withReplacement: true };
}

export function weightedSample(bank: BankQuestion[], length: number): SampleResult<BankQuestion> {
  const quota = mockDomainQuota(length);
  const byDomain: Record<number, BankQuestion[]> = { 1: [], 2: [], 3: [], 4: [], 5: [], 6: [], 7: [] };
  for (const q of bank) {
    const d = domainOf(q);
    (byDomain[d] ?? byDomain[1]).push(q);
  }
  const out: BankQuestion[] = [];
  let withReplacement = false;
  for (const d of [1, 2, 3, 4, 5, 6, 7]) {
    const need = quota[d] ?? 0;
    if (!need) continue;
    const pool = byDomain[d] ?? [];
    const part = sampleWithoutReplacement(pool, need);
    if (part.withReplacement) withReplacement = true;
    out.push(...part.items);
  }
  return { items: shuffle(out), withReplacement };
}
