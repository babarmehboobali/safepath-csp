import { cookies } from "next/headers";
import { hash, compare } from "bcryptjs";
import { SignJWT } from "jose";
import { prisma } from "./prisma";
import { signSessionToken, verifySessionToken, type TokenPayload } from "./session-token";
import { DEMO_PROFILE_COOKIE, SESSION_COOKIE } from "./constants";

const COOKIE_OPTS = {
  httpOnly: true,
  sameSite: "lax" as const,
  secure: process.env.NODE_ENV === "production",
  path: "/",
};

export type SessionUser = TokenPayload;

export async function hashPassword(plain: string) {
  return hash(plain, 12);
}

export async function verifyPassword(plain: string, passwordHash: string) {
  return compare(plain, passwordHash);
}

export async function createSession(user: SessionUser) {
  const token = await signSessionToken(user);
  const expiresAt = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000);
  await prisma.session.create({
    data: { userId: user.id, token, expiresAt },
  });
  const jar = await cookies();
  jar.set(SESSION_COOKIE, token, { ...COOKIE_OPTS, expires: expiresAt });
}

export async function getSession(): Promise<SessionUser | null> {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  return verifySessionToken(token);
}

export async function requireSession(): Promise<SessionUser> {
  const s = await getSession();
  if (!s) {
    throw new Error("UNAUTHENTICATED");
  }
  return s;
}

export async function clearSession() {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (token) {
    await prisma.session.deleteMany({ where: { token } });
  }
  jar.delete(SESSION_COOKIE);
  jar.delete(DEMO_PROFILE_COOKIE);
}

export async function setDemoProfileCookie(profile: Record<string, unknown>) {
  const secret = process.env.AUTH_SECRET;
  if (!secret) throw new Error("AUTH_SECRET is not set");
  const jar = await cookies();
  const token = await new SignJWT({ profile })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("14d")
    .sign(new TextEncoder().encode(secret));
  jar.set(DEMO_PROFILE_COOKIE, token, {
    ...COOKIE_OPTS,
    expires: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
  });
}

export async function readDemoProfileCookie(): Promise<Record<string, unknown> | null> {
  const jar = await cookies();
  const token = jar.get(DEMO_PROFILE_COOKIE)?.value;
  if (!token) return null;
  try {
    const { jwtVerify } = await import("jose");
    const secret = process.env.AUTH_SECRET;
    if (!secret) return null;
    const { payload } = await jwtVerify(
      token,
      new TextEncoder().encode(secret),
    );
    return (payload.profile as Record<string, unknown>) ?? null;
  } catch {
    return null;
  }
}
