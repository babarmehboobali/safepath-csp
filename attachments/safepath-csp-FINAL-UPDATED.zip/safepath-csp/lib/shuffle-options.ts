/** Deterministic A/B/C/D shuffle so stored answerIndex is not leaked on the wire. */

export type ShuffleInput = {
  id: string;
  options: string[];
  answerIndex: number;
  distractors?: string[];
  optionTraps?: string[];
};

export type ShuffleOutput = {
  options: string[];
  answerIndex: number;
  distractors?: string[];
  optionTraps?: string[];
  /** newIndex -> oldIndex */
  order: number[];
};

function hash32(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function permutationForId(id: string, n: number): number[] {
  const order = Array.from({ length: n }, (_, i) => i);
  if (n < 2) return order;
  const rand = mulberry32(hash32(`opt:${id}:${n}`));
  for (let i = n - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    const tmp = order[i]!;
    order[i] = order[j]!;
    order[j] = tmp;
  }
  return order;
}

function remapAligned(list: string[] | undefined, order: number[], n: number): string[] | undefined {
  if (!list || list.length !== n) return list;
  return order.map((old) => list[old] ?? "");
}

export function shuffleOptions(input: ShuffleInput): ShuffleOutput {
  const n = input.options.length;
  const order = permutationForId(input.id, n);
  const options = order.map((old) => input.options[old] ?? "");
  const mapped = order.indexOf(input.answerIndex);
  const answerIndex = mapped < 0 ? input.answerIndex : mapped;
  return {
    options,
    answerIndex,
    distractors: remapAligned(input.distractors, order, n),
    optionTraps: remapAligned(input.optionTraps, order, n),
    order,
  };
}

export function letterCounts(answerIndexes: number[]): { A: number; B: number; C: number; D: number } {
  const out = { A: 0, B: 0, C: 0, D: 0 };
  const letters = ["A", "B", "C", "D"] as const;
  for (const i of answerIndexes) {
    const L = letters[i];
    if (L) out[L] += 1;
  }
  return out;
}
