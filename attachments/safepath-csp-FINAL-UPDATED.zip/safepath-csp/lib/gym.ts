import type { Question } from "@prisma/client";
import type { Item } from "@/components/QuestionPlayer";
import { sampleWithoutReplacement, type BankQuestion } from "./sample";
import { shuffleOptions } from "./shuffle-options";

/** ~12% of items: deterministic pretest flag from id (never shown during attempt). */
export function isPretestId(id: string): boolean {
  let h = 2166136261;
  for (let i = 0; i < id.length; i++) {
    h ^= id.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0) % 100 < 12;
}

function parseStringQuad(raw: string | null | undefined): string[] | undefined {
  if (!raw) return undefined;
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (Array.isArray(parsed) && parsed.length === 4) return parsed.map((s) => String(s));
  } catch {
    return undefined;
  }
  return undefined;
}

function parseMathJson(raw: string | null | undefined): Item["stepByStepMath"] {
  if (!raw) return undefined;
  try {
    const parsed = JSON.parse(raw) as Item["stepByStepMath"];
    if (parsed && typeof parsed === "object" && "formula" in parsed) return parsed;
  } catch {
    return undefined;
  }
  return undefined;
}

export function toItem(q: Question & { class?: { domain: number } | null }): Item {
  const row = q as Question & {
    distractorsJson?: string | null;
    optionTrapsJson?: string | null;
    scenarioText?: string | null;
    standardReference?: string | null;
    difficultyLevel?: string | null;
    fieldTakeaway?: string | null;
    mathJson?: string | null;
  };
  const distractors = parseStringQuad(row.distractorsJson);
  const optionTraps = parseStringQuad(row.optionTrapsJson) ?? distractors;
  let options: string[] = [];
  try {
    const parsed = JSON.parse(q.optionsJson) as unknown;
    if (Array.isArray(parsed)) options = parsed.map((s) => String(s));
  } catch {
    options = [];
  }
  const shuffled = shuffleOptions({
    id: q.id,
    options,
    answerIndex: q.answerIndex,
    distractors,
    optionTraps,
  });
  return {
    id: q.id,
    stem: q.stem,
    options: shuffled.options,
    answerIndex: shuffled.answerIndex,
    explanation: q.explanation,
    errorCode: q.errorCode,
    taskCode: q.taskCode,
    difficulty: row.difficultyLevel || q.difficulty,
    classId: q.classId,
    classTitle: q.class?.title,
    domain: q.class?.domain,
    kind: "kind" in q ? String((q as { kind?: string }).kind ?? "class") : "class",
    distractors: shuffled.distractors,
    optionTraps: shuffled.optionTraps,
    scenarioText: row.scenarioText || undefined,
    standardReference: row.standardReference || undefined,
    fieldTakeaway: row.fieldTakeaway || undefined,
    stepByStepMath: parseMathJson(row.mathJson),
    pretest: isPretestId(q.id),
  };
}

export function sampleItems(bank: BankQuestion[], n: number) {
  const { items, withReplacement } = sampleWithoutReplacement(bank, n);
  return { items: items.map(toItem), withReplacement };
}

export function formatClock(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
  return `${m}:${String(sec).padStart(2, "0")}`;
}

export function mockTimerMinutes(length: number): number {
  if (length >= 200) return 330;
  if (length >= 100) return 165;
  return 82.5; // 50-item scaled mock
}

export const MATH_TOPICS = [
  { id: "twa", label: "Time-weighted average", formulaSlug: "twa", blurb: "Partial-shift concentrations rolled to an 8-hour TWA." },
  { id: "xchg", label: "OSHA 5 dB vs NIOSH 3 dB", formulaSlug: "osha-niosh-noise", blurb: "Matched criterion and exchange pairs — never mix." },
  { id: "rwl", label: "NIOSH recommended weight limit", formulaSlug: "niosh-rwl", blurb: "LC = 51 lb times six multipliers." },
  { id: "trir", label: "TRIR and DART", formulaSlug: "trir", blurb: "200,000-hour base. First aid is not a recordable." },
  { id: "qva", label: "Q = VA flow", formulaSlug: "q-va", blurb: "Velocity times area. Diameter is not radius." },
  { id: "dike", label: "Dike and cylinder volume", formulaSlug: "dike-volume", blurb: "LWH or πr²h, then gallons with 7.48 if asked." },
  { id: "stats", label: "Descriptive statistics", formulaSlug: "mean", blurb: "Mean, median, mode, range — sort first for median." },
  { id: "ppm", label: "ppm ↔ mg/m³", formulaSlug: "ppm-mgm3", blurb: "mg/m³ = (ppm × MW) / 24.45 at 25 °C." },
  { id: "roi", label: "ROI and payback", formulaSlug: "roi", blurb: "ROI is (Gain − Cost) / Cost. Payback is years, not percent." },
  { id: "algebra", label: "Algebra warmup", formulaSlug: "algebra-warmup", blurb: "Order of operations, scientific notation, rearranging Q = VA." },
] as const;

export type MathTopicId = (typeof MATH_TOPICS)[number]["id"];


export type AssessReport = {
  score: number;
  domainScores: Record<number, number>;
  createdAt: Date;
};

export function parseGymPayload(answersJson: string): { domainScores: Record<number, number> } {
  try {
    const parsed = JSON.parse(answersJson) as {
      domainScores?: Record<string, number>;
      answers?: { domain?: number; correct?: boolean }[];
    };
    if (parsed.domainScores && Object.keys(parsed.domainScores).length) {
      const out: Record<number, number> = {};
      for (const [k, v] of Object.entries(parsed.domainScores)) out[Number(k)] = Number(v);
      return { domainScores: out };
    }
    const acc: Record<number, { ok: number; n: number }> = {};
    for (const row of parsed.answers || []) {
      const d = row.domain ?? 0;
      if (!d) continue;
      acc[d] = acc[d] ?? { ok: 0, n: 0 };
      acc[d].n += 1;
      if (row.correct) acc[d].ok += 1;
    }
    const domainScores: Record<number, number> = {};
    for (const [k, v] of Object.entries(acc)) domainScores[Number(k)] = v.n ? (v.ok / v.n) * 100 : 0;
    return { domainScores };
  } catch {
    return { domainScores: {} };
  }
}
