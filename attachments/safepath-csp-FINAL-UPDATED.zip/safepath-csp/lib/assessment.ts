export const CSP_DOMAIN_WEIGHTS = {
  1: 25,
  2: 25,
  3: 15,
  4: 9,
  5: 6,
  6: 10,
  7: 10,
} as const;

export const CSP_DOMAIN_NAMES = {
  1: "Advanced Application of Safety Principles",
  2: "Program Management",
  3: "Risk Management",
  4: "Emergency Management",
  5: "Environmental Management",
  6: "Occupational Health and Applied Science",
  7: "Training",
} as const;

export const DOMAIN_ICONS = {
  1: "🛡️",
  2: "⚖️",
  3: "🎯",
  4: "🚨",
  5: "🌎",
  6: "🔬",
  7: "🎓",
} as const;

export const READINESS_THRESHOLDS = {
  readyOverall: 75,
  borderlineOverall: 65,
  weakDomain: 60,
} as const;

export function readinessFor(score: number, domainScores: Record<number, number>, timedOut = false) {
  const weakDomains = [1, 2, 3, 4, 5, 6, 7].filter((d) => (domainScores[d] ?? 0) < READINESS_THRESHOLDS.weakDomain);
  if (score >= READINESS_THRESHOLDS.readyOverall && weakDomains.length === 0 && !timedOut) {
    return { label: "Ready for Exam", tone: "ready", blurb: "Strong overall performance with no domain below the focused-review threshold." };
  }
  if (score >= READINESS_THRESHOLDS.borderlineOverall && weakDomains.length <= 2 && !timedOut) {
    return { label: "Borderline", tone: "borderline", blurb: "You have a workable base. Targeted repair and another timed sitting are recommended." };
  }
  return { label: "Requires Focused Review", tone: "focus", blurb: "Prioritize the weakest domains, reopen linked modules, and use MathCORE for calculation-heavy gaps." };
}
