import { SignJWT, jwtVerify } from "jose";
import { SESSION_COOKIE } from "./constants";

export type TokenPayload = {
  id: string;
  email: string;
  name: string | null;
  isDemo: boolean;
};

function secretKey() {
  const s = process.env.AUTH_SECRET;
  if (!s) throw new Error("AUTH_SECRET is not set");
  return new TextEncoder().encode(s);
}

export async function signSessionToken(user: TokenPayload, expiresIn = "14d") {
  return new SignJWT({
    email: user.email,
    name: user.name,
    isDemo: user.isDemo,
  })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(user.id)
    .setIssuedAt()
    .setExpirationTime(expiresIn)
    .sign(secretKey());
}

export async function verifySessionToken(token: string): Promise<TokenPayload | null> {
  try {
    const { payload } = await jwtVerify(token, secretKey());
    if (!payload.sub) return null;
    return {
      id: payload.sub,
      email: String(payload.email ?? ""),
      name: (payload.name as string | null) ?? null,
      isDemo: Boolean(payload.isDemo),
    };
  } catch {
    return null;
  }
}

export { SESSION_COOKIE };
