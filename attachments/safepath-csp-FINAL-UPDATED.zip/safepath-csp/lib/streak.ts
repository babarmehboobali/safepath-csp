export const XP_PER_CORRECT = 10;
export const XP_PER_LESSON = 100;
export const XP_PER_ASSESSMENT = 50;

export function levelForXp(xp: number) {
  return Math.floor(Math.max(0, xp) / 250) + 1;
}

export function xpIntoLevel(xp: number) {
  return Math.max(0, xp) % 250;
}

export function xpToNextLevel(xp: number) {
  return 250 - xpIntoLevel(xp);
}

export function localDateKey(d = new Date()) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function nextActivityStreak(lastActivityDate: string | null | undefined, currentStreak: number, now = new Date()) {
  const today = localDateKey(now);
  if (!lastActivityDate) return 1;
  if (lastActivityDate === today) return Math.max(1, currentStreak);
  const yesterday = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
  return lastActivityDate === localDateKey(yesterday) ? Math.max(1, currentStreak + 1) : 1;
}

export function consecutiveUtcStreak(timestamps: Date[], now = new Date()): number {
  const days = new Set(timestamps.map((t) => `${t.getUTCFullYear()}-${String(t.getUTCMonth()+1).padStart(2,"0")}-${String(t.getUTCDate()).padStart(2,"0")}`));
  let streak = 0;
  const cursor = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  for (;;) {
    const key = `${cursor.getUTCFullYear()}-${String(cursor.getUTCMonth()+1).padStart(2,"0")}-${String(cursor.getUTCDate()).padStart(2,"0")}`;
    if (!days.has(key)) break;
    streak += 1;
    cursor.setUTCDate(cursor.getUTCDate() - 1);
  }
  return streak;
}

export function consecutiveLocalStreak(isoTimestamps: string[], now = new Date()): number {
  const days = new Set(isoTimestamps.map((iso) => { const d = new Date(iso); return Number.isNaN(d.getTime()) ? "" : localDateKey(d); }).filter(Boolean));
  let streak = 0;
  const cursor = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  for (;;) {
    const key = localDateKey(cursor);
    if (!days.has(key)) break;
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}
