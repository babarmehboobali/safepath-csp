import type { PrismaClient } from "@prisma/client";
import { prisma as defaultPrisma } from "./prisma";

export type WipeDemoResult = {
  users: number;
  attempts: number;
  mockRuns: number;
  cardReviews: number;
  sessions: number;
  gymRuns: number;
  flags: number;
};

export async function wipeDemoProgress(
  client: PrismaClient = defaultPrisma,
): Promise<WipeDemoResult> {
  const demos = await client.user.findMany({
    where: { isDemo: true },
    select: { id: true },
  });
  const ids = demos.map((d) => d.id);
  if (ids.length === 0) {
    return { users: 0, attempts: 0, mockRuns: 0, cardReviews: 0, sessions: 0, gymRuns: 0, flags: 0 };
  }
  const attempts = await client.attempt.deleteMany({ where: { userId: { in: ids } } });
  const mockRuns = await client.mockRun.deleteMany({ where: { userId: { in: ids } } });
  const cardReviews = await client.cardReview.deleteMany({ where: { userId: { in: ids } } });
  const sessions = await client.session.deleteMany({ where: { userId: { in: ids } } });
  const gymRuns = await client.gymRun.deleteMany({ where: { userId: { in: ids } } });
  const flags = await client.flag.deleteMany({ where: { userId: { in: ids } } });
  await client.user.updateMany({
    where: { id: { in: ids } },
    data: { onboardingComplete: false },
  });
  return {
    users: ids.length,
    attempts: attempts.count,
    mockRuns: mockRuns.count,
    cardReviews: cardReviews.count,
    sessions: sessions.count,
    gymRuns: gymRuns.count,
    flags: flags.count,
  };
}
