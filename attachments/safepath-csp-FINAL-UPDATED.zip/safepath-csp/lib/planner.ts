import { CATALOG, classCountForTrack } from "./catalog";
import { DOMAIN_WEIGHTS, HOURS_WARN_THRESHOLD } from "./constants";
import type { StudyProfile } from "./profile";

export const PLANNER_MODES = ["adaptive", "mix", "domain", "choice"] as const;
export type PlannerMode = (typeof PLANNER_MODES)[number];

export type DomainPlan = {
  domain: number;
  classIds: number[];
  weight: number;
  score: number | null;
  plannedCount: number;
};

export type StudyDay = {
  date: string;
  label: string;
  hours: number;
};

export type WeekPlan = {
  week: number;
  start: string;
  end: string;
  hours: number;
  classIds: number[];
  milestone: string;
  focusDomains: number[];
  domains: DomainPlan[];
  studyDays: StudyDay[];
};

export type ChoiceWeights = Record<number, number>;

export type PlannerResult = {
  mode: PlannerMode;
  selectedDomains: number[];
  choiceWeights: ChoiceWeights;
  courseStart: string;
  examDate: string | null;
  daysTotal: number;
  daysRemaining: number;
  weeksUntilExam: number;
  hoursBudget: number;
  hoursNeeded: number;
  dailyHours: number;
  underHours: boolean;
  unlockedIds: number[];
  weeks: WeekPlan[];
};

const ALL_DOMAINS = [1, 2, 3, 4, 5, 6, 7] as const;

function dateOnly(value: string | null | undefined, fallback = new Date()): Date {
  const d = value ? new Date(`${value}T00:00:00Z`) : new Date(fallback);
  d.setUTCHours(0, 0, 0, 0);
  return d;
}

function iso(d: Date) {
  return d.toISOString().slice(0, 10);
}

export function weeksUntil(examDate: string | null, startDate?: string | null): number {
  if (!examDate) return 12;
  const end = dateOnly(examDate);
  const start = dateOnly(startDate || iso(new Date()));
  const days = Math.max(1, Math.ceil((end.getTime() - start.getTime()) / 86400000) + 1);
  return Math.max(1, Math.ceil(days / 7));
}

export function isClassUnlocked(classId: number, track: string, domainScores: Record<number, number | null>): boolean {
  const entry = CATALOG.find((c) => c.id === classId);
  if (!entry) return false;
  const cap = classCountForTrack(track);
  if (!entry.isMaximum) return classId <= cap;
  if (track === "maximum") return true;
  const score = domainScores[entry.domain];
  return score != null && score < 60;
}

function normalizeWeights(domains: number[], domainScores: Record<number, number | null>, mode: PlannerMode, customWeights?: ChoiceWeights) {
  const weights: Record<number, number> = {};
  for (const d of domains) {
    let weight = customWeights?.[d] ?? DOMAIN_WEIGHTS[d] ?? 0;
    if (mode === "adaptive") {
      const score = domainScores[d];
      if (score != null) {
        const weakness = Math.max(0, 75 - score) / 75;
        weight *= 1 + weakness * 1.75;
      }
    }
    weights[d] = Math.max(0, weight);
  }

  let total = domains.reduce((sum, d) => sum + weights[d], 0);
  if (total <= 0) {
    for (const d of domains) weights[d] = 1;
    total = domains.length;
  }

  return Object.fromEntries(domains.map((d) => [d, weights[d] / total])) as Record<number, number>;
}

function largestRemainderAllocation(total: number, domains: number[], weights: Record<number, number>): Record<number, number> {
  const out: Record<number, number> = Object.fromEntries(domains.map((d) => [d, 0]));
  if (!domains.length || total <= 0) return out;
  let allocated = 0;
  const parts = domains.map((domain) => {
    const raw = total * (weights[domain] ?? 0);
    const base = Math.floor(raw);
    out[domain] = base;
    allocated += base;
    return { domain, remainder: raw - base };
  });
  parts.sort((a, b) => b.remainder - a.remainder);
  let i = 0;
  while (allocated < total) {
    out[parts[i % parts.length].domain] += 1;
    allocated += 1;
    i += 1;
  }
  return out;
}

function adaptiveDomainOrder(domains: number[], scores: Record<number, number | null>) {
  return [...domains].sort((a, b) => {
    const aScore = scores[a] ?? 50;
    const bScore = scores[b] ?? 50;
    if (aScore !== bScore) return aScore - bScore;
    return (DOMAIN_WEIGHTS[b] ?? 0) - (DOMAIN_WEIGHTS[a] ?? 0);
  });
}

function sanitizeChoiceOrder(selected: number[], requestedOrder?: number[]) {
  const chosenSet = new Set(selected);
  const ordered = (requestedOrder ?? []).filter((d, index, array) => chosenSet.has(d) && array.indexOf(d) === index);
  for (const d of selected) if (!ordered.includes(d)) ordered.push(d);
  return ordered;
}

function sanitizeChoiceWeights(selected: number[], customWeights?: ChoiceWeights): ChoiceWeights {
  const out: ChoiceWeights = {};
  for (const d of selected) {
    const value = Number(customWeights?.[d]);
    out[d] = Number.isFinite(value) && value >= 0 ? Math.min(100, value) : DOMAIN_WEIGHTS[d] ?? 0;
  }
  const total = selected.reduce((sum, d) => sum + out[d], 0);
  if (total <= 0) {
    for (const d of selected) out[d] = 100 / Math.max(1, selected.length);
    return out;
  }
  // Preserve user percentages proportionally while making the model sum to 100.
  for (const d of selected) out[d] = (out[d] / total) * 100;
  return out;
}

function buildStudyDays(start: Date, end: Date, profile: StudyProfile, dailyHours: number): StudyDay[] {
  const studyDays: StudyDay[] = [];
  const cursor = new Date(start);
  while (cursor <= end) {
    const weekday = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][cursor.getUTCDay()];
    if (profile.availableDays.includes(weekday)) {
      studyDays.push({ date: iso(cursor), label: weekday, hours: Number(dailyHours.toFixed(1)) });
    }
    cursor.setUTCDate(cursor.getUTCDate() + 1);
  }
  if (!studyDays.length) {
    studyDays.push({ date: iso(start), label: "Flex", hours: Number(profile.hoursPerWeek.toFixed(1)) });
  }
  return studyDays;
}

export function buildPlanner(
  profile: StudyProfile,
  domainScores: Record<number, number | null> = {},
  mode: PlannerMode = "adaptive",
  selectedDomains: number[] = ALL_DOMAINS as unknown as number[],
  choiceWeights?: ChoiceWeights,
  choiceOrder?: number[],
): PlannerResult {
  const validMode: PlannerMode = PLANNER_MODES.includes(mode) ? mode : "adaptive";
  const requested = selectedDomains.filter((d) => ALL_DOMAINS.includes(d as (typeof ALL_DOMAINS)[number]));
  const chosenBase = requested.length ? [...new Set(requested)] : [...ALL_DOMAINS];
  const normalizedChoiceWeights = sanitizeChoiceWeights(chosenBase, choiceWeights);
  const chosen = validMode === "choice" ? sanitizeChoiceOrder(chosenBase, choiceOrder) : chosenBase;

  const today = dateOnly(iso(new Date()));
  const courseStart = dateOnly(profile.courseStartDate || iso(today));
  const exam = profile.examDate ? dateOnly(profile.examDate) : null;
  const scheduleStart = courseStart > today ? courseStart : today;
  const daysRemaining = exam ? Math.max(0, Math.ceil((exam.getTime() - today.getTime()) / 86400000)) : 84;
  const daysTotal = exam ? Math.max(1, Math.ceil((exam.getTime() - courseStart.getTime()) / 86400000) + 1) : 84;
  const weeksUntilExam = exam ? Math.max(1, Math.ceil(daysTotal / 7)) : 12;
  const hoursBudget = profile.hoursPerWeek * weeksUntilExam;
  const activeDays = Math.max(1, profile.availableDays.length || 7);
  const dailyHours = profile.hoursPerWeek / activeDays;
  const underHours = hoursBudget < HOURS_WARN_THRESHOLD;

  const unlockedIds = CATALOG.filter((c) => isClassUnlocked(c.id, profile.track, domainScores))
    .filter((c) => chosen.includes(c.domain))
    .map((c) => c.id);

  const byDomain: Record<number, number[]> = Object.fromEntries(ALL_DOMAINS.map((d) => [d, []])) as Record<number, number[]>;
  for (const id of unlockedIds) {
    const c = CATALOG.find((x) => x.id === id);
    if (c) byDomain[c.domain].push(id);
  }

  const queues: Record<number, number[]> = Object.fromEntries(ALL_DOMAINS.map((d) => [d, [...byDomain[d]]])) as Record<number, number[]>;
  const effectiveWeights = normalizeWeights(
    chosen,
    domainScores,
    validMode === "choice" ? "mix" : validMode,
    validMode === "choice" ? normalizedChoiceWeights : undefined,
  );
  const weeks: WeekPlan[] = [];
  const domainOrder = validMode === "adaptive" ? adaptiveDomainOrder(chosen, domainScores) : validMode === "domain" ? [...ALL_DOMAINS] : chosen;
  let domainCursor = 0;

  for (let w = 0; w < weeksUntilExam; w++) {
    const start = new Date(scheduleStart);
    start.setUTCDate(start.getUTCDate() + w * 7);
    const end = new Date(start);
    end.setUTCDate(end.getUTCDate() + 6);
    if (exam && end > exam) end.setTime(exam.getTime());

    const remainingClassCount = Object.values(queues).reduce((sum, ids) => sum + ids.length, 0);
    const remainingWeeks = weeksUntilExam - w;
    const targetCount = Math.ceil(remainingClassCount / remainingWeeks);
    const classIds: number[] = [];
    const weeklyByDomain: Record<number, number[]> = Object.fromEntries(ALL_DOMAINS.map((d) => [d, []])) as Record<number, number[]>;

    if (validMode === "domain") {
      // A domain is a true block: a week never spills into the next domain.
      // If the active domain finishes mid-week, the remaining capacity becomes review/recovery time.
      while (domainCursor < domainOrder.length && !queues[domainOrder[domainCursor]].length) domainCursor += 1;
      const activeDomain = domainOrder[domainCursor];
      if (activeDomain != null) {
        const need = Math.min(targetCount, queues[activeDomain].length);
        for (let i = 0; i < need; i++) {
          const id = queues[activeDomain].shift()!;
          classIds.push(id);
          weeklyByDomain[activeDomain].push(id);
        }
        if (!queues[activeDomain].length) domainCursor += 1;
      }
    } else {
      const allocations = largestRemainderAllocation(targetCount, chosen, effectiveWeights);
      for (const domain of chosen) {
        const need = Math.min(queues[domain].length, allocations[domain] ?? 0);
        for (let i = 0; i < need; i++) {
          const id = queues[domain].shift()!;
          classIds.push(id);
          weeklyByDomain[domain].push(id);
        }
      }
      while (classIds.length < targetCount) {
        const candidates = chosen.filter((d) => queues[d].length);
        if (!candidates.length) break;
        const next = candidates.sort((a, b) => (queues[b].length - queues[a].length) || (chosen.indexOf(a) - chosen.indexOf(b)))[0];
        const id = queues[next].shift()!;
        classIds.push(id);
        weeklyByDomain[next].push(id);
      }
    }

    const focusDomains = chosen.filter((d) => weeklyByDomain[d].length > 0);
    const studyDays = buildStudyDays(start, end, profile, dailyHours);
    const milestone =
      w === weeksUntilExam - 1
        ? "Final consolidation + timed readiness check"
        : validMode === "domain"
          ? focusDomains.length
            ? `Domain block: D${focusDomains[0]} · ${classIds.length} modules + review/missed-item repair before advancing`
            : "Review week · revisit misses and complete recall drills"
          : w === 0
            ? validMode === "adaptive"
              ? "Baseline + weakest-domain repair"
              : validMode === "choice"
                ? "My Choice plan starts with your selected sequence and material mix"
                : "Baseline + first study block"
            : validMode === "choice"
              ? `Complete ${classIds.length} scheduled modules using your custom domain mix + review misses`
              : `Complete ${classIds.length} scheduled modules + review misses`;

    const domains = ALL_DOMAINS.map((domain) => ({
      domain,
      classIds: weeklyByDomain[domain],
      weight: validMode === "choice" ? normalizedChoiceWeights[domain] ?? 0 : DOMAIN_WEIGHTS[domain],
      score: domainScores[domain] ?? null,
      plannedCount: weeklyByDomain[domain].length,
    }));

    weeks.push({
      week: w + 1,
      start: iso(start),
      end: iso(end),
      hours: profile.hoursPerWeek,
      classIds,
      milestone,
      focusDomains,
      domains,
      studyDays,
    });
  }

  // Backfill only non-domain strategies. A domain-by-domain plan must never cross a domain boundary in a week.
  if (validMode !== "domain") {
    for (const domain of chosen) {
      while (queues[domain].length) {
        const target = weeks.reduce((a, b) => (a.classIds.length <= b.classIds.length ? a : b));
        const id = queues[domain].shift()!;
        target.classIds.push(id);
        const bucket = target.domains.find((d) => d.domain === domain);
        bucket?.classIds.push(id);
        if (bucket) bucket.plannedCount += 1;
        if (!target.focusDomains.includes(domain)) target.focusDomains.push(domain);
      }
    }
  }

  return {
    mode: validMode,
    selectedDomains: chosen,
    choiceWeights: normalizedChoiceWeights,
    courseStart: iso(courseStart),
    examDate: exam ? iso(exam) : null,
    daysTotal,
    daysRemaining,
    weeksUntilExam,
    hoursBudget,
    hoursNeeded: HOURS_WARN_THRESHOLD,
    dailyHours,
    underHours,
    unlockedIds,
    weeks,
  };
}
