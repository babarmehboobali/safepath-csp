import { CATALOG, type CatalogEntry } from "./catalog";
import { CSP_DOMAIN_NAMES, CSP_DOMAIN_WEIGHTS } from "./assessment";

const INTENTS = [
  "exam prep",
  "study guide",
  "practice questions",
  "practice test",
  "review",
  "study notes",
  "worked examples",
  "scenario practice",
  "exam review",
  "quiz",
  "drill",
  "flashcards",
  "CSP preparation",
  "safety professional review",
  "CSP 11 prep",
  "CSP study plan",
] as const;

const FORMATS = [
  "questions",
  "answers",
  "explanations",
  "calculations",
  "formula practice",
  "concept review",
  "scenario questions",
  "lesson",
] as const;

export function slugify(value: string) {
  return value
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export function classSlug(entry: CatalogEntry) {
  return `${entry.id}-${slugify(entry.title)}`;
}

export function keywordCluster(entry: CatalogEntry): string[] {
  const domain = CSP_DOMAIN_NAMES[entry.domain as keyof typeof CSP_DOMAIN_NAMES] ?? "CSP exam domain";
  const base = [
    `CSP ${entry.title}`,
    `CSP11 ${entry.title}`,
    `${entry.title} CSP`,
    `${entry.title} safety professional`,
    `${entry.title} ${domain}`,
    entry.taskCode,
    `${entry.taskCode} ${entry.title}`,
    `${entry.title} exam preparation`,
    `${entry.title} safety exam`,
    `${entry.title} CSP practice`,
    `${entry.title} CSP questions`,
    `${entry.title} study guide`,
    `${entry.title} study notes`,
    `${entry.title} worked example`,
    `${entry.title} scenario practice`,
    `${entry.title} review questions`,
    `${entry.title} quiz`,
    `${entry.title} flashcards`,
  ];
  for (const intent of INTENTS) {
    base.push(`${entry.title} ${intent}`);
    base.push(`${domain} ${intent}`);
  }
  for (const format of FORMATS) base.push(`${entry.title} ${format}`);
  return [...new Set(base)].slice(0, 72);
}

export function domainKeywordCluster(domain: number): string[] {
  const name = CSP_DOMAIN_NAMES[domain as keyof typeof CSP_DOMAIN_NAMES] ?? `Domain ${domain}`;
  const weight = CSP_DOMAIN_WEIGHTS[domain as keyof typeof CSP_DOMAIN_WEIGHTS] ?? 0;
  const titles = CATALOG.filter((entry) => entry.domain === domain).map((entry) => entry.title);
  const keywords = [
    `CSP Domain ${domain}`,
    `CSP Domain ${domain} study guide`,
    `CSP Domain ${domain} practice questions`,
    `${name} CSP`,
    `${name} CSP exam prep`,
    `${name} safety professional`,
    `${name} practice test`,
    `${name} study notes`,
    `${name} scenario questions`,
    `${name} review`,
    `CSP Domain ${domain} ${weight}%`,
    ...titles.flatMap((title) => [
      `CSP ${title}`,
      `${title} practice questions`,
      `${title} study guide`,
      `${title} exam review`,
    ]),
  ];
  return [...new Set(keywords)];
}

export function getCatalogEntry(id: number) {
  return CATALOG.find((entry) => entry.id === id) ?? null;
}
