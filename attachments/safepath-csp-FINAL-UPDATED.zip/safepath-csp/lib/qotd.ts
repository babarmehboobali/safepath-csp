export function utcDateKey(d = new Date()): string {
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, "0");
  const day = String(d.getUTCDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function hashString(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/** Stable pick: same UTC calendar day always yields the same bank index. */
export function qotdIndex(bankLength: number, d = new Date()): number {
  if (bankLength <= 0) return 0;
  return hashString(`csp-qotd:${utcDateKey(d)}`) % bankLength;
}
