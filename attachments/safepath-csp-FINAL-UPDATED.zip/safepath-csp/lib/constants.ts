export const APP_NAME = "Safepath CSP";
export const NAV_SHORT = "SafePath";
export const HONESTY_SHORT =
  "Safepath is a study aid, not a pass guarantee. The CSP is earned by your hours, your judgment, and exam day — we give you the desks; you do the work.";

export const HONESTY_PRIMARY =
  "Safepath CSP is an independent study system. It is not BCSP, Pearson VUE, or any other prep vendor. Completing classes, gyms, and mocks does not guarantee that you will pass the CSP exam or receive any particular score.\n\nPassing is your work: a real study plan, honest drills, weak-domain repair, and full-length sittings under the clock. We built the path. You have to walk it.\n\nUse the catalog, sit the 5.5-hour mock until the habits stick, and treat every miss as a topic to reopen. A good score is built before you enter the test center — not promised by software.";

export const HONESTY_LEGAL =
  "No affiliation with BCSP or Pearson VUE. Original practice items only. Passing is not guaranteed.";

export const HONESTY_CLOSER =
  "Study well. Sit the exam prepared. The credential is yours only if you earn it.";

/** Footer / shared legal: primary honesty + one-line legal. */
export const DISCLAIMER = `${HONESTY_PRIMARY}\n\n${HONESTY_LEGAL}`;

export const DEMO_EMAIL = "demo@cspcoach.app";
export const DEMO_PASSWORD = "Demo1234!";

export const SESSION_COOKIE = "csp_session";
export const DEMO_PROFILE_COOKIE = "csp_demo_profile";

export const DOMAIN_WEIGHTS: Record<number, number> = {
  1: 25,
  2: 25,
  3: 15,
  4: 9,
  5: 6,
  6: 10,
  7: 10,
};

export const DOMAIN_NAMES: Record<number, string> = {
  1: "Advanced Application of Safety Principles",
  2: "Program Management",
  3: "Risk Management",
  4: "Emergency Management",
  5: "Environmental Management",
  6: "Occupational Health and Applied Science",
  7: "Training",
};

export const TRACKS = [
  { id: "compact", label: "Compact 47", classes: 47 },
  { id: "recommended", label: "Recommended 78", classes: 78 },
  { id: "maximum", label: "Maximum 130", classes: 130 },
] as const;

export const DEPTHS = ["brief", "standard", "deep"] as const;
export const DIFFICULTIES = ["foundation", "exam", "expert"] as const;
export const SKINS = [
  { id: "manufacturing", label: "Manufacturing" },
  { id: "oil-and-gas", label: "Oil and gas" },
  { id: "construction", label: "Construction" },
] as const;

export const CREDENTIALS = ["ASP", "GSP", "TSP", "NEBOSH-ID", "CIH", "Other"] as const;
export const APP_STATUSES = [
  "Not started",
  "Application in progress",
  "Approved — exam not scheduled",
  "Exam scheduled",
  "Retake",
] as const;

export const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"] as const;

export const CARD_INTERVALS = [1, 3, 7, 21] as const;

export const EXAM_TIP =
  "If two answers work, take the higher hierarchy / system / design option.";

export const HOURS_WARN_THRESHOLD = 120;

export const MOCK_LENGTHS = [50, 100, 200] as const;

export const ERROR_CODES: { code: string; meaning: string }[] = [
  { code: "HIER", meaning: "PPE/admin chosen while design/engineering was open" },
  { code: "PELTLV", meaning: "Legal limit confused with advisory guideline" },
  { code: "TOOL", meaning: "Wrong analysis tool (FMEA vs FTA etc.)" },
  { code: "UNIT", meaning: "Exchange rate, ppm vs mg/m3, ft vs m" },
  { code: "STEM", meaning: "Missed a constraint in the last sentence" },
  { code: "FORM", meaning: "Wrong formula" },
  { code: "FIN", meaning: "Avoid/retain/share/transfer/loss prevention mix-up" },
  { code: "TIME", meaning: "8-hour vs 24-hour reporting clock" },
];

export const MAX_CLASS_DOMAIN: Record<number, number> = {
  79: 1,
  80: 1,
  81: 6,
  82: 1,
  83: 6,
  84: 6,
  85: 2,
  86: 3,
  87: 1,
  88: 4,
  89: 7,
  90: 7,
};

export type TrackId = (typeof TRACKS)[number]["id"];
export type DepthId = (typeof DEPTHS)[number];
export type DifficultyId = (typeof DIFFICULTIES)[number];
export type SkinId = (typeof SKINS)[number]["id"];
