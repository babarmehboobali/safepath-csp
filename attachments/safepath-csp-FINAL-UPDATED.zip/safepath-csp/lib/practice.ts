import { prisma } from "./prisma";
import { nextDifficultyFromAccuracy, type DifficultyBand } from "./level";

export async function missedQuestionIds(userId: string): Promise<string[]> {
  const rows = await prisma.attempt.findMany({
    where: { userId, correct: false },
    orderBy: { createdAt: "desc" },
    select: { questionId: true },
  });
  const seen = new Set<string>();
  const ids: string[] = [];
  for (const r of rows) {
    if (seen.has(r.questionId)) continue;
    seen.add(r.questionId);
    ids.push(r.questionId);
  }
  return ids;
}

export async function weakestDomainFromAttempts(userId: string): Promise<number | null> {
  const rows = await prisma.attempt.findMany({
    where: { userId },
    select: {
      correct: true,
      question: { select: { class: { select: { domain: true } } } },
    },
  });
  const acc: Record<number, { ok: number; n: number }> = {};
  for (const r of rows) {
    const d = r.question.class.domain;
    acc[d] = acc[d] ?? { ok: 0, n: 0 };
    acc[d].n += 1;
    if (r.correct) acc[d].ok += 1;
  }
  let worst: number | null = null;
  let rate = 2;
  for (const [k, v] of Object.entries(acc)) {
    if (v.n < 1) continue;
    const r = v.ok / v.n;
    if (r < rate) {
      rate = r;
      worst = Number(k);
    }
  }
  return worst;
}

export async function levelFromAttempts(userId: string): Promise<DifficultyBand> {
  const rows = await prisma.attempt.findMany({
    where: { userId },
    select: { correct: true, question: { select: { difficulty: true } } },
  });
  const acc: Record<string, { ok: number; n: number }> = {
    Foundation: { ok: 0, n: 0 },
    Exam: { ok: 0, n: 0 },
    Expert: { ok: 0, n: 0 },
  };
  for (const r of rows) {
    const d = r.question.difficulty;
    if (!acc[d]) continue;
    acc[d].n += 1;
    if (r.correct) acc[d].ok += 1;
  }
  return nextDifficultyFromAccuracy(acc);
}

export async function attemptTimestamps(userId: string): Promise<Date[]> {
  const rows = await prisma.attempt.findMany({
    where: { userId },
    select: { createdAt: true },
    orderBy: { createdAt: "desc" },
    take: 2000,
  });
  return rows.map((r) => r.createdAt);
}

export async function nextFlag(userId: string) {
  return prisma.flag.findFirst({
    where: { userId },
    orderBy: { createdAt: "asc" },
    include: { question: { select: { id: true, stem: true, classId: true, class: { select: { domain: true } } } } },
  });
}

export function parseDomainList(raw: string | undefined): number[] {
  if (!raw) return [];
  return raw
    .split(",")
    .map((s) => Number(s.trim()))
    .filter((n) => [1, 2, 3, 4, 5, 6, 7].includes(n));
}
