import type { User } from "@prisma/client";
import { prisma } from "./prisma";
import { getSession, readDemoProfileCookie } from "./auth";
import type { DepthId, DifficultyId, SkinId, TrackId } from "./constants";

export type StudyProfile = {
  name: string;
  credential: string;
  applicationStatus: string;
  courseStartDate: string | null;
  examDate: string | null;
  hoursPerWeek: number;
  availableDays: string[];
  track: TrackId;
  depth: DepthId;
  difficulty: DifficultyId;
  industrySkin: SkinId;
  themePreset: string;
  accentColor: string;
  density: "comfortable" | "compact";
  layoutStyle: "focus" | "wide" | "cards";
  onboardingComplete: boolean;
  isDemo: boolean;
  email: string;
  userId: string;
};

const DEFAULTS: Omit<StudyProfile, "email" | "userId" | "isDemo"> = {
  name: "Demo candidate",
  credential: "ASP",
  applicationStatus: "Exam scheduled",
  courseStartDate: null,
  examDate: null,
  hoursPerWeek: 8,
  availableDays: ["Tue", "Thu", "Sat"],
  track: "recommended",
  depth: "standard",
  difficulty: "exam",
  industrySkin: "manufacturing",
  themePreset: "midnight",
  accentColor: "#7cdb3a",
  density: "comfortable",
  layoutStyle: "focus",
  onboardingComplete: false,
};

function defaultExamDate() {
  const d = new Date();
  d.setUTCHours(0, 0, 0, 0);
  d.setUTCDate(d.getUTCDate() + 12 * 7);
  return d.toISOString().slice(0, 10);
}

export function parseDays(raw: string | null | undefined): string[] {
  try {
    const v = JSON.parse(raw || "[]");
    return Array.isArray(v) ? v.map(String) : [];
  } catch {
    return [];
  }
}

function fromUser(user: User): StudyProfile {
  return {
    name: user.name || "Candidate",
    credential: user.credential || "ASP",
    applicationStatus: user.applicationStatus || "Not started",
    courseStartDate: user.courseStartDate ? user.courseStartDate.toISOString().slice(0, 10) : null,
    examDate: user.examDate ? user.examDate.toISOString().slice(0, 10) : null,
    hoursPerWeek: user.hoursPerWeek ?? 8,
    availableDays: parseDays(user.availableDays),
    track: (user.track as TrackId) || "recommended",
    depth: (user.depth as DepthId) || "standard",
    difficulty: (user.difficulty as DifficultyId) || "exam",
    industrySkin: (user.industrySkin as SkinId) || "manufacturing",
    themePreset: user.themePreset || "midnight",
    accentColor: user.accentColor || "#7cdb3a",
    density: user.density === "compact" ? "compact" : "comfortable",
    layoutStyle: user.layoutStyle === "wide" || user.layoutStyle === "cards" ? user.layoutStyle : "focus",
    onboardingComplete: user.onboardingComplete,
    isDemo: user.isDemo,
    email: user.email,
    userId: user.id,
  };
}

export async function getStudyProfile(): Promise<StudyProfile | null> {
  const session = await getSession();
  if (!session) return null;
  const user = await prisma.user.findUnique({ where: { id: session.id } });
  if (!user) return null;
  if (user.isDemo) {
    const cookie = await readDemoProfileCookie();
    const courseStartDate =
      (cookie?.courseStartDate as string | undefined) || new Date().toISOString().slice(0, 10);
    const examDate =
      (cookie?.examDate as string | undefined) || defaultExamDate();
    return {
      ...DEFAULTS,
      ...cookie,
      courseStartDate,
      examDate,
      availableDays: Array.isArray(cookie?.availableDays)
        ? (cookie?.availableDays as string[])
        : DEFAULTS.availableDays,
      hoursPerWeek: Number(cookie?.hoursPerWeek ?? DEFAULTS.hoursPerWeek),
      onboardingComplete: Boolean(cookie?.onboardingComplete),
      isDemo: true,
      email: user.email,
      userId: user.id,
      name: String(cookie?.name ?? user.name ?? DEFAULTS.name),
    };
  }
  return fromUser(user);
}
