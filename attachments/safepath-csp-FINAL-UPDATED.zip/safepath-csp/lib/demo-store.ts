"use client";

import type { Item } from "@/components/QuestionPlayer";
import { consecutiveLocalStreak, localDateKey } from "./streak";
import { nextDifficultyFromAccuracy, type DifficultyBand } from "./level";

const ATTEMPTS = "csp.demo.attempts";
const FLAGS = "csp.demo.flags";
const DAYS = "csp.demo.days";

export type DemoAttempt = {
  questionId: string;
  selected: number;
  correct: boolean;
  domain?: number;
  classId?: number;
  difficulty?: string;
  at: string;
  item?: Item;
};

export type DemoFlag = {
  questionId: string;
  stemPreview: string;
  domain?: number;
  classId?: number;
  difficulty?: string;
};

function readJson<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = sessionStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function writeJson(key: string, value: unknown) {
  if (typeof window === "undefined") return;
  sessionStorage.setItem(key, JSON.stringify(value));
}

export function isDemoClient(): boolean {
  if (typeof document === "undefined") return false;
  return !!document.querySelector("[data-demo]");
}

export function loadDemoAttempts(): DemoAttempt[] {
  return readJson<DemoAttempt[]>(ATTEMPTS, []);
}

export function recordDemoAttempt(row: DemoAttempt) {
  const list = loadDemoAttempts();
  list.push(row);
  writeJson(ATTEMPTS, list.slice(-400));
  const days = new Set(readJson<string[]>(DAYS, []));
  days.add(localDateKey(new Date(row.at)));
  writeJson(DAYS, [...days]);
}

export function demoMissedItems(): Item[] {
  const seen = new Set<string>();
  const out: Item[] = [];
  const attempts = loadDemoAttempts();
  for (let i = attempts.length - 1; i >= 0; i--) {
    const a = attempts[i]!;
    if (a.correct || !a.item || seen.has(a.questionId)) continue;
    seen.add(a.questionId);
    out.push(a.item);
  }
  return out;
}

export function demoDomainAccuracy(): Record<number, { ok: number; n: number }> {
  const acc: Record<number, { ok: number; n: number }> = {};
  for (const a of loadDemoAttempts()) {
    const d = a.domain ?? 0;
    if (!d) continue;
    acc[d] = acc[d] ?? { ok: 0, n: 0 };
    acc[d].n += 1;
    if (a.correct) acc[d].ok += 1;
  }
  return acc;
}

export function demoWeakestDomain(): number | null {
  const acc = demoDomainAccuracy();
  let worst: number | null = null;
  let rate = 2;
  for (const [k, v] of Object.entries(acc)) {
    if (v.n < 1) continue;
    const r = v.ok / v.n;
    if (r < rate) {
      rate = r;
      worst = Number(k);
    }
  }
  return worst;
}

export function demoDifficultyAccuracy(): Record<string, { ok: number; n: number }> {
  const acc: Record<string, { ok: number; n: number }> = {
    Foundation: { ok: 0, n: 0 },
    Exam: { ok: 0, n: 0 },
    Expert: { ok: 0, n: 0 },
  };
  for (const a of loadDemoAttempts()) {
    const d = a.difficulty || "";
    if (!acc[d]) continue;
    acc[d].n += 1;
    if (a.correct) acc[d].ok += 1;
  }
  return acc;
}

export function demoLevel(): DifficultyBand {
  return nextDifficultyFromAccuracy(demoDifficultyAccuracy());
}

export function demoStreak(): number {
  const days = readJson<string[]>(DAYS, []);
  const iso = days.map((d) => `${d}T12:00:00`);
  return consecutiveLocalStreak(iso);
}

export function loadDemoFlags(): DemoFlag[] {
  return readJson<DemoFlag[]>(FLAGS, []);
}

export function demoHasFlag(questionId: string): boolean {
  return loadDemoFlags().some((f) => f.questionId === questionId);
}

export function toggleDemoFlag(meta: DemoFlag): boolean {
  const list = loadDemoFlags();
  const i = list.findIndex((f) => f.questionId === meta.questionId);
  if (i >= 0) {
    list.splice(i, 1);
    writeJson(FLAGS, list);
    return false;
  }
  list.push(meta);
  writeJson(FLAGS, list);
  return true;
}
