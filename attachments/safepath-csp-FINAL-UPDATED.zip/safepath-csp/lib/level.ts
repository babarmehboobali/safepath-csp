export type DifficultyBand = "Foundation" | "Exam" | "Expert";

export function nextDifficultyFromAccuracy(
  acc: Record<string, { ok: number; n: number }>,
): DifficultyBand {
  const f = acc.Foundation ?? { ok: 0, n: 0 };
  const e = acc.Exam ?? { ok: 0, n: 0 };
  if (!f.n || f.ok / f.n < 0.7) return "Foundation";
  if (!e.n || e.ok / e.n < 0.7) return "Exam";
  return "Expert";
}
