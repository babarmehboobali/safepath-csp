"use client";

import { useMemo, useState } from "react";

function cleanText(value: string) {
  return value
    .replace(/Â°/g, "°")
    .replace(/Â·/g, "·")
    .replace(/â|â€“/g, "–")
    .replace(/â|â€”/g, "—")
    .replace(/â|â€œ/g, "“")
    .replace(/â|â€/g, "”")
    .replace(/â|â€™/g, "’")
    .replace(/â¦|â€¦/g, "…")
    .replace(/â|âž|âž/g, "➔")
    .replace(/â¥/g, "≥")
    .replace(/â¤/g, "≤")
    .replace(/â/g, "√");
}

function splitIntoBlocks(raw: string) {
  const text = cleanText(raw || "Placeholder notes for this class.").trim();
  const explicit = text.split(/\n\s*\n/).map((x) => x.trim()).filter(Boolean);
  if (explicit.length > 1) return explicit;
  const sentences = text.split(/(?<=[.!?])\s+/).filter(Boolean);
  const blocks: string[] = [];
  for (let i = 0; i < sentences.length; i += 3) blocks.push(sentences.slice(i, i + 3).join(" "));
  return blocks.length ? blocks : [text];
}

function classify(block: string, index: number) {
  const lower = block.toLowerCase();
  if (/formula|calculate|sin\(|cos\(|twa|ppm|mg\/m|lb|kg|equation|ti-30|=/.test(lower)) return { label: "⚡ Formula / calculation", tone: "formula", icon: "⚡" };
  if (/must-score|critical|remember|exam default|core rule|key rule/.test(lower)) return { label: "🎯 Must-score", tone: "key", icon: "🎯" };
  if (/trap|wrong|distractor|losing|avoid|mistake/.test(lower)) return { label: "⚠️ Common trap", tone: "trap", icon: "⚠️" };
  if (/field|rig|plant|construction|worker|operator|scenario|example/.test(lower)) return { label: "🦺 Field application", tone: "field", icon: "🦺" };
  return { label: index === 0 ? "📌 Core concept" : "📖 Study note", tone: "normal", icon: index === 0 ? "📌" : "📖" };
}

export function DepthNotes({ brief, standard, deep, defaultDepth }: { brief: string; standard: string; deep: string; defaultDepth: string }) {
  const start = defaultDepth === "brief" || defaultDepth === "deep" ? defaultDepth : "standard";
  const [tab, setTab] = useState(start);
  const [presentation, setPresentation] = useState<"focus" | "scan">("focus");
  const [focusIndex, setFocusIndex] = useState(0);
  const body = tab === "brief" ? brief : tab === "deep" ? deep : standard;
  const blocks = useMemo(() => splitIntoBlocks(body), [body]);
  const safeIndex = Math.min(focusIndex, Math.max(0, blocks.length - 1));
  const focusBlock = blocks[safeIndex] || blocks[0] || "";
  const meta = classify(focusBlock, safeIndex);

  function changeTab(next: typeof start) {
    setTab(next);
    setFocusIndex(0);
  }

  function nextFocus() {
    setFocusIndex((current) => Math.min(blocks.length - 1, current + 1));
  }

  return (
    <section className="note-reader card overflow-hidden">
      <div className="border-b border-line bg-panel-2/60 p-4 sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="kicker">📚 Study reader</p>
            <h3 className="mt-1 text-lg font-bold">Learn it in layers — not a wall of text</h3>
          </div>
          <span className="chip">{blocks.length} reading blocks</span>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-2" role="tablist" aria-label="Reading depth">
          {(["brief", "standard", "deep"] as const).map((d) => (
            <button key={d} type="button" role="tab" aria-selected={tab === d} onClick={() => changeTab(d)} className={`tap rounded-xl border px-3 py-2 text-sm font-semibold transition ${tab === d ? "border-[var(--user-accent)] bg-[var(--user-accent-soft)] text-[var(--theme-text)]" : "border-line bg-panel text-muted hover:text-[var(--theme-text)]"}`}>
              {d === "brief" ? "⚡ Brief" : d === "standard" ? "🎓 Standard" : "🔎 Deep"}
            </button>
          ))}
        </div>
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-line bg-panel p-1.5">
          <button type="button" className={`tap rounded-lg px-3 py-1.5 text-xs font-bold ${presentation === "focus" ? "bg-[var(--user-accent-soft)] text-[var(--theme-text)]" : "text-muted"}`} onClick={() => setPresentation("focus")}>🎯 Focus one block</button>
          <button type="button" className={`tap rounded-lg px-3 py-1.5 text-xs font-bold ${presentation === "scan" ? "bg-[var(--user-accent-soft)] text-[var(--theme-text)]" : "text-muted"}`} onClick={() => setPresentation("scan")}>📑 Scan all</button>
        </div>
      </div>

      <div className="lesson-reader p-4 sm:p-7">
        {presentation === "focus" ? (
          <div>
            <div className="mb-5 flex items-center gap-3 text-xs text-muted">
              <span className="h-2 flex-1 rounded-full bg-panel-2"><span className="block h-2 rounded-full bg-[var(--user-accent)] transition-all duration-300" style={{ width: `${Math.round(((safeIndex + 1) / Math.max(1, blocks.length)) * 100)}%` }} /></span>
              <span className="tabular-nums">{safeIndex + 1}/{blocks.length}</span>
            </div>

            <article className={`note-callout ${meta.tone === "formula" ? "border-sky-800/80 bg-slate-950" : ""} min-h-[250px] p-5 sm:p-7`}>
              <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
                <span className={`text-xs font-bold uppercase tracking-wide ${meta.tone === "trap" ? "text-bad" : meta.tone === "formula" ? "text-sky-400" : meta.tone === "key" ? "text-[var(--user-accent)]" : "text-muted"}`}>{meta.label}</span>
                <span className="font-mono text-[11px] text-muted">Block {safeIndex + 1}</span>
              </div>
              <div className="mb-4 text-2xl" aria-hidden>{meta.icon}</div>
              <p className={meta.tone === "formula" ? "whitespace-pre-wrap font-mono text-sm leading-8 text-sky-400" : "lesson-prose whitespace-pre-wrap"}>{focusBlock}</p>
            </article>

            <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
              <button type="button" className="btn-ghost tap" onClick={() => setFocusIndex((current) => Math.max(0, current - 1))} disabled={safeIndex === 0}>← Previous</button>
              <button type="button" className="btn-primary tap" onClick={nextFocus} disabled={safeIndex >= blocks.length - 1}>{safeIndex >= blocks.length - 1 ? "✓ Reading complete" : "Got it — next →"}</button>
            </div>
          </div>
        ) : (
          <div>
            <div className="mb-5 flex items-center gap-3 text-xs text-muted"><span className="h-2 flex-1 rounded-full bg-panel-2"><span className="block h-2 rounded-full bg-[var(--user-accent)]" style={{ width: "100%" }} /></span><span>{blocks.length} blocks</span></div>
            <div className="space-y-4">
              {blocks.map((block, index) => {
                const blockMeta = classify(block, index);
                const isFormula = blockMeta.tone === "formula";
                return (
                  <article key={`${index}-${block.slice(0, 20)}`} className={`note-callout ${isFormula ? "bg-slate-950" : ""}`}>
                    <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                      <span className={`text-xs font-bold uppercase tracking-wide ${blockMeta.tone === "trap" ? "text-bad" : blockMeta.tone === "formula" ? "text-sky-400" : blockMeta.tone === "key" ? "text-[var(--user-accent)]" : "text-muted"}`}>{blockMeta.label}</span>
                      <span className="font-mono text-[11px] text-muted">#{index + 1}</span>
                    </div>
                    <p className={isFormula ? "whitespace-pre-wrap font-mono text-sm leading-7 text-sky-400" : "lesson-prose whitespace-pre-wrap"}>{block}</p>
                  </article>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
