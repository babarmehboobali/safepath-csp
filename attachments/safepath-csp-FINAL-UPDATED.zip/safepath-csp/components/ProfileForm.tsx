"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  APP_STATUSES,
  CREDENTIALS,
  DAYS,
  DEPTHS,
  DIFFICULTIES,
  SKINS,
  TRACKS,
} from "@/lib/constants";
import type { StudyProfile } from "@/lib/profile";

export function ProfileForm({
  profile,
  endpoint,
  submitLabel,
}: {
  profile: StudyProfile;
  endpoint: string;
  submitLabel: string;
}) {
  const router = useRouter();
  const [days, setDays] = useState<string[]>(profile.availableDays);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  function toggle(day: string) {
    setDays((d) => (d.includes(day) ? d.filter((x) => x !== day) : [...d, day]));
  }

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setPending(true);
    setError(null);
    const fd = new FormData(e.currentTarget);
    const body = {
      name: String(fd.get("name") || ""),
      credential: String(fd.get("credential") || ""),
      applicationStatus: String(fd.get("applicationStatus") || ""),
      courseStartDate: String(fd.get("courseStartDate") || ""),
      examDate: String(fd.get("examDate") || ""),
      hoursPerWeek: Number(fd.get("hoursPerWeek") || 8),
      availableDays: days,
      track: String(fd.get("track") || "recommended"),
      depth: String(fd.get("depth") || "standard"),
      difficulty: String(fd.get("difficulty") || "exam"),
      industrySkin: String(fd.get("industrySkin") || "manufacturing"),
      themePreset: profile.themePreset,
      accentColor: profile.accentColor,
      density: profile.density,
      layoutStyle: profile.layoutStyle,
    };
    const res = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json().catch(() => ({}));
    setPending(false);
    if (!res.ok) {
      setError(data.error || "Could not save.");
      return;
    }
    router.push(data.redirect || "/dashboard");
    router.refresh();
  }

  return (
    <form onSubmit={onSubmit} className="card space-y-4 p-5">
      <div>
        <label htmlFor="name" className="mb-1 block text-sm">Name</label>
        <input id="name" name="name" className="field" defaultValue={profile.name} required />
      </div>
      <div>
        <label htmlFor="credential" className="mb-1 block text-sm">CSP pathway credential</label>
        <select id="credential" name="credential" className="field" defaultValue={profile.credential}>
          {CREDENTIALS.map((c) => (
            <option key={c}>{c}</option>
          ))}
        </select>
        <p className="mt-2 text-xs text-muted">Use the <a href="/eligibility" className="font-semibold text-[var(--user-accent)] underline-offset-4 hover:underline">Eligibility Wizard</a> for a fuller pathway screen.</p>
      </div>
      <div>
        <label htmlFor="applicationStatus" className="mb-1 block text-sm">Application status</label>
        <select id="applicationStatus" name="applicationStatus" className="field" defaultValue={profile.applicationStatus}>
          {APP_STATUSES.map((c) => (
            <option key={c}>{c}</option>
          ))}
        </select>
      </div>
      <div>
        <label htmlFor="courseStartDate" className="mb-1 block text-sm">Course start date</label>
        <input id="courseStartDate" name="courseStartDate" type="date" className="field" defaultValue={profile.courseStartDate ?? ""} required />
      </div>
      <div>
        <label htmlFor="examDate" className="mb-1 block text-sm">Exam target date</label>
        <input id="examDate" name="examDate" type="date" className="field" defaultValue={profile.examDate ?? ""} required />
      </div>
      <div>
        <label htmlFor="hoursPerWeek" className="mb-1 block text-sm">Hours per week</label>
        <input id="hoursPerWeek" name="hoursPerWeek" type="number" min={1} max={80} className="field" defaultValue={profile.hoursPerWeek} required />
      </div>
      <fieldset>
        <legend className="mb-2 text-sm">Available days</legend>
        <div className="flex flex-wrap gap-2">
          {DAYS.map((d) => (
            <label key={d} className={`tap inline-flex items-center rounded-lg border px-3 ${days.includes(d) ? "border-amber bg-amber/15" : "border-line"}`}>
              <input type="checkbox" className="mr-2" checked={days.includes(d)} onChange={() => toggle(d)} />
              {d}
            </label>
          ))}
        </div>
      </fieldset>
      <div>
        <label htmlFor="track" className="mb-1 block text-sm">Track</label>
        <select id="track" name="track" className="field" defaultValue={profile.track}>
          {TRACKS.map((t) => (
            <option key={t.id} value={t.id}>{t.label}</option>
          ))}
        </select>
      </div>
      <div>
        <label htmlFor="depth" className="mb-1 block text-sm">Depth</label>
        <select id="depth" name="depth" className="field" defaultValue={profile.depth}>
          {DEPTHS.map((d) => (
            <option key={d} value={d} className="capitalize">{d}</option>
          ))}
        </select>
      </div>
      <div>
        <label htmlFor="difficulty" className="mb-1 block text-sm">Difficulty</label>
        <select id="difficulty" name="difficulty" className="field" defaultValue={profile.difficulty}>
          {DIFFICULTIES.map((d) => (
            <option key={d} value={d} className="capitalize">{d}</option>
          ))}
        </select>
      </div>
      <div>
        <label htmlFor="industrySkin" className="mb-1 block text-sm">Industry skin (hook text only)</label>
        <select id="industrySkin" name="industrySkin" className="field" defaultValue={profile.industrySkin}>
          {SKINS.map((s) => (
            <option key={s.id} value={s.id}>{s.label}</option>
          ))}
        </select>
      </div>
      {profile.isDemo ? (
        <p className="text-sm text-amber">Demo: this form stays in the session cookie and vanishes at logout.</p>
      ) : null}
      {error ? <p className="text-sm text-bad">{error}</p> : null}
      <button className="btn-primary w-full" type="submit" disabled={pending}>
        {pending ? "Saving…" : submitLabel}
      </button>
    </form>
  );
}
