import type { ReactNode } from "react";

const NAVY = "#0d1730";
const AMBER = "#e4a11b";
const AMBER2 = "#f3c45a";
const CREAM = "#f4ead4";
const PANEL = "#1a2742";
const INK = "#08101c";
const ON_AMBER = "#1a1204";
const OK = "#2f9e6c";
const BAD = "#d85a4a";

/** Tiny slot around a class diagram. Null child keeps the empty dashed state. */
export function InfographicSlot({ children }: { children?: ReactNode }) {
  return (
    <div className="overflow-x-auto">
      {children ?? (
        <p className="rounded-lg border border-dashed border-line px-3 py-6 text-center text-sm text-muted">
          No extra diagram — redraw the model from the caption.
        </p>
      )}
    </div>
  );
}

function SvgShell({
  w,
  h,
  label,
  title,
  desc,
  children,
}: {
  w: number;
  h: number;
  label: string;
  title?: string;
  desc?: string;
  children: ReactNode;
}) {
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-auto w-full font-sans" role="img" aria-label={label}>
      {title ? <title>{title}</title> : null}
      {desc ? <desc>{desc}</desc> : null}
      <rect width={w} height={h} fill={NAVY} rx="8" />
      {children}
    </svg>
  );
}

function Tl({
  x,
  y,
  fill,
  size,
  lines,
  gap = 17,
  weight = 700,
  anchor = "middle",
}: {
  x: number;
  y: number;
  fill: string;
  size: number;
  lines: string[];
  gap?: number;
  weight?: number;
  anchor?: "middle" | "start" | "end";
}) {
  return (
    <text x={x} y={y} textAnchor={anchor} fill={fill} fontSize={size} fontWeight={weight}>
      {lines.map((line, i) => (
        <tspan key={`${i}-${line}`} x={x} dy={i === 0 ? 0 : gap}>
          {line}
        </tspan>
      ))}
    </text>
  );
}

export function PtDTimeline() {
  const boxes = [
    { title: ["Concept / material"], under: ["ELIMINATE /", "SUBSTITUTE"] },
    { title: ["Detailed design"], under: ["ELIMINATE /", "SUBSTITUTE"] },
    { title: ["Build / commission"], under: ["ENGINEERING /", "ADMIN / PPE"] },
    { title: ["Operate / maintain", "/ retire"], under: ["ENGINEERING /", "ADMIN / PPE"] },
  ];
  return (
    <figure className="space-y-3">
      <SvgShell
        w={400}
        h={520}
        label="Prevention through Design timeline"
        title="Prevention through Design timeline"
        desc="Four time boxes stacked. Eliminate and substitute under the first two. Engineering, admin, and PPE under the last two. Cost of change rises down the page."
      >
        {boxes.map((b, i) => {
          const y = 16 + i * 112;
          const fill = i < 2 ? AMBER : PANEL;
          const fg = i < 2 ? ON_AMBER : CREAM;
          return (
            <g key={b.title.join(" ")}>
              <rect x="16" y={y} width="368" height="72" rx="10" fill={fill} stroke={CREAM} strokeWidth="2" />
              <circle cx="44" cy={y + 36} r="16" fill={i < 2 ? ON_AMBER : AMBER} />
              <text x="44" y={y + 41} textAnchor="middle" fill={i < 2 ? AMBER : ON_AMBER} fontSize="16" fontWeight="700">
                {i + 1}
              </text>
              <Tl x={210} y={y + 32} fill={fg} size={16} lines={b.title} gap={18} />
              <rect x="16" y={y + 76} width="368" height="28" rx="6" fill={INK} stroke={AMBER} strokeWidth="2" />
              <text x="200" y={y + 95} textAnchor="middle" fill={AMBER} fontSize="12" fontWeight="700">
                {b.under.join(" ")}
              </text>
              {i < 3 ? <polygon points={`200,${y + 108} 192,${y + 112} 208,${y + 112}`} fill={AMBER2} /> : null}
            </g>
          );
        })}
        <Tl x={200} y={472} fill={AMBER2} size={14} lines={["Cost of change rises as you move down"]} />
      </SvgShell>
      <figcaption className="text-sm text-muted">Cost of change rises as you move down (later = costlier).</figcaption>
    </figure>
  );
}


export function HierarchySvg() {
  const rows = [
    { label: "Elimination", w: 368, fill: AMBER, fg: ON_AMBER },
    { label: "Substitution", w: 312, fill: "#d39218", fg: ON_AMBER },
    { label: "Engineering", w: 256, fill: OK, fg: INK },
    { label: "Administrative", w: 200, fill: PANEL, fg: CREAM },
    { label: "PPE", w: 144, fill: BAD, fg: CREAM },
  ];
  return (
    <SvgShell w={400} h={290} label="Hierarchy of controls">
      {rows.map((r, i) => {
        const x = (400 - r.w) / 2;
        const y = 16 + i * 52;
        return (
          <g key={r.label}>
            <rect x={x} y={y} width={r.w} height="44" rx="6" fill={r.fill} />
            <text x="200" y={y + 29} textAnchor="middle" fill={r.fg} fontSize="16" fontWeight="700">
              {r.label}
            </text>
          </g>
        );
      })}
    </SvgShell>
  );
}


export function ProcessSafetyLayers() {
  const rings = [
    { r: 96, fill: "#e4a11b", fg: "#1a1204", label: "Process" },
    { r: 132, fill: "#d39218", fg: "#1a1204", label: "BPCS" },
    { r: 168, fill: "#2f9e6c", fg: "#08101c", label: "Alarm / admin" },
    { r: 204, fill: "#1a2742", fg: "#f4ead4", label: "SIS" },
    { r: 240, fill: "#0d1730", fg: "#f3c45a", label: "Relief / dike" },
    { r: 276, fill: "#08101c", fg: "#f4ead4", label: "Emergency" },
  ];
  const ordered = [...rings].reverse();
  return (
    <svg viewBox="0 0 800 320" className="w-full h-auto" role="img" aria-label="Process safety layers of protection">
      <rect width="800" height="320" fill="#0d1730" />
      {ordered.map((ring) => (
        <circle key={ring.label} cx="260" cy="160" r={ring.r * 0.52} fill={ring.fill} stroke="#f4ead4" strokeWidth="2" />
      ))}
      <text x="260" y="164" textAnchor="middle" fill="#1a1204" fontSize="14" fontWeight="700">
        Inherent
      </text>
      {rings.map((ring, i) => (
        <text key={ring.label} x="430" y={36 + i * 44} fill={ring.fg === "#1a1204" ? "#f3c45a" : "#f4ead4"} fontSize="16" fontWeight="700">
          {i + 1}. {ring.label}
        </text>
      ))}
      <text x="400" y="308" textAnchor="middle" fill="#f3c45a" fontSize="13" fontWeight="700">
        Outer rings fail independently — detectors are not inventory
      </text>
    </svg>
  );
}

export function LotoEnergy() {
  const types = ["Electrical", "Mechanical", "Hydraulic", "Pneumatic", "Thermal", "Chemical", "Gravity"];
  const steps = ["Shutdown", "Isolate", "Lock / tag", "Dissipate", "Verify (try-out)"];
  return (
    <svg viewBox="0 0 800 280" className="w-full h-auto" role="img" aria-label="LOTO energy types and sequence">
      <rect width="800" height="280" fill="#0d1730" />
      {types.map((t, i) => {
        const x = 16 + (i % 7) * 110;
        return (
          <g key={t}>
            <rect x={x} y="20" width="100" height="44" rx="8" fill="#1a2742" stroke="#e4a11b" strokeWidth="2" />
            <text x={x + 50} y="47" textAnchor="middle" fill="#f4ead4" fontSize="11" fontWeight="700">
              {t}
            </text>
          </g>
        );
      })}
      {steps.map((s, i) => {
        const x = 20 + i * 156;
        return (
          <g key={s}>
            <rect x={x} y="110" width="140" height="72" rx="10" fill={i === 4 ? "#e4a11b" : "#1a2742"} stroke="#f4ead4" strokeWidth="2" />
            <text x={x + 70} y="140" textAnchor="middle" fill={i === 4 ? "#1a1204" : "#f4ead4"} fontSize="13" fontWeight="700">
              {i + 1}
            </text>
            <text x={x + 70} y="162" textAnchor="middle" fill={i === 4 ? "#1a1204" : "#f3c45a"} fontSize="12" fontWeight="700">
              {s}
            </text>
            {i < 4 ? <polygon points={`${x + 142},146 ${x + 156},146 ${x + 149},154`} fill="#f3c45a" /> : null}
          </g>
        );
      })}
      <text x="400" y="230" textAnchor="middle" fill="#f3c45a" fontSize="14" fontWeight="700">
        A missing energy type is a missing isolation
      </text>
      <text x="400" y="258" textAnchor="middle" fill="#f4ead4" fontSize="13">
        A spotter is not a lock. Personal lock + try-out.
      </text>
    </svg>
  );
}

export function ExcavationSlope() {
  return (
    <svg viewBox="0 0 800 280" className="w-full h-auto" role="img" aria-label="Type C excavation slope">
      <rect width="800" height="280" fill="#0d1730" />
      <polygon points="40,60 260,220 40,220" fill="#1a2742" stroke="#e4a11b" strokeWidth="3" />
      <polygon points="760,60 540,220 760,220" fill="#1a2742" stroke="#e4a11b" strokeWidth="3" />
      <rect x="260" y="196" width="280" height="24" fill="#08101c" />
      <rect x="380" y="120" width="18" height="76" fill="#e4a11b" />
      <rect x="368" y="108" width="42" height="12" fill="#f3c45a" />
      <rect x="70" y="36" width="90" height="28" rx="4" fill="#d85a4a" />
      <text x="115" y="55" textAnchor="middle" fill="#f4ead4" fontSize="12" fontWeight="700">
        SPOIL ≥ 2 ft
      </text>
      <text x="400" y="250" textAnchor="middle" fill="#f3c45a" fontSize="14" fontWeight="700">
        Type C: 1½ H : 1 V — a spotter does not hold the wall
      </text>
      <text x="150" y="150" fill="#f4ead4" fontSize="13" fontWeight="700">
        1.5
      </text>
      <text x="230" y="200" fill="#f4ead4" fontSize="13" fontWeight="700">
        1
      </text>
    </svg>
  );
}

export function ConfinedSpaceSvg() {
  return (
    <svg viewBox="0 0 800 280" className="w-full h-auto" role="img" aria-label="Permit confined space controls">
      <rect width="800" height="280" fill="#0d1730" />
      <ellipse cx="280" cy="170" rx="160" ry="70" fill="#1a2742" stroke="#f4ead4" strokeWidth="3" />
      <rect x="240" y="70" width="80" height="50" rx="8" fill="#08101c" stroke="#e4a11b" strokeWidth="3" />
      <text x="280" y="100" textAnchor="middle" fill="#e4a11b" fontSize="12" fontWeight="700">
        MANWAY
      </text>
      <circle cx="280" cy="48" r="14" fill="#e4a11b" />
      <text x="280" y="53" textAnchor="middle" fill="#1a1204" fontSize="11" fontWeight="700">
        T
      </text>
      <rect x="500" y="40" width="260" height="200" rx="10" fill="#08101c" stroke="#e4a11b" strokeWidth="2" />
      <text x="630" y="70" textAnchor="middle" fill="#f3c45a" fontSize="14" fontWeight="700">
        Test order
      </text>
      {["1. Oxygen", "2. LEL / flammable", "3. Toxic"].map((row, i) => (
        <text key={row} x="530" y={110 + i * 32} fill="#f4ead4" fontSize="16" fontWeight="700">
          {row}
        </text>
      ))}
      <text x="630" y="220" textAnchor="middle" fill="#e4a11b" fontSize="12" fontWeight="700">
        Attendant stays outside
      </text>
      <text x="280" y="260" textAnchor="middle" fill="#f3c45a" fontSize="13" fontWeight="700">
        Isolate · ventilate · retrieve — a half-mask is not a plan
      </text>
    </svg>
  );
}

export function EgressSvg() {
  const boxes = [
    { title: "Exit access", sub: "Aisle / path" },
    { title: "Exit", sub: "Protected stair" },
    { title: "Exit discharge", sub: "To public way" },
  ];
  return (
    <svg viewBox="0 0 800 240" className="w-full h-auto" role="img" aria-label="Means of egress three parts">
      <rect width="800" height="240" fill="#0d1730" />
      {boxes.map((b, i) => {
        const x = 30 + i * 255;
        return (
          <g key={b.title}>
            <rect x={x} y="40" width="230" height="100" rx="10" fill={i === 1 ? "#e4a11b" : "#1a2742"} stroke="#f4ead4" strokeWidth="2" />
            <text x={x + 115} y="82" textAnchor="middle" fill={i === 1 ? "#1a1204" : "#f4ead4"} fontSize="18" fontWeight="700">
              {b.title}
            </text>
            <text x={x + 115} y="110" textAnchor="middle" fill={i === 1 ? "#1a1204" : "#f3c45a"} fontSize="13">
              {b.sub}
            </text>
            {i < 2 ? <polygon points={`${x + 234},90 ${x + 254},90 ${x + 244},98`} fill="#f3c45a" /> : null}
          </g>
        );
      })}
      <text x="400" y="180" textAnchor="middle" fill="#f3c45a" fontSize="14" fontWeight="700">
        Sprinklers sit beside the path — they are not a stair
      </text>
      <text x="400" y="210" textAnchor="middle" fill="#f4ead4" fontSize="13">
        Unlocked · unobstructed · occupant load
      </text>
    </svg>
  );
}

export function ElectricalBoundaries() {
  return (
    <svg viewBox="0 0 800 260" className="w-full h-auto" role="img" aria-label="Electrical approach boundaries">
      <rect width="800" height="260" fill="#0d1730" />
      <circle cx="260" cy="130" r="110" fill="#1a2742" stroke="#f3c45a" strokeWidth="3" />
      <circle cx="260" cy="130" r="74" fill="#2f9e6c" stroke="#f4ead4" strokeWidth="2" />
      <circle cx="260" cy="130" r="40" fill="#d85a4a" stroke="#f4ead4" strokeWidth="2" />
      <circle cx="260" cy="130" r="12" fill="#e4a11b" />
      <text x="500" y="70" fill="#f3c45a" fontSize="16" fontWeight="700">
        Outer: arc-flash boundary
      </text>
      <text x="500" y="110" fill="#2f9e6c" fontSize="16" fontWeight="700">
        Limited approach (shock)
      </text>
      <text x="500" y="150" fill="#d85a4a" fontSize="16" fontWeight="700">
        Restricted approach (shock)
      </text>
      <text x="500" y="190" fill="#e4a11b" fontSize="16" fontWeight="700">
        Energized part
      </text>
      <text x="400" y="240" textAnchor="middle" fill="#f4ead4" fontSize="13" fontWeight="700">
        Prefer IR window / outage — 42 in is not 42 cm
      </text>
    </svg>
  );
}

export function FallClearance() {
  const rows = [
    { label: "Lanyard 6 ft", h: 36 },
    { label: "Decel ~3.5 ft", h: 28 },
    { label: "D-ring to feet ~6 ft", h: 36 },
    { label: "Connectors ~1 ft", h: 18 },
    { label: "Margin ~2 ft", h: 22 },
  ];
  let y = 24;
  const blocks: { label: string; y: number; h: number }[] = [];
  for (const r of rows) {
    blocks.push({ label: r.label, y, h: r.h });
    y += r.h + 6;
  }
  return (
    <svg viewBox="0 0 800 260" className="w-full h-auto" role="img" aria-label="Fall clearance stack">
      <rect width="800" height="260" fill="#0d1730" />
      {blocks.map((b, i) => (
        <g key={b.label}>
          <rect x="80" y={b.y} width="280" height={b.h} rx="6" fill={i === 0 ? "#e4a11b" : "#1a2742"} stroke="#f4ead4" strokeWidth="2" />
          <text x="220" y={b.y + b.h / 2 + 5} textAnchor="middle" fill={i === 0 ? "#1a1204" : "#f4ead4"} fontSize="13" fontWeight="700">
            {b.label}
          </text>
        </g>
      ))}
      <text x="520" y="90" fill="#f3c45a" fontSize="18" fontWeight="700">
        Stack ≈ 18.5 ft
      </text>
      <text x="520" y="124" fill="#f4ead4" fontSize="14">
        If story is 16 ft, 6-ft lanyard fails
      </text>
      <text x="520" y="156" fill="#f4ead4" fontSize="14">
        3.5 m is not 3.5 ft
      </text>
      <text x="400" y="240" textAnchor="middle" fill="#f3c45a" fontSize="13" fontWeight="700">
        Guardrail first — PFAS last and only with clearance
      </text>
    </svg>
  );
}

export function SlingAngleSvg() {
  return (
    <svg viewBox="0 0 800 260" className="w-full h-auto" role="img" aria-label="Two-leg sling tension versus angle">
      <rect width="800" height="260" fill="#0d1730" />
      <circle cx="200" cy="40" r="10" fill="#e4a11b" />
      <line x1="200" y1="40" x2="80" y2="180" stroke="#f4ead4" strokeWidth="4" />
      <line x1="200" y1="40" x2="320" y2="180" stroke="#f4ead4" strokeWidth="4" />
      <rect x="150" y="180" width="100" height="36" rx="4" fill="#e4a11b" />
      <text x="200" y="204" textAnchor="middle" fill="#1a1204" fontSize="14" fontWeight="700">
        W
      </text>
      <text x="200" y="150" textAnchor="middle" fill="#f3c45a" fontSize="14" fontWeight="700">
        θ = 30°
      </text>
      <text x="480" y="80" fill="#f4ead4" fontSize="16" fontWeight="700">
        T = (W / 2) / sin(θ)
      </text>
      <text x="480" y="114" fill="#f3c45a" fontSize="16" fontWeight="700">
        θ = 30° → T = W each leg
      </text>
      <text x="480" y="148" fill="#f4ead4" fontSize="14">
        Calculator in DEG, not RAD
      </text>
      <text x="400" y="240" textAnchor="middle" fill="#f3c45a" fontSize="13" fontWeight="700">
        A 4-ton hoist nameplate is not net capacity
      </text>
    </svg>
  );
}


export function MocWindows() {
  const cols = [
    { title: "1. BEFORE", items: ["Screen · risk", "Authorize · communicate"] },
    { title: "2. DURING", items: ["Isolate · temp barriers", "Named owner"] },
    { title: "3. AFTER", items: ["Verify · update P&IDs", "Expire temps"] },
  ];
  return (
    <SvgShell w={400} h={430} label="Management of change before during after">
      {cols.map((c, i) => {
        const y = 16 + i * 118;
        const fill = i === 0 ? AMBER : PANEL;
        const fg = i === 0 ? ON_AMBER : CREAM;
        return (
          <g key={c.title}>
            <rect x="16" y={y} width="368" height="102" rx="10" fill={fill} stroke={CREAM} strokeWidth="2" />
            <text x="200" y={y + 32} textAnchor="middle" fill={fg} fontSize="18" fontWeight="700">
              {c.title}
            </text>
            <Tl x={200} y={y + 58} fill={i === 0 ? ON_AMBER : AMBER2} size={14} lines={c.items} gap={18} />
          </g>
        );
      })}
      <Tl
        x={200}
        y={378}
        fill={AMBER}
        size={13}
        lines={["Temporary that stays loops back to BEFORE"]}
      />
      <Tl x={200} y={402} fill={CREAM} size={12} lines={["Identical form/fit/function = replacement in kind"]} />
    </SvgShell>
  );
}


export function FtaTree() {
  return (
    <SvgShell w={400} h={360} label="Fault tree AND OR cut set">
      <rect x="120" y="12" width="160" height="40" rx="6" fill={AMBER} />
      <text x="200" y="38" textAnchor="middle" fill={ON_AMBER} fontSize="15" fontWeight="700">
        TOP EVENT
      </text>
      <polygon points="200,52 190,68 210,68" fill={AMBER2} />
      <rect x="150" y="68" width="100" height="32" rx="16" fill={OK} />
      <text x="200" y="89" textAnchor="middle" fill={INK} fontSize="14" fontWeight="700">
        AND
      </text>
      <line x1="96" y1="100" x2="304" y2="100" stroke={CREAM} strokeWidth="2" />
      <line x1="96" y1="100" x2="96" y2="120" stroke={CREAM} strokeWidth="2" />
      <line x1="304" y1="100" x2="304" y2="120" stroke={CREAM} strokeWidth="2" />
      <rect x="16" y="120" width="160" height="44" rx="6" fill={PANEL} stroke={CREAM} strokeWidth="2" />
      <text x="96" y="148" textAnchor="middle" fill={CREAM} fontSize="14" fontWeight="700">
        Loop A fails
      </text>
      <rect x="224" y="120" width="160" height="44" rx="6" fill={PANEL} stroke={CREAM} strokeWidth="2" />
      <text x="304" y="148" textAnchor="middle" fill={CREAM} fontSize="14" fontWeight="700">
        Loop B fails
      </text>
      <rect x="56" y="176" width="80" height="28" rx="14" fill={PANEL} stroke={AMBER} strokeWidth="2" />
      <text x="96" y="195" textAnchor="middle" fill={AMBER} fontSize="13" fontWeight="700">
        OR
      </text>
      <rect x="264" y="176" width="80" height="28" rx="14" fill={PANEL} stroke={AMBER} strokeWidth="2" />
      <text x="304" y="195" textAnchor="middle" fill={AMBER} fontSize="13" fontWeight="700">
        OR
      </text>
      <Tl
        x={200}
        y={232}
        fill={AMBER2}
        size={13}
        lines={["Cut set: both independent", "barriers — RPN does not live here"]}
        gap={18}
      />
      <Tl
        x={200}
        y={278}
        fill={CREAM}
        size={12}
        lines={["Independent AND multiplies.", "A shared PLC is not independence."]}
        gap={17}
      />
    </SvgShell>
  );
}


export function FmeaRpn() {
  const cols = [
    { t: "S", s: "Severity" },
    { t: "O", s: "Occurrence" },
    { t: "D", s: "Detection" },
  ];
  return (
    <SvgShell w={400} h={340} label="FMEA RPN equals S times O times D">
      {cols.map((c, i) => {
        const x = 16 + i * 128;
        return (
          <g key={c.t}>
            <rect x={x} y="16" width="112" height="96" rx="10" fill={PANEL} stroke={AMBER} strokeWidth="2" />
            <text x={x + 56} y="58" textAnchor="middle" fill={AMBER} fontSize="32" fontWeight="700">
              {c.t}
            </text>
            <text x={x + 56} y="90" textAnchor="middle" fill={CREAM} fontSize="13" fontWeight="700">
              {c.s}
            </text>
            {i < 2 ? (
              <text x={x + 120} y="72" textAnchor="middle" fill={AMBER2} fontSize="22" fontWeight="700">
                ×
              </text>
            ) : null}
          </g>
        );
      })}
      <rect x="16" y="128" width="368" height="56" rx="10" fill={AMBER} />
      <text x="200" y="154" textAnchor="middle" fill={ON_AMBER} fontSize="22" fontWeight="700">
        = RPN
      </text>
      <text x="200" y="174" textAnchor="middle" fill={ON_AMBER} fontSize="12" fontWeight="700">
        ranking aid, not P()
      </text>
      <Tl
        x={200}
        y={210}
        fill={AMBER2}
        size={13}
        lines={["Cut S or O by design first.", "Lowering D is the cheap cheat."]}
        gap={18}
      />
      <Tl
        x={200}
        y={258}
        fill={CREAM}
        size={12}
        lines={["Two-barrier combinations → FTA / bowtie.", "8 × 7 × 9 = 504 — do not add 8+7+9."]}
        gap={17}
      />
    </SvgShell>
  );
}


export function BowtieSvg() {
  return (
    <SvgShell w={400} h={340} label="Safety case bowtie barriers">
      <polygon points="16,170 168,52 168,288" fill={PANEL} stroke={AMBER} strokeWidth="2" />
      <polygon points="384,170 232,52 232,288" fill={PANEL} stroke={AMBER} strokeWidth="2" />
      <circle cx="200" cy="170" r="40" fill={AMBER} />
      <Tl x={200} y={164} fill={ON_AMBER} size={13} lines={["TOP", "EVENT"]} gap={16} />
      <Tl x={92} y={150} fill={AMBER2} size={13} lines={["Preventive"]} />
      <Tl x={92} y={172} fill={CREAM} size={11} lines={["threats →", "barriers"]} gap={14} />
      <Tl x={308} y={150} fill={AMBER2} size={13} lines={["Mitigative"]} />
      <Tl x={308} y={172} fill={CREAM} size={11} lines={["barriers →", "consequences"]} gap={14} />
      <Tl
        x={200}
        y={312}
        fill={AMBER}
        size={12}
        lines={["Safety case = demonstration.", "RPN tables are the wrong method."]}
        gap={16}
      />
    </SvgShell>
  );
}


export function PdcaWheel() {
  const quads = [
    { label: "PLAN", sub: ["risks · legal", "objectives"], x: 140, y: 12 },
    { label: "DO", sub: ["hierarchy", "MoC · operate"], x: 276, y: 148 },
    { label: "CHECK", sub: ["monitor · audit", "review"], x: 140, y: 292 },
    { label: "ACT", sub: ["CAPA", "improve"], x: 12, y: 148 },
  ];
  return (
    <SvgShell w={400} h={400} label="ISO 45001 PDCA wheel">
      <circle cx="200" cy="180" r="52" fill={PANEL} stroke={AMBER} strokeWidth="4" />
      <circle cx="200" cy="180" r="36" fill={AMBER} />
      <Tl x={200} y={174} fill={ON_AMBER} size={11} lines={["Leadership", "+ workers"]} gap={14} />
      {quads.map((q, i) => (
        <g key={q.label}>
          <rect
            x={q.x}
            y={q.y}
            width="112"
            height="64"
            rx="8"
            fill={i === 0 ? AMBER : INK}
            stroke={CREAM}
            strokeWidth="2"
          />
          <text x={q.x + 56} y={q.y + 24} textAnchor="middle" fill={i === 0 ? ON_AMBER : AMBER2} fontSize="14" fontWeight="700">
            {q.label}
          </text>
          <Tl x={q.x + 56} y={q.y + 42} fill={i === 0 ? ON_AMBER : CREAM} size={10} lines={q.sub} gap={12} />
        </g>
      ))}
      <Tl
        x={200}
        y={372}
        fill={AMBER2}
        size={12}
        lines={["Certificate sits outside the wheel —", "it is not a PDCA step"]}
        gap={16}
      />
    </SvgShell>
  );
}


export function ParetoChart() {
  const bars = [
    { h: 140, label: "Nicks" },
    { h: 90, label: "Strains" },
    { h: 48, label: "Eye" },
    { h: 28, label: "Other*" },
  ];
  return (
    <svg viewBox="0 0 800 280" className="w-full h-auto" role="img" aria-label="Pareto bars and cumulative line">
      <rect width="800" height="280" fill="#0d1730" />
      {bars.map((b, i) => {
        const x = 70 + i * 130;
        const y = 200 - b.h;
        return (
          <g key={b.label}>
            <rect x={x} y={y} width="90" height={b.h} fill={i === 3 ? "#e4a11b" : "#1a2742"} stroke="#f4ead4" strokeWidth="2" />
            <text x={x + 45} y="224" textAnchor="middle" fill="#f4ead4" fontSize="12" fontWeight="700">
              {b.label}
            </text>
          </g>
        );
      })}
      <polyline points="115,60 245,92 375,148 505,172" fill="none" stroke="#e4a11b" strokeWidth="3" />
      {["115,60", "245,92", "375,148", "505,172"].map((p) => {
        const [x, y] = p.split(",").map(Number);
        return <circle key={p} cx={x} cy={y} r="5" fill="#f3c45a" />;
      })}
      <text x="640" y="80" fill="#e4a11b" fontSize="14" fontWeight="700">
        Cumulative %
      </text>
      <text x="400" y="252" textAnchor="middle" fill="#f3c45a" fontSize="13" fontWeight="700">
        *Other hid the amputation — height is not hierarchy
      </text>
    </svg>
  );
}


export function RiskLoopSvg() {
  const steps = ["Context", "Identify", "Analyze", "Evaluate", "Treat", "Monitor"];
  return (
    <SvgShell w={400} h={420} label="Risk process loop">
      <rect x="16" y="12" width="368" height="44" rx="8" fill={AMBER} />
      <text x="200" y="40" textAnchor="middle" fill={ON_AMBER} fontSize="16" fontWeight="700">
        Communicate / consult
      </text>
      {steps.map((label, i) => {
        const y = 68 + i * 48;
        const fill = i === 0 || i === 5 ? AMBER : INK;
        const fg = i === 0 || i === 5 ? ON_AMBER : AMBER2;
        return (
          <g key={label}>
            <rect x="16" y={y} width="368" height="40" rx="8" fill={fill} stroke={CREAM} strokeWidth="2" />
            <text x="200" y={y + 26} textAnchor="middle" fill={fg} fontSize="15" fontWeight="700">
              {i + 1}. {label}
            </text>
          </g>
        );
      })}
      <Tl
        x={200}
        y={368}
        fill={AMBER2}
        size={12}
        lines={["A finished FMEA is one Analyze tool —", "not a closed loop"]}
        gap={16}
      />
    </SvgShell>
  );
}


export function FinancialFourSvg() {
  const four = [
    { title: "Avoid", sub: ["Stop the", "activity"], control: true },
    { title: "Retain", sub: ["Deductible /", "captive"], control: false },
    { title: "Share / Transfer", sub: ["Policy /", "indemnity"], control: false },
    { title: "Reduce", sub: ["Prevention +", "reduction"], control: true },
  ];
  return (
    <SvgShell w={400} h={360} label="Four financial risk strategies">
      {four.map((b, i) => {
        const x = 16 + (i % 2) * 188;
        const y = 16 + Math.floor(i / 2) * 132;
        const fill = b.control ? AMBER : PANEL;
        const fg = b.control ? ON_AMBER : CREAM;
        return (
          <g key={b.title}>
            <rect x={x} y={y} width="180" height="120" rx="10" fill={fill} stroke={CREAM} strokeWidth="2" />
            <Tl x={x + 90} y={y + 32} fill={b.control ? ON_AMBER : AMBER2} size={15} lines={[b.title]} />
            <Tl x={x + 90} y={y + 58} fill={fg} size={13} lines={b.sub} gap={16} />
            <text x={x + 90} y={y + 102} textAnchor="middle" fill={b.control ? ON_AMBER : AMBER} fontSize="11" fontWeight="700">
              {b.control ? "CONTROL SIDE" : "FINANCING"}
            </text>
          </g>
        );
      })}
      <Tl
        x={200}
        y={292}
        fill={AMBER2}
        size={12}
        lines={["Deductible + umbrella = retain + transfer.", "Reduce / Avoid still missing."]}
        gap={16}
      />
      <text x="200" y="338" textAnchor="middle" fill={CREAM} fontSize="12" fontWeight="700">
        ROI prices a control. A policy is not a guard.
      </text>
    </SvgShell>
  );
}


export function IcsOrgSvg() {
  return (
    <SvgShell w={400} h={400} label="ICS organization">
      <rect x="90" y="12" width="220" height="44" rx="8" fill={AMBER} />
      <text x="200" y="40" textAnchor="middle" fill={ON_AMBER} fontSize="15" fontWeight="700">
        Incident Commander
      </text>
      <line x1="200" y1="56" x2="200" y2="72" stroke={AMBER} strokeWidth="2" />
      {[
        { x: 12, label: "PIO" },
        { x: 140, label: "Safety Officer" },
        { x: 268, label: "Liaison" },
      ].map((c) => (
        <g key={c.label}>
          <rect x={c.x} y="72" width="120" height="40" rx="8" fill={INK} stroke={CREAM} strokeWidth="2" />
          <text x={c.x + 60} y="98" textAnchor="middle" fill={AMBER2} fontSize="12" fontWeight="700">
            {c.label}
          </text>
        </g>
      ))}
      {[
        { x: 16, y: 132, label: "Operations" },
        { x: 208, y: 132, label: "Planning" },
        { x: 16, y: 200, label: "Logistics" },
        { x: 208, y: 200, label: "Finance/Admin" },
      ].map((g) => (
        <g key={g.label}>
          <rect x={g.x} y={g.y} width="176" height="52" rx="8" fill={PANEL} stroke={AMBER} strokeWidth="2" />
          <text x={g.x + 88} y={g.y + 32} textAnchor="middle" fill={CREAM} fontSize="14" fontWeight="700">
            {g.label}
          </text>
        </g>
      ))}
      <Tl
        x={200}
        y={276}
        fill={AMBER2}
        size={12}
        lines={["One IC · Safety reports to IC", "and can stop tactics · span ~3–7"]}
        gap={16}
      />
      <Tl
        x={200}
        y={320}
        fill={CREAM}
        size={12}
        lines={["Finance/Admin is incident money —", "not the parking-lot headcount"]}
        gap={16}
      />
    </SvgShell>
  );
}


export function FireTetrahedronSvg() {
  return (
    <SvgShell w={400} h={360} label="Fire tetrahedron">
      <polygon points="200,56 48,232 352,232" fill={PANEL} stroke={AMBER} strokeWidth="3" />
      <polygon points="200,56 200,156 48,232" fill={INK} stroke={CREAM} strokeWidth="2" />
      <circle cx="200" cy="156" r="26" fill={AMBER} />
      <text x="200" y="161" textAnchor="middle" fill={ON_AMBER} fontSize="12" fontWeight="700">
        Fire
      </text>
      <rect x="130" y="8" width="140" height="32" rx="8" fill={AMBER} />
      <text x="200" y="30" textAnchor="middle" fill={ON_AMBER} fontSize="14" fontWeight="700">
        Fuel
      </text>
      <rect x="16" y="248" width="140" height="32" rx="8" fill={AMBER} />
      <text x="86" y="270" textAnchor="middle" fill={ON_AMBER} fontSize="14" fontWeight="700">
        Oxidizer
      </text>
      <rect x="244" y="248" width="140" height="32" rx="8" fill={AMBER} />
      <text x="314" y="270" textAnchor="middle" fill={ON_AMBER} fontSize="14" fontWeight="700">
        Heat
      </text>
      <rect x="258" y="72" width="126" height="48" rx="8" fill={AMBER} />
      <Tl x={321} y={92} fill={ON_AMBER} size={13} lines={["Chain", "reaction"]} gap={15} />
      <Tl x={200} y={308} fill={AMBER2} size={13} lines={["Prevention = take a leg off", "before ignition"]} gap={16} />
      <Tl x={200} y={348} fill={CREAM} size={11} lines={["Sprinklers / alarms / cans = protection"]} />
    </SvgShell>
  );
}


export function ErpVsBcpSvg() {
  return (
    <svg viewBox="0 0 800 240" className="w-full h-auto" role="img" aria-label="ERP versus BCP">
      <rect width="800" height="240" fill="#0d1730" />
      <rect x="24" y="28" width="360" height="148" rx="10" fill="#e4a11b" />
      <text x="204" y="60" textAnchor="middle" fill="#1a1204" fontSize="18" fontWeight="700">
        ERP / ICS
      </text>
      <text x="204" y="90" textAnchor="middle" fill="#1a1204" fontSize="13" fontWeight="700">
        Life safety · isolate · suppress
      </text>
      <text x="204" y="114" textAnchor="middle" fill="#1a1204" fontSize="12">
        Headcount · analog comms
      </text>
      <text x="204" y="138" textAnchor="middle" fill="#1a1204" fontSize="12">
        Cyber as loss-of-control now
      </text>
      <text x="204" y="162" textAnchor="middle" fill="#1a1204" fontSize="12">
        Utilities degraded mode
      </text>
      <rect x="416" y="28" width="360" height="148" rx="10" fill="#1a2742" stroke="#f4ead4" strokeWidth="2" />
      <text x="596" y="60" textAnchor="middle" fill="#f3c45a" fontSize="18" fontWeight="700">
        BCP
      </text>
      <text x="596" y="90" textAnchor="middle" fill="#f4ead4" fontSize="13" fontWeight="700">
        BIA · RTO · RPO
      </text>
      <text x="596" y="114" textAnchor="middle" fill="#f4ead4" fontSize="12">
        Restore functions / IT
      </text>
      <text x="596" y="138" textAnchor="middle" fill="#f4ead4" fontSize="12">
        Cyber rebuild / backups
      </text>
      <text x="596" y="162" textAnchor="middle" fill="#f4ead4" fontSize="12">
        Dual feed / generator restore
      </text>
      <text x="400" y="210" textAnchor="middle" fill="#f3c45a" fontSize="13" fontWeight="700">
        Fire-pump power before invoicing · insurance is neither box
      </text>
    </svg>
  );
}



export function NoiseExchangeSvg() {
  const osha = ["90 dBA → 8 h", "95 dBA → 4 h", "100 dBA → 2 h", "105 dBA → 1 h"];
  const niosh = ["85 dBA → 8 h", "88 dBA → 4 h", "91 dBA → 2 h", "100 dBA → 15 min"];
  return (
    <SvgShell w={400} h={430} label="OSHA 5 dB versus NIOSH 3 dB noise exchange">
      <rect x="16" y="16" width="368" height="176" rx="10" fill={AMBER} />
      <text x="200" y="48" textAnchor="middle" fill={ON_AMBER} fontSize="16" fontWeight="700">
        OSHA · 5 dB · PEL 90
      </text>
      {osha.map((row, i) => (
        <text key={row} x="200" y={80 + i * 26} textAnchor="middle" fill={ON_AMBER} fontSize="15" fontWeight="700">
          {row}
        </text>
      ))}
      <rect x="16" y="204" width="368" height="176" rx="10" fill={PANEL} stroke={CREAM} strokeWidth="2" />
      <text x="200" y="236" textAnchor="middle" fill={AMBER2} fontSize="16" fontWeight="700">
        NIOSH · 3 dB · REL 85
      </text>
      {niosh.map((row, i) => (
        <text key={row} x="200" y={268 + i * 26} textAnchor="middle" fill={CREAM} fontSize="15" fontWeight="700">
          {row}
        </text>
      ))}
      <Tl
        x={200}
        y={400}
        fill={AMBER}
        size={12}
        lines={["Exchange rate is a unit system — do not mix tables.", "85 dBA is OSHA action level, not PEL."]}
        gap={16}
      />
    </SvgShell>
  );
}


export function NioshLiftSvg() {
  const mult = ["HM reach", "VM height", "DM travel", "AM twist", "FM reps", "CM grip"];
  return (
    <SvgShell w={400} h={390} label="NIOSH lifting equation RWL from 51 pound load constant">
      <rect x="16" y="16" width="368" height="64" rx="10" fill={AMBER} />
      <text x="200" y="44" textAnchor="middle" fill={ON_AMBER} fontSize="20" fontWeight="700">
        LC 51 lb
      </text>
      <text x="200" y="66" textAnchor="middle" fill={ON_AMBER} fontSize="12" fontWeight="700">
        not automatically RWL
      </text>
      {mult.map((m, i) => {
        const x = 16 + (i % 3) * 124;
        const y = 96 + Math.floor(i / 3) * 64;
        return (
          <g key={m}>
            <rect x={x} y={y} width="116" height="56" rx="8" fill={PANEL} stroke={AMBER} strokeWidth="2" />
            <text x={x + 58} y={y + 26} textAnchor="middle" fill={CREAM} fontSize="13" fontWeight="700">
              {m}
            </text>
            <text x={x + 58} y={y + 44} textAnchor="middle" fill={AMBER2} fontSize="12" fontWeight="700">
              ≤ 1
            </text>
          </g>
        );
      })}
      <rect x="16" y="232" width="368" height="52" rx="10" fill={AMBER} />
      <Tl x={200} y={254} fill={ON_AMBER} size={15} lines={["RWL ≤ 51 lb", "LI = Load / RWL"]} gap={18} />
      <Tl
        x={200}
        y={308}
        fill={AMBER}
        size={13}
        lines={["Hoist / lift table / shorter reach", "beat a back belt"]}
        gap={17}
      />
      <text x="200" y="358" textAnchor="middle" fill={CREAM} fontSize="12" fontWeight="700">
        23 kg is the SI LC — not 23 lb
      </text>
    </SvgShell>
  );
}


export function QVaSvg() {
  return (
    <svg viewBox="0 0 800 260" className="w-full h-auto" role="img" aria-label="Q equals V times A duct flow">
      <rect width="800" height="260" fill="#0d1730" />
      <ellipse cx="180" cy="110" rx="70" ry="48" fill="none" stroke="#e4a11b" strokeWidth="6" />
      <ellipse cx="180" cy="110" rx="40" ry="26" fill="none" stroke="#f4ead4" strokeWidth="3" />
      <text x="180" y="116" textAnchor="middle" fill="#f3c45a" fontSize="14" fontWeight="700">
        A = πr²
      </text>
      <text x="180" y="180" textAnchor="middle" fill="#f4ead4" fontSize="13" fontWeight="700">
        r = D/2 in feet
      </text>
      <rect x="320" y="48" width="160" height="80" rx="10" fill="#1a2742" stroke="#f4ead4" strokeWidth="2" />
      <text x="400" y="80" textAnchor="middle" fill="#e4a11b" fontSize="22" fontWeight="700">
        Q = V × A
      </text>
      <text x="400" y="108" textAnchor="middle" fill="#f4ead4" fontSize="12" fontWeight="700">
        cfm = fpm × ft²
      </text>
      <rect x="520" y="48" width="250" height="120" rx="10" fill="#e4a11b" />
      <text x="645" y="84" textAnchor="middle" fill="#1a1204" fontSize="14" fontWeight="700">
        12 in @ 2000 fpm
      </text>
      <text x="645" y="114" textAnchor="middle" fill="#1a1204" fontSize="16" fontWeight="700">
        Q ≈ 1,571 cfm
      </text>
      <text x="645" y="144" textAnchor="middle" fill="#1a1204" fontSize="12" fontWeight="700">
        D as r → 6,283 (×4 miss)
      </text>
      <text x="400" y="214" textAnchor="middle" fill="#e4a11b" fontSize="14" fontWeight="700">
        Inches are not feet · in² needs /144
      </text>
      <text x="400" y="240" textAnchor="middle" fill="#f4ead4" fontSize="12">
        A dike is gallons — it is not Q
      </text>
    </svg>
  );
}

export function PelTlvSvg() {
  return (
    <svg viewBox="0 0 800 260" className="w-full h-auto" role="img" aria-label="PEL legal versus TLV advisory and ppm to mg per cubic meter">
      <rect width="800" height="260" fill="#0d1730" />
      <rect x="24" y="28" width="240" height="120" rx="10" fill="#e4a11b" />
      <text x="144" y="72" textAnchor="middle" fill="#1a1204" fontSize="22" fontWeight="700">
        PEL
      </text>
      <text x="144" y="104" textAnchor="middle" fill="#1a1204" fontSize="14" fontWeight="700">
        OSHA legal limit
      </text>
      <rect x="280" y="28" width="240" height="120" rx="10" fill="#1a2742" stroke="#f4ead4" strokeWidth="2" />
      <text x="400" y="72" textAnchor="middle" fill="#f3c45a" fontSize="22" fontWeight="700">
        TLV / REL
      </text>
      <text x="400" y="104" textAnchor="middle" fill="#f4ead4" fontSize="14" fontWeight="700">
        advisory guideline
      </text>
      <rect x="536" y="28" width="240" height="120" rx="10" fill="#08101c" stroke="#e4a11b" strokeWidth="2" />
      <text x="656" y="68" textAnchor="middle" fill="#e4a11b" fontSize="13" fontWeight="700">
        mg/m³ = (ppm × MW) / 24.45
      </text>
      <text x="656" y="96" textAnchor="middle" fill="#f4ead4" fontSize="12" fontWeight="700">
        50 ppm CO (MW 28) ≈ 57.3
      </text>
      <text x="656" y="122" textAnchor="middle" fill="#f4ead4" fontSize="12" fontWeight="700">
        not 50 mg/m³
      </text>
      <text x="400" y="180" textAnchor="middle" fill="#e4a11b" fontSize="14" fontWeight="700">
        Smaller is not automatically the law (PELTLV)
      </text>
      <text x="400" y="208" textAnchor="middle" fill="#f4ead4" fontSize="13">
        LD50 is not an OEL · 24.45 is 25 °C, not 0 °C
      </text>
      <text x="400" y="236" textAnchor="middle" fill="#f4ead4" fontSize="12">
        Particulates/fibers do not use 24.45
      </text>
    </svg>
  );
}

export function AdultLearningSvg() {
  const boxes = [
    { t: "WHY", s: "reason to care" },
    { t: "EXPERIENCE", s: "use it, correct it" },
    { t: "PROBLEM", s: "the real task" },
    { t: "PRACTICE", s: "feedback on the job" },
  ];
  return (
    <svg viewBox="0 0 800 260" className="w-full h-auto" role="img" aria-label="Adult learning why experience problem practice">
      <rect width="800" height="260" fill="#0d1730" />
      {boxes.map((b, i) => {
        const x = 18 + i * 196;
        return (
          <g key={b.t}>
            <rect x={x} y="36" width="180" height="100" rx="10" fill={i === 3 ? "#e4a11b" : "#1a2742"} stroke="#f4ead4" strokeWidth="2" />
            <text x={x + 90} y="78" textAnchor="middle" fill={i === 3 ? "#1a1204" : "#f3c45a"} fontSize="16" fontWeight="700">
              {i + 1}. {b.t}
            </text>
            <text x={x + 90} y="106" textAnchor="middle" fill={i === 3 ? "#1a1204" : "#f4ead4"} fontSize="12" fontWeight="700">
              {b.s}
            </text>
            {i < 3 ? <polygon points={`${x + 184},86 ${x + 196},86 ${x + 190},94`} fill="#f3c45a" /> : null}
          </g>
        );
      })}
      <rect x="80" y="160" width="640" height="40" rx="8" fill="#08101c" stroke="#d85a4a" strokeWidth="2" />
      <text x="400" y="186" textAnchor="middle" fill="#d85a4a" fontSize="14" fontWeight="700">
        80-slide monologue is not andragogy · a quiz is not a skill
      </text>
      <text x="400" y="230" textAnchor="middle" fill="#f3c45a" fontSize="13" fontWeight="700">
        AI can draft slides — it cannot replace OJT or a competent person
      </text>
    </svg>
  );
}



export function DustPentagonSvg() {
  const labels = [
    { t: "FUEL", x: 145, y: 10, w: 110 },
    { t: "OXIDIZER", x: 262, y: 118, w: 126 },
    { t: "IGNITION", x: 230, y: 292, w: 140 },
    { t: "CONFINEMENT", x: 16, y: 292, w: 150 },
    { t: "DISPERSION", x: 12, y: 118, w: 126 },
  ];
  return (
    <SvgShell w={400} h={380} label="Combustible dust pentagon">
      <polygon points="200,70 300,143 262,260 138,260 100,143" fill={PANEL} stroke={AMBER} strokeWidth="4" />
      <Tl x={200} y={168} fill={AMBER2} size={13} lines={["FLASH FIRE = 4 SIDES"]} />
      <Tl x={200} y={190} fill={CREAM} size={12} lines={["EXPLOSION = 5 (add box)"]} />
      {labels.map((l) => (
        <g key={l.t}>
          <rect x={l.x} y={l.y} width={l.w} height="28" rx="6" fill={INK} stroke={AMBER} strokeWidth="2" />
          <text x={l.x + l.w / 2} y={l.y + 19} textAnchor="middle" fill={AMBER} fontSize="11" fontWeight="700">
            {l.t}
          </text>
        </g>
      ))}
      <Tl
        x={200}
        y={348}
        fill={AMBER2}
        size={12}
        lines={["A broom is not a vent.", "Kst / Pmax size protection."]}
        gap={16}
      />
    </SvgShell>
  );
}


export function VentilationSvg() {
  const boxes = [
    { t: "ENCLOSE", s: "booth / lid", fill: "#e4a11b", fg: "#1a1204" },
    { t: "CAPTURE", s: "Q = V × A", fill: "#1a2742", fg: "#f3c45a" },
    { t: "DILUTION", s: "wall fan LAST", fill: "#08101c", fg: "#f4ead4" },
  ];
  return (
    <svg viewBox="0 0 800 260" className="w-full h-auto" role="img" aria-label="Ventilation enclose capture dilution and Q equals VA">
      <rect width="800" height="260" fill="#0d1730" />
      {boxes.map((b, i) => {
        const x = 24 + i * 252;
        return (
          <g key={b.t}>
            <rect x={x} y="24" width="232" height="88" rx="10" fill={b.fill} stroke="#f4ead4" strokeWidth="2" />
            <text x={x + 116} y="60" textAnchor="middle" fill={b.fg} fontSize="16" fontWeight="700">
              {i + 1}. {b.t}
            </text>
            <text x={x + 116} y="86" textAnchor="middle" fill={b.fg} fontSize="13" fontWeight="700">
              {b.s}
            </text>
          </g>
        );
      })}
      <rect x="80" y="132" width="640" height="56" rx="8" fill="#1a2742" stroke="#e4a11b" strokeWidth="2" />
      <text x="400" y="166" textAnchor="middle" fill="#f3c45a" fontSize="16" fontWeight="700">
        12 in @ 2000 fpm → Q ≈ 1,571 cfm · r = D/2 in feet
      </text>
      <text x="400" y="220" textAnchor="middle" fill="#e4a11b" fontSize="14" fontWeight="700">
        Inches are not feet · D as r → 6,283 (×4 miss)
      </text>
      <text x="400" y="244" textAnchor="middle" fill="#f4ead4" fontSize="12">
        Substitution still beats a beautiful hood
      </text>
    </svg>
  );
}


export function ClassInfographic({ classId }: { classId: number }) {
  let node: ReactNode = null;
  switch (classId) {
    case 1:
      node = <PtDTimeline />;
      break;
    case 2:
      node = <HierarchySvg />;
      break;
    case 3:
      node = <ProcessSafetyLayers />;
      break;
    case 4:
      node = <ElectricalBoundaries />;
      break;
    case 5:
      node = <LotoEnergy />;
      break;
    case 6:
      node = <FallClearance />;
      break;
    case 7:
      node = <ExcavationSlope />;
      break;
    case 9:
      node = <ConfinedSpaceSvg />;
      break;
    case 11:
      node = <EgressSvg />;
      break;
    case 14:
      node = <SlingAngleSvg />;
      break;
    case 22:
      node = <MocWindows />;
      break;
    case 23:
      node = <FtaTree />;
      break;
    case 24:
      node = <FmeaRpn />;
      break;
    case 25:
      node = <BowtieSvg />;
      break;
    case 27:
      node = <PdcaWheel />;
      break;
    case 38:
      node = <ParetoChart />;
      break;
    case 39:
    case 46:
      node = <RiskLoopSvg />;
      break;
    case 44:
    case 45:
      node = <FinancialFourSvg />;
      break;
    case 47:
    case 49:
      node = <ErpVsBcpSvg />;
      break;
    case 48:
      node = <IcsOrgSvg />;
      break;
    case 50:
    case 51:
      node = <FireTetrahedronSvg />;
      break;
    case 64:
      node = <NoiseExchangeSvg />;
      break;
    case 68:
    case 63:
      node = <PelTlvSvg />;
      break;
    case 70:
      node = <NioshLiftSvg />;
      break;
    case 71:
    case 72:
      node = <QVaSvg />;
      break;
    case 74:
    case 75:
      node = <AdultLearningSvg />;
      break;
    case 79:
      node = <HierarchySvg />;
      break;
    case 80:
      node = <DustPentagonSvg />;
      break;
    case 81:
      node = <VentilationSvg />;
      break;
    case 83:
      node = <NoiseExchangeSvg />;
      break;
    case 84:
      node = <PelTlvSvg />;
      break;
    case 86:
      node = <BowtieSvg />;
      break;
    case 87:
      node = <ProcessSafetyLayers />;
      break;
    case 88:
      node = <ErpVsBcpSvg />;
      break;
    case 89:
      node = <AdultLearningSvg />;
      break;
    case 90:
      node = <QVaSvg />;
      break;
    default:
      node = null;
  }
  return <InfographicSlot>{node}</InfographicSlot>;
}
