"use client";

import { QuestionPlayer, type Item, type PlayResult } from "./QuestionPlayer";

export function GymPersist({
  items,
  gym,
  slug,
  timerMinutes,
  examMode,
  showCalculator,
  showCards,
  showDomainBreakdown,
  seedNote,
  sprintMode,
  teachMode,
  selfAssessment = false,
}: {
  items: Item[];
  gym: string;
  slug: string;
  timerMinutes?: number;
  examMode?: boolean;
  showCalculator?: boolean;
  showCards?: boolean;
  showDomainBreakdown?: boolean;
  seedNote?: string;
  sprintMode?: boolean;
  teachMode?: boolean;
  selfAssessment?: boolean;
}) {
  async function persist(result: PlayResult) {
    await fetch("/api/gym", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ gym, slug, length: result.total, score: result.pct, answers: result.answers, domainScores: result.domainScores }) });
    if (selfAssessment) {
      await fetch("/api/progression", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ event: "assessment_complete" }) });
    }
  }

  return (
    <div className="space-y-6">
      <QuestionPlayer
        items={items}
        persistUrl="/api/attempts"
        examMode={examMode}
        showCalculator={showCalculator}
        showCards={showCards}
        timerMinutes={timerMinutes}
        showDomainBreakdown={showDomainBreakdown}
        seedNote={seedNote}
        sprintMode={sprintMode}
        teachMode={teachMode}
        readinessMode={selfAssessment}
        onComplete={persist}
      />
    </div>
  );
}
