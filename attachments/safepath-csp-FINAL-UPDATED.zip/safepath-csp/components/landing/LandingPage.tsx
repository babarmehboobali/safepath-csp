import Image from "next/image";
import Link from "next/link";
import { CATALOG } from "@/lib/catalog";
import { APP_NAME, DISCLAIMER, HONESTY_CLOSER, HONESTY_PRIMARY, HONESTY_SHORT, DOMAIN_NAMES, DOMAIN_WEIGHTS, TRACKS } from "@/lib/constants";
import { LandingDemoQuiz } from "./LandingDemoQuiz";
import { DomainInsideChips } from "./DomainInsideChips";

const WHAT_YOU_GET = [
  { title: "130 classes", body: "Compact 47 → Recommended 78 → Maximum 130. Blueprint-aligned modules with must-score, worked cases, and drills." },
  { title: "Practice gyms", body: "Session blocks, domain gyms, math and tox labs, missed/weakest drills, and Expert challenge decks." },
  { title: "5.5 h mock", body: "Weighted 50 / 100 / 200 CBT sittings. Flag, review, timer — one item on screen." },
  { title: "Calculator + cards", body: "TI-30XS-style practice calculator, equation desk, and 1 / 3 / 7 / 21 memory cards." },
];

const HOW_CLASS = [
  { step: "1", title: "Must-score", body: "Check the rules that gate Continue before you see the case." },
  { step: "2", title: "Worked case", body: "One decision walkthrough with traps and contrast pairs." },
  { step: "3", title: "Stem if-then", body: "Pattern lines that map stem language to the right control." },
  { step: "4", title: "Drill", body: "One question per screen with explanation and error codes." },
];

const ANCHORS = [
  ["#what-you-get", "What you get"],
  ["#how-class", "How a class works"],
  ["#exam-mode", "Exam mode"],
  ["#catalog", "Catalog"],
  ["/csp-prep", "CSP Study Library"],
  ["#try-it", "Try it"],
  ["#demo-vs-real", "Demo vs real"],
  ["#honest-study", "Honest study"],
] as const;

export function LandingPage() {
  const catalogLite = CATALOG.map((c) => ({
    id: c.id,
    domain: c.domain,
    title: c.title,
    taskCode: c.taskCode,
    isMaximum: c.isMaximum,
    isDeep: c.isDeep,
  }));

  return (
    <div className="landing">
      <nav className="border-b border-line/60 bg-navy/40" aria-label="Page sections">
        <div className="mx-auto flex max-w-6xl gap-2 overflow-x-auto px-6 py-3 text-sm">
          {ANCHORS.map(([href, label]) => (
            <a
              key={href}
              href={href}
              className="shrink-0 rounded-full border border-transparent px-3 py-1.5 text-cream/75 hover:border-line hover:bg-white/5 hover:text-cream"
            >
              {label}
            </a>
          ))}
        </div>
      </nav>

      <section className="relative overflow-hidden border-b border-line">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(900px_420px_at_15%_-10%,rgba(27,94,59,0.35),transparent_55%),radial-gradient(700px_360px_at_90%_10%,rgba(124,219,58,0.12),transparent_50%)]" />
        <div className="relative mx-auto grid max-w-6xl gap-10 px-6 py-14 sm:py-20 lg:grid-cols-[1.15fr_0.85fr] lg:items-center">
          <div>
            <p className="kicker">{APP_NAME}</p>
            <h1 className="mt-3 font-serif text-[clamp(2.1rem,4vw,3.25rem)] font-semibold leading-[1.12] tracking-tight text-cream">
              Independent CSP-11 study system
            </h1>
            <p className="mt-4 max-w-xl text-lg leading-relaxed text-muted">
              Blueprint-aligned, original items — classes, gyms, cards, calculator, and a full 5.5-hour mock sitting.
              Includes ergo RULA/REBA estimators plus tox and math solvers inside the app.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/login?demo=1" className="btn-primary">
                Start free demo
              </Link>
              <Link href="/register" className="btn-ghost">
                Create account
              </Link>
              <Link href="/csp-prep" className="btn-ghost">
                Explore CSP Study Library →
              </Link>
              <Link href="/eligibility" className="btn-ghost">
                🎯 Check CSP Eligibility →
              </Link>
            </div>
            <p className="mt-5 max-w-xl text-sm leading-relaxed text-muted">
              {HONESTY_SHORT}
            </p>
          </div>
          <div className="card relative overflow-hidden p-6 sm:p-8">
            <Image
              src="/logo.jpg"
              alt="Safepath CSP green logo"
              width={320}
              height={110}
              className="h-16 w-auto rounded-xl border border-line bg-panel p-2 sm:h-20"
              priority
            />
            <p className="mt-6 text-sm font-semibold text-safepath-lime">Maximum track</p>
            <p className="mt-1 font-serif text-3xl font-semibold tracking-tight">{TRACKS[2].classes} classes</p>
            <ul className="mt-5 space-y-2 text-sm text-muted">
              <li>Seven domains · weights 25 / 25 / 15 / 9 / 6 / 10 / 10</li>
              <li>Must-score → case → stem-if-then → drill</li>
              <li>Demo login: activity is not stored</li>
            </ul>
            <div className="mt-6 flex flex-wrap gap-2">
              {TRACKS.map((t) => (
                <span key={t.id} className="chip">
                  {t.label}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="what-you-get" className="scroll-mt-28 border-b border-line">
        <div className="mx-auto max-w-6xl px-6 py-14 sm:py-16">
          <p className="kicker">What you get</p>
          <h2 className="page-title mt-2">A full study stack, not a question dump</h2>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {WHAT_YOU_GET.map((card) => (
              <article key={card.title} className="card p-5">
                <h3 className="text-lg font-semibold tracking-tight">{card.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted">{card.body}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="how-class" className="scroll-mt-28 border-b border-line bg-panel/30">
        <div className="mx-auto max-w-6xl px-6 py-14 sm:py-16">
          <p className="kicker">How a class works</p>
          <h2 className="page-title mt-2">Same rhythm every module</h2>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {HOW_CLASS.map((s) => (
              <article key={s.step} className="card p-5">
                <p className="font-mono text-sm text-safepath-lime">Step {s.step}</p>
                <h3 className="mt-2 text-lg font-semibold">{s.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">{s.body}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="exam-mode" className="scroll-mt-28 border-b border-line">
        <div className="mx-auto grid max-w-6xl gap-8 px-6 py-14 sm:py-16 lg:grid-cols-2 lg:items-center">
          <div>
            <p className="kicker">Exam mode</p>
            <h2 className="page-title mt-2">CBT habits before test day</h2>
            <p className="page-lead">
              One item on screen. Flag and review. On-screen timer. Confirm before submit. 200 items / 330 minutes for the
              final mock — cards off, calculator available.
            </p>
            <ul className="mt-6 space-y-2 text-sm text-muted">
              <li>· Weighted sampling across Domains 1–7</li>
              <li>· Break overlay does not pause the clock</li>
              <li>· Demo sittings discard scores; real accounts keep them</li>
            </ul>
            <Link href="/login?demo=1" className="btn-primary mt-8">
              Start free demo
            </Link>
          </div>
          <div className="card space-y-4 p-6">
            <div className="flex items-center justify-between text-sm text-muted">
              <span>Item 47 of 200</span>
              <span className="font-mono text-safepath-lime">4:12:08</span>
            </div>
            <p className="text-[0.98rem] leading-relaxed">
              Stem shows one decision. Options A–D. Flag for review. Previous / Next stay available.
            </p>
            <div className="space-y-2">
              {["A", "B", "C", "D"].map((letter) => (
                <div key={letter} className="option-row pointer-events-none opacity-90">
                  <span className="font-mono text-sm text-muted">{letter}</span>
                  <span className="text-sm text-muted">Option preview — live sitting after login</span>
                </div>
              ))}
            </div>
            <div className="flex flex-wrap gap-2 pt-2">
              <span className="btn-ghost pointer-events-none text-sm opacity-80">Flag</span>
              <span className="btn-ghost pointer-events-none text-sm opacity-80">Review</span>
              <span className="btn-primary pointer-events-none text-sm opacity-90">Next</span>
            </div>
          </div>
        </div>
      </section>

      <section id="catalog" className="scroll-mt-28 border-b border-line bg-panel/30">
        <div className="mx-auto max-w-6xl px-6 py-14 sm:py-16">
          <p className="kicker">Catalog proof</p>
          <h2 className="page-title mt-2">Domain 1–7 · 130 classes</h2>
          <p className="page-lead">
            Filter by domain weight. Titles come from the live catalog used by Learn and seed.
          </p>
          <div className="mt-4 flex flex-wrap gap-2 text-sm text-muted">
            {[1, 2, 3, 4, 5, 6, 7].map((d) => (
              <span key={d} className="chip">
                D{d} {DOMAIN_NAMES[d]} · {DOMAIN_WEIGHTS[d]}%
              </span>
            ))}
          </div>
          <div className="mt-8">
            <DomainInsideChips catalog={catalogLite} />
          </div>
        </div>
      </section>

      <section id="try-it" className="scroll-mt-28 border-b border-line">
        <div className="mx-auto max-w-6xl px-6 py-14 sm:py-16">
          <p className="kicker">Interactive preview</p>
          <h2 className="page-title mt-2">Feel the study loop before you register</h2>
          <p className="page-lead mb-8">No account required. Original sample content only.</p>
          <LandingDemoQuiz />
        </div>
      </section>

      <section id="demo-vs-real" className="scroll-mt-28 border-b border-line bg-panel/30">
        <div className="mx-auto max-w-6xl px-6 py-14 sm:py-16">
          <p className="kicker">Demo vs real</p>
          <h2 className="page-title mt-2">Try freely, then keep the work</h2>
          <div className="mt-8 grid gap-4 md:grid-cols-2">
            <article className="card p-6">
              <h3 className="text-lg font-semibold">Free demo</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted">
                demo@cspcoach.app / Demo1234! — full product chrome. Plan, attempts, scores, flags, streak, and card
                reviews are <strong className="text-cream">not stored</strong>.
              </p>
              <Link href="/login?demo=1" className="btn-primary mt-6">
                Start free demo
              </Link>
            </article>
            <article className="card p-6">
              <h3 className="text-lg font-semibold">Real account</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted">
                Register to keep onboarding, plan unlocks, gym runs, mock scores, and the 1 / 3 / 7 / 21 card schedule.
              </p>
              <Link href="/register" className="btn-ghost mt-6">
                Create account
              </Link>
            </article>
          </div>
        </div>
      </section>

      <section id="honest-study" className="scroll-mt-28 border-b border-line">
        <div className="mx-auto max-w-6xl px-6 py-14 sm:py-16">
          <p className="kicker">Honest study</p>
          <h2 className="page-title mt-2">We built the path. You walk it.</h2>
          <div className="mt-6 max-w-3xl space-y-4 text-sm leading-relaxed text-muted whitespace-pre-line">
            {HONESTY_PRIMARY}
          </div>
          <p className="mt-6 max-w-3xl text-sm font-medium leading-relaxed text-cream">{HONESTY_CLOSER}</p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-12">
        <p className="text-sm leading-relaxed text-muted whitespace-pre-line">{DISCLAIMER}</p>
        <p className="mt-4 text-sm leading-relaxed text-muted">
          Practice items are aligned to the publicly posted CSP-11 blueprint. Demo activity is not stored.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Link href="/login?demo=1" className="btn-primary">
            Start free demo
          </Link>
          <Link href="/disclaimer" className="btn-ghost">
            Full disclaimer
          </Link>
        </div>
      </section>
    </div>
  );
}
