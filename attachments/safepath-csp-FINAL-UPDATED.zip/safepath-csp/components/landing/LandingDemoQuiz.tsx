"use client";

import { useState } from "react";

const MUST_SCORE = [
  "If two answers work, take the higher hierarchy / system / design option.",
  "PPE and admin controls are last-line — not first when engineering is open.",
  "Legal PEL is not the same as advisory TLV / REL.",
  "Read the last sentence of the stem before you commit.",
];

const ITEMS = [
  {
    id: "sample-1",
    stem: "A fixed guard can eliminate reach into a point of operation, but leadership wants high-viz gloves and a toolbox talk this week. Engineering and purchase of the guard are funded. Best next move?",
    options: [
      "Issue gloves and schedule the talk; revisit the guard next quarter.",
      "Install the fixed guard first; training and PPE support residual risk only.",
      "Rely on a procedure that forbids reaching in — no hardware change.",
      "Add a warning label and call the hierarchy complete.",
    ],
    answerIndex: 1,
    explanation:
      "Hierarchy of controls: elimination/engineering before admin/PPE when those higher controls are open and funded.",
  },
  {
    id: "sample-2",
    stem: "An eight-hour TWA is reported against a TLV. The plant’s compliance officer asks whether that number is also the legal exposure limit. Correct read?",
    options: [
      "Yes — TLV and PEL are always interchangeable on the CSP exam.",
      "No — TLV is advisory (ACGIH); OSHA PEL is the enforceable limit unless a substance-specific standard applies.",
      "TLV is always stricter, so citing it satisfies every legal standard.",
      "Only NIOSH REL is enforceable in general industry.",
    ],
    answerIndex: 1,
    explanation:
      "PEL / TLV / REL trap: legal limit vs advisory guideline. Do not swap them in the stem.",
  },
] as const;

export function LandingDemoQuiz() {
  const [checked, setChecked] = useState<Record<number, boolean>>({});
  const [picked, setPicked] = useState<Record<string, number | null>>({});
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});

  const mustDone = MUST_SCORE.every((_, i) => checked[i]);

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <article className="card p-6">
        <p className="kicker">Sample must-score</p>
        <h3 className="mt-2 text-xl font-semibold tracking-tight">Tap each rule before a class drill</h3>
        <p className="mt-2 text-sm text-muted">
          Real classes gate Continue until must-score is complete. This demo is local — no login, no save.
        </p>
        <ul className="mt-5 space-y-3">
          {MUST_SCORE.map((line, i) => (
            <li key={line}>
              <button
                type="button"
                className={`option-row w-full ${checked[i] ? "is-correct" : ""}`}
                onClick={() => setChecked((c) => ({ ...c, [i]: !c[i] }))}
                aria-pressed={Boolean(checked[i])}
              >
                <span
                  className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded border ${
                    checked[i] ? "border-ok bg-ok text-cream" : "border-line"
                  }`}
                  aria-hidden
                >
                  {checked[i] ? "✓" : ""}
                </span>
                <span className="text-[0.95rem] leading-snug">{line}</span>
              </button>
            </li>
          ))}
        </ul>
        <p className={`mt-4 text-sm font-medium ${mustDone ? "text-ok" : "text-muted"}`}>
          {mustDone ? "Must-score complete — ready for the worked case." : "Check all four to unlock the habit."}
        </p>
      </article>

      <article className="card p-6">
        <p className="kicker">Sample items</p>
        <h3 className="mt-2 text-xl font-semibold tracking-tight">Try 1–2 original MCQs</h3>
        <p className="mt-2 text-sm text-muted">Hardcoded demo content. Answers stay in your browser only.</p>
        <div className="mt-5 space-y-8">
          {ITEMS.map((item) => {
            const choice = picked[item.id];
            const show = revealed[item.id];
            return (
              <div key={item.id}>
                <p className="text-[0.98rem] font-medium leading-relaxed">{item.stem}</p>
                <div className="mt-3 space-y-2">
                  {item.options.map((opt, idx) => {
                    let cls = "option-row w-full";
                    if (show) {
                      if (idx === item.answerIndex) cls += " is-correct";
                      else if (choice === idx) cls += " is-wrong";
                    } else if (choice === idx) {
                      cls += " ring-1 ring-safepath-lime/40";
                    }
                    return (
                      <button
                        key={opt}
                        type="button"
                        className={cls}
                        disabled={show}
                        onClick={() => setPicked((p) => ({ ...p, [item.id]: idx }))}
                      >
                        <span className="font-mono text-sm text-muted">{String.fromCharCode(65 + idx)}</span>
                        <span className="text-[0.95rem] leading-snug">{opt}</span>
                      </button>
                    );
                  })}
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  {!show ? (
                    <button
                      type="button"
                      className="btn-primary text-sm"
                      disabled={choice == null}
                      onClick={() => setRevealed((r) => ({ ...r, [item.id]: true }))}
                    >
                      Check answer
                    </button>
                  ) : (
                    <p className="text-sm leading-relaxed text-muted">{item.explanation}</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </article>
    </div>
  );
}
