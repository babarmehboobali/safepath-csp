"use client";

import { useMemo, useState } from "react";
import { DOMAIN_NAMES, DOMAIN_WEIGHTS } from "@/lib/constants";
import type { CatalogEntry } from "@/lib/catalog";

export function DomainInsideChips({ catalog }: { catalog: CatalogEntry[] }) {
  const [active, setActive] = useState<number>(1);

  const topics = useMemo(
    () => catalog.filter((c) => c.domain === active).slice(0, 14),
    [catalog, active],
  );

  const totalInDomain = catalog.filter((c) => c.domain === active).length;

  return (
    <div>
      <div className="flex flex-wrap gap-2">
        {[1, 2, 3, 4, 5, 6, 7].map((d) => {
          const on = d === active;
          return (
            <button
              key={d}
              type="button"
              onClick={() => setActive(d)}
              className={`chip tap transition ${
                on
                  ? "border-safepath-lime/50 bg-safepath-green/35 text-cream ring-1 ring-safepath-lime/40"
                  : "hover:border-safepath-lime/30"
              }`}
              aria-pressed={on}
            >
              D{d} · {DOMAIN_WEIGHTS[d]}% · {DOMAIN_NAMES[d]}
            </button>
          );
        })}
      </div>
      <p className="mt-4 text-sm text-muted">
        Domain {active} · {DOMAIN_NAMES[active]} · {DOMAIN_WEIGHTS[active]}% of the CSP-11 blueprint · {totalInDomain}{" "}
        classes in Maximum track
      </p>
      <ul className="mt-4 grid gap-2 sm:grid-cols-2">
        {topics.map((c) => (
          <li key={c.id} className="rounded-lg border border-line bg-panel-2/60 px-3 py-2 text-sm">
            <span className="font-mono text-xs text-safepath-lime">#{c.id}</span>{" "}
            <span className="text-cream">{c.title}</span>
            {c.isDeep ? <span className="ml-2 chip text-[0.65rem]">Deep</span> : null}
            {c.isMaximum && !c.isDeep ? <span className="ml-2 chip text-[0.65rem]">Max</span> : null}
          </li>
        ))}
      </ul>
      {totalInDomain > topics.length ? (
        <p className="mt-3 text-sm text-muted">Showing {topics.length} of {totalInDomain} — full list after you log in on Learn.</p>
      ) : null}
    </div>
  );
}
