"use client";

import { useEffect, useMemo, useState } from "react";
import { CalculatorDrawer } from "@/components/CalculatorDrawer";
import { CardReviewer } from "@/components/CardReviewer";
import { ClassInfographic } from "@/components/Infographics";
import { DepthNotes } from "@/components/DepthNotes";
import { PrintButton } from "@/components/PrintButton";
import { QuestionPlayer, type Item } from "@/components/QuestionPlayer";
import {
  CaseWalkthroughBlock,
  HierarchySortBlock,
  SpotTheTrapBlock,
  type ArithmeticExample,
  type CaseStage,
} from "@/components/InteractiveClassBlocks";
import { TeachBack } from "@/components/TeachBack";
import { LessonNotesDrawer } from "@/components/LessonNotesDrawer";

export type InstructorContrast = {
  looksLike: string;
  actually: string;
};

export type StemIfThenRow = {
  ifStem: string;
  pick: string;
};

export type InstructorLessonDeckProps = {
  classId: number;
  domain: number;
  domainCount: number;
  classIndex: number;
  taskCode: string;
  isMaximum?: boolean;
  title: string;
  hook: string;
  rule: string;
  modelCaption: string;
  workedCase: string;
  traps: string[];
  contrast: InstructorContrast[];
  mustScore: string[];
  stemIfThen: StemIfThenRow[];
  brief: string;
  standard: string;
  deep: string;
  cardFront: string;
  cardBack: string;
  teachBackKey: string;
  formulaSlug?: string | null;
  items: Item[];
  quizMode: boolean;
  unlocked: boolean;
  isDemo?: boolean;
  examTip: string;
  arithmeticExample: ArithmeticExample;
  walkthroughStages: CaseStage[];
};

type SlideId =
  | "opening"
  | "rule"
  | "model"
  | "worked"
  | "mustscore"
  | "apply"
  | "notes"
  | "recall"
  | "drill";

type Slide = {
  id: SlideId;
  shortTitle: string;
  icon: string;
  label: string;
};

const SLIDES: Slide[] = [
  { id: "opening", shortTitle: "Opening", icon: "🚀", label: "Start" },
  { id: "rule", shortTitle: "Rule", icon: "📌", label: "Core rule" },
  { id: "model", shortTitle: "Picture", icon: "🖼️", label: "Visual model" },
  { id: "worked", shortTitle: "Worked", icon: "🧮", label: "Worked case" },
  { id: "mustscore", shortTitle: "Must-score", icon: "🎯", label: "Must-score" },
  { id: "apply", shortTitle: "Stem / traps", icon: "⚠️", label: "Apply" },
  { id: "notes", shortTitle: "Reading", icon: "📖", label: "Study reader" },
  { id: "recall", shortTitle: "Card", icon: "🧠", label: "Recall" },
  { id: "drill", shortTitle: "Drill", icon: "⚡", label: "Drill" },
];

function cx(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}

function parseWorked(text: string): { steps: string[]; losing: string | null } {
  const raw = text.trim();
  if (!raw) return { steps: [], losing: null };
  let losing: string | null = null;
  let body = raw;
  const lose = raw.match(/(?:Losing answer\s*[:—-]?\s*)(.+)$/i);
  if (lose) {
    losing = lose[1].trim();
    body = raw.slice(0, lose.index).trim();
  } else {
    const loses = raw.match(/[^.]*\bloses\b[^.]*\.?/i);
    if (loses) {
      losing = loses[0].trim();
      body = raw.replace(loses[0], "").trim();
    }
  }
  const numbered = body
    .split(/(?=\(\s*[1-9]\s*\)|\bStep\s*[1-9]\b)/i)
    .map((s) => s.trim())
    .filter(Boolean);
  if (numbered.length >= 2) return { steps: numbered.slice(0, 5), losing };
  const sentences = body.split(/(?<=\.)\s+/).map((s) => s.trim()).filter(Boolean);
  return { steps: sentences.slice(0, 5), losing };
}

function formatStemRow(row: StemIfThenRow): string {
  const stem = row.ifStem.trim().replace(/^if\s+/i, "");
  return `If ${stem}, pick ${row.pick.trim()}`;
}

function domainVisual(domain: number) {
  const map: Record<number, { icon: string; label: string; tone: string }> = {
    1: { icon: "⚡", label: "Advanced science & applied technology", tone: "#7cdb3a" },
    2: { icon: "🛡️", label: "Program & management systems", tone: "#31c5f4" },
    3: { icon: "⚠️", label: "Risk management & decision traps", tone: "#f5c451" },
    4: { icon: "🚨", label: "Emergency management", tone: "#fb7185" },
    5: { icon: "🌎", label: "Environmental management", tone: "#72d572" },
    6: { icon: "🔬", label: "Occupational health & applied science", tone: "#a78bfa" },
    7: { icon: "⚖️", label: "Training & professional practice", tone: "#fb923c" },
  };
  return map[domain] ?? map[1];
}

export default function InstructorLessonDeck(props: InstructorLessonDeckProps) {
  const [index, setIndex] = useState(0);
  const [completed, setCompleted] = useState(false);
  const [completing, setCompleting] = useState(false);
  const [redrawn, setRedrawn] = useState(false);
  const total = SLIDES.length;
  const currentSlide = SLIDES[index];
  const parsed = useMemo(() => parseWorked(props.workedCase), [props.workedCase]);
  const formulaLabel = props.formulaSlug ? props.formulaSlug.replace(/-/g, " ") : null;
  const mathItem = useMemo(() => props.items.find((item) => item.stepByStepMath), [props.items]);

  useEffect(() => {
    function onKeyDown(event: KeyboardEvent) {
      if (event.key === "ArrowRight" || event.key === "PageDown") {
        event.preventDefault();
        setIndex((value) => Math.min(total - 1, value + 1));
      } else if (event.key === "ArrowLeft" || event.key === "PageUp") {
        event.preventDefault();
        setIndex((value) => Math.max(0, value - 1));
      } else if (event.key === "Home") {
        event.preventDefault();
        setIndex(0);
      } else if (event.key === "End") {
        event.preventDefault();
        setIndex(total - 1);
      }
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [total]);

  function go(delta: number) {
    setIndex((value) => Math.max(0, Math.min(total - 1, value + delta)));
  }

  async function completeLesson() {
    if (completed || completing) return;
    setCompleting(true);
    try {
      const res = await fetch("/api/progression", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ event: "lesson_complete", classId: props.classId }) });
      if (res.ok) setCompleted(true);
    } finally {
      setCompleting(false);
    }
  }

  const visual = domainVisual(props.domain);
  const chrome = `Class ${props.classIndex} of ${props.domainCount} · Domain ${props.domain} · ${props.title}`;

  return (
    <div id={`instructor-deck-${props.classId}`} className="instructor-deck-root mt-4 bg-navy pb-2">
      <div className="sticky top-[73px] z-20 mb-4 overflow-hidden rounded-2xl border border-line bg-navy/95 p-3 shadow-xl backdrop-blur">
        <div className="flex items-center gap-3">
          <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border" style={{ borderColor: `${visual.tone}55`, background: `${visual.tone}18` }}>{visual.icon}</div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-xs font-semibold uppercase tracking-wide text-muted">{visual.label}</p>
            <p className="lesson-chrome truncate">{chrome}</p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <LessonNotesDrawer classId={props.classId} title={props.title} compact isDemo={props.isDemo} />
            <CalculatorDrawer label="🧮" moveable />
            <span className="hidden rounded-full border border-line bg-panel-2 px-3 py-1 text-xs font-semibold sm:inline-flex">{props.isMaximum ? "🔴 Expert" : props.classId >= 47 ? "🟡 Advanced" : "🟢 Core"}</span>
          </div>
        </div>
        <div className="mt-4 flex gap-2 overflow-x-auto pb-1 lg:grid lg:grid-cols-9" role="tablist" aria-label="Lesson sections">
          {SLIDES.map((slide, slideIndex) => (
            <button
              key={slide.id}
              type="button"
              role="tab"
              aria-selected={slideIndex === index}
              onClick={() => setIndex(slideIndex)}
              className={cx("lesson-step-tab", "shrink-0 lg:min-w-0", slideIndex === index && "is-active", slideIndex < index && "is-complete")}
              title={slide.label}
            >
              <span aria-hidden className="text-base">{slide.icon}</span>
              <span className="truncate text-[10px] font-semibold sm:text-[11px]">{slide.shortTitle}</span>
            </button>
          ))}
        </div>
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
          <p className="text-xs font-semibold text-muted">
            {currentSlide.icon} Step {index + 1}/{total} · {currentSlide.label}
          </p>
          <div className="flex items-center gap-2">
            <span className="rounded-full border border-[var(--theme-border)] bg-[var(--theme-panel-2)] px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-[var(--theme-muted)]">Swipe tabs →</span>
            <PrintButton className="btn-ghost tap text-xs">Print</PrintButton>
          </div>
        </div>
      </div>

      <section
        className="lesson-surface min-h-[62vh] overflow-hidden rounded-2xl border border-line bg-panel shadow-xl"
        aria-label={`Step ${index + 1}: ${currentSlide.shortTitle}`}
      >
        <div className="mx-auto w-full max-w-5xl px-4 py-6 sm:px-8 sm:py-9">
          {currentSlide.id === "opening" ? (
            <div className="space-y-6">
              <p className="kicker text-gold">Opening</p>
              <h2 className="font-serif text-3xl leading-tight sm:text-4xl">{props.title}</h2>
              <p className="lesson-body max-w-3xl text-muted">{props.examTip}</p>
              <div className="rounded-2xl border border-gold/40 bg-gold/5 p-5 sm:p-7">
                <p className="kicker text-gold">Field hook</p>
                <p className="mt-3 lesson-body text-lg leading-relaxed">{props.hook || "No hook supplied for this class."}</p>
              </div>
              <p className="text-sm text-muted">
                {props.taskCode}
                {props.isMaximum ? " · Maximum" : ""}
                {props.domainCount ? ` · Class ${props.classIndex} of ${props.domainCount} in domain path` : ""}
              </p>
            </div>
          ) : null}

          {currentSlide.id === "rule" ? (
            <div className="space-y-6">
              <p className="kicker text-gold">One reusable rule</p>
              <p className="lesson-rule max-w-3xl">{props.rule || "Rule not supplied."}</p>
              <p className="text-sm text-muted">Hold this sentence. Every later slide is an application of it.</p>
            </div>
          ) : null}

          {currentSlide.id === "model" ? (
            <div className="space-y-5">
              <p className="kicker text-gold">Picture</p>
              <div className="w-full rounded-2xl border border-line bg-ink p-3 sm:p-5">
                <ClassInfographic classId={props.classId} />
              </div>
              <p className="lesson-body max-w-3xl">{props.modelCaption || "Redraw the model from the caption."}</p>
              <button
                type="button"
                className={cx("btn-ghost tap", redrawn && "border-gold text-gold")}
                aria-pressed={redrawn}
                onClick={() => setRedrawn((v) => !v)}
              >
                {redrawn ? "Redrawn" : "I’ve redrawn this"}
              </button>
            </div>
          ) : null}

          {currentSlide.id === "worked" ? (
            <div className="space-y-5">
              <p className="kicker text-gold">Worked case</p>
              <ol className="space-y-3">
                {(parsed.steps.length ? parsed.steps : [props.workedCase || "No worked case supplied."]).map((step, i) => (
                  <li key={`${i}-${step.slice(0, 24)}`} className="flex gap-4 rounded-xl border border-line bg-ink p-4">
                    <span className="font-mono text-gold">{i + 1}</span>
                    <p className="lesson-body leading-relaxed">{step}</p>
                  </li>
                ))}
              </ol>
              {parsed.losing ? (
                <aside className="rounded-xl border border-bad/45 bg-bad/5 p-4">
                  <p className="kicker text-bad">Losing answer</p>
                  <p className="mt-2 lesson-body">{parsed.losing}</p>
                </aside>
              ) : null}
              {mathItem?.stepByStepMath || formulaLabel ? (
                <div className="rounded-2xl border border-sky-900/70 bg-slate-950 p-4 shadow-inner sm:p-5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <p className="font-mono text-[11px] font-bold uppercase tracking-[0.16em] text-sky-500">⚡ Formula Lab</p>
                      <p className="mt-1 text-xs text-slate-400">{formulaLabel ? `Formula · ${formulaLabel}` : "Calculation walkthrough"}</p>
                    </div>
                    <span className="rounded-full border border-sky-800 bg-slate-900 px-2 py-1 font-mono text-[10px] text-sky-400">TI-30XS</span>
                  </div>
                  {mathItem?.stepByStepMath ? (
                    <div className="mt-4 space-y-4 font-mono text-sm text-sky-400">
                      <div className="rounded-lg border border-slate-800 bg-slate-900 p-3 text-base">{mathItem.stepByStepMath.formula}</div>
                      <div className="grid gap-2 sm:grid-cols-2">
                        {Object.entries(mathItem.stepByStepMath.variables).map(([name, value]) => (
                          <div key={name} className="rounded-lg border border-slate-800 bg-slate-900 p-2">{name} = {value}</div>
                        ))}
                      </div>
                      <ol className="space-y-2">
                        {mathItem.stepByStepMath.derivationSteps.map((step, i) => (
                          <li key={`${i}-${step.slice(0, 24)}`} className="rounded-lg border border-slate-800 bg-slate-900 p-3">{`Step ${i + 1} ➔ ${step}`}</li>
                        ))}
                      </ol>
                      {mathItem.stepByStepMath.ti30KeystrokeSequence ? (
                        <div className="rounded-xl border border-sky-800 bg-black p-3 text-sky-300">[TI-30XS] ➔ {mathItem.stepByStepMath.ti30KeystrokeSequence}</div>
                      ) : null}
                    </div>
                  ) : null}
                </div>
              ) : null}
            </div>
          ) : null}

          {currentSlide.id === "mustscore" ? (
            <div className="space-y-5">
              <p className="kicker text-gold">Must-score</p>
              <ol className="space-y-3">
                {(props.mustScore.length ? props.mustScore : ["Must-score lines will appear when this class is expanded."]).map((line, i) => (
                  <li key={`${i}-${line.slice(0, 18)}`} className="flex gap-3 rounded-xl border border-line bg-ink p-3">
                    <span className="font-mono text-gold">{i + 1}</span>
                    <span className="lesson-body text-[0.98rem] leading-relaxed">{line}</span>
                  </li>
                ))}
              </ol>
            </div>
          ) : null}

          {currentSlide.id === "apply" ? (
            <div className="space-y-8">
              <div>
                <p className="kicker text-gold">Stem if-then</p>
                <ol className="mt-4 space-y-3">
                  {(props.stemIfThen.length
                    ? props.stemIfThen
                    : [{ ifStem: "this class is expanded", pick: "the dense if-then lines" }]
                  ).map((row, i) => (
                    <li key={`${i}-${row.ifStem.slice(0, 18)}`} className="flex gap-3 rounded-xl border border-gold/30 bg-gold/5 p-3">
                      <span className="font-mono text-gold">{i + 1}</span>
                      <span className="lesson-body text-[0.98rem] leading-relaxed">{formatStemRow(row)}</span>
                    </li>
                  ))}
                </ol>
              </div>

              <div>
                <p className="kicker text-gold">Traps</p>
                <ol className="mt-4 space-y-3">
                  {(props.traps.length ? props.traps : ["Trap placeholder"]).slice(0, 3).map((trap, i) => (
                    <li key={trap} className="flex gap-3 rounded-lg border border-bad/25 bg-bad/5 p-3">
                      <span className="font-mono text-bad">T{i + 1}</span>
                      <span className="lesson-body text-[0.98rem] leading-relaxed">{trap}</span>
                    </li>
                  ))}
                </ol>
              </div>

              <div>
                <p className="kicker text-gold">Contrast</p>
                <div className="mt-4 overflow-hidden rounded-2xl border border-line">
                  <div className="grid grid-cols-2 bg-panel-2">
                    <div className="border-r border-line p-4 text-xs font-semibold uppercase tracking-[0.12em] text-muted">Looks like</div>
                    <div className="p-4 text-xs font-semibold uppercase tracking-[0.12em] text-muted">Actually</div>
                  </div>
                  {(props.contrast.length ? props.contrast : [{ looksLike: "No pairs supplied", actually: "—" }]).slice(0, 6).map((row) => (
                    <div key={row.looksLike} className="grid grid-cols-2 border-t border-line">
                      <div className="border-r border-line p-4 text-[0.98rem] leading-relaxed">{row.looksLike}</div>
                      <div className="p-4 text-[0.98rem] leading-relaxed text-gold-2">{row.actually}</div>
                    </div>
                  ))}
                </div>
              </div>

              {props.classId % 3 === 1 ? (
                <HierarchySortBlock title={`Hierarchy sort · Class ${props.classId}`} intro="Sort the five controls. The point is control-selection logic, not speed." />
              ) : props.classId % 3 === 2 ? (
                <SpotTheTrapBlock
                  comparison={{
                    scenario: `A field team is handling “${props.title}” and is tempted to accept a convenient secondary measurement without proving the measurement basis.`,
                    trap: "Accept the convenient secondary reading without confirming correction, calibration, or acceptance criteria.",
                    compliant: "Use the primary verification method and confirm the stated acceptance criterion before relying on the measurement.",
                    trapExplanation: props.traps[0] || "The distractor skips verification and relies on convenience.",
                    compliantExplanation: props.rule || "The compliant answer follows the stated rule before accepting the result.",
                  }}
                />
              ) : (
                <CaseWalkthroughBlock title={`Case walkthrough · Class ${props.classId}`} stages={props.walkthroughStages} arithmetic={props.arithmeticExample} />
              )}
            </div>
          ) : null}

          {currentSlide.id === "notes" ? (
            <div className="space-y-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="kicker text-gold">Standard · Deep reading</p>
                  <p className="mt-1 text-sm text-muted">The reading content stays rich; the delivery is now layered so you can scan, study, or go deep without losing your place.</p>
                </div>
                <LessonNotesDrawer classId={props.classId} title={props.title} isDemo={props.isDemo} />
              </div>
              <DepthNotes brief={props.brief} standard={props.standard} deep={props.deep} defaultDepth="standard" />
            </div>
          ) : null}

          {currentSlide.id === "recall" ? (
            <div className="grid gap-6 lg:grid-cols-2">
              <div>
                <p className="kicker text-gold">Recall card</p>
                <div className="mt-3">
                  <CardReviewer cards={[{ classId: props.classId, title: props.title, front: props.cardFront || "Card prompt", back: props.cardBack || "Card answer" }]} />
                </div>
              </div>
              <div>
                <p className="kicker text-gold">Teach it back</p>
                <div className="mt-3">
                  <TeachBack keyHint={props.teachBackKey || "State the rule, decision sequence, and verification step."} />
                </div>
              </div>
            </div>
          ) : null}

          {currentSlide.id === "drill" ? (
            <div className="space-y-5">
              <p className="kicker text-gold">Drill · one question per screen</p>
              <p className="lesson-body text-muted">Prove the rule. One item at a time. Use the answer explanation as the debrief.</p>
              {props.quizMode ? (
                <QuestionPlayer
                  items={props.items.slice(0, 5)}
                  persistUrl="/api/attempts"
                  seedNote="Five class items — study mode."
                />
              ) : (
                <QuestionPlayer
                  items={props.items}
                  persistUrl="/api/attempts"
                  seedNote={props.items.length ? undefined : "No items in this class yet."}
                />
              )}
            </div>
          ) : null}
        </div>
      </section>

      <div className="lesson-footer mt-4 flex items-center justify-between gap-3 rounded-xl px-3 py-3">
        <button type="button" className="btn-ghost tap" onClick={() => go(-1)} disabled={index === 0}>
          Back
        </button>
        <p className="text-center text-sm text-muted">
          Step {index + 1}/{total}
        </p>
        {index === total - 1 ? (
          <button type="button" className="tap inline-flex min-h-11 items-center justify-center rounded-lg bg-gold px-4 font-semibold text-ink disabled:opacity-50" onClick={completeLesson} disabled={completed || completing}>
            {completed ? "✓ Lesson complete · +100 XP" : completing ? "Saving…" : "Complete lesson · +100 XP"}
          </button>
        ) : (
          <button type="button" className="tap inline-flex min-h-11 items-center justify-center rounded-lg bg-gold px-4 font-semibold text-ink disabled:opacity-40" onClick={() => go(1)}>
            Continue
          </button>
        )}
      </div>
    </div>
  );
}
