"use client";

import { useState } from "react";
import { evaluate, formatResult, type AngleMode } from "@/lib/ti30";

const KEYS: { label: string; insert?: string; action?: string; wide?: boolean }[] = [
  { label: "2nd", action: "2nd" },
  { label: "DEG", action: "mode" },
  { label: "π", insert: "pi" },
  { label: "EE", insert: "E" },
  { label: "(", insert: "(" },
  { label: ")", insert: ")" },
  { label: "√", insert: "sqrt(" },
  { label: "x²", insert: "^(2)" },
  { label: "y^x", insert: "^" },
  { label: "1/x", insert: "recip(" },
  { label: "sin", insert: "sin(" },
  { label: "cos", insert: "cos(" },
  { label: "tan", insert: "tan(" },
  { label: "log", insert: "log(" },
  { label: "ln", insert: "ln(" },
  { label: "7", insert: "7" },
  { label: "8", insert: "8" },
  { label: "9", insert: "9" },
  { label: "÷", insert: "/" },
  { label: "%", insert: "%" },
  { label: "4", insert: "4" },
  { label: "5", insert: "5" },
  { label: "6", insert: "6" },
  { label: "×", insert: "*" },
  { label: "±", action: "neg" },
  { label: "1", insert: "1" },
  { label: "2", insert: "2" },
  { label: "3", insert: "3" },
  { label: "−", insert: "-" },
  { label: "ANS", insert: "ANS" },
  { label: "0", insert: "0" },
  { label: ".", insert: "." },
  { label: "=", action: "eq" },
  { label: "+", insert: "+" },
  { label: "F↔D", action: "frac" },
  { label: "CE", action: "ce" },
  { label: "C", action: "c", wide: true },
];

export function Calculator({
  compact = false,
  variant = "study",
}: {
  compact?: boolean;
  variant?: "study" | "exam";
}) {
  const [expr, setExpr] = useState("");
  const [out, setOut] = useState("0");
  const [mode, setMode] = useState<AngleMode>("DEG");
  const [ans, setAns] = useState(0);
  const [second, setSecond] = useState(false);
  const [frac, setFrac] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  function insert(s: string) {
    let token = s;
    if (second) {
      if (s === "sin(") token = "asin(";
      if (s === "cos(") token = "acos(";
      if (s === "tan(") token = "atan(";
      setSecond(false);
    }
    setExpr((e) => e + token);
    setErr(null);
  }

  function run() {
    try {
      const v = evaluate(expr.replace(/ANS/g, String(ans)), mode, ans);
      setAns(v);
      setOut(formatResult(v, frac));
      setErr(null);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Error");
    }
  }

  function handle(k: (typeof KEYS)[number]) {
    if (k.action === "2nd") return setSecond((v) => !v);
    if (k.action === "mode") return setMode((m) => (m === "DEG" ? "RAD" : "DEG"));
    if (k.action === "eq") return run();
    if (k.action === "frac") {
      setFrac((f) => !f);
      try {
        const v = evaluate(expr.replace(/ANS/g, String(ans)) || String(ans), mode, ans);
        setOut(formatResult(v, !frac));
      } catch {
        /* keep */
      }
      return;
    }
    if (k.action === "ce") return setExpr((e) => e.slice(0, -1));
    if (k.action === "c") {
      setExpr("");
      setOut("0");
      setErr(null);
      return;
    }
    if (k.action === "neg") {
      setExpr((e) => (e.startsWith("-") ? e.slice(1) : "-" + e));
      return;
    }
    if (k.insert) insert(k.insert);
  }

  const exam = variant === "exam";

  return (
    <div className={exam ? "calc-exam" : `card p-4 ${compact ? "" : "max-w-md"}`}>
      <p className={exam ? "calc-exam-note" : "kicker mb-2"}>
        Practice look-alike · not Pearson software · not TI firmware
      </p>
      <div className={exam ? "calc-exam-screen" : "mb-3 rounded-lg bg-ink px-3 py-2 font-mono"}>
        <div className={exam ? "calc-exam-screen-top" : "flex justify-between text-xs text-muted"}>
          <span>{mode}{second ? " · 2nd" : ""}{frac ? " · F" : " · D"}</span>
          <span>ANS {formatResult(ans, false)}</span>
        </div>
        <div className={exam ? "calc-exam-expr" : "min-h-8 break-all text-sm text-muted"}>{expr || " "}</div>
        <div className={exam ? "calc-exam-out" : "text-2xl text-cream"}>{err ?? out}</div>
      </div>
      <div className={exam ? "calc-exam-keys" : "grid grid-cols-5 gap-2"}>
        {KEYS.map((k) => (
          <button
            key={k.label}
            type="button"
            onClick={() => handle(k)}
            className={
              exam
                ? `calc-exam-key ${k.wide ? "is-wide" : ""} ${k.label === "=" ? "is-eq" : ""}`
                : `tap rounded-lg border border-line bg-panel-2 text-sm font-semibold hover:border-amber ${k.wide ? "col-span-4" : ""} ${k.label === "=" ? "bg-amber text-ink" : ""}`
            }
          >
            {second && ["sin", "cos", "tan"].includes(k.label) ? k.label + "⁻¹" : k.label === "DEG" ? mode : k.label}
          </button>
        ))}
      </div>
    </div>
  );
}
