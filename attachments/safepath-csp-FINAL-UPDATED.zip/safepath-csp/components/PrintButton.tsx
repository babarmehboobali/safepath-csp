"use client";

import type { ReactNode } from "react";

export function PrintButton({
  className = "exam-btn-primary",
  children = "Print / save PDF",
}: {
  className?: string;
  children?: ReactNode;
}) {
  return (
    <button type="button" className={className} onClick={() => window.print()}>
      {children}
    </button>
  );
}
