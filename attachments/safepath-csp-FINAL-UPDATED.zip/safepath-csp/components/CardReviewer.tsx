"use client";

import { useState } from "react";

export type CardItem = {
  classId?: number;
  cardId?: string;
  title: string;
  front: string;
  back: string;
  deck?: string;
};

export function CardReviewer({ cards }: { cards: CardItem[] }) {
  const [i, setI] = useState(0);
  const [flip, setFlip] = useState(false);
  const card = cards[i];

  async function grade(remembered: boolean) {
    if (!card) return;
    await fetch("/api/cards", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        classId: card.classId,
        cardId: card.cardId,
        remembered,
      }),
    });
    setFlip(false);
    setI((n) => n + 1);
  }

  if (!card) {
    return (
      <div className="card p-6">
        <p className="kicker">Caught up</p>
        <p className="mt-2">No cards left in this stack. Open another deck or a class.</p>
      </div>
    );
  }

  return (
    <div className="card space-y-4 p-6">
      <p className="kicker">
        {card.deck ? `${card.deck} deck` : card.classId ? `Class ${card.classId}` : "Card"} · 1 / 3 / 7 / 21 day
        schedule · {i + 1} / {cards.length}
      </p>
      <h2 className="font-serif text-2xl">{card.title}</h2>
      <button
        type="button"
        className="min-h-40 w-full rounded-xl border border-line bg-ink p-6 text-left text-lg tap"
        onClick={() => setFlip((f) => !f)}
      >
        {flip ? card.back : card.front}
        <span className="mt-4 block text-sm text-muted">Tap to flip</span>
      </button>
      {flip ? (
        <div className="flex gap-2">
          <button type="button" className="btn-ghost flex-1 tap" onClick={() => grade(false)}>
            Again
          </button>
          <button type="button" className="btn-primary flex-1 tap" onClick={() => grade(true)}>
            Got it
          </button>
        </div>
      ) : null}
    </div>
  );
}
