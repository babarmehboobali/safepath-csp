"use client";

import { useState } from "react";
import { DOMAIN_NAMES } from "@/lib/constants";

export function BuildOwnForm() {
  const [domains, setDomains] = useState<number[]>([1, 2]);
  const [count, setCount] = useState(10);

  function toggle(d: number) {
    setDomains((cur) => (cur.includes(d) ? cur.filter((x) => x !== d) : [...cur, d].sort()));
  }

  const href =
    domains.length && [10, 20, 40].includes(count)
      ? `/practice?mode=custom&domains=${domains.join(",")}&count=${count}`
      : "";

  return (
    <form
      className="space-y-3"
      onSubmit={(e) => {
        e.preventDefault();
        if (href) location.href = href;
      }}
    >
      <p className="text-sm text-muted">Pick one or more domains and a count.</p>
      <div className="flex flex-wrap gap-2">
        {[1, 2, 3, 4, 5, 6, 7].map((d) => (
          <label key={d} className="btn-ghost tap text-sm">
            <input
              type="checkbox"
              className="mr-2"
              checked={domains.includes(d)}
              onChange={() => toggle(d)}
            />
            D{d} {DOMAIN_NAMES[d]}
          </label>
        ))}
      </div>
      <div className="flex flex-wrap gap-2">
        {[10, 20, 40].map((n) => (
          <label key={n} className="btn-ghost tap text-sm">
            <input type="radio" className="mr-2" name="count" checked={count === n} onChange={() => setCount(n)} />
            {n} items
          </label>
        ))}
      </div>
      <button type="submit" className="btn-primary tap" disabled={!href}>
        Launch custom gym
      </button>
    </form>
  );
}
