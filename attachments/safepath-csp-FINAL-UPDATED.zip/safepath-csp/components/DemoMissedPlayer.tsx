"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { QuestionPlayer, type Item } from "./QuestionPlayer";
import { demoMissedItems, demoWeakestDomain, loadDemoFlags } from "@/lib/demo-store";

export function DemoMissedPlayer() {
  const [items, setItems] = useState<Item[] | null>(null);
  useEffect(() => setItems(demoMissedItems()), []);
  if (!items) return <p className="text-muted">Loading missed items from this session…</p>;
  if (!items.length) {
    return (
      <div className="card p-5">
        <p>No missed items in this demo session yet. Run a Quick 10 first. Demo does not persist.</p>
        <Link href="/practice?mode=quick" className="btn-primary mt-3 tap">
          Quick 10
        </Link>
      </div>
    );
  }
  return (
    <QuestionPlayer
      items={items}
      persistUrl="/api/attempts"
      seedNote="Demo missed list lives in sessionStorage only."
    />
  );
}

export function DemoFlagsList() {
  const [rows, setRows] = useState<{ questionId: string; stemPreview: string; classId?: number; domain?: number }[]>([]);
  useEffect(() => setRows(loadDemoFlags()), []);
  if (!rows.length) {
    return (
      <div className="card p-5">
        <p>No flagged items in this demo session. Flag a question from any gym. Demo flags are not stored.</p>
        <Link href="/practice" className="btn-primary mt-3 tap">
          Practice hub
        </Link>
      </div>
    );
  }
  return (
    <ul className="space-y-2">
      {rows.map((r) => (
        <li key={r.questionId} className="card p-4">
          <p className="text-sm text-muted">
            {r.domain ? `D${r.domain}` : ""} {r.classId ? `· Class ${r.classId}` : ""}
          </p>
          <p className="mt-1">{r.stemPreview}</p>
          <Link href={`/practice?mode=one&qid=${encodeURIComponent(r.questionId)}`} className="btn-ghost mt-3 tap text-sm">
            Practice this item
          </Link>
        </li>
      ))}
    </ul>
  );
}

export function DemoWeakestLaunch() {
  const [href, setHref] = useState<string | null>(null);
  const [empty, setEmpty] = useState(false);
  useEffect(() => {
    const d = demoWeakestDomain();
    if (d) setHref(`/practice?mode=custom&domains=${d}&count=10`);
    else setEmpty(true);
  }, []);
  if (empty) {
    return (
      <div className="card p-5">
        <p>Need at least one demo attempt to rank a weakest domain. Session only.</p>
        <Link href="/practice?mode=quick" className="btn-primary mt-3 tap">
          Quick 10
        </Link>
      </div>
    );
  }
  if (!href) return <p className="text-muted">Finding weakest domain from this session…</p>;
  return (
    <div className="card p-5">
      <p>Weakest domain from this demo session.</p>
      <Link href={href} className="btn-primary mt-3 tap">
        Launch 10 in that domain
      </Link>
    </div>
  );
}
