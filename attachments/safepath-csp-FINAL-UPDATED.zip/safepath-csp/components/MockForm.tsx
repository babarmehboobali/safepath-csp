"use client";

import { useState } from "react";
import Link from "next/link";
import type { Item, PlayResult } from "./QuestionPlayer";
import { ExamSitting } from "./ExamSitting";
import { CertificateView } from "./CertificateView";
import { mockTimerMinutes } from "@/lib/gym";
import { DOMAIN_NAMES, HONESTY_LEGAL, HONESTY_SHORT } from "@/lib/constants";
import { practiceCertificateGate } from "@/lib/certificate";

export function MockForm({
  length,
  items,
  started,
  withReplacement,
  candidateName,
  isDemo,
}: {
  length: number;
  items: Item[];
  started: boolean;
  withReplacement?: boolean;
  candidateName: string;
  isDemo: boolean;
}) {
  const [persistSent, setPersistSent] = useState(false);
  const [result, setResult] = useState<PlayResult | null>(null);
  const [runId, setRunId] = useState<string | null>(null);
  const [reviewMissed, setReviewMissed] = useState(false);
  const minutes = mockTimerMinutes(length);

  async function persist(play: PlayResult) {
    setResult(play);
    if (persistSent) return;
    setPersistSent(true);
    const res = await fetch("/api/mock", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        length,
        score: play.pct,
        domainScores: play.domainScores,
        answers: play.answers,
      }),
    });
    const data = (await res.json().catch(() => ({}))) as { runId?: string; skipped?: boolean };
    if (data.runId) setRunId(data.runId);
  }

  if (!started) {
    return (
      <div className="card space-y-5 p-8">
        <p>
          Choose a length. Exam mode: one item at a time, flag/review, Previous/Next until submit, cards and formula
          library hidden, practice calculator on demand, no instant scoring. Domain weights 25 / 25 / 15 / 9 / 6 / 10 / 10.
          About 12% of items are internal pretest and excluded from the displayed score.
        </p>
        <div className="flex flex-wrap gap-2">
          <Link href="/mock?length=50" className="btn-ghost tap">
            50 items · 82.5 min
          </Link>
          <Link href="/mock?length=100" className="btn-ghost tap">
            100 items · 2 h 45 min
          </Link>
          <Link href="/mock?length=200" className="btn-primary tap">
            200-item final · 5.5 h
          </Link>
        </div>
        <p className="text-sm text-muted">
          Two saved 200-item runs count as two finals. Sampled without replacement when the bank is large enough. A
          practice result of completion is available when the sitting is ≥70% with no domain below 60%. Demo sittings
          are not stored.
        </p>
        <p className="text-sm leading-relaxed text-muted">{HONESTY_SHORT}</p>
        <p className="text-xs leading-relaxed text-muted">{HONESTY_LEGAL}</p>
      </div>
    );
  }

  if (!result) {
    return (
      <ExamSitting
        items={items}
        length={length}
        timerMinutes={minutes}
        onSubmit={(play) => {
          void persist(play);
        }}
      />
    );
  }

  const gate = practiceCertificateGate(result.pct, result.domainScores);
  const missed = result.answers.filter((a) => !a.correct);
  const weak = [...gate.weakDomains, ...gate.missingDomains];

  return (
    <div className="exam-root exam-results">
      <header className="exam-header">
        <div className="exam-header-inner">
          <p className="exam-brand">Safepath CSP practice examination</p>
          <p className="exam-meta">Score report</p>
        </div>
      </header>
      <main className="exam-intro">
        {result.timedOut ? (
          <p className="exam-banner">Time expired. Blanks stayed blank (counted incorrect on scored items).</p>
        ) : null}
        <h1>Sitting complete</h1>
        <p className="exam-lead">
          {result.correct} of {result.total} scored correct ({result.pct}%)
          {result.pretestExcluded ? ` · ${result.pretestExcluded} pretest item(s) excluded from displayed score` : ""}.
          {withReplacement ? " A domain bank was short, so a few items may have repeated." : ""}
        </p>
        <p className="exam-fine">
          Flagged but wrong (scored items): {result.flaggedWrong ?? 0}.
        </p>
        {result.errorCounts && Object.keys(result.errorCounts).length ? (
          <ul className="exam-score-list">
            <li>
              Error codes:{" "}
              {Object.entries(result.errorCounts)
                .sort((a, b) => b[1] - a[1])
                .map(([code, n]) => `${code} ×${n}`)
                .join(", ")}
            </li>
          </ul>
        ) : null}
        <ul className="exam-score-list">
          {[1, 2, 3, 4, 5, 6, 7].map((d) => (
            <li key={d}>
              Domain {d} {DOMAIN_NAMES[d]}:{" "}
              {result.domainScores[d] == null ? "not sampled" : `${Math.round(result.domainScores[d])}%`}
              {weak.includes(d) ? " — below 60%" : ""}
            </li>
          ))}
        </ul>

        {gate.eligible ? (
          <>
            <CertificateView
              candidateName={candidateName}
              date={new Date()}
              length={length}
              score={result.pct}
              domainScores={result.domainScores}
              demo={isDemo}
            />
            <div className="exam-intro-actions no-print">
              <button type="button" className="exam-btn-primary" onClick={() => window.print()}>
                Print / save PDF
              </button>
              {runId ? (
                <Link href={`/certificate/${runId}`} className="exam-btn-secondary">
                  Open saved certificate
                </Link>
              ) : isDemo ? (
                <p className="exam-fine">Demo — certificate shown in-session only and was not saved.</p>
              ) : null}
            </div>
          </>
        ) : (
          <section className="exam-fail">
            <h2>Score report — no practice certificate</h2>
            <p>
              A practice result of completion requires 70% or higher and no domain below 60%.{" "}
              {!gate.scoreOk ? `Overall score is ${result.pct}%. ` : null}
              {weak.length
                ? `Domains under 60% (or not sampled): ${weak
                    .map((d) => `D${d} ${DOMAIN_NAMES[d]}`)
                    .join("; ")}.`
                : null}
            </p>
            <div className="exam-intro-actions">
              <button type="button" className="exam-btn-primary" onClick={() => setReviewMissed(true)}>
                Review missed items
              </button>
              <Link href="/mock" className="exam-btn-secondary">
                Another mock
              </Link>
              <Link href="/practice" className="exam-btn-secondary">
                Practice hub
              </Link>
            </div>
          </section>
        )}

        {reviewMissed || gate.eligible ? (
          <section className="exam-missed no-print">
            <h2>Missed-item review</h2>
            {missed.length === 0 ? (
              <p>No missed items.</p>
            ) : (
              <ol className="exam-missed-list">
                {missed.map((row) => {
                  const q = items.find((it) => it.id === row.questionId);
                  if (!q) return null;
                  const yours = row.selected >= 0 ? q.options[row.selected] : "No response";
                  return (
                    <li key={row.questionId}>
                      <p className="exam-stem">{q.stem}</p>
                      <p>
                        Your answer: {yours}. Key: {q.options[q.answerIndex]}.
                      </p>
                      <p>{q.explanation}</p>
                      {q.classId ? (
                        <Link href={`/learn/${q.classId}`}>Open class {q.classId}</Link>
                      ) : null}{" "}
                      <Link href={`/practice?mode=one&qid=${encodeURIComponent(q.id)}`}>Practice this item</Link>
                    </li>
                  );
                })}
              </ol>
            )}
          </section>
        ) : null}

        <p className="exam-fine no-print">
          <Link href="/dashboard">Dashboard</Link>
          {" · "}
          <Link href="/mock">Mock home</Link>
        </p>
      </main>
    </div>
  );
}
