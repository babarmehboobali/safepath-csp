"use client";

import { useMemo, useState } from "react";

export type TermRow = { id: string; kind: string; term: string; meaning: string; topic: string };

export function TermSearch({ terms, title }: { terms: TermRow[]; title: string }) {
  const [q, setQ] = useState("");
  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return terms;
    return terms.filter((t) => `${t.term} ${t.meaning} ${t.topic}`.toLowerCase().includes(s));
  }, [q, terms]);

  return (
    <section className="space-y-3">
      <h2 className="font-serif text-2xl">{title}</h2>
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Filter…"
        className="w-full rounded-xl border border-line bg-ink px-4 py-3 text-cream"
      />
      <p className="text-sm text-muted">
        {filtered.length} of {terms.length}
      </p>
      <ul className="space-y-2">
        {filtered.map((t) => (
          <li key={t.id} className="card p-4">
            <p className="font-mono text-amber">{t.term}</p>
            <p className="mt-1 text-sm">{t.meaning}</p>
          </li>
        ))}
      </ul>
    </section>
  );
}
