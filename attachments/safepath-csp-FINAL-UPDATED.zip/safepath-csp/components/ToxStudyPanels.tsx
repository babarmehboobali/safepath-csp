const INTERACTIONS = [
  {
    name: "Additive",
    rule: "1 + 1 ≈ 2",
    body: "Combined effect roughly equals the sum. Mixture unity Σ(Ci/OELi) belongs here when the stem says same target / additive.",
  },
  {
    name: "Synergistic",
    rule: "1 + 1 > 2",
    body: "Combined effect greater than the sum. Classic teaching pair: asbestos with cigarette smoking multiplies lung-cancer risk far beyond either alone.",
  },
  {
    name: "Potentiation",
    rule: "0 + 1 > 1",
    body: "An agent with little effect of its own increases another agent’s toxicity (e.g., isopropanol boosting carbon tetrachloride liver injury in study lore).",
  },
  {
    name: "Antagonistic",
    rule: "1 + 1 < 2",
    body: "One agent reduces the effect of another. Do not invent antagonism unless the stem supports it.",
  },
];

const TARGET_ORGANS = [
  {
    category: "Hepatotoxin",
    organ: "Liver",
    agents: "Carbon tetrachloride, chloroform, vinyl chloride",
    effect: "Fatty change, necrosis, angiosarcoma (vinyl chloride teaching case)",
  },
  {
    category: "Nephrotoxin",
    organ: "Kidney",
    agents: "Lead, cadmium, mercury, ethylene glycol",
    effect: "Tubular injury, glomerular damage",
  },
  {
    category: "Neurotoxin",
    organ: "CNS / PNS",
    agents: "n-Hexane, lead, carbon disulfide, mercury",
    effect: "Peripheral neuropathy, encephalopathy, ataxia",
  },
  {
    category: "Hematotoxin",
    organ: "Blood / marrow",
    agents: "Benzene, carbon monoxide, aniline",
    effect: "Aplastic anemia, leukemia risk, methemoglobinemia / COHb",
  },
  {
    category: "Pulmonary toxicant",
    organ: "Lung / airway",
    agents: "Crystalline silica, asbestos, isocyanates, beryllium",
    effect: "Silicosis, mesothelioma, occupational asthma, chronic beryllium disease",
  },
];

const DOSE_RESPONSE = [
  { term: "LD50 / LC50", meaning: "Animal lethality benchmark for a stated study — not a workplace PEL." },
  { term: "NOAEL", meaning: "Highest tested dose with no observed adverse effect in that study." },
  { term: "LOAEL", meaning: "Lowest tested dose with an observed adverse effect." },
  { term: "Ames test", meaning: "Bacterial mutagenicity screen (Salmonella strains). Mutagen signal correlates with carcinogen concern — still not an OEL." },
];

export function ToxStudyPanels() {
  return (
    <div className="space-y-6">
      <section className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
        {INTERACTIONS.map((row) => (
          <article key={row.name} className="card p-5">
            <p className="kicker">Interaction</p>
            <h3 className="mt-1 font-serif text-xl">{row.name}</h3>
            <p className="mt-2 font-mono text-sm text-amber">{row.rule}</p>
            <p className="mt-2 text-sm text-muted">{row.body}</p>
          </article>
        ))}
      </section>

      <section className="card p-5">
        <p className="kicker">Dose–response objects</p>
        <h2 className="mt-1 font-serif text-2xl">Study markers, not citation PELs</h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {DOSE_RESPONSE.map((row) => (
            <div key={row.term} className="rounded-xl border border-line bg-ink p-4">
              <p className="font-semibold text-cream">{row.term}</p>
              <p className="mt-2 text-sm text-muted">{row.meaning}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="card overflow-x-auto p-5">
        <p className="kicker">Target-organ matrix</p>
        <h2 className="mt-1 font-serif text-2xl">Where the effect shows up</h2>
        <table className="mt-4 w-full min-w-[40rem] border-collapse text-left text-sm">
          <thead>
            <tr className="border-b border-line text-muted">
              <th className="py-2 pr-3 font-medium">Category</th>
              <th className="py-2 pr-3 font-medium">Target</th>
              <th className="py-2 pr-3 font-medium">Classic agents</th>
              <th className="py-2 font-medium">Effect pattern</th>
            </tr>
          </thead>
          <tbody>
            {TARGET_ORGANS.map((row) => (
              <tr key={row.category} className="border-b border-line/70 align-top">
                <td className="py-3 pr-3 font-semibold text-cream">{row.category}</td>
                <td className="py-3 pr-3 text-muted">{row.organ}</td>
                <td className="py-3 pr-3 text-muted">{row.agents}</td>
                <td className="py-3 text-muted">{row.effect}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </div>
  );
}
