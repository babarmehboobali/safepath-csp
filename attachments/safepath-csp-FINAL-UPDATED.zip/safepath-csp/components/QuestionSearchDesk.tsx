"use client";

import Link from "next/link";
import { useMemo, useState } from "react";

export type QuestionSearchRow = {
  id: string;
  classId: number;
  classTitle: string;
  domain: string;
  kind: string;
  topic?: string;
  taskCode: string;
  difficulty: "Foundation" | "Exam" | "Expert";
  errorCode: string;
  stem: string;
  options: [string, string, string, string];
  answerIndex: 0 | 1 | 2 | 3;
  explanation: string;
  distractors?: [string, string, string, string];
  standard: string;
  formulaSlug?: string | null;
  formulaBreakdown: string;
  keywords: string[];
  isMath: boolean;
  source: "class" | "gym" | "challenge";
  classHref?: string;
};

type RationaleSections = {
  coreRule: string;
  calculationSteps: string;
  standardsCited: string;
  distractorRationale: string;
};

const LETTERS = ["A", "B", "C", "D"] as const;
const EMPTY_RATIONALE = "No separately labeled rationale section is stored for this item.";

function normalize(value: string): string {
  return value
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9%./+\-×÷=^ ]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function tokenSubsequence(token: string, candidate: string): boolean {
  if (!token) return true;
  let j = 0;
  for (const ch of candidate) {
    if (ch === token[j]) j += 1;
    if (j === token.length) return true;
  }
  return false;
}

function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  if (!a) return b.length;
  if (!b) return a.length;

  const prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  const curr = new Array<number>(b.length + 1).fill(0);

  for (let i = 1; i <= a.length; i += 1) {
    curr[0] = i;
    for (let j = 1; j <= b.length; j += 1) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      curr[j] = Math.min(
        curr[j - 1] + 1,
        prev[j] + 1,
        prev[j - 1] + cost,
      );
    }
    for (let j = 0; j <= b.length; j += 1) prev[j] = curr[j];
  }

  return prev[b.length];
}

function fuzzyScore(query: string, haystack: string): number {
  const q = normalize(query);
  const h = normalize(haystack);
  if (!q) return 1;
  if (!h) return 0;

  let score = 0;

  if (h.includes(q)) score += 100;

  const qTokens = q.split(" ").filter(Boolean);
  const hTokens = h.split(" ").filter(Boolean);

  let matchedTokens = 0;
  for (const token of qTokens) {
    if (hTokens.some((candidate) => candidate === token)) {
      score += 35;
      matchedTokens += 1;
      continue;
    }

    if (hTokens.some((candidate) => candidate.startsWith(token))) {
      score += 25;
      matchedTokens += 1;
      continue;
    }

    if (hTokens.some((candidate) => tokenSubsequence(token, candidate))) {
      score += 15;
      matchedTokens += 1;
      continue;
    }

    if (token.length >= 3) {
      const close = hTokens.some((candidate) => {
        const limit = token.length <= 4 ? 1 : 2;
        return Math.abs(candidate.length - token.length) <= limit && levenshtein(token, candidate) <= limit;
      });
      if (close) {
        score += 10;
        matchedTokens += 1;
      }
    }
  }

  if (qTokens.length > 0) {
    score += (matchedTokens / qTokens.length) * 20;
  }

  return score;
}

function parseRationale(row: QuestionSearchRow): RationaleSections {
  const explanation = row.explanation.trim();
  const core = /Core Rule:\s*(.*?)(?=\s+Calculation Steps:|\s+Standards Cited:|\s+Why Each Distractor Fails:|$)/i.exec(explanation)?.[1]?.trim();
  const calc = /Calculation Steps:\s*(.*?)(?=\s+Standards Cited:|\s+Why Each Distractor Fails:|$)/i.exec(explanation)?.[1]?.trim();
  const standards = /Standards Cited:\s*(.*?)(?=\s+Why Each Distractor Fails:|$)/i.exec(explanation)?.[1]?.trim();
  const distractors = /Why Each Distractor Fails:\s*(.*)$/i.exec(explanation)?.[1]?.trim();

  return {
    coreRule: core || explanation || EMPTY_RATIONALE,
    calculationSteps: calc || (row.isMath ? explanation || EMPTY_RATIONALE : EMPTY_RATIONALE),
    standardsCited: standards || row.standard || EMPTY_RATIONALE,
    distractorRationale: distractors || EMPTY_RATIONALE,
  };
}

function optionAnatomy(row: QuestionSearchRow, index: number): string {
  if (row.distractors?.[index]) return row.distractors[index];
  if (index === row.answerIndex) return "Correct key — this is the answer supported by the stored rationale.";
  return "No option-specific distractor anatomy is stored for this item.";
}

export function QuestionSearchDesk({
  questions,
  domainOptions,
}: {
  questions: QuestionSearchRow[];
  domainOptions: string[];
}) {
  const [query, setQuery] = useState("");
  const [domain, setDomain] = useState("all");
  const [mathOnly, setMathOnly] = useState(false);
  const [openId, setOpenId] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim();

    return questions
      .map((row, index) => ({
        row,
        index,
        score: q
          ? fuzzyScore(q, [
              row.id,
              row.classId.toString(),
              row.classTitle,
              row.domain,
              row.kind,
              row.topic ?? "",
              row.taskCode,
              row.errorCode,
              row.stem,
              row.standard,
              row.formulaSlug ?? "",
              row.formulaBreakdown,
              ...row.keywords,
            ].join(" "))
          : 1,
      }))
      .filter(({ row, score }) => {
        if (domain !== "all" && row.domain !== domain) return false;
        if (mathOnly && !row.isMath) return false;
        if (!q) return true;
        return score >= 10;
      })
      .sort((a, b) => (b.score - a.score) || (a.index - b.index))
      .map(({ row }) => row);
  }, [domain, mathOnly, query, questions]);

  const visible = filtered.slice(0, 150);

  return (
    <section className="space-y-4">
      <div className="card p-4">
        <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_240px_auto] lg:items-end">
          <label className="block text-sm">
            <span className="kicker">Search questions, IDs, standards, keywords</span>
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              className="field mt-2 w-full"
              placeholder="NFPA 70E, 1910.119, ANSI Z10, reliability, TWA…"
              aria-label="Search the question and formula desk"
            />
          </label>

          <label className="block text-sm">
            <span className="kicker">Blueprint domain</span>
            <select
              value={domain}
              onChange={(event) => setDomain(event.target.value)}
              className="field mt-2 w-full"
              aria-label="Filter by blueprint domain"
            >
              <option value="all">All domains</option>
              {domainOptions.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
          </label>

          <label className="flex h-11 items-center gap-2 rounded-xl border border-line bg-ink px-3 text-sm">
            <input
              type="checkbox"
              checked={mathOnly}
              onChange={(event) => setMathOnly(event.target.checked)}
            />
            <span>Math / calculations only</span>
          </label>
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-between gap-2 text-sm text-muted">
          <span>
            {filtered.length.toLocaleString()} matching items
            {filtered.length > visible.length ? ` · showing first ${visible.length}` : ""}
          </span>
          <span>Search runs locally across the full loaded bank.</span>
        </div>
      </div>

      {visible.length === 0 ? (
        <div className="card p-6 text-center text-muted">
          No questions match those filters. Try a shorter standard, class ID, or keyword.
        </div>
      ) : null}

      <div className="space-y-3">
        {visible.map((row) => {
          const open = openId === row.id;
          const rationale = parseRationale(row);
          const keyLetter = LETTERS[row.answerIndex];

          return (
            <article key={row.id} className="card overflow-hidden">
              <button
                type="button"
                onClick={() => setOpenId(open ? null : row.id)}
                className="w-full p-5 text-left"
                aria-expanded={open}
                aria-controls={`${row.id}-details`}
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-muted">
                      <span className="font-mono text-amber">{row.id}</span>
                      <span>·</span>
                      <span>{row.classTitle}</span>
                      <span>·</span>
                      <span>{row.domain}</span>
                      <span>·</span>
                      <span>{row.kind}</span>
                      {row.isMath ? <span className="rounded border border-amber/40 px-1.5 py-0.5 text-amber">MATH</span> : null}
                    </div>
                    <h2 className="mt-2 text-base font-medium leading-relaxed">{row.stem}</h2>
                  </div>
                  <span className="shrink-0 text-amber" aria-hidden="true">{open ? "−" : "+"}</span>
                </div>
                <div className="mt-3 flex flex-wrap gap-2 text-xs">
                  <span className="rounded border border-line px-2 py-1">{row.taskCode}</span>
                  <span className="rounded border border-line px-2 py-1">{row.difficulty}</span>
                  <span className="rounded border border-line px-2 py-1">{row.errorCode}</span>
                  {row.standard ? <span className="rounded border border-line px-2 py-1">Standard linked</span> : null}
                </div>
              </button>

              {open ? (
                <div id={`${row.id}-details`} className="border-t border-line px-5 pb-5 pt-4">
                  <div className="grid gap-4 lg:grid-cols-2">
                    <section>
                      <p className="kicker">Correct key</p>
                      <div className="mt-2 rounded-xl border border-amber/50 bg-ink p-4">
                        <p className="font-mono text-amber">{keyLetter}</p>
                        <p className="mt-1 text-sm">{row.options[row.answerIndex]}</p>
                      </div>
                    </section>

                    <section>
                      <p className="kicker">Formula breakdown</p>
                      <div className="mt-2 rounded-xl border border-line bg-ink p-4 text-sm leading-relaxed">
                        {row.formulaBreakdown || (row.isMath ? rationale.calculationSteps : "No formula is attached to this item.")}
                      </div>
                    </section>
                  </div>

                  <div className="mt-4 grid gap-4 md:grid-cols-2">
                    <section className="rounded-xl border border-line p-4">
                      <p className="kicker">1 · Core rule</p>
                      <p className="mt-2 text-sm leading-relaxed">{rationale.coreRule}</p>
                    </section>
                    <section className="rounded-xl border border-line p-4">
                      <p className="kicker">2 · Calculation steps</p>
                      <p className="mt-2 text-sm leading-relaxed">{rationale.calculationSteps}</p>
                    </section>
                    <section className="rounded-xl border border-line p-4">
                      <p className="kicker">3 · Standards cited</p>
                      <p className="mt-2 text-sm leading-relaxed">{rationale.standardsCited}</p>
                    </section>
                    <section className="rounded-xl border border-line p-4">
                      <p className="kicker">4 · Distractor anatomy</p>
                      <p className="mt-2 text-sm leading-relaxed">{rationale.distractorRationale}</p>
                    </section>
                  </div>

                  <section className="mt-4">
                    <p className="kicker">A–D option anatomy</p>
                    <div className="mt-2 grid gap-2 md:grid-cols-2">
                      {row.options.map((option, index) => (
                        <div
                          key={`${row.id}-option-${index}`}
                          className={`rounded-xl border p-3 text-sm ${
                            index === row.answerIndex
                              ? "border-amber/60 bg-amber/10"
                              : "border-line"
                          }`}
                        >
                          <p className="font-mono text-amber">{LETTERS[index]}</p>
                          <p className="mt-1 leading-relaxed">{option}</p>
                          <p className="mt-2 text-xs text-muted">{optionAnatomy(row, index)}</p>
                        </div>
                      ))}
                    </div>
                  </section>

                  <section className="mt-4">
                    <p className="kicker">Search metadata</p>
                    <div className="mt-2 flex flex-wrap gap-2 text-xs text-muted">
                      {[row.classTitle, row.domain, row.kind, row.topic, row.taskCode, row.errorCode, ...row.keywords]
                        .filter(Boolean)
                        .map((keyword, index) => (
                          <span key={`${row.id}-kw-${index}`} className="rounded border border-line px-2 py-1">
                            {keyword}
                          </span>
                        ))}
                    </div>
                  </section>

                  {row.classHref ? (
                    <div className="mt-4">
                      <Link href={row.classHref} className="btn-ghost tap text-sm">
                        Open class module
                      </Link>
                    </div>
                  ) : null}
                </div>
              ) : null}
            </article>
          );
        })}
      </div>
    </section>
  );
}

export default QuestionSearchDesk;
