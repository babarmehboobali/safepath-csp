"use client";

import { useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { DEMO_EMAIL, DEMO_PASSWORD, HONESTY_LEGAL } from "@/lib/constants";

export function AuthForm({ mode }: { mode: "login" | "register" }) {
  const router = useRouter();
  const params = useSearchParams();
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);
  const next = params.get("next") || "/dashboard";
  const demoHint = mode === "login" && params.get("demo") === "1";

  const defaults = useMemo(
    () =>
      demoHint
        ? { email: DEMO_EMAIL, password: DEMO_PASSWORD }
        : { email: "", password: "" },
    [demoHint],
  );

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setPending(true);
    setError(null);
    const fd = new FormData(e.currentTarget);
    const body = {
      name: String(fd.get("name") || ""),
      email: String(fd.get("email") || ""),
      password: String(fd.get("password") || ""),
    };
    const res = await fetch(mode === "login" ? "/api/auth/login" : "/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json().catch(() => ({}));
    setPending(false);
    if (!res.ok) {
      setError(data.error || "Could not continue.");
      return;
    }
    router.push(data.redirect || next);
    router.refresh();
  }

  async function loginDemo() {
    setPending(true);
    setError(null);
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: DEMO_EMAIL, password: DEMO_PASSWORD }),
    });
    const data = await res.json().catch(() => ({}));
    setPending(false);
    if (!res.ok) {
      setError(data.error || "Could not start demo.");
      return;
    }
    router.push(data.redirect || next);
    router.refresh();
  }

  return (
    <div className="space-y-4">
      {demoHint ? (
        <div className="card border-safepath-lime/30 bg-safepath-green/15 p-4">
          <p className="text-sm font-semibold text-cream">Free demo ready</p>
          <p className="mt-1 text-sm text-muted">
            Prefills {DEMO_EMAIL}. Progress is discarded when you log out.
          </p>
          <button type="button" className="btn-primary mt-3 w-full" disabled={pending} onClick={loginDemo}>
            {pending ? "Working…" : "One-click demo login"}
          </button>
        </div>
      ) : null}
      <form onSubmit={onSubmit} className="card space-y-4 p-6">
        {mode === "register" ? (
          <div>
            <label htmlFor="name" className="mb-1 block text-sm">
              Name
            </label>
            <input id="name" name="name" required className="field" autoComplete="name" />
          </div>
        ) : null}
        <div>
          <label htmlFor="email" className="mb-1 block text-sm">
            Email
          </label>
          <input
            id="email"
            name="email"
            type="email"
            required
            className="field"
            autoComplete="email"
            defaultValue={defaults.email}
            key={demoHint ? "demo-email" : "email"}
          />
        </div>
        <div>
          <label htmlFor="password" className="mb-1 block text-sm">
            Password
          </label>
          <input
            id="password"
            name="password"
            type="password"
            required
            minLength={8}
            className="field"
            autoComplete={mode === "login" ? "current-password" : "new-password"}
            defaultValue={defaults.password}
            key={demoHint ? "demo-password" : "password"}
          />
        </div>
        {error ? <p className="text-sm text-bad">{error}</p> : null}
        <button type="submit" className="btn-primary w-full" disabled={pending}>
          {pending ? "Working…" : mode === "login" ? "Log in" : "Create account"}
        </button>
        <p className="text-center text-xs leading-relaxed text-muted">{HONESTY_LEGAL}</p>
      </form>
    </div>
  );
}
