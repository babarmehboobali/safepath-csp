"use client";

import { useMemo, useState } from "react";

export type HierarchyControl = {
  id: string;
  control: string;
  correctLevel: 1 | 2 | 3 | 4 | 5;
  rationale: string;
};

export type TrapComparison = {
  scenario: string;
  trap: string;
  compliant: string;
  trapExplanation: string;
  compliantExplanation: string;
};

export type CaseChoice = {
  label: string;
  correct?: boolean;
  explanation: string;
  nextStage?: number;
};

export type CaseStage = {
  title: string;
  prompt: string;
  choices: CaseChoice[];
};

export type ArithmeticExample = {
  title: string;
  prompt: string;
  steps: string[];
  answer: string;
};

const HIERARCHY_LEVELS = [
  { value: 1, label: "1 · Elimination" },
  { value: 2, label: "2 · Substitution" },
  { value: 3, label: "3 · Engineering" },
  { value: 4, label: "4 · Administrative" },
  { value: 5, label: "5 · PPE" },
] as const;

export const DEFAULT_HIERARCHY_CONTROLS: HierarchyControl[] = [
  {
    id: "benzene-transfer",
    control: "Remove the manual benzene transfer step from the task design.",
    correctLevel: 1,
    rationale: "The hazardous exposure is eliminated because the task no longer requires the transfer step.",
  },
  {
    id: "solvent-replacement",
    control: "Replace a high-volatility solvent with a lower-hazard alternative that performs the same function.",
    correctLevel: 2,
    rationale: "The hazard is reduced at the source by substituting a safer material.",
  },
  {
    id: "machine-guard",
    control: "Install a fixed interlocked guard around the rotating drive.",
    correctLevel: 3,
    rationale: "The control changes the physical system and separates the worker from the hazard.",
  },
  {
    id: "permit-procedure",
    control: "Require a documented permit, pre-job briefing, and supervisor verification before the task starts.",
    correctLevel: 4,
    rationale: "The control relies on procedures, planning, supervision, or worker behavior rather than changing the hazard itself.",
  },
  {
    id: "respirator",
    control: "Issue a fit-tested respirator for the worker to wear during the task.",
    correctLevel: 5,
    rationale: "PPE is the last layer because protection depends on correct selection, fit, use, and maintenance by the worker.",
  },
];

const DEFAULT_TRAP: TrapComparison = {
  scenario:
    "A field team is verifying a low-flow air-sampling pump and is tempted to accept a secondary rotameter reading as proof that the sampling flow is correct.",
  trap:
    "Use the secondary rotameter reading as-is without correcting for pressure or temperature, then document the flow as calibrated.",
  compliant:
    "Use the primary air calibration method and verify the measured flow is within ±5% before sampling.",
  trapExplanation:
    "This is a classic distractor because the instrument appears to provide a number. The procedural flaw is treating an uncorrected secondary indication as equivalent to a verified primary calibration.",
  compliantExplanation:
    "The stronger answer verifies the primary measurement method and checks the stated acceptance criterion before the task proceeds.",
};

function cx(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}

export function HierarchySortBlock({
  controls = DEFAULT_HIERARCHY_CONTROLS,
  title = "Hierarchy sort",
  intro = "Place each control at the strongest applicable ANSI/ASSP Z10 hierarchy level. Feedback is immediate, so correct the classification before moving on.",
}: {
  controls?: HierarchyControl[];
  title?: string;
  intro?: string;
}) {
  const [answers, setAnswers] = useState<Record<string, number | null>>(
    () => Object.fromEntries(controls.map((item) => [item.id, null])),
  );

  const correctCount = useMemo(
    () =>
      controls.filter(
        (item) => answers[item.id] === item.correctLevel,
      ).length,
    [answers, controls],
  );

  const reset = () => {
    setAnswers(Object.fromEntries(controls.map((item) => [item.id, null])));
  };

  return (
    <section className="card mt-4 p-5" aria-labelledby="hierarchy-sort-title">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="kicker">Active learning · sort</p>
          <h2 id="hierarchy-sort-title" className="mt-1 font-serif text-2xl">
            {title}
          </h2>
          <p className="mt-2 text-sm text-muted">{intro}</p>
        </div>
        <div className="rounded-lg border border-line px-3 py-2 text-sm">
          Score: <span className="font-bold text-amber">{correctCount}/{controls.length}</span>
        </div>
      </div>

      <div className="mt-5 space-y-3">
        {controls.map((item, index) => {
          const selected = answers[item.id];
          const answered = selected !== null && selected !== undefined;
          const correct = selected === item.correctLevel;

          return (
            <div
              key={item.id}
              className={cx(
                "rounded-lg border p-4 transition",
                !answered && "border-line bg-ink",
                answered && correct && "border-ok bg-ok/10",
                answered && !correct && "border-bad bg-bad/10",
              )}
            >
              <div className="flex flex-wrap items-start gap-3">
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md border border-line font-mono text-sm text-muted">
                  {index + 1}
                </span>
                <p className="min-w-0 flex-1 text-sm leading-relaxed">{item.control}</p>
              </div>

              <div className="mt-3 flex flex-wrap items-end gap-3">
                <label className="min-w-0 flex-1 text-sm">
                  <span className="mb-1 block font-medium">Z10 level</span>
                  <select
                    className="field"
                    value={selected ?? ""}
                    onChange={(event) => {
                      const next = event.target.value ? Number(event.target.value) : null;
                      setAnswers((current) => ({ ...current, [item.id]: next }));
                    }}
                  >
                    <option value="">Choose a level…</option>
                    {HIERARCHY_LEVELS.map((level) => (
                      <option key={level.value} value={level.value}>
                        {level.label}
                      </option>
                    ))}
                  </select>
                </label>

                {answered ? (
                  <p className={cx("max-w-xl text-sm", correct ? "text-ok" : "text-bad")}>
                    <span className="font-semibold">
                      {correct ? "Correct." : `Not quite. Correct: ${item.correctLevel}.`}
                    </span>{" "}
                    {item.rationale}
                  </p>
                ) : null}
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-3">
        <button type="button" className="btn-ghost tap" onClick={reset}>
          Reset
        </button>
        {correctCount === controls.length ? (
          <p className="text-sm text-ok" role="status">
            All five controls are correctly classified. Think hierarchy first when two distractor answers both sound reasonable.
          </p>
        ) : null}
      </div>
    </section>
  );
}

export function SpotTheTrapBlock({
  comparison = DEFAULT_TRAP,
  title = "Spot the BCSP trap",
}: {
  comparison?: TrapComparison;
  title?: string;
}) {
  const [choice, setChoice] = useState<"trap" | "compliant" | null>(null);
  const answered = choice !== null;
  const correct = choice === "compliant";

  const choose = (value: "trap" | "compliant") => {
    setChoice(value);
  };

  return (
    <section className="card mt-4 p-5" aria-labelledby="spot-trap-title">
      <p className="kicker">Active learning · distractor recognition</p>
      <h2 id="spot-trap-title" className="mt-1 font-serif text-2xl">
        {title}
      </h2>

      <div className="mt-4 rounded-lg border border-line bg-ink p-4">
        <p className="kicker">Field scenario</p>
        <p className="mt-2 leading-relaxed">{comparison.scenario}</p>
      </div>

      <p className="mt-4 text-sm text-muted">
        Which response is the standard-compliant CSP decision? Choose before reading the comparison.
      </p>

      <div className="mt-3 grid gap-3 lg:grid-cols-2">
        <button
          type="button"
          className={cx(
            "rounded-lg border p-4 text-left transition",
            choice === "trap" ? "border-bad bg-bad/10" : "border-line bg-ink hover:border-amber",
          )}
          onClick={() => choose("trap")}
        >
          <span className="kicker">Option A · distractor</span>
          <p className="mt-2 text-sm leading-relaxed">{comparison.trap}</p>
        </button>

        <button
          type="button"
          className={cx(
            "rounded-lg border p-4 text-left transition",
            choice === "compliant" ? "border-ok bg-ok/10" : "border-line bg-ink hover:border-amber",
          )}
          onClick={() => choose("compliant")}
        >
          <span className="kicker">Option B · compliant</span>
          <p className="mt-2 text-sm leading-relaxed">{comparison.compliant}</p>
        </button>
      </div>

      {answered ? (
        <div className={cx("mt-4 rounded-lg border p-4", correct ? "border-ok bg-ok/10" : "border-bad bg-bad/10")} role="status">
          <p className={cx("font-semibold", correct ? "text-ok" : "text-bad")}>
            {correct ? "Correct call." : "BCSP distractor selected."}
          </p>
          <p className="mt-2 text-sm leading-relaxed">
            {correct ? comparison.compliantExplanation : comparison.trapExplanation}
          </p>
          <div className="mt-3 grid gap-3 lg:grid-cols-2">
            <div className="rounded-md border border-bad/40 p-3">
              <p className="kicker">Why the trap fails</p>
              <p className="mt-1 text-sm leading-relaxed">{comparison.trapExplanation}</p>
            </div>
            <div className="rounded-md border border-ok/40 p-3">
              <p className="kicker">Why the compliant answer wins</p>
              <p className="mt-1 text-sm leading-relaxed">{comparison.compliantExplanation}</p>
            </div>
          </div>
          <button
            type="button"
            className="btn-ghost tap mt-3"
            onClick={() => setChoice(null)}
          >
            Try again
          </button>
        </div>
      ) : null}
    </section>
  );
}

export function CaseWalkthroughBlock({
  stages,
  arithmetic,
  title = "Case walkthrough",
  intro = "Work the field decision in sequence. Each choice gives the procedural reason before you move to the next stage.",
}: {
  stages: CaseStage[];
  arithmetic?: ArithmeticExample;
  title?: string;
  intro?: string;
}) {
  const [stageIndex, setStageIndex] = useState(0);
  const [selectedChoice, setSelectedChoice] = useState<number | null>(null);

  const currentStage = stages[stageIndex];
  const selected =
    selectedChoice === null ? undefined : currentStage?.choices[selectedChoice];
  const finished = stageIndex >= stages.length;
  const correct = selected?.correct === true;

  if (!currentStage || finished) {
    return (
      <section className="card mt-4 p-5" aria-labelledby="case-walkthrough-title">
        <p className="kicker">Active learning · field decision</p>
        <h2 id="case-walkthrough-title" className="mt-1 font-serif text-2xl">
          {title}
        </h2>
        <div className="mt-4 rounded-lg border border-ok bg-ok/10 p-4">
          <p className="font-semibold text-ok">Walkthrough complete.</p>
          <p className="mt-2 text-sm leading-relaxed">
            You completed the decision tree. The key habit is to identify the hazard, apply the stronger control logic, verify the requirement, and then use the math only after the inputs and units are fixed.
          </p>
        </div>
        {arithmetic ? <ArithmeticPanel example={arithmetic} /> : null}
        <button
          type="button"
          className="btn-ghost tap mt-4"
          onClick={() => {
            setStageIndex(0);
            setSelectedChoice(null);
          }}
        >
          Restart walkthrough
        </button>
      </section>
    );
  }

  const goNext = () => {
    const requestedNext = selected?.nextStage;
    const next = requestedNext ?? stageIndex + 1;
    setStageIndex(next);
    setSelectedChoice(null);
  };

  return (
    <section className="card mt-4 p-5" aria-labelledby="case-walkthrough-title">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="kicker">Active learning · field decision tree</p>
          <h2 id="case-walkthrough-title" className="mt-1 font-serif text-2xl">
            {title}
          </h2>
          <p className="mt-2 text-sm text-muted">{intro}</p>
        </div>
        <div className="rounded-lg border border-line px-3 py-2 text-sm">
          Stage <span className="font-bold text-amber">{stageIndex + 1}</span> / {stages.length}
        </div>
      </div>

      <div className="mt-5 rounded-lg border border-line bg-ink p-4">
        <p className="kicker">{currentStage.title}</p>
        <p className="mt-2 text-lg leading-relaxed">{currentStage.prompt}</p>
      </div>

      <div className="mt-4 space-y-3">
        {currentStage.choices.map((choice, index) => {
          const isSelected = selectedChoice === index;
          const stateClass =
            isSelected && choice.correct
              ? "border-ok bg-ok/10"
              : isSelected
                ? "border-bad bg-bad/10"
                : "border-line bg-ink hover:border-amber";

          return (
            <button
              key={`${choice.label}-${index}`}
              type="button"
              className={cx("w-full rounded-lg border p-4 text-left transition", stateClass)}
              onClick={() => setSelectedChoice(index)}
            >
              <span className="flex items-start gap-3">
                <span className="option-letter">{String.fromCharCode(65 + index)}</span>
                <span className="flex-1 text-sm leading-relaxed">{choice.label}</span>
              </span>
              {isSelected ? (
                <span className={cx("mt-3 block border-t border-line/70 pt-3 text-sm leading-relaxed", choice.correct ? "text-ok" : "text-bad")}>
                  <span className="font-semibold">
                    {choice.correct ? "Optimal CSP decision. " : "Procedural flaw. "}
                  </span>
                  {choice.explanation}
                </span>
              ) : null}
            </button>
          );
        })}
      </div>

      {selected ? (
        <div className="mt-4 flex flex-wrap items-center gap-3">
          <button
            type="button"
            className="btn-primary tap"
            onClick={goNext}
            disabled={!correct}
            aria-disabled={!correct}
          >
            {stageIndex === stages.length - 1 ? "Finish walkthrough" : "Continue to next stage"}
          </button>
          {!correct ? (
            <p className="text-sm text-muted" role="status">
              Correct the decision above before continuing to the next stage.
            </p>
          ) : null}
        </div>
      ) : null}
    </section>
  );
}

function ArithmeticPanel({ example }: { example: ArithmeticExample }) {
  return (
    <div className="mt-4 rounded-lg border border-amber/50 bg-panel-2 p-4">
      <p className="kicker">Worked arithmetic check</p>
      <h3 className="mt-1 font-serif text-xl">{example.title}</h3>
      <p className="mt-2 text-sm leading-relaxed">{example.prompt}</p>
      <ol className="mt-3 list-decimal space-y-1 pl-5 text-sm">
        {example.steps.map((step) => (
          <li key={step}>{step}</li>
        ))}
      </ol>
      <p className="mt-3 rounded-md border border-amber/50 bg-amber/10 p-3 text-sm">
        <span className="font-semibold text-amber">Answer:</span> {example.answer}
      </p>
    </div>
  );
}
