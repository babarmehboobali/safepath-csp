"use client";

import { CalculatorDrawer } from "./CalculatorDrawer";

export function FloatingCalculator() {
  return (
    <div className="fixed bottom-5 right-5 z-40">
      <CalculatorDrawer label="🧮" moveable />
    </div>
  );
}
