"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { Calculator } from "./Calculator";
import type { Item, PlayResult } from "./QuestionPlayer";

const LETTERS = ["A", "B", "C", "D"] as const;

function hhmmss(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}

function domainScoresFrom(
  rows: { domain?: number; correct: boolean; pretest?: boolean }[],
): Record<number, number> {
  const acc: Record<number, { ok: number; n: number }> = {};
  for (const row of rows) {
    if (row.pretest) continue;
    const d = row.domain ?? 0;
    if (!d) continue;
    acc[d] = acc[d] ?? { ok: 0, n: 0 };
    acc[d].n += 1;
    if (row.correct) acc[d].ok += 1;
  }
  const out: Record<number, number> = {};
  for (const [k, v] of Object.entries(acc)) {
    out[Number(k)] = v.n ? (v.ok / v.n) * 100 : 0;
  }
  return out;
}

function pacingHint(n: number, timerMinutes: number): string {
  if (n <= 0) return "";
  const sec = Math.round((timerMinutes * 60) / n);
  return `~${sec} s/item`;
}

export function ExamSitting({
  items,
  length,
  timerMinutes,
  onSubmit,
}: {
  items: Item[];
  length: number;
  timerMinutes: number;
  onSubmit: (result: PlayResult) => void;
}) {
  const [phase, setPhase] = useState<"intro" | "sitting" | "review" | "confirm">("intro");
  const [i, setI] = useState(0);
  const [answers, setAnswers] = useState<Array<number | null>>(() => items.map(() => null));
  const [flagged, setFlagged] = useState<boolean[]>(() => items.map(() => false));
  const [seen, setSeen] = useState<boolean[]>(() => items.map(() => false));
  const [remain, setRemain] = useState(Math.round(timerMinutes * 60));
  const [calcOpen, setCalcOpen] = useState(false);
  const [breakOpen, setBreakOpen] = useState(false);
  const [notes, setNotes] = useState("");
  const [flagWarn, setFlagWarn] = useState(false);
  const doneRef = useRef(false);
  const snapshot = useRef({ answers, flagged, remain });
  snapshot.current = { answers, flagged, remain };

  const item = items[i];
  const n = items.length || length;
  const answeredCount = answers.filter((a) => a != null).length;
  const flaggedCount = flagged.filter(Boolean).length;
  const unansweredCount = n - answeredCount;
  const seenCount = seen.filter(Boolean).length;
  const allSeen = n > 0 && seenCount >= n;
  const pace = pacingHint(n, timerMinutes);

  useEffect(() => {
    if (phase === "sitting" && items[i]) {
      setSeen((prev) => {
        if (prev[i]) return prev;
        const next = [...prev];
        next[i] = true;
        return next;
      });
      setNotes("");
    }
  }, [i, phase, items]);

  function finish(timeout: boolean) {
    if (doneRef.current) return;
    doneRef.current = true;
    const snap = snapshot.current;
    const rows = items.map((q, idx) => {
      const selected = snap.answers[idx];
      const pick = selected == null ? -1 : selected;
      const pretest = Boolean(q.pretest);
      return {
        questionId: q.id,
        selected: pick,
        correct: pick === q.answerIndex,
        domain: q.domain,
        classId: q.classId,
        errorCode: q.errorCode,
        flagged: Boolean(snap.flagged[idx]),
        pretest,
      };
    });
    const scored = rows.filter((r) => !r.pretest);
    const ok = scored.filter((r) => r.correct).length;
    const scoredTotal = scored.length || 1;
    const flaggedWrong = rows.filter((r) => r.flagged && !r.correct && !r.pretest).length;
    const errorCounts: Record<string, number> = {};
    for (const r of scored) {
      if (r.correct) continue;
      const code = r.errorCode || "UNK";
      errorCounts[code] = (errorCounts[code] ?? 0) + 1;
    }
    onSubmit({
      pct: Math.round((ok / scoredTotal) * 100),
      correct: ok,
      total: scored.length,
      scoredTotal: scored.length,
      answers: rows,
      domainScores: domainScoresFrom(rows),
      timedOut: timeout,
      flaggedWrong,
      errorCounts,
      pretestExcluded: rows.length - scored.length,
    });
  }

  useEffect(() => {
    if (phase === "intro") return;
    if (doneRef.current) return;
    if (remain <= 0) {
      finish(true);
      return;
    }
    const t = setTimeout(() => setRemain((r) => r - 1), 1000);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [remain, phase]);

  function choose(idx: number) {
    if (phase !== "sitting" || doneRef.current) return;
    setFlagWarn(false);
    setAnswers((prev) => {
      const next = [...prev];
      next[i] = idx;
      return next;
    });
  }

  function jump(idx: number) {
    if (idx < 0 || idx >= items.length) return;
    setI(idx);
    setPhase("sitting");
    setBreakOpen(false);
  }

  function toggleFlag() {
    if (answers[i] == null) {
      setFlagWarn(true);
      return;
    }
    setFlagWarn(false);
    setFlagged((prev) => {
      const next = [...prev];
      next[i] = !next[i];
      return next;
    });
  }

  const hoursLabel =
    timerMinutes >= 330
      ? "5.5 hours"
      : timerMinutes >= 165
        ? "2 hours 45 minutes"
        : "1 hour 22.5 minutes";

  const header = (
    <header className="exam-header">
      <div className="exam-header-inner">
        <p className="exam-brand">Safepath CSP practice examination</p>
        {phase !== "intro" ? (
          <>
            <p className="exam-meta">
              {phase === "review" || phase === "confirm"
                ? "Review"
                : `Item ${i + 1} of ${n}`}
              {pace ? ` · ${pace}` : ""}
            </p>
            <p className={`exam-clock ${remain <= 300 ? "exam-clock-low" : ""}`} aria-live="polite">
              {hhmmss(remain)}
            </p>
            <button type="button" className="exam-header-btn" onClick={() => setCalcOpen(true)}>
              Calculator
            </button>
            <button type="button" className="exam-header-btn" onClick={() => setBreakOpen(true)}>
              Break
            </button>
            <button
              type="button"
              className="exam-header-btn"
              onClick={() => {
                setBreakOpen(false);
                setPhase("review");
              }}
            >
              Review
            </button>
            <button
              type="button"
              className="exam-header-btn exam-header-btn-end"
              onClick={() => {
                setBreakOpen(false);
                setPhase("confirm");
              }}
            >
              End Exam
            </button>
          </>
        ) : (
          <p className="exam-meta">
            {n} items · {hoursLabel}
            {pace ? ` · ${pace}` : ""}
          </p>
        )}
      </div>
    </header>
  );

  const calcModal = calcOpen ? (
    <div className="exam-modal" role="dialog" aria-modal="true" aria-label="Practice calculator">
      <div className="exam-modal-panel">
        <div className="exam-modal-bar">
          <span>Practice calculator (TI-30XS-style) — not Pearson software</span>
          <button type="button" className="exam-header-btn" onClick={() => setCalcOpen(false)}>
            Close
          </button>
        </div>
        <div className="exam-modal-body">
          <Calculator compact variant="exam" />
        </div>
      </div>
    </div>
  ) : null;

  const breakOverlay = breakOpen ? (
    <div className="exam-break" role="dialog" aria-modal="true" aria-label="Break overlay">
      <div className="exam-break-panel">
        <h2>Break overlay</h2>
        <p>
          The timer <strong>does not pause</strong>. Time remaining:{" "}
          <strong className={remain <= 300 ? "exam-clock-low" : ""}>{hhmmss(remain)}</strong>
        </p>
        <p className="exam-fine">This is a practice overlay only — not an official Pearson break screen.</p>
        <button type="button" className="exam-btn-primary" onClick={() => setBreakOpen(false)}>
          Resume exam
        </button>
      </div>
    </div>
  ) : null;

  if (phase === "intro") {
    return (
      <div className="exam-root">
        {header}
        <main className="exam-intro">
          <h1>Practice examination</h1>
          <p className="exam-lead">
            This sitting is a Safepath CSP computer-based practice examination aligned to the public CSP-11
            blueprint. Navigation matches a typical CBT pattern. It is not a Board of Certified Safety Professionals
            examination and is not Pearson VUE software.
          </p>
          <ul>
            <li>One item on screen at a time. You may select, change, skip, or flag for review.</li>
            <li>Previous / Next stay available until you confirm submit. Review is available anytime.</li>
            <li>
              Select an answer before you flag. If time ends, blanks stay blank.
            </li>
            <li>Closed book. No class notes, cards, formula library, or teach-back in exam mode.</li>
            <li>
              Practice calculator (TI-30XS-style) is available from the header — labeled practice, not Pearson.
            </li>
            <li>No formula sheet. Optional practice notes clear when you leave an item.</li>
            <li>DEG (degrees), not radians, unless a stem truly requires radians.</li>
            <li>Select the closest rounded listed value.</li>
            <li>Some items may be pretest and unscored. You will not be told which. Answer all of them.</li>
            <li>
              Length {n} items. Time allowed {hoursLabel} ({hhmmss(Math.round(timerMinutes * 60))})
              {pace ? ` · pacing ${pace}` : ""}. Domain weights 25 / 25 / 15 / 9 / 6 / 10 / 10.
            </li>
            <li>The break overlay does not stop the clock. Do not auto-advance — you control Next.</li>
          </ul>
          <div className="exam-intro-actions">
            <button type="button" className="exam-btn-primary" onClick={() => setPhase("sitting")}>
              Start
            </button>
            <Link href="/mock" className="exam-btn-secondary">
              Return
            </Link>
          </div>
        </main>
        {calcModal}
      </div>
    );
  }

  const navigator = (
    <nav className="exam-nav" aria-label="Item navigator">
      <p className="exam-nav-legend">
        <span className="exam-pill exam-pill-current">Current</span>
        <span className="exam-pill exam-pill-answered">Answered</span>
        <span className="exam-pill exam-pill-flag">Flagged</span>
        <span className="exam-pill">Blank</span>
      </p>
      <div className="exam-nav-grid">
        {items.map((_, idx) => {
          const current = phase === "sitting" && idx === i;
          const answered = answers[idx] != null;
          const flag = flagged[idx];
          const cls = [
            "exam-nav-cell",
            current ? "is-current" : "",
            answered ? "is-answered" : "",
            flag ? "is-flagged" : "",
          ]
            .filter(Boolean)
            .join(" ");
          return (
            <button
              key={idx}
              type="button"
              className={cls}
              onClick={() => jump(idx)}
              aria-current={current ? "true" : undefined}
              aria-label={`Item ${idx + 1}${answered ? ", answered" : ", blank"}${flag ? ", flagged" : ""}`}
            >
              {idx + 1}
              {flag ? <span className="exam-flag-dot" /> : null}
            </button>
          );
        })}
      </div>
    </nav>
  );

  if (phase === "confirm") {
    return (
      <div className="exam-root">
        {header}
        <main className="exam-intro">
          <h1>Submit examination?</h1>
          <p className="exam-lead">
            You cannot return after submit. Answered: {answeredCount} of {n}. Blank: {unansweredCount}. Flagged:{" "}
            {flaggedCount}.
          </p>
          <p className="exam-fine">
            Blanks stay blank if you submit now or if time has already ended. Feedback appears only after submit.
          </p>
          <div className="exam-intro-actions">
            <button type="button" className="exam-btn-primary" onClick={() => finish(false)}>
              Confirm submit — cannot return
            </button>
            <button type="button" className="exam-btn-secondary" onClick={() => setPhase("review")}>
              Back to review
            </button>
            <button type="button" className="exam-btn-secondary" onClick={() => setPhase("sitting")}>
              Return to items
            </button>
          </div>
        </main>
        {calcModal}
        {breakOverlay}
      </div>
    );
  }

  if (phase === "review") {
    const unanswered = items.map((_, idx) => (answers[idx] == null ? idx : -1)).filter((idx) => idx >= 0);
    const flaggedIdx = items.map((_, idx) => (flagged[idx] ? idx : -1)).filter((idx) => idx >= 0);
    return (
      <div className="exam-root">
        {header}
        <div className="exam-layout">
          {navigator}
          <main className="exam-main">
            <h1>Review before submit</h1>
            <p>
              Unanswered: <strong>{unansweredCount}</strong>. Flagged: <strong>{flaggedCount}</strong>. Answered:{" "}
              <strong>{answeredCount}</strong> of {n}.
              {allSeen ? " All items have been opened at least once." : ` Opened ${seenCount} of ${n}.`}
            </p>
            <p className="exam-fine">
              Select an answer before you flag. If time ends, blanks stay blank. Click an item number to open it and
              change your answer.
            </p>
            {unanswered.length ? (
              <p>
                Jump to blank:{" "}
                {unanswered.map((idx) => (
                  <button key={idx} type="button" className="exam-jump" onClick={() => jump(idx)}>
                    {idx + 1}
                  </button>
                ))}
              </p>
            ) : (
              <p>Every item has a response.</p>
            )}
            {flaggedIdx.length ? (
              <p>
                Jump to flagged:{" "}
                {flaggedIdx.map((idx) => (
                  <button key={idx} type="button" className="exam-jump" onClick={() => jump(idx)}>
                    {idx + 1}
                  </button>
                ))}
              </p>
            ) : (
              <p>No items flagged for review.</p>
            )}
            <div className="exam-intro-actions">
              <button type="button" className="exam-btn-primary" onClick={() => setPhase("confirm")}>
                Proceed to submit
              </button>
              <button type="button" className="exam-btn-secondary" onClick={() => setPhase("sitting")}>
                Return to items
              </button>
            </div>
          </main>
        </div>
        {calcModal}
        {breakOverlay}
      </div>
    );
  }

  if (!item) {
    return (
      <div className="exam-root">
        {header}
        <main className="exam-intro">
          <p>No items in this sitting.</p>
          <Link href="/mock" className="exam-btn-secondary">
            Return
          </Link>
        </main>
      </div>
    );
  }

  return (
    <div className="exam-root">
      {header}
      <div className="exam-layout">
        {navigator}
        <div className="exam-col">
          <main className="exam-main">
            <p className="exam-stem">{item.stem}</p>
            <div className="exam-options" role="radiogroup" aria-label="Answer choices">
              {item.options.map((opt, idx) => {
                const selected = answers[i] === idx;
                return (
                  <label key={idx} className={`exam-option ${selected ? "is-selected" : ""}`}>
                    <input
                      type="radio"
                      name={`exam-${item.id}`}
                      checked={selected}
                      onChange={() => choose(idx)}
                    />
                    <span className="exam-letter">{LETTERS[idx]}</span>
                    <span className="exam-option-text">{opt}</span>
                  </label>
                );
              })}
            </div>
            <p className="exam-fine">
              Select an answer before you flag. If time ends, blanks stay blank. You may change this answer until you
              confirm submit. No instant scoring during the sitting.
            </p>
            {flagWarn ? (
              <p className="exam-fine" role="alert" style={{ color: "#b45309", fontWeight: 600 }}>
                Select an answer before you flag for review.
              </p>
            ) : null}
            <label className="exam-notes">
              <span className="exam-fine">Practice notes (clears when you leave this item) — practice only</span>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={3}
                className="exam-notes-box"
                placeholder="Scratch work for this item only"
              />
            </label>
            {allSeen ? (
              <p className="exam-fine">
                All items have been seen.{" "}
                <button type="button" className="exam-jump" onClick={() => setPhase("review")}>
                  Open review list
                </button>
              </p>
            ) : null}
          </main>
          <footer className="exam-footer">
            <button
              type="button"
              className="exam-btn-secondary"
              disabled={i === 0}
              onClick={() => setI((x) => Math.max(0, x - 1))}
            >
              Previous
            </button>
            <button
              type="button"
              className={`exam-btn-secondary ${flagged[i] ? "is-flag-on" : ""}`}
              aria-pressed={flagged[i]}
              onClick={toggleFlag}
            >
              {flagged[i] ? "Flagged" : "Flag for review"}
            </button>
            <button type="button" className="exam-btn-secondary" onClick={() => setPhase("review")}>
              Review
            </button>
            <button
              type="button"
              className="exam-btn-primary"
              onClick={() => setI((x) => Math.min(items.length - 1, x + 1))}
              disabled={i + 1 >= items.length}
            >
              Next
            </button>
          </footer>
        </div>
      </div>
      {calcModal}
      {breakOverlay}
    </div>
  );
}
