"use client";

import { useEffect, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { DOMAIN_ICONS, CSP_DOMAIN_NAMES, CSP_DOMAIN_WEIGHTS } from "@/lib/assessment";
import { PLANNER_MODES, type ChoiceWeights, type PlannerMode } from "@/lib/planner";

const MODES: Array<{ id: PlannerMode; label: string; icon: string; blurb: string }> = [
  { id: "adaptive", label: "Adaptive", icon: "🧠", blurb: "Uses your latest diagnostic weaknesses." },
  { id: "mix", label: "Auto Mix", icon: "🔀", blurb: "Blends all domains by blueprint weight." },
  { id: "domain", label: "Domain by Domain", icon: "🧭", blurb: "Finishes one domain before the next starts." },
  { id: "choice", label: "My Choice", icon: "🎛️", blurb: "Choose order, domains, and material share." },
];

const DOMAIN_IDS = [1, 2, 3, 4, 5, 6, 7];

function clampPercent(value: number) {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(100, Math.round(value)));
}

function normalized(weights: ChoiceWeights, domains: number[]) {
  const total = domains.reduce((sum, d) => sum + (weights[d] ?? 0), 0);
  if (!total) {
    const equal = domains.length ? Math.floor(100 / domains.length) : 0;
    const next: ChoiceWeights = {};
    domains.forEach((d, index) => {
      next[d] = index === domains.length - 1 ? 100 - equal * Math.max(0, domains.length - 1) : equal;
    });
    return next;
  }
  const next: ChoiceWeights = {};
  const raw = domains.map((d) => ({ d, value: ((weights[d] ?? 0) / total) * 100 }));
  let allocated = 0;
  raw.forEach(({ d, value }) => {
    const rounded = Math.floor(value);
    next[d] = rounded;
    allocated += rounded;
  });
  const byRemainder = raw
    .map(({ d, value }) => ({ d, remainder: value - Math.floor(value) }))
    .sort((a, b) => b.remainder - a.remainder);
  for (let i = 0; i < 100 - allocated; i++) {
    next[byRemainder[i % byRemainder.length].d] += 1;
  }
  return next;
}

export function PlannerControls({
  selectedDomains,
  mode,
  choiceOrder,
  choiceWeights,
}: {
  selectedDomains: number[];
  mode: PlannerMode;
  choiceOrder: number[];
  choiceWeights: ChoiceWeights;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [localOrder, setLocalOrder] = useState<number[]>(choiceOrder.length ? choiceOrder : selectedDomains);
  const [localWeights, setLocalWeights] = useState<ChoiceWeights>(choiceWeights);
  const [dirty, setDirty] = useState(false);

  useEffect(() => {
    setLocalOrder(choiceOrder.length ? choiceOrder : selectedDomains);
    setLocalWeights(choiceWeights);
    setDirty(false);
  }, [choiceOrder, choiceWeights, selectedDomains]);

  function navigate(nextMode: PlannerMode, nextDomains = selectedDomains, nextOrder = localOrder, nextWeights = localWeights) {
    const params = new URLSearchParams(searchParams.toString());
    params.set("mode", nextMode);
    if (nextMode === "choice") {
      params.set("domains", nextDomains.join(","));
      params.set("order", nextOrder.join(","));
      const normalizedWeights = normalized(nextWeights, nextDomains);
      params.set("weights", nextDomains.map((d) => `${d}:${normalizedWeights[d] ?? 0}`).join(","));
    } else {
      params.delete("domains");
      params.delete("order");
      params.delete("weights");
    }
    router.push(`${pathname}?${params.toString()}`);
  }

  function toggleDomain(domain: number) {
    if (localOrder.includes(domain)) {
      const nextSelected = selectedDomains.filter((d) => d !== domain);
      if (!nextSelected.length) return;
      setLocalOrder(localOrder.filter((d) => d !== domain));
      setLocalWeights((current) => {
        const next = { ...current };
        delete next[domain];
        return next;
      });
      setDirty(true);
      return;
    }

    const nextSelected = [...selectedDomains, domain];
    const nextOrder = localOrder.filter((d) => nextSelected.includes(d));
    nextOrder.push(domain);
    setLocalOrder(nextOrder);
    setLocalWeights((current) => ({
      ...current,
      [domain]: CSP_DOMAIN_WEIGHTS[domain as keyof typeof CSP_DOMAIN_WEIGHTS],
    }));
    setDirty(true);
  }

  function move(domain: number, direction: -1 | 1) {
    const index = localOrder.indexOf(domain);
    const nextIndex = index + direction;
    if (index < 0 || nextIndex < 0 || nextIndex >= localOrder.length) return;
    const next = [...localOrder];
    [next[index], next[nextIndex]] = [next[nextIndex], next[index]];
    setLocalOrder(next);
    setDirty(true);
  }

  function setWeight(domain: number, value: string) {
    const nextValue = clampPercent(Number(value));
    setLocalWeights((current) => ({ ...current, [domain]: nextValue }));
    setDirty(true);
  }

  function normalizeShare() {
    setLocalWeights(normalized(localWeights, localOrder));
    setDirty(true);
  }

  function distributeBlueprint() {
    const next: ChoiceWeights = {};
    localOrder.forEach((d) => {
      next[d] = CSP_DOMAIN_WEIGHTS[d as keyof typeof CSP_DOMAIN_WEIGHTS];
    });
    setLocalWeights(normalized(next, localOrder));
    setDirty(true);
  }

  return (
    <section className="card overflow-hidden">
      <div className="border-b border-line bg-panel-2/45 p-5 sm:p-6">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="kicker">🎛️ Plan engine</p>
            <h2 className="mt-1 font-serif text-2xl">Choose how SafePath should schedule you</h2>
            <p className="mt-2 max-w-3xl text-sm text-muted">Switch strategy any time. Your curriculum and progress stay intact; only the upcoming schedule changes.</p>
          </div>
          <span className="chip">Current: {MODES.find((m) => m.id === mode)?.label ?? "Adaptive"}</span>
        </div>
        <div className="mt-5 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {MODES.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => navigate(item.id)}
              className={`planner-mode ${mode === item.id ? "is-active" : ""}`}
            >
              <span className="text-xl" aria-hidden>{item.icon}</span>
              <span className="min-w-0">
                <span className="block font-semibold">{item.label}</span>
                <span className="mt-1 block text-xs text-muted">{item.blurb}</span>
              </span>
            </button>
          ))}
        </div>
      </div>

      <div className="p-5 sm:p-6">
        {mode === "domain" ? (
          <div className="rounded-2xl border border-[var(--user-accent)]/30 bg-[var(--user-accent-soft)]/40 p-4">
            <div className="flex flex-wrap items-start gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-[var(--user-accent)]/40 bg-panel text-xl">🧭</div>
              <div className="min-w-0 flex-1">
                <p className="font-bold">True domain-block scheduling</p>
                <p className="mt-1 text-sm text-muted">
                  Week 1 stays inside D1 until D1 is finished. If D1 ends part-way through a week, the remaining time becomes review/recovery time — D2 does not start early. The same rule applies to every following domain.
                </p>
              </div>
            </div>
            <div className="mt-4 grid gap-2 sm:grid-cols-4 lg:grid-cols-7">
              {DOMAIN_IDS.map((domain) => (
                <div key={domain} className="rounded-xl border border-line bg-panel px-3 py-3 text-center">
                  <div className="text-lg" aria-hidden>{DOMAIN_ICONS[domain as keyof typeof DOMAIN_ICONS]}</div>
                  <div className="mt-1 text-xs font-bold">D{domain}</div>
                  <div className="mt-1 text-[10px] text-muted">Block {domain}</div>
                </div>
              ))}
            </div>
          </div>
        ) : mode === "choice" ? (
          <div className="space-y-5">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div>
                <p className="text-sm font-semibold">Build your own study sequence</p>
                <p className="mt-1 max-w-3xl text-xs text-muted">Choose the domains, move them into your preferred order, then set the percentage of your scheduled learning material allocated to each active domain. Shares are normalized to 100% when applied.</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <button type="button" onClick={distributeBlueprint} className="btn-ghost tap text-xs">↺ Use blueprint shares</button>
                <button type="button" onClick={normalizeShare} className="btn-ghost tap text-xs">⚖ Normalize to 100%</button>
              </div>
            </div>

            <div className="rounded-xl border border-line bg-panel-2/30 p-4">
              <div className="mb-3 flex items-center justify-between gap-3 text-xs">
                <span className="font-semibold">Material allocation</span>
                <span className="chip">{localOrder.reduce((sum, d) => sum + (localWeights[d] ?? 0), 0)}% entered</span>
              </div>
              <div className="h-3 overflow-hidden rounded-full bg-panel-2">
                {localOrder.map((d) => (
                  <span
                    key={d}
                    className="inline-block h-full border-r border-panel first:border-l"
                    style={{
                      width: `${Math.max(0, Math.min(100, localWeights[d] ?? 0))}%`,
                      background: `color-mix(in srgb, var(--user-accent) ${30 + d * 8}%, #17263a)`,
                    }}
                    title={`D${d}: ${localWeights[d] ?? 0}%`}
                  />
                ))}
              </div>
            </div>

            <div className="grid gap-3">
              {localOrder.map((domain, index) => {
                const active = localOrder.includes(domain);
                const weight = localWeights[domain] ?? 0;
                return (
                  <div key={domain} className={`rounded-2xl border p-4 transition ${active ? "border-[var(--user-accent)]/45 bg-panel" : "border-line bg-panel-2/20 opacity-70"}`}>
                    <div className="flex flex-wrap items-center gap-3">
                      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-line bg-panel-2 text-xl" aria-hidden>
                        {DOMAIN_ICONS[domain as keyof typeof DOMAIN_ICONS]}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="rounded-full bg-[var(--user-accent-soft)] px-2 py-1 text-[10px] font-black uppercase tracking-wider text-[var(--user-accent)]">Priority {index + 1}</span>
                          <span className="font-bold">D{domain}</span>
                          <span className="text-xs text-muted">Blueprint {CSP_DOMAIN_WEIGHTS[domain as keyof typeof CSP_DOMAIN_WEIGHTS]}%</span>
                        </div>
                        <p className="mt-1 truncate text-sm font-semibold">{CSP_DOMAIN_NAMES[domain as keyof typeof CSP_DOMAIN_NAMES]}</p>
                      </div>

                      <div className="flex items-center gap-1 rounded-xl border border-line bg-panel-2 p-1">
                        <button type="button" onClick={() => move(domain, -1)} disabled={index === 0} className="planner-icon-button" aria-label={`Move D${domain} up`}>↑</button>
                        <button type="button" onClick={() => move(domain, 1)} disabled={index === localOrder.length - 1} className="planner-icon-button" aria-label={`Move D${domain} down`}>↓</button>
                      </div>

                      <label className="flex items-center gap-2 text-xs font-semibold">
                        <span>Material</span>
                        <input
                          type="number"
                          inputMode="numeric"
                          min={0}
                          max={100}
                          value={weight}
                          onChange={(event) => setWeight(domain, event.target.value)}
                          className="w-20 rounded-xl border border-line bg-panel px-3 py-2 text-right font-mono font-bold outline-none ring-offset-2 focus:ring-2 focus:ring-[var(--user-accent)]"
                          aria-label={`D${domain} material percentage`}
                        />
                        <span>%</span>
                      </label>

                      <button
                        type="button"
                        onClick={() => toggleDomain(domain)}
                        className={`rounded-xl border px-3 py-2 text-xs font-bold transition ${active ? "border-bad/35 bg-bad/10 text-bad" : "border-[var(--user-accent)]/35 bg-[var(--user-accent-soft)] text-[var(--user-accent)]"}`}
                      >
                        {active ? "Remove" : "Add"}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
              {DOMAIN_IDS.filter((domain) => !localOrder.includes(domain)).map((domain) => (
                <button key={domain} type="button" onClick={() => toggleDomain(domain)} className="domain-choice">
                  <span className="domain-choice-icon" aria-hidden>{DOMAIN_ICONS[domain as keyof typeof DOMAIN_ICONS]}</span>
                  <span className="min-w-0 text-left">
                    <span className="block text-xs font-bold">Add D{domain}</span>
                    <span className="mt-1 block truncate text-sm text-muted">{CSP_DOMAIN_NAMES[domain as keyof typeof CSP_DOMAIN_NAMES]}</span>
                  </span>
                </button>
              ))}
            </div>

            {dirty ? (
              <div className="sticky bottom-3 z-10 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[var(--user-accent)]/40 bg-panel/95 p-3 shadow-xl backdrop-blur">
                <p className="text-xs text-muted">Your custom order and percentages are ready.</p>
                <button
                  type="button"
                  onClick={() => navigate("choice", localOrder, localOrder, localWeights)}
                  className="btn-primary tap"
                >
                  Apply My Plan →
                </button>
              </div>
            ) : null}
          </div>
        ) : (
          <div className="grid gap-3 md:grid-cols-3">
            <div className="planner-tip"><span>1</span><p><strong>Schedule</strong><br />The next weeks are regenerated from the chosen strategy.</p></div>
            <div className="planner-tip"><span>2</span><p><strong>Study</strong><br />Every scheduled class has a direct lesson launch.</p></div>
            <div className="planner-tip"><span>3</span><p><strong>Recalibrate</strong><br />Retake a diagnostic and Adaptive mode can change the priority.</p></div>
          </div>
        )}
      </div>
    </section>
  );
}
