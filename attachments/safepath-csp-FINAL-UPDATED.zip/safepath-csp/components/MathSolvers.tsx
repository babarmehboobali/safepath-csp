"use client";

import { useMemo, useState } from "react";
import Link from "next/link";

const FIELD = "mt-1 w-full rounded-xl border border-line bg-ink px-3 py-2.5 text-cream";
const LABEL = "block text-sm text-muted";

type NoiseRow = { level: string; hours: string };

function num(s: string) {
  const n = Number(s);
  return Number.isFinite(n) ? n : NaN;
}

export function MathSolvers() {
  const [noiseRows, setNoiseRows] = useState<NoiseRow[]>([
    { level: "95", hours: "3.5" },
    { level: "", hours: "" },
  ]);
  const [noiseOut, setNoiseOut] = useState<string[] | null>(null);

  const [er, setEr] = useState("1.8");
  const [sg, setSg] = useState("0.87");
  const [mw, setMw] = useState("92.14");
  const [k, setK] = useState("4");
  const [tlv, setTlv] = useState("50");
  const [dilOut, setDilOut] = useState<string[] | null>(null);

  const [weight, setWeight] = useState("16000");
  const [angle, setAngle] = useState("45");
  const [slingOut, setSlingOut] = useState<string[] | null>(null);

  const [hours, setHours] = useState("200000");
  const [recordables, setRecordables] = useState("4");
  const [dartCases, setDartCases] = useState("2");
  const [rateOut, setRateOut] = useState<string[] | null>(null);

  const slingWarn = useMemo(() => {
    const a = num(angle);
    return Number.isFinite(a) && a > 0 && a < 30;
  }, [angle]);

  function runNoise() {
    const parts: { L: number; C: number; T: number; frac: number }[] = [];
    for (const row of noiseRows) {
      const L = num(row.level);
      const C = num(row.hours);
      if (!row.level.trim() && !row.hours.trim()) continue;
      if (!(L > 0) || !(C > 0)) {
        setNoiseOut(["Enter positive dBA and hours for each used row."]);
        return;
      }
      const T = 8 / Math.pow(2, (L - 90) / 5);
      parts.push({ L, C, T, frac: C / T });
    }
    if (!parts.length) {
      setNoiseOut(["Add at least one exposure row."]);
      return;
    }
    const dose = parts.reduce((s, p) => s + p.frac, 0) * 100;
    const twa = 16.61 * Math.log10(dose / 100) + 90;
    const status =
      twa >= 90 ? "PEL exceeded (≥90 dBA TWA)" : twa >= 85 ? "Action level exceeded (≥85 dBA TWA)" : "Below action level";
    const lines = [
      "OSHA 5 dB exchange · criterion 90 dBA",
      ...parts.map(
        (p, i) =>
          `Row ${i + 1}: T = 8 / 2^((${p.L}-90)/5) = ${p.T.toFixed(3)} h; C/T = ${p.C}/${p.T.toFixed(3)} = ${p.frac.toFixed(4)}`,
      ),
      parts.length > 1
        ? `Dose % = 100 × Σ(Ci/Ti) = ${dose.toFixed(1)}%`
        : `Dose % = (C/T)×100 = ${dose.toFixed(1)}%`,
      `8-hr TWA = 16.61 × log10(Dose/100) + 90 = ${twa.toFixed(2)} dBA`,
      status,
    ];
    setNoiseOut(lines);
  }

  function runDilution() {
    const ER = num(er);
    const SG = num(sg);
    const MW = num(mw);
    const K = num(k);
    const TLV = num(tlv);
    if (!(ER > 0 && SG > 0 && MW > 0 && K > 0 && TLV > 0)) {
      setDilOut(["Fill every dilution variable with a positive number."]);
      return;
    }
    // ER in pints/hour → divide by 60 so the classic 403×10⁶ constant (built for pints/min) still applies.
    const Q = (403_000_000 * SG * ER * K) / (MW * TLV * 60);
    setDilOut([
      "Constant 403×10⁶ converts SG×ER (US customary vapor generation) into cfm-scale airflow for a ppm target.",
      "This solver takes ER in pints/hour, so the formula divides by 60 (minutes per hour).",
      "Equation desk form without ÷60 expects ER in pints/min — same constant, different ER clock.",
      `Q = (403,000,000 × SG × ER × K) / (MW × TLV × 60)`,
      `Q = (403,000,000 × ${SG} × ${ER} × ${K}) / (${MW} × ${TLV} × 60)`,
      `Q ≈ ${Math.round(Q).toLocaleString()} cfm to hold ≈ ${TLV} ppm with K = ${K}`,
    ]);
  }

  function runSling() {
    const W = num(weight);
    const theta = num(angle);
    if (!(W > 0) || !(theta > 0) || theta > 90) {
      setSlingOut(["Enter positive load and angle between 0° and 90° from horizontal."]);
      return;
    }
    const rad = (theta * Math.PI) / 180; // degrees → radians for sin
    const tension = W / (2 * Math.sin(rad));
    const laf = 1 / Math.sin(rad);
    const lines = [
      "Two-leg bridle · θ measured from horizontal · sin() uses degrees converted to radians",
      `T = (W/2) / sin(θ) = (${W}/2) / sin(${theta}°) = ${Math.round(tension).toLocaleString()} lb per leg`,
      `Load angle factor 1/sin(θ) = ${laf.toFixed(3)}`,
    ];
    if (theta < 30) {
      lines.push("Warning: θ < 30° from horizontal — leg tension rises sharply; prefer a steeper hitch when the stem allows.");
    }
    setSlingOut(lines);
  }

  function runRates() {
    const H = num(hours);
    const N = num(recordables);
    const D = num(dartCases);
    if (!(H > 0) || N < 0 || D < 0 || Number.isNaN(N) || Number.isNaN(D)) {
      setRateOut(["Enter hours > 0 and non-negative case counts."]);
      return;
    }
    const trir = (N * 200_000) / H;
    const dart = (D * 200_000) / H;
    setRateOut([
      "Base 200,000 = 100 FTE × 2,000 hours",
      `TRIR = (N × 200,000) / hours = (${N} × 200,000) / ${H.toLocaleString()} = ${trir.toFixed(2)}`,
      `DART = (DART cases × 200,000) / hours = (${D} × 200,000) / ${H.toLocaleString()} = ${dart.toFixed(2)}`,
      "First aid alone is not a DART case.",
    ]);
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="kicker">Live solvers · step traces</p>
          <h2 className="font-serif text-2xl">Noise, dilution, sling, TRIR/DART</h2>
        </div>
        <Link href="/formulas" className="btn-ghost tap text-sm">
          Equation desk
        </Link>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <article className="card space-y-3 p-5">
          <h3 className="font-serif text-xl">OSHA noise dose & TWA</h3>
          <p className="text-sm text-muted">T = 8 / 2^((L−90)/5); Dose = 100 × Σ(Ci/Ti); TWA = 16.61 log10(Dose/100) + 90</p>
          {noiseRows.map((row, idx) => (
            <div key={idx} className="grid grid-cols-2 gap-2">
              <label className="block">
                <span className={LABEL}>Level dBA {idx + 1}</span>
                <input
                  className={FIELD}
                  value={row.level}
                  onChange={(e) => {
                    const next = [...noiseRows];
                    next[idx] = { ...row, level: e.target.value };
                    setNoiseRows(next);
                    setNoiseOut(null);
                  }}
                />
              </label>
              <label className="block">
                <span className={LABEL}>Hours {idx + 1}</span>
                <input
                  className={FIELD}
                  value={row.hours}
                  onChange={(e) => {
                    const next = [...noiseRows];
                    next[idx] = { ...row, hours: e.target.value };
                    setNoiseRows(next);
                    setNoiseOut(null);
                  }}
                />
              </label>
            </div>
          ))}
          {noiseRows.length < 4 ? (
            <button
              type="button"
              className="btn-ghost tap text-sm"
              onClick={() => setNoiseRows((r) => [...r, { level: "", hours: "" }])}
            >
              Add exposure row
            </button>
          ) : null}
          <button type="button" className="btn-primary w-full tap" onClick={runNoise}>
            Calculate dose & TWA
          </button>
          {noiseOut ? (
            <pre className="whitespace-pre-wrap rounded-xl border border-line bg-ink p-3 font-mono text-xs text-muted">
              {noiseOut.join("\n")}
            </pre>
          ) : null}
        </article>

        <article className="card space-y-3 p-5">
          <h3 className="font-serif text-xl">Dilution exhaust (cfm)</h3>
          <p className="text-sm text-muted">
            Q = (403×10⁶ × SG × ER × K) / (MW × TLV × 60) with ER in pints/hour
          </p>
          {(
            [
              ["Evaporation rate ER (pints/hr)", er, setEr],
              ["Specific gravity SG", sg, setSg],
              ["Molecular weight MW", mw, setMw],
              ["Mixing factor K (1–10)", k, setK],
              ["Target TLV / C (ppm)", tlv, setTlv],
            ] as const
          ).map(([label, val, set]) => (
            <label key={label} className="block">
              <span className={LABEL}>{label}</span>
              <input
                className={FIELD}
                value={val}
                onChange={(e) => {
                  set(e.target.value);
                  setDilOut(null);
                }}
              />
            </label>
          ))}
          <button type="button" className="btn-primary w-full tap" onClick={runDilution}>
            Calculate airflow
          </button>
          {dilOut ? (
            <pre className="whitespace-pre-wrap rounded-xl border border-line bg-ink p-3 font-mono text-xs text-muted">
              {dilOut.join("\n")}
            </pre>
          ) : null}
        </article>

        <article className="card space-y-3 p-5">
          <h3 className="font-serif text-xl">Two-leg bridle tension</h3>
          <p className="text-sm text-muted">T = (W/2) / sin(θ) · θ from horizontal · calculator DEG</p>
          <label className="block">
            <span className={LABEL}>Gross load W (lb)</span>
            <input
              className={FIELD}
              value={weight}
              onChange={(e) => {
                setWeight(e.target.value);
                setSlingOut(null);
              }}
            />
          </label>
          <label className="block">
            <span className={LABEL}>Horizontal sling angle θ (°)</span>
            <input
              className={FIELD}
              value={angle}
              onChange={(e) => {
                setAngle(e.target.value);
                setSlingOut(null);
              }}
            />
          </label>
          {slingWarn ? (
            <p className="rounded-lg border border-amber/40 bg-panel-2 px-3 py-2 text-sm text-amber">
              θ under 30° — tension climbs fast. Prefer a steeper angle when possible.
            </p>
          ) : null}
          <button type="button" className="btn-primary w-full tap" onClick={runSling}>
            Calculate leg tension
          </button>
          {slingOut ? (
            <pre className="whitespace-pre-wrap rounded-xl border border-line bg-ink p-3 font-mono text-xs text-muted">
              {slingOut.join("\n")}
            </pre>
          ) : null}
        </article>

        <article className="card space-y-3 p-5">
          <h3 className="font-serif text-xl">TRIR & DART</h3>
          <p className="text-sm text-muted">(N × 200,000) / hours worked</p>
          <label className="block">
            <span className={LABEL}>Total hours worked</span>
            <input
              className={FIELD}
              value={hours}
              onChange={(e) => {
                setHours(e.target.value);
                setRateOut(null);
              }}
            />
          </label>
          <label className="block">
            <span className={LABEL}>Recordable cases N</span>
            <input
              className={FIELD}
              value={recordables}
              onChange={(e) => {
                setRecordables(e.target.value);
                setRateOut(null);
              }}
            />
          </label>
          <label className="block">
            <span className={LABEL}>DART cases</span>
            <input
              className={FIELD}
              value={dartCases}
              onChange={(e) => {
                setDartCases(e.target.value);
                setRateOut(null);
              }}
            />
          </label>
          <button type="button" className="btn-primary w-full tap" onClick={runRates}>
            Compute rates
          </button>
          {rateOut ? (
            <pre className="whitespace-pre-wrap rounded-xl border border-line bg-ink p-3 font-mono text-xs text-muted">
              {rateOut.join("\n")}
            </pre>
          ) : null}
        </article>
      </div>
    </div>
  );
}
