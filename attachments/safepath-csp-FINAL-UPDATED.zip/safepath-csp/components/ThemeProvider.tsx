"use client";

import { createContext, useContext, useEffect, useMemo, useState } from "react";

export const THEME_PRESETS = {
  midnight: {
    label: "Midnight Pro",
    description: "Deep navy, electric lime, calm for long study sessions.",
    bg: "#071322",
    panel: "#102238",
    panel2: "#172e47",
    text: "#f4f7fb",
    muted: "#a8b9cc",
    border: "#2d4966",
    accent: "#7cdb3a",
    accent2: "#b6f36e",
  },
  ocean: {
    label: "Ocean Focus",
    description: "Cool blue surfaces with a bright cyan learning accent.",
    bg: "#071a2a",
    panel: "#0f2a3f",
    panel2: "#173b55",
    text: "#f2fbff",
    muted: "#a7c6d7",
    border: "#2f5872",
    accent: "#31c5f4",
    accent2: "#7be7ff",
  },
  forest: {
    label: "Safety Forest",
    description: "Professional green safety language with warm highlights.",
    bg: "#081a15",
    panel: "#102b22",
    panel2: "#173a2e",
    text: "#f3faf6",
    muted: "#a8c7bb",
    border: "#315748",
    accent: "#72d572",
    accent2: "#b7f2a5",
  },
  slate: {
    label: "Slate Minimal",
    description: "Neutral, low-distraction workspace for dense reading.",
    bg: "#111827",
    panel: "#1f2937",
    panel2: "#273548",
    text: "#f8fafc",
    muted: "#b7c2d0",
    border: "#435166",
    accent: "#f0c75e",
    accent2: "#ffe29a",
  },
  highContrast: {
    label: "High Contrast",
    description: "Maximum separation for navigation, cards and study text.",
    bg: "#050505",
    panel: "#121212",
    panel2: "#1d1d1d",
    text: "#ffffff",
    muted: "#e2e8f0",
    border: "#64748b",
    accent: "#a3ff12",
    accent2: "#d5ff75",
  },
} as const;

export const ACCENTS = [
  ["lime", "#7cdb3a"],
  ["cyan", "#31c5f4"],
  ["violet", "#a78bfa"],
  ["rose", "#fb7185"],
  ["amber", "#f5c451"],
  ["orange", "#fb923c"],
] as const;

export type ThemePreset = keyof typeof THEME_PRESETS;
export type Density = "comfortable" | "compact";
export type LayoutStyle = "focus" | "wide" | "cards";

export type ThemeSettings = {
  themePreset: ThemePreset;
  accentColor: string;
  density: Density;
  layoutStyle: LayoutStyle;
};

const DEFAULTS: ThemeSettings = {
  themePreset: "midnight",
  accentColor: "#7cdb3a",
  density: "comfortable",
  layoutStyle: "focus",
};

const ThemeContext = createContext<{
  settings: ThemeSettings;
  setSettings: (settings: ThemeSettings) => void;
} | null>(null);

function validPreset(value: unknown): ThemePreset {
  return typeof value === "string" && value in THEME_PRESETS ? (value as ThemePreset) : DEFAULTS.themePreset;
}

function validDensity(value: unknown): Density {
  return value === "compact" ? "compact" : "comfortable";
}

function validLayout(value: unknown): LayoutStyle {
  return value === "wide" || value === "cards" ? value : "focus";
}

export function normalizeTheme(input?: Partial<ThemeSettings> | null): ThemeSettings {
  return {
    themePreset: validPreset(input?.themePreset),
    accentColor: typeof input?.accentColor === "string" && /^#[0-9a-f]{6}$/i.test(input.accentColor) ? input.accentColor : DEFAULTS.accentColor,
    density: validDensity(input?.density),
    layoutStyle: validLayout(input?.layoutStyle),
  };
}

export function ThemeProvider({
  initial,
  children,
  storageKey = "safepath-theme",
}: {
  initial?: Partial<ThemeSettings>;
  storageKey?: string;
  children: React.ReactNode;
}) {
  const [settings, setSettings] = useState<ThemeSettings>(() => normalizeTheme(initial));
  const preset = THEME_PRESETS[settings.themePreset];

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(storageKey);
      if (saved) setSettings((current) => normalizeTheme({ ...current, ...JSON.parse(saved) }));
    } catch {
      // Ignore malformed local preferences.
    }
  }, [storageKey]);

  useEffect(() => {
    const root = document.documentElement;
    root.dataset.theme = settings.themePreset;
    root.dataset.density = settings.density;
    root.dataset.layout = settings.layoutStyle;
    root.style.setProperty("--user-accent", settings.accentColor);
    root.style.setProperty("--user-accent-soft", `${settings.accentColor}22`);
    root.style.setProperty("--user-accent-strong", `${settings.accentColor}44`);
    root.style.setProperty("--theme-bg", preset.bg);
    root.style.setProperty("--theme-panel", preset.panel);
    root.style.setProperty("--theme-panel-2", preset.panel2);
    root.style.setProperty("--theme-text", preset.text);
    root.style.setProperty("--theme-muted", preset.muted);
    root.style.setProperty("--theme-border", preset.border);
    root.style.setProperty("--theme-accent-2", preset.accent2);
    try {
      window.localStorage.setItem(storageKey, JSON.stringify(settings));
    } catch {
      // Storage is optional; database remains the persistent source.
    }
  }, [settings, preset, storageKey]);

  const value = useMemo(() => ({ settings, setSettings }), [settings]);
  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme() {
  const value = useContext(ThemeContext);
  if (!value) throw new Error("useTheme must be used inside ThemeProvider");
  return value;
}
