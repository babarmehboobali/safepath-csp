"use client";

import { useMemo, useState } from "react";
import Link from "next/link";

const SELECT =
  "mt-1 w-full rounded-xl border border-line bg-ink px-3 py-2.5 text-cream";
const LABEL = "block text-sm text-muted";

const RULA_UPPER = [
  { v: 1, t: "20° extension to 20° flexion (1)" },
  { v: 2, t: "20°–45° flexion or >20° extension (2)" },
  { v: 3, t: "45°–90° flexion (3)" },
  { v: 4, t: ">90° flexion (4)" },
];
const RULA_FORE = [
  { v: 1, t: "Flexion 60°–100° (1)" },
  { v: 2, t: "Flexion <60° or >100° (2)" },
];
const RULA_WRIST = [
  { v: 1, t: "Neutral (1)" },
  { v: 2, t: "0°–15° flexion/extension (2)" },
  { v: 3, t: ">15° with twist (3)" },
];
const RULA_NECK = [
  { v: 1, t: "0°–10° flexion (1)" },
  { v: 2, t: "10°–20° flexion (2)" },
  { v: 3, t: ">20° flexion or extension (3)" },
];
const RULA_TRUNK = [
  { v: 1, t: "Supported upright / 0° (1)" },
  { v: 2, t: "0°–20° flexion (2)" },
  { v: 3, t: "20°–60° flexion (3)" },
  { v: 4, t: ">60° flexion (4)" },
];
const RULA_LEGS = [
  { v: 1, t: "Legs and feet supported (1)" },
  { v: 2, t: "Not evenly supported (2)" },
];
const RULA_MUSCLE = [
  { v: 0, t: "Intermittent (<1 min or <4/min) (0)" },
  { v: 1, t: "Static >1 min or repeat >4/min (1)" },
];
const RULA_FORCE = [
  { v: 0, t: "Load <2 kg intermittent (0)" },
  { v: 1, t: "2–10 kg intermittent (1)" },
  { v: 2, t: "2–10 kg static/repeat or ≥10 kg intermittent (2)" },
  { v: 3, t: "≥10 kg static/repeat or shock (3)" },
];

function rulaAction(score: number) {
  if (score <= 2) return { level: 1, text: "Action level 1 — acceptable if not held or repeated for long periods." };
  if (score <= 4) return { level: 2, text: "Action level 2 — investigate further; changes may be needed." };
  if (score <= 6) return { level: 3, text: "Action level 3 — investigate and change soon." };
  return { level: 4, text: "Action level 4 — investigate and change immediately." };
}

function rebaRisk(score: number) {
  if (score <= 1) return "Negligible — no action needed.";
  if (score <= 3) return "Low — change may be needed.";
  if (score <= 7) return "Medium — action required soon.";
  if (score <= 10) return "High — action required promptly.";
  return "Very high — implement change now.";
}

export function ErgoDesk() {
  const [uArm, setUArm] = useState(2);
  const [fArm, setFArm] = useState(1);
  const [wrist, setWrist] = useState(2);
  const [neck, setNeck] = useState(2);
  const [trunk, setTrunk] = useState(2);
  const [legs, setLegs] = useState(1);
  const [muscle, setMuscle] = useState(0);
  const [force, setForce] = useState(0);
  const [rulaOn, setRulaOn] = useState(false);

  const [rebaTrunk, setRebaTrunk] = useState(2);
  const [rebaNeck, setRebaNeck] = useState(1);
  const [rebaLegs, setRebaLegs] = useState(1);
  const [rebaArms, setRebaArms] = useState(3);
  const [rebaLoad, setRebaLoad] = useState(1);
  const [rebaCouple, setRebaCouple] = useState(1);
  const [rebaOn, setRebaOn] = useState(false);

  const rula = useMemo(() => {
    const postureA = Math.min(9, uArm + fArm + wrist);
    const postureB = Math.min(9, neck + trunk + legs);
    const scoreA = Math.min(9, postureA + muscle + force);
    const scoreB = Math.min(9, postureB + muscle + force);
    // Teaching estimator — NOT published Table C. Combines A/B with a capped mean, then clamps 1–7.
    const grand = Math.min(7, Math.max(1, Math.round((scoreA + scoreB) / 2)));
    return { postureA, postureB, scoreA, scoreB, grand, action: rulaAction(grand) };
  }, [uArm, fArm, wrist, neck, trunk, legs, muscle, force]);

  const reba = useMemo(() => {
    const groupA = rebaTrunk + rebaNeck + rebaLegs + rebaLoad;
    const groupB = rebaArms + rebaCouple;
    // Teaching estimator — NOT published REBA Table C. Scaled blend of A/B, clamped 1–15.
    const grand = Math.min(15, Math.max(1, Math.round((groupA + groupB) / 1.5) + 1));
    return { groupA, groupB, grand, risk: rebaRisk(grand) };
  }, [rebaTrunk, rebaNeck, rebaLegs, rebaArms, rebaLoad, rebaCouple]);

  return (
    <div className="space-y-6">
      <p className="rounded-xl border border-amber/40 bg-panel-2 px-4 py-3 text-sm text-cream">
        Teaching approximation — not a substitute for published RULA/REBA tables. Scores here train posture
        language and action-level bands. Field decisions need the official lookup tables and trained observers.
      </p>

      <div className="grid gap-4 lg:grid-cols-2">
        <article className="card space-y-3 p-5">
          <p className="kicker">RULA · upper limb</p>
          <h2 className="font-serif text-xl">Rapid Upper Limb Assessment</h2>
          <p className="text-sm text-muted">
            Posture scores for arm, wrist, neck, trunk, and legs, plus simple muscle/force additives. Grand score is a
            study estimator, not Table C.
          </p>
          {(
            [
              ["Upper arm", uArm, setUArm, RULA_UPPER],
              ["Forearm", fArm, setFArm, RULA_FORE],
              ["Wrist", wrist, setWrist, RULA_WRIST],
              ["Neck", neck, setNeck, RULA_NECK],
              ["Trunk", trunk, setTrunk, RULA_TRUNK],
              ["Legs", legs, setLegs, RULA_LEGS],
              ["Muscle use", muscle, setMuscle, RULA_MUSCLE],
              ["Force / load", force, setForce, RULA_FORCE],
            ] as const
          ).map(([label, val, set, opts]) => (
            <label key={label} className="block">
              <span className={LABEL}>{label}</span>
              <select
                className={SELECT}
                value={val}
                onChange={(e) => {
                  set(Number(e.target.value));
                  setRulaOn(false);
                }}
              >
                {opts.map((o) => (
                  <option key={o.v} value={o.v}>
                    {o.t}
                  </option>
                ))}
              </select>
            </label>
          ))}
          <button type="button" className="btn-primary w-full tap" onClick={() => setRulaOn(true)}>
            Estimate RULA score
          </button>
          {rulaOn ? (
            <div className="space-y-2 rounded-xl border border-line bg-ink p-4 text-sm">
              <p className="font-mono text-lg text-amber">Estimator grand score: {rula.grand} (1–7)</p>
              <p className="font-semibold">Action level {rula.action.level}. {rula.action.text}</p>
              <pre className="whitespace-pre-wrap font-mono text-xs text-muted">{`Step 1 — Posture A (arm+forearm+wrist) = ${uArm}+${fArm}+${wrist} → ${rula.postureA}
Step 2 — Score A = posture A + muscle + force = ${rula.postureA}+${muscle}+${force} → ${rula.scoreA}
Step 3 — Posture B (neck+trunk+legs) = ${neck}+${trunk}+${legs} → ${rula.postureB}
Step 4 — Score B = posture B + muscle + force = ${rula.postureB}+${muscle}+${force} → ${rula.scoreB}
Step 5 — Teaching grand ≈ round((A+B)/2), clamp 1–7 → ${rula.grand}
(Not the published RULA Table C lookup.)`}</pre>
            </div>
          ) : null}
        </article>

        <article className="card space-y-3 p-5">
          <p className="kicker">REBA · whole body</p>
          <h2 className="font-serif text-xl">Rapid Entire Body Assessment</h2>
          <p className="text-sm text-muted">
            Trunk, neck, legs, upper extremity, load, and coupling inputs. Grand score is a study estimator, not the
            published REBA tables.
          </p>
          <label className="block">
            <span className={LABEL}>Trunk score (1 upright → 5 extreme)</span>
            <input
              type="number"
              min={1}
              max={5}
              className={SELECT}
              value={rebaTrunk}
              onChange={(e) => {
                setRebaTrunk(Number(e.target.value));
                setRebaOn(false);
              }}
            />
          </label>
          <label className="block">
            <span className={LABEL}>Neck score (1–3)</span>
            <input
              type="number"
              min={1}
              max={3}
              className={SELECT}
              value={rebaNeck}
              onChange={(e) => {
                setRebaNeck(Number(e.target.value));
                setRebaOn(false);
              }}
            />
          </label>
          <label className="block">
            <span className={LABEL}>Legs score (1–4)</span>
            <input
              type="number"
              min={1}
              max={4}
              className={SELECT}
              value={rebaLegs}
              onChange={(e) => {
                setRebaLegs(Number(e.target.value));
                setRebaOn(false);
              }}
            />
          </label>
          <label className="block">
            <span className={LABEL}>Upper extremity composite (1–6)</span>
            <input
              type="number"
              min={1}
              max={6}
              className={SELECT}
              value={rebaArms}
              onChange={(e) => {
                setRebaArms(Number(e.target.value));
                setRebaOn(false);
              }}
            />
          </label>
          <label className="block">
            <span className={LABEL}>Load / force</span>
            <select
              className={SELECT}
              value={rebaLoad}
              onChange={(e) => {
                setRebaLoad(Number(e.target.value));
                setRebaOn(false);
              }}
            >
              <option value={0}>&lt;11 lb (&lt;5 kg) (0)</option>
              <option value={1}>11–22 lb (5–10 kg) (1)</option>
              <option value={2}>&gt;22 lb (&gt;10 kg) (2)</option>
              <option value={3}>Shock / rapid build-up (3)</option>
            </select>
          </label>
          <label className="block">
            <span className={LABEL}>Coupling</span>
            <select
              className={SELECT}
              value={rebaCouple}
              onChange={(e) => {
                setRebaCouple(Number(e.target.value));
                setRebaOn(false);
              }}
            >
              <option value={0}>Good handles (0)</option>
              <option value={1}>Fair (1)</option>
              <option value={2}>Poor (2)</option>
              <option value={3}>Unacceptable (3)</option>
            </select>
          </label>
          <button type="button" className="btn-primary w-full tap" onClick={() => setRebaOn(true)}>
            Estimate REBA score
          </button>
          {rebaOn ? (
            <div className="space-y-2 rounded-xl border border-line bg-ink p-4 text-sm">
              <p className="font-mono text-lg text-amber">Estimator score: {reba.grand} (1–15)</p>
              <p className="font-semibold">{reba.risk}</p>
              <pre className="whitespace-pre-wrap font-mono text-xs text-muted">{`Step 1 — Group A = trunk+neck+legs+load = ${rebaTrunk}+${rebaNeck}+${rebaLegs}+${rebaLoad} → ${reba.groupA}
Step 2 — Group B = arms+coupling = ${rebaArms}+${rebaCouple} → ${reba.groupB}
Step 3 — Teaching grand ≈ round((A+B)/1.5)+1, clamp 1–15 → ${reba.grand}
(Not the published REBA Table C lookup.)`}</pre>
            </div>
          ) : null}
        </article>
      </div>

      <article className="card p-5">
        <p className="kicker">Related</p>
        <h2 className="mt-1 font-serif text-xl">NIOSH recommended weight limit</h2>
        <p className="mt-2 text-sm text-muted">
          Full RWL needs six multipliers (HM, VM, DM, AM, FM, CM) on LC = 51 lb. Use the math gym and equation desk —
          this page does not fake a six-multiplier worksheet.
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          <Link href="/math?topic=rwl" className="btn-primary tap">
            NIOSH RWL math topic
          </Link>
          <Link href="/formulas" className="btn-ghost tap">
            Equation desk
          </Link>
        </div>
      </article>
    </div>
  );
}
