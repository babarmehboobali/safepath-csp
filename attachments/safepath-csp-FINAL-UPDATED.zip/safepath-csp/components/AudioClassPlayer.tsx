"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { usePathname } from "next/navigation";

const SPEEDS = [0.85, 1, 1.2, 1.4] as const;
const SENTENCE_SPLIT_REGEX = /(?<=[.?!])\s+/;

export type AudioPracticeItem = {
  stem: string;
  options: string[];
};

export type AudioClassPlayerProps = {
  title: string;
  hook?: string | null;
  rule?: string | null;
  standard?: string | null;
  practiceItems?: AudioPracticeItem[];
  className?: string;
};

type SpeechVoice = SpeechSynthesisVoice;

function cleanMarkdown(text: string): string {
  return text
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/!\[[^\]]*\]\([^)]*\)/g, " ")
    .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
    .replace(/^\s{0,3}#{1,6}\s+/gm, "")
    .replace(/^\s{0,3}>\s?/gm, "")
    .replace(/^\s*[-*+]\s+/gm, "")
    .replace(/^\s*\d+[.)]\s+/gm, "")
    .replace(/[*_~]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

export function splitIntoSentences(text: string): string[] {
  const cleaned = cleanMarkdown(text);
  if (!cleaned) return [];
  return cleaned
    .split(SENTENCE_SPLIT_REGEX)
    .map((sentence) => sentence.trim())
    .filter(Boolean);
}

function buildLessonText({
  title,
  hook,
  rule,
  standard,
}: Pick<AudioClassPlayerProps, "title" | "hook" | "rule" | "standard">): string {
  return [
    `Class title: ${title}`,
    hook ? `Hook: ${hook}` : "",
    rule ? `Core rule: ${rule}` : "",
    standard ? `Standard: ${standard}` : "",
  ]
    .filter(Boolean)
    .join(" ");
}

function isEnglishVoice(voice: SpeechVoice): boolean {
  return /^en(?:-|$)/i.test(voice.lang);
}

export default function AudioClassPlayer({
  title,
  hook,
  rule,
  standard,
  practiceItems = [],
  className = "",
}: AudioClassPlayerProps) {
  const pathname = usePathname();
  const transcriptRefs = useRef<Array<HTMLButtonElement | null>>([]);
  const transcriptScrollRef = useRef<HTMLDivElement | null>(null);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const activeIndexRef = useRef(-1);
  const runIdRef = useRef(0);

  const isMockExam = pathname === "/mock" || pathname.startsWith("/mock/");
  const supported =
    typeof window !== "undefined" &&
    "speechSynthesis" in window &&
    "SpeechSynthesisUtterance" in window;

  const sentences = useMemo(
    () => splitIntoSentences(buildLessonText({ title, hook, rule, standard })),
    [title, hook, rule, standard],
  );

  const [voices, setVoices] = useState<SpeechVoice[]>([]);
  const [voiceName, setVoiceName] = useState("");
  const [speed, setSpeed] = useState<(typeof SPEEDS)[number]>(1);
  const [activeIndex, setActiveIndex] = useState(-1);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [practiceEnabled, setPracticeEnabled] = useState(false);
  const [collapsed, setCollapsed] = useState(true);

  const selectedVoice = useMemo(
    () => voices.find((voice) => voice.name === voiceName) ?? voices[0],
    [voiceName, voices],
  );

  const practiceSentences = useMemo(() => {
    if (!practiceEnabled) return [];
    return practiceItems.flatMap((item, itemIndex) => [
      `Practice item ${itemIndex + 1}. ${item.stem}`,
      ...item.options.slice(0, 4).map(
        (option, optionIndex) => `${String.fromCharCode(65 + optionIndex)}. ${option}`,
      ),
    ]);
  }, [practiceEnabled, practiceItems]);

  const stream = useMemo(
    () => (practiceEnabled ? [...sentences, ...practiceSentences] : sentences),
    [practiceEnabled, sentences, practiceSentences],
  );

  const setActive = useCallback((index: number) => {
    activeIndexRef.current = index;
    setActiveIndex(index);
  }, []);

  const stop = useCallback(() => {
    runIdRef.current += 1;
    if (supported) window.speechSynthesis.cancel();
    utteranceRef.current = null;
    setIsPlaying(false);
    setIsPaused(false);
    setActive(-1);
  }, [setActive, supported]);

  const speakFrom = useCallback(
    (startIndex: number) => {
      if (!supported || !stream.length) return;
      const start = Math.max(0, Math.min(startIndex, stream.length - 1));
      const runId = ++runIdRef.current;
      window.speechSynthesis.cancel();
      setIsPlaying(true);
      setIsPaused(false);

      const speakIndex = (index: number) => {
        if (runIdRef.current !== runId || index >= stream.length) {
          if (runIdRef.current === runId) {
            utteranceRef.current = null;
            setIsPlaying(false);
            setIsPaused(false);
            setActive(-1);
          }
          return;
        }

        const utterance = new SpeechSynthesisUtterance(stream[index]);
        utterance.rate = speed;
        utterance.pitch = 1;
        if (selectedVoice) utterance.voice = selectedVoice;
        utterance.onstart = () => {
          if (runIdRef.current === runId) setActive(index);
        };
        utterance.onend = () => {
          if (runIdRef.current === runId) speakIndex(index + 1);
        };
        utterance.onerror = (event) => {
          if (runIdRef.current !== runId) return;
          if (event.error !== "interrupted" && event.error !== "canceled") {
            setIsPlaying(false);
            setIsPaused(false);
            setActive(-1);
          }
        };
        utteranceRef.current = utterance;
        window.speechSynthesis.speak(utterance);
      };

      speakIndex(start);
    },
    [selectedVoice, setActive, speed, stream, supported],
  );

  const play = useCallback(() => {
    if (!supported || !stream.length) return;
    if (isPaused) {
      window.speechSynthesis.resume();
      setIsPaused(false);
      setIsPlaying(true);
      return;
    }
    speakFrom(activeIndexRef.current >= 0 ? activeIndexRef.current : 0);
  }, [isPaused, speakFrom, stream.length, supported]);

  const pause = useCallback(() => {
    if (!supported || !isPlaying) return;
    window.speechSynthesis.pause();
    setIsPaused(true);
  }, [isPlaying, supported]);

  const jumpTo = useCallback(
    (index: number) => {
      setActive(index);
      speakFrom(index);
    },
    [setActive, speakFrom],
  );

  useEffect(() => {
    if (!supported) return;
    const loadVoices = () => {
      const english = window.speechSynthesis.getVoices().filter(isEnglishVoice);
      setVoices(english);
      setVoiceName((current) =>
        current && english.some((voice) => voice.name === current)
          ? current
          : english[0]?.name ?? "",
      );
    };
    loadVoices();
    window.speechSynthesis.addEventListener("voiceschanged", loadVoices);
    return () => window.speechSynthesis.removeEventListener("voiceschanged", loadVoices);
  }, [supported]);

  useEffect(() => {
    if (activeIndex < 0) return;
    const button = transcriptRefs.current[activeIndex];
    if (!button) return;
    button.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
  }, [activeIndex]);

  useEffect(() => stop(), [title, hook, rule, standard, practiceEnabled, stop]);
  useEffect(() => () => stop(), [stop]);

  if (isMockExam || !sentences.length) return null;

  if (collapsed) {
    return (
      <div className={`mt-4 ${className}`}>
        <button type="button" className="btn-ghost tap" onClick={() => setCollapsed(false)}>
          Listen
        </button>
      </div>
    );
  }

  return (
    <section className={`card mt-4 overflow-hidden ${className}`} aria-label="Class audio player">
      <div className="border-b border-line bg-panel-2 p-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="kicker">Hands-free instructor stream</p>
            <h2 className="mt-1 text-xl font-semibold">Listen & follow the lesson</h2>
            <p className="mt-1 max-w-3xl text-sm text-muted">
              Native browser speech only. Each sentence is queued independently to avoid long-utterance cutoff behavior.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button type="button" className="btn-primary tap" onClick={play} disabled={!supported || (isPlaying && !isPaused)}>
              {isPaused ? "Resume" : "Play"}
            </button>
            <button type="button" className="btn-ghost tap" onClick={pause} disabled={!supported || !isPlaying || isPaused}>
              Pause
            </button>
            <button type="button" className="btn-ghost tap" onClick={stop} disabled={!supported || !isPlaying}>
              Stop
            </button>
            <button type="button" className="btn-ghost tap" onClick={() => { stop(); setCollapsed(true); }}>
              Hide
            </button>
          </div>
        </div>

        <div className="mt-4 grid gap-3 md:grid-cols-2">
          <label className="text-sm">
            <span className="mb-1 block font-medium">Playback speed</span>
            <select className="field" value={speed} onChange={(event) => setSpeed(Number(event.target.value) as (typeof SPEEDS)[number])}>
              {SPEEDS.map((value) => (
                <option key={value} value={value}>{value.toFixed(2).replace(/0$/, "")}×</option>
              ))}
            </select>
          </label>
          <label className="text-sm">
            <span className="mb-1 block font-medium">English voice</span>
            <select className="field" value={voiceName} onChange={(event) => setVoiceName(event.target.value)} disabled={!supported || !voices.length}>
              {!voices.length ? <option value="">System default</option> : null}
              {voices.map((voice) => <option key={`${voice.name}-${voice.lang}`} value={voice.name}>{voice.name} · {voice.lang}</option>)}
            </select>
          </label>
        </div>

        {practiceItems.length ? (
          <label className="mt-4 flex cursor-pointer items-center gap-2 text-sm">
            <input type="checkbox" checked={practiceEnabled} onChange={(event) => setPracticeEnabled(event.target.checked)} />
            <span>Read practice stems and up to four answer choices</span>
          </label>
        ) : null}

        {!supported ? (
          <p className="mt-3 rounded-lg border border-amber/50 bg-amber/10 p-3 text-sm text-amber">
            Native speech synthesis is unavailable in this browser.
          </p>
        ) : null}
      </div>

      <div ref={transcriptScrollRef} className="max-h-[28rem] overflow-y-auto p-3" aria-label="Interactive transcript">
        <div className="mb-2 flex items-center justify-between gap-3 px-2">
          <p className="kicker">Interactive transcript</p>
          <span className="text-xs text-muted">{stream.length} lines · click any line to jump</span>
        </div>
        <ol className="space-y-1">
          {stream.map((sentence, index) => {
            const active = index === activeIndex;
            const practice = index >= sentences.length;
            return (
              <li key={`${index}-${sentence}`}>
                <button
                  ref={(node) => { transcriptRefs.current[index] = node; }}
                  type="button"
                  onClick={() => jumpTo(index)}
                  className={`w-full rounded-lg border p-3 text-left text-sm leading-relaxed transition ${
                    active
                      ? "border-amber bg-amber/10 shadow-[inset_3px_0_0_var(--amber)]"
                      : "border-transparent hover:border-line hover:bg-panel-2"
                  }`}
                  aria-current={active ? "true" : undefined}
                >
                  <span className="mr-2 font-mono text-xs text-muted">{index + 1}</span>
                  {practice ? <span className="mr-2 rounded bg-panel-2 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-amber">Practice</span> : null}
                  <span className={active ? "font-semibold" : undefined}>{sentence}</span>
                </button>
              </li>
            );
          })}
        </ol>
      </div>
    </section>
  );
}
