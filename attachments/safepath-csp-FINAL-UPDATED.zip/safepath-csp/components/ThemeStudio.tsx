"use client";

import { useState, type CSSProperties } from "react";
import { ACCENTS, THEME_PRESETS, useTheme, type Density, type LayoutStyle, type ThemePreset } from "./ThemeProvider";
import type { StudyProfile } from "@/lib/profile";

export function ThemeStudio({ profile }: { profile: StudyProfile }) {
  const { settings, setSettings } = useTheme();
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  async function update(patch: Partial<typeof settings>) {
    const next = { ...settings, ...patch };
    setSettings(next);
    setSaving(true);
    setSaved(false);
    try {
      const res = await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: profile.name,
          credential: profile.credential,
          applicationStatus: profile.applicationStatus,
          courseStartDate: profile.courseStartDate || "",
          examDate: profile.examDate || "",
          hoursPerWeek: profile.hoursPerWeek,
          availableDays: profile.availableDays,
          track: profile.track,
          depth: profile.depth,
          difficulty: profile.difficulty,
          industrySkin: profile.industrySkin,
          ...next,
        }),
      });
      if (res.ok) setSaved(true);
    } finally {
      setSaving(false);
    }
  }

  return (
    <section className="theme-studio card p-5 sm:p-7">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="kicker">Personal workspace</p>
          <h2 className="mt-1 font-serif text-2xl">Make SafePath yours</h2>
          <p className="mt-2 max-w-2xl text-sm text-muted">
            Choose a visual template, accent color, reading density, and layout style. Your preference follows you across the learning system.
          </p>
        </div>
        <div className="text-xs text-muted">{saving ? "Saving…" : saved ? "✓ Saved" : "Auto-saved"}</div>
      </div>

      <div className="mt-6">
        <p className="mb-3 text-sm font-semibold">1. Visual template</p>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {(Object.entries(THEME_PRESETS) as [ThemePreset, (typeof THEME_PRESETS)[ThemePreset]][]).map(([id, preset]) => {
            const active = settings.themePreset === id;
            return (
              <button
                key={id}
                type="button"
                onClick={() => update({ themePreset: id })}
                className={`theme-choice ${active ? "is-selected" : ""}`}
                style={{ "--preview-bg": preset.bg, "--preview-panel": preset.panel, "--preview-accent": settings.accentColor || preset.accent } as CSSProperties}
              >
                <span className="theme-preview" aria-hidden>
                  <span className="theme-preview-top" />
                  <span className="theme-preview-card" />
                  <span className="theme-preview-dot" />
                </span>
                <span className="min-w-0 text-left">
                  <span className="block font-semibold">{preset.label}</span>
                  <span className="mt-1 block text-xs text-muted">{preset.description}</span>
                </span>
                {active ? <span className="theme-selected-mark">✓</span> : null}
              </button>
            );
          })}
        </div>
      </div>

      <div className="mt-7 grid gap-7 lg:grid-cols-2">
        <div>
          <p className="mb-3 text-sm font-semibold">2. Accent color</p>
          <div className="flex flex-wrap gap-3">
            {ACCENTS.map(([id, color]) => (
              <button
                key={id}
                type="button"
                aria-label={`Use ${id} accent`}
                aria-pressed={settings.accentColor === color}
                onClick={() => update({ accentColor: color })}
                className={`accent-choice ${settings.accentColor === color ? "is-selected" : ""}`}
                style={{ backgroundColor: color }}
              >
                {settings.accentColor === color ? "✓" : ""}
              </button>
            ))}
            <label className="flex items-center gap-2 rounded-xl border border-line bg-panel-2 px-3 py-2 text-xs">
              Custom
              <input
                type="color"
                value={settings.accentColor}
                onChange={(e) => update({ accentColor: e.target.value })}
                className="h-8 w-10 cursor-pointer rounded border-0 bg-transparent p-0"
              />
            </label>
          </div>
        </div>

        <div>
          <p className="mb-3 text-sm font-semibold">3. Reading density</p>
          <div className="grid grid-cols-2 gap-2">
            {(["comfortable", "compact"] as Density[]).map((value) => (
              <button key={value} type="button" onClick={() => update({ density: value })} className={`choice-button ${settings.density === value ? "is-selected" : ""}`}>
                <span>{value === "comfortable" ? "📖 Comfortable" : "⚡ Compact"}</span>
                <span className="block text-xs text-muted">{value === "comfortable" ? "More breathing room" : "More content on screen"}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-7">
        <p className="mb-3 text-sm font-semibold">4. Layout style</p>
        <div className="grid gap-3 md:grid-cols-3">
          {([
            ["focus", "🎯 Focus", "Centered reading and fewer distractions"],
            ["wide", "🖥️ Wide", "More horizontal workspace for dashboards"],
            ["cards", "🧩 Cards", "Denser visual dashboard and mission cards"],
          ] as [LayoutStyle, string, string][]).map(([value, label, desc]) => (
            <button key={value} type="button" onClick={() => update({ layoutStyle: value })} className={`choice-button text-left ${settings.layoutStyle === value ? "is-selected" : ""}`}>
              <span className="font-semibold">{label}</span>
              <span className="mt-1 block text-xs text-muted">{desc}</span>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
