"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { EDUCATION_OPTIONS, ELIGIBILITY_CREDENTIALS, evaluateEligibility, type EligibilityInput } from "@/lib/eligibility";

const STEPS = [
  { id: 1, label: "Education", icon: "🎓" },
  { id: 2, label: "Experience", icon: "🦺" },
  { id: 3, label: "Credential", icon: "🏅" },
  { id: 4, label: "Result", icon: "✅" },
] as const;

export function EligibilityWizard({ initial, canSave = false }: { initial?: Partial<EligibilityInput>; canSave?: boolean }) {
  const [step, setStep] = useState(1);
  const [data, setData] = useState<EligibilityInput>({
    education: initial?.education || "none",
    experienceYears: Number(initial?.experienceYears ?? 0),
    preventativePct: Number(initial?.preventativePct ?? 50),
    credential: initial?.credential || "OTHER",
  });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const report = useMemo(() => evaluateEligibility(data), [data]);
  const canContinue = step === 1
    ? Boolean(data.education)
    : step === 2
      ? data.experienceYears >= 0 && data.preventativePct >= 0
      : step === 3
        ? Boolean(data.credential)
        : true;

  function next() {
    if (step < 4) setStep((value) => value + 1);
  }
  function back() {
    if (step > 1) setStep((value) => value - 1);
  }

  async function save() {
    if (!canSave) return;
    setSaving(true);
    setSaved(false);
    try {
      const res = await fetch("/api/eligibility", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (res.ok) setSaved(true);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="eligibility-stepper" role="list" aria-label="Eligibility wizard progress">
        {STEPS.map((item) => (
          <div key={item.id} role="listitem" className={`eligibility-step ${step >= item.id ? "is-active" : ""}`}>
            <span className="eligibility-step-icon" aria-hidden>{item.icon}</span>
            <span><b>{item.id}</b><small>{item.label}</small></span>
          </div>
        ))}
      </div>

      {step === 1 ? (
        <section className="eligibility-panel">
          <p className="kicker">Step 1 · Education</p>
          <h2 className="mt-1 font-serif text-3xl">What is your highest education level?</h2>
          <p className="mt-2 text-sm text-muted">For CSP screening, the current BCSP requirement lists a minimum of a bachelor's degree in any field.</p>
          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            {EDUCATION_OPTIONS.map((option) => (
              <button key={option.id} type="button" onClick={() => setData((current) => ({ ...current, education: option.id }))} className={`wizard-choice ${data.education === option.id ? "is-selected" : ""}`}>
                <span className="wizard-radio" aria-hidden>{data.education === option.id ? "✓" : ""}</span>
                <span>{option.label}</span>
              </button>
            ))}
          </div>
        </section>
      ) : null}

      {step === 2 ? (
        <section className="eligibility-panel">
          <p className="kicker">Step 2 · Professional experience</p>
          <h2 className="mt-1 font-serif text-3xl">How much qualifying SH&E experience do you have?</h2>
          <p className="mt-2 text-sm text-muted">Enter the approximate total SH&E experience and the percentage that was preventative, professional-level work with breadth and depth of safety duties.</p>
          <div className="mt-6 grid gap-5 md:grid-cols-2">
            <label className="wizard-field"><span>Years of SH&E experience</span><input className="field" type="number" min="0" max="50" step="0.5" value={data.experienceYears} onChange={(event) => setData((current) => ({ ...current, experienceYears: Number(event.target.value) }))} /></label>
            <label className="wizard-field"><span>Preventative professional work</span><div className="flex items-center gap-3"><input className="flex-1 accent-[var(--user-accent)]" type="range" min="0" max="100" value={data.preventativePct} onChange={(event) => setData((current) => ({ ...current, preventativePct: Number(event.target.value) }))} /><span className="min-w-14 rounded-full border border-line bg-panel-2 px-3 py-1 text-center font-mono text-sm">{data.preventativePct}%</span></div></label>
          </div>
          <div className="mt-5 rounded-xl border border-amber/40 bg-amber/10 p-4 text-sm text-muted"><strong className="text-cream">Tip:</strong> Don't count every year in a job automatically. Screen the role for the nature of the actual SH&E duties.</div>
        </section>
      ) : null}

      {step === 3 ? (
        <section className="eligibility-panel">
          <p className="kicker">Step 3 · Credential</p>
          <h2 className="mt-1 font-serif text-3xl">Which qualifying credential or pathway do you have?</h2>
          <p className="mt-2 text-sm text-muted">BCSP's current CSP page lists multiple qualified credentials. NEBOSH National or International Diploma is among the listed credentials.</p>
          <div className="mt-6 grid gap-3 md:grid-cols-2">
            {ELIGIBILITY_CREDENTIALS.map((credential) => (
              <button key={credential.id} type="button" onClick={() => setData((current) => ({ ...current, credential: credential.id }))} className={`wizard-choice ${data.credential === credential.id ? "is-selected" : ""}`}>
                <span className="wizard-radio" aria-hidden>{data.credential === credential.id ? "✓" : ""}</span>
                <span className="text-left text-sm leading-relaxed">{credential.label}</span>
              </button>
            ))}
          </div>
        </section>
      ) : null}

      {step === 4 ? (
        <section className={`eligibility-result ${report.eligible ? "is-ready" : "is-focus"}`}>
          <div className="flex flex-col gap-5 sm:flex-row sm:items-center">
            <div className="eligibility-score-orb" aria-hidden>{report.eligible ? "✓" : "!"}</div>
            <div>
              <p className="kicker">Eligibility screen</p>
              <h2 className="mt-1 font-serif text-3xl">{report.headline}</h2>
              <p className="mt-2 max-w-3xl text-sm leading-relaxed text-muted">{report.summary}</p>
            </div>
          </div>
          <div className="mt-6 grid gap-3 md:grid-cols-2">
            {report.checks.map((check) => (
              <div key={check.key} className={`eligibility-check ${check.passed ? "is-pass" : "is-fail"}`}>
                <div className="flex items-center justify-between gap-3"><strong>{check.label}</strong><span aria-hidden>{check.passed ? "✓" : "×"}</span></div>
                <p className="mt-2 text-sm text-muted">{check.detail}</p>
              </div>
            ))}
          </div>
          <div className="mt-6 rounded-2xl border border-line bg-panel/70 p-5">
            <p className="kicker">Recommended next steps</p>
            <ol className="mt-3 list-decimal space-y-2 pl-5 text-sm text-muted">{report.nextSteps.map((item) => <li key={item}>{item}</li>)}</ol>
          </div>
          <div className="mt-5 flex flex-wrap gap-3">
            {canSave ? <button type="button" className="btn-primary tap" onClick={save} disabled={saving}>{saving ? "Saving…" : saved ? "✓ Saved to profile" : "Save eligibility result"}</button> : <Link href="/login?next=/eligibility" className="btn-primary tap">Log in to save result →</Link>}
            <Link href="/plan" className="btn-ghost tap">Build my study plan →</Link>
            <Link href="/assess/self?sitting=50" className="btn-ghost tap">Take a baseline diagnostic →</Link>
          </div>
          <p className="mt-4 text-xs leading-relaxed text-muted">This screen is educational guidance, not an official BCSP eligibility decision. BCSP reviews applications and supporting documentation.</p>
        </section>
      ) : null}

      {step < 4 ? (
        <div className="flex items-center justify-between gap-3">
          <button type="button" className="btn-ghost tap" onClick={back} disabled={step === 1}>← Back</button>
          <div className="text-xs text-muted">Step {step} of 4</div>
          <button type="button" className="btn-primary tap" onClick={next} disabled={!canContinue}>{step === 3 ? "See my result →" : "Continue →"}</button>
        </div>
      ) : (
        <button type="button" className="btn-ghost tap" onClick={() => setStep(1)}>↺ Recheck answers</button>
      )}
    </div>
  );
}
