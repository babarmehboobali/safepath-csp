"use client";

import { useState } from "react";

export function TeachBack({ keyHint }: { keyHint: string }) {
  const [text, setText] = useState("");
  const [result, setResult] = useState<null | boolean>(null);

  function check() {
    const t = text.toLowerCase();
    const pass =
      (t.includes("design") && (t.includes("control") || t.includes("stage"))) ||
      (t.includes("life cycle") && t.includes("maintain")) ||
      ((t.includes("eliminat") || t.includes("substitut")) && t.includes("ppe"));
    setResult(pass);
  }

  return (
    <section className="card space-y-3 p-5">
      <p className="kicker">Teach-back</p>
      <p>In one sentence, what will you do on the next design review?</p>
      <label htmlFor="tb" className="sr-only">
        Teach-back sentence
      </label>
      <textarea id="tb" className="field min-h-24" value={text} onChange={(e) => setText(e.target.value)} />
      <button type="button" className="btn-primary" onClick={check}>
        Check
      </button>
      {result != null ? (
        <p className={result ? "text-ok" : "text-bad"}>
          {result
            ? "Pass — you hit design-stage control, life cycle including maintenance, or eliminate/substitute before PPE."
            : "Not yet. Include design-stage control, life cycle including maintenance, or eliminate/substitute before PPE."}
        </p>
      ) : (
        <p className="text-sm text-muted">Scoring key (study only): {keyHint}</p>
      )}
    </section>
  );
}
