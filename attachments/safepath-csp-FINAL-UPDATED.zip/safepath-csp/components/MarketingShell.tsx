import Link from "next/link";
import Image from "next/image";
import { APP_NAME, NAV_SHORT } from "@/lib/constants";
import { SiteFooter } from "./AppShell";

export function MarketingShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-full flex-col">
      <header className="sticky top-0 z-30 border-b border-line bg-navy/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-4 px-6 py-4">
          <Link
            href="/"
            className="flex items-center gap-2 font-semibold tracking-tight"
            title={APP_NAME}
            aria-label={APP_NAME}
          >
            <Image
              src="/logo-mark.png"
              alt="Safepath CSP"
              width={36}
              height={36}
              className="h-9 w-9 object-contain"
              priority
            />
            <span className="hidden text-lg md:inline">{APP_NAME}</span>
            <span className="text-lg md:hidden">{NAV_SHORT}</span>
          </Link>
          <div className="ml-auto flex items-center gap-3">
            <Link href="/login" className="text-[15px] text-cream/80 hover:text-cream">
              Log in
            </Link>
            <Link href="/login?demo=1" className="btn-primary text-sm">
              Start free demo
            </Link>
          </div>
        </div>
      </header>
      <main className="w-full flex-1">{children}</main>
      <SiteFooter />
    </div>
  );
}
