"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { CSP_DOMAIN_NAMES, DOMAIN_ICONS } from "@/lib/assessment";
import type { TopicModule } from "@/content/gym/topic-map";

type ClassLite = { id: number; title: string; domain: number };

export function TopicMapDesk({
  modules,
  classes,
}: {
  modules: TopicModule[];
  classes: ClassLite[];
}) {
  const [q, setQ] = useState("");
  const byId = useMemo(() => new Map(classes.map((c) => [c.id, c])), [classes]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return modules;
    return modules.filter((m) => {
      const classTitles = m.classIds.map((id) => byId.get(id)?.title ?? "").join(" ");
      return [m.title, m.category, m.blurb, CSP_DOMAIN_NAMES[m.domain as keyof typeof CSP_DOMAIN_NAMES] ?? "", classTitles]
        .join(" ")
        .toLowerCase()
        .includes(s);
    });
  }, [q, modules, byId]);

  return (
    <div className="space-y-5">
      <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4" aria-label="CSP domains">
        {[1,2,3,4,5,6,7].map((domain) => (
          <Link key={domain} href={`/domains?d=${domain}`} className="domain-choice">
            <span className="domain-choice-icon" aria-hidden>{DOMAIN_ICONS[domain as keyof typeof DOMAIN_ICONS]}</span>
            <span className="min-w-0 text-left"><span className="block text-xs font-bold">D{domain}</span><span className="block truncate text-xs text-muted">{CSP_DOMAIN_NAMES[domain as keyof typeof CSP_DOMAIN_NAMES]}</span></span>
          </Link>
        ))}
      </div>
      <label className="block">
        <span className="kicker">Search topics</span>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="SPCC, HAZOP, noise, LOTO…"
          className="mt-2 w-full rounded-xl border border-line bg-ink px-4 py-3 text-cream"
        />
      </label>
      <p className="text-sm text-muted">
        {filtered.length} of {modules.length} topics. Each card deep-links existing catalog classes — not a parallel
        course numbering.
      </p>
      <div className="grid gap-3 md:grid-cols-2">
        {filtered.map((m) => (
          <article key={m.id} className="card p-5">
            <p className="kicker">
              {DOMAIN_ICONS[m.domain as keyof typeof DOMAIN_ICONS]} Topic {m.id} · {m.category} · D{m.domain} {CSP_DOMAIN_NAMES[m.domain as keyof typeof CSP_DOMAIN_NAMES]}
            </p>
            <h2 className="mt-2 font-serif text-xl">{m.title}</h2>
            <p className="mt-2 text-sm text-muted">{m.blurb}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {m.classIds.map((id) => {
                const entry = byId.get(id);
                return entry ? (
                  <Link
                    key={id}
                    href={`/learn/${id}`}
                    className="rounded-full border border-line px-2.5 py-1 text-xs text-muted hover:text-amber"
                  >
                    {id} · {entry.title}
                  </Link>
                ) : null;
              })}
              {(m.extraHrefs ?? []).map((x) => (
                <Link
                  key={x.href}
                  href={x.href}
                  className="rounded-full border border-amber/40 px-2.5 py-1 text-xs text-amber"
                >
                  {x.label}
                </Link>
              ))}
              <Link
                href={`/domains?d=${m.domain}`}
                className="rounded-full border border-line px-2.5 py-1 text-xs text-muted hover:text-amber"
              >
                Domain gym
              </Link>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
