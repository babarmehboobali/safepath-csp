"use client";

import Link from "next/link";
import { Flame, Sparkles, Trophy } from "lucide-react";
import { xpIntoLevel, xpToNextLevel } from "@/lib/streak";

export function StreakView({ xp = 0, level = 1, streak = 0, compact = false }: { xp?: number; level?: number; streak?: number; compact?: boolean }) {
  const into = xpIntoLevel(xp);
  const next = xpToNextLevel(xp);
  const pct = Math.min(100, Math.round((into / 250) * 100));
  return (
    <Link href="/dashboard" className={`group flex items-center gap-3 rounded-xl border border-line bg-panel-2/80 px-3 py-2 transition hover:-translate-y-0.5 hover:border-[var(--user-accent-strong)] hover:shadow-[0_8px_30px_var(--user-accent-soft)] ${compact ? "text-xs" : ""}`} aria-label={`Level ${level}, ${xp} XP, ${streak} day streak`}>
      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[var(--user-accent-soft)] text-[var(--user-accent)] ring-1 ring-[var(--user-accent-strong)]"><Trophy className="h-4 w-4" /></div>
      <div className="min-w-[112px]">
        <div className="flex items-center justify-between gap-3 text-[11px] font-semibold uppercase tracking-[0.12em] text-muted"><span>Level {level}</span><span>{xp} XP</span></div>
        <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-ink"><div className="h-full rounded-full bg-gradient-to-r from-[var(--user-accent)] to-[var(--theme-accent-2)] transition-[width] duration-700" style={{ width: `${pct}%` }} /></div>
        {!compact ? <div className="mt-1 text-[10px] text-muted">{next} XP to next level</div> : null}
      </div>
      <div className="flex items-center gap-1.5 rounded-lg bg-bad/10 px-2 py-1 text-bad ring-1 ring-bad/20"><Flame className="h-4 w-4" fill="currentColor" /><span className="font-bold tabular-nums">{streak}</span><span className="hidden text-[10px] uppercase sm:inline">day</span></div>
      {!compact ? <Sparkles className="hidden h-4 w-4 text-[var(--user-accent)]/70 sm:block" /> : null}
    </Link>
  );
}
