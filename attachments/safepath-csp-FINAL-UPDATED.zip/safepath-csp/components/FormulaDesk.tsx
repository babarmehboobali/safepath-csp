"use client";

import { useMemo, useState } from "react";
import Link from "next/link";

export type FormulaRow = {
  slug: string;
  name: string;
  expression: string;
  variables: string;
  whenToUse: string;
  pitfall: string;
  pitfallCode: string;
  workedExample: string;
  units: string;
};

export function FormulaDesk({ formulas }: { formulas: FormulaRow[] }) {
  const [q, setQ] = useState("");
  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return formulas;
    return formulas.filter((f) =>
      [f.name, f.slug, f.expression, f.variables, f.whenToUse, f.units, f.workedExample]
        .join(" ")
        .toLowerCase()
        .includes(s),
    );
  }, [q, formulas]);

  return (
    <div className="space-y-4">
      <label className="block">
        <span className="kicker">Search equations</span>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="TRIR, 24.45, RWL, dike…"
          className="mt-2 w-full rounded-xl border border-line bg-ink px-4 py-3 text-cream"
        />
      </label>
      <p className="text-sm text-muted">
        {filtered.length} of {formulas.length} equations. No formula sheet in the test center — this desk is for
        study.
      </p>
      <div className="space-y-4">
        {filtered.map((f) => (
          <article key={f.slug} id={f.slug} className="card p-5">
            <h2 className="font-serif text-xl">{f.name}</h2>
            <p className="mt-2 font-mono text-amber">{f.expression}</p>
            <p className="mt-2 text-sm">
              <span className="text-muted">Variables. </span>
              {f.variables}
            </p>
            <p className="mt-2 text-sm">
              <span className="text-muted">Units. </span>
              {f.units}
            </p>
            <p className="mt-2 text-sm">
              <span className="text-muted">When. </span>
              {f.whenToUse}
            </p>
            <p className="mt-2 text-sm">
              <span className="text-muted">Worked. </span>
              {f.workedExample}
            </p>
            <p className="mt-2 text-sm">
              <span className="text-muted">{f.pitfallCode} pitfall. </span>
              {f.pitfall}
            </p>
            <Link href="/calculator" className="btn-ghost mt-3 text-sm tap">
              Open calculator
            </Link>
          </article>
        ))}
      </div>
    </div>
  );
}
