"use client";

import { useCallback, useEffect, useRef, useState, type PointerEvent } from "react";
import { Calculator } from "./Calculator";

const PANEL_W = 380;
const PANEL_H = 640;

type Point = { x: number; y: number };

function clampPosition(point: Point): Point {
  if (typeof window === "undefined") return point;
  const maxX = Math.max(8, window.innerWidth - PANEL_W - 8);
  const maxY = Math.max(8, window.innerHeight - Math.min(PANEL_H, window.innerHeight - 16) - 8);
  return {
    x: Math.min(Math.max(8, point.x), maxX),
    y: Math.min(Math.max(8, point.y), maxY),
  };
}

function loadPosition(key: string): Point | null {
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<Point>;
    if (typeof parsed.x !== "number" || typeof parsed.y !== "number") return null;
    return clampPosition({ x: parsed.x, y: parsed.y });
  } catch {
    return null;
  }
}

export function CalculatorDrawer({
  variant = "study",
  label = "Calculator",
  moveable = true,
}: {
  variant?: "study" | "exam";
  label?: string;
  moveable?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [position, setPosition] = useState<Point | null>(null);
  const [dragging, setDragging] = useState(false);
  const dragRef = useRef<{ dx: number; dy: number } | null>(null);
  const storageKey = `safepath-calculator-position:${variant}`;

  const openPanel = useCallback(() => {
    if (position) {
      setOpen(true);
      return;
    }
    const saved = typeof window !== "undefined" ? loadPosition(storageKey) : null;
    const fallback = clampPosition({
      x: typeof window !== "undefined" ? window.innerWidth - PANEL_W - 28 : 24,
      y: 88,
    });
    setPosition(saved ?? fallback);
    setOpen(true);
  }, [position, storageKey]);

  useEffect(() => {
    if (!open) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") setOpen(false);
    }
    function onResize() {
      setPosition((current) => (current ? clampPosition(current) : current));
    }
    window.addEventListener("keydown", onKey);
    window.addEventListener("resize", onResize);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("resize", onResize);
    };
  }, [open]);

  useEffect(() => {
    if (!position || !moveable) return;
    try {
      window.localStorage.setItem(storageKey, JSON.stringify(position));
    } catch {
      // Position persistence is optional.
    }
  }, [position, moveable, storageKey]);

  useEffect(() => {
    if (!dragging) return;
    function onMove(e: PointerEvent) {
      if (!dragRef.current) return;
      setPosition(clampPosition({ x: e.clientX - dragRef.current.dx, y: e.clientY - dragRef.current.dy }));
    }
    function onUp() {
      dragRef.current = null;
      setDragging(false);
    }
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
  }, [dragging]);

  function startDrag(event: PointerEvent<HTMLDivElement>) {
    if (!moveable) return;
    if (event.pointerType === "mouse" && event.button !== 0) return;
    const rect = event.currentTarget.parentElement?.getBoundingClientRect();
    if (!rect) return;
    event.preventDefault();
    dragRef.current = { dx: event.clientX - rect.left, dy: event.clientY - rect.top };
    setDragging(true);
  }

  function resetPosition() {
    const next = clampPosition({ x: typeof window !== "undefined" ? window.innerWidth - PANEL_W - 28 : 24, y: 88 });
    setPosition(next);
  }

  return (
    <>
      <button
        type="button"
        className="tap flex h-14 w-14 items-center justify-center rounded-full border border-gold/50 bg-panel/95 text-2xl shadow-[0_10px_35px_rgba(0,0,0,.35)] backdrop-blur transition hover:-translate-y-1 hover:border-safepath-lime hover:shadow-[0_12px_40px_rgba(124,219,58,.14)]"
        onClick={openPanel}
        aria-haspopup="dialog"
        aria-expanded={open}
      >
        {label}
      </button>

      {open ? (
        <>
          <button
            type="button"
            className="fixed inset-0 z-40 bg-black/10 sm:hidden"
            aria-label="Close calculator"
            onClick={() => setOpen(false)}
          />
          <div
            className="fixed z-50 w-[min(380px,calc(100vw-16px))] max-w-[calc(100vw-16px)] overflow-hidden rounded-2xl border border-sky-800/80 bg-slate-950 shadow-[0_24px_80px_rgba(0,0,0,.48)]"
            style={position ? { left: position.x, top: position.y } : undefined}
            role="dialog"
            aria-modal="false"
            aria-label="TI-30XS style practice calculator"
          >
            <div
              className={`flex items-center justify-between gap-3 border-b border-slate-800 bg-slate-900 px-3 py-2.5 ${moveable ? "cursor-grab select-none" : ""} ${dragging ? "cursor-grabbing" : ""}`}
              onPointerDown={startDrag}
            >
              <div className="flex min-w-0 items-center gap-2">
                <span className="grid h-8 w-8 place-items-center rounded-lg bg-sky-500/10 text-lg text-sky-300">🧮</span>
                <div className="min-w-0">
                  <p className="truncate text-xs font-bold uppercase tracking-[0.14em] text-sky-300">TI-30XS Practice Lab</p>
                  <p className="text-[10px] text-slate-400">{moveable ? "Drag this bar to move the calculator" : "Calculator"}</p>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                {moveable ? (
                  <button type="button" className="tap h-9 rounded-lg border border-slate-700 px-2 text-[11px] font-semibold text-slate-300 hover:border-sky-700 hover:text-white" onPointerDown={(e) => e.stopPropagation()} onClick={resetPosition}>
                    Reset
                  </button>
                ) : null}
                <button type="button" className="tap h-9 rounded-lg border border-slate-700 px-2 text-sm font-semibold text-slate-200 hover:border-sky-700 hover:text-white" onPointerDown={(e) => e.stopPropagation()} onClick={() => setOpen(false)}>
                  Close
                </button>
              </div>
            </div>
            <div className="max-h-[calc(100vh-88px)] overflow-auto p-3 sm:p-4">
              <Calculator compact variant={variant} />
            </div>
          </div>
        </>
      ) : null}
    </>
  );
}
