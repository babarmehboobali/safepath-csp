"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { Item, AnswerRow } from "@/components/QuestionPlayer";
import { formatClock } from "@/lib/gym";

const MISSED_STORAGE_KEY = "csp_missed_questions";
const MASTERED_STORAGE_KEY = "csp_mastered_questions";
const TELEMETRY_QUEUE_KEY = "csp_pending_telemetry";
const MISSED_STORAGE_VERSION = 1;
const BURNDOWN_TARGET = 2;
const BLITZ_LENGTH = 10;
const BLITZ_MINUTES = 10;

export type MissedQuestionRecord = {
  version: number;
  item: Item;
  consecutiveCorrect: number;
  addedAt: string;
  updatedAt: string;
};

type Mode = "burndown" | "blitz";

type Feedback = {
  kind: "correct" | "incorrect" | "complete";
  message: string;
  detail?: string;
};

type PendingAttemptTelemetry = {
  questionId: string;
  selected: number;
  correct: boolean;
  queuedAt: string;
};

type Props = {
  items: Item[];
  seedMissedItems?: Item[];
};

function cloneItem(item: Item): Item {
  return {
    ...item,
    options: [...item.options],
    distractors: item.distractors ? [...item.distractors] : undefined,
  };
}

function safeReadMissed(): MissedQuestionRecord[] {
  if (typeof window === "undefined") return [];

  try {
    const raw = window.localStorage.getItem(MISSED_STORAGE_KEY);
    if (!raw) return [];

    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];

    return parsed
      .filter((entry): entry is MissedQuestionRecord => {
        if (!entry || typeof entry !== "object") return false;
        const candidate = entry as Partial<MissedQuestionRecord>;
        return (
          typeof candidate.item?.id === "string" &&
          typeof candidate.consecutiveCorrect === "number" &&
          Number.isFinite(candidate.consecutiveCorrect)
        );
      })
      .map((entry) => ({
        ...entry,
        version: MISSED_STORAGE_VERSION,
        consecutiveCorrect: Math.max(0, Math.min(BURNDOWN_TARGET - 1, Math.floor(entry.consecutiveCorrect))),
        item: cloneItem(entry.item),
      }))
      .filter((entry) => entry.consecutiveCorrect >= 0 && entry.consecutiveCorrect < BURNDOWN_TARGET);
  } catch {
    return [];
  }
}

function safeWriteMissed(records: MissedQuestionRecord[]) {
  if (typeof window === "undefined") return;

  try {
    window.localStorage.setItem(MISSED_STORAGE_KEY, JSON.stringify(records));
  } catch {
    // Storage can be unavailable in private/restricted browser contexts.
  }
}

function safeReadMastered(): Set<string> {
  if (typeof window === "undefined") return new Set<string>();

  try {
    const raw = window.localStorage.getItem(MASTERED_STORAGE_KEY);
    if (!raw) return new Set<string>();
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return new Set<string>();
    return new Set(parsed.filter((id): id is string => typeof id === "string"));
  } catch {
    return new Set<string>();
  }
}

function safeWriteMastered(ids: Set<string>) {
  if (typeof window === "undefined") return;

  try {
    window.localStorage.setItem(MASTERED_STORAGE_KEY, JSON.stringify([...ids]));
  } catch {
    // Best-effort local persistence only.
  }
}

function queuePendingAttempt(payload: PendingAttemptTelemetry) {
  if (typeof window === "undefined") return;

  try {
    const raw = window.localStorage.getItem(TELEMETRY_QUEUE_KEY);
    const existing = raw ? (JSON.parse(raw) as unknown) : [];
    const rows = Array.isArray(existing) ? existing : [];
    rows.push(payload);
    window.localStorage.setItem(TELEMETRY_QUEUE_KEY, JSON.stringify(rows.slice(-500)));
  } catch {
    // Telemetry must never block study interactions.
  }
}

async function postAttempt(payload: PendingAttemptTelemetry): Promise<boolean> {
  try {
    const response = await fetch("/api/attempts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        questionId: payload.questionId,
        selected: payload.selected,
        correct: payload.correct,
      }),
      keepalive: true,
    });
    return response.ok;
  } catch {
    return false;
  }
}

async function syncPendingTelemetry() {
  if (typeof window === "undefined") return;

  let pending: PendingAttemptTelemetry[] = [];
  try {
    const raw = window.localStorage.getItem(TELEMETRY_QUEUE_KEY);
    const parsed = raw ? (JSON.parse(raw) as unknown) : [];
    pending = Array.isArray(parsed) ? parsed.filter(Boolean) as PendingAttemptTelemetry[] : [];
  } catch {
    return;
  }

  if (!pending.length) return;

  const remaining: PendingAttemptTelemetry[] = [];
  for (const row of pending) {
    const ok = await postAttempt(row);
    if (!ok) remaining.push(row);
  }

  try {
    if (remaining.length) {
      window.localStorage.setItem(TELEMETRY_QUEUE_KEY, JSON.stringify(remaining.slice(-500)));
    } else {
      window.localStorage.removeItem(TELEMETRY_QUEUE_KEY);
    }
  } catch {
    // Best-effort sync only.
  }
}

function randomUnit() {
  if (typeof crypto !== "undefined" && "getRandomValues" in crypto) {
    const buffer = new Uint32Array(1);
    crypto.getRandomValues(buffer);
    return buffer[0]! / 2 ** 32;
  }
  return Math.random();
}

function shuffled<T>(values: T[]): T[] {
  const out = [...values];
  for (let i = out.length - 1; i > 0; i -= 1) {
    const j = Math.floor(randomUnit() * (i + 1));
    [out[i], out[j]] = [out[j]!, out[i]!];
  }
  return out;
}

function pickBlitzItems(items: Item[]): Item[] {
  if (items.length <= BLITZ_LENGTH) return shuffled(items).map(cloneItem);

  const byDomain = new Map<number, Item[]>();
  for (const item of items) {
    const domain = item.domain ?? 0;
    const bucket = byDomain.get(domain) ?? [];
    bucket.push(item);
    byDomain.set(domain, bucket);
  }

  const selected: Item[] = [];
  const used = new Set<string>();

  // Prefer one from every available blueprint domain before filling the remaining slots.
  for (const domain of [1, 2, 3, 4, 5, 6, 7]) {
    const bucket = byDomain.get(domain);
    if (!bucket?.length || selected.length >= BLITZ_LENGTH) continue;
    const item = shuffled(bucket)[0]!;
    selected.push(item);
    used.add(item.id);
  }

  const remaining = shuffled(items.filter((item) => !used.has(item.id)));
  for (const item of remaining) {
    if (selected.length >= BLITZ_LENGTH) break;
    selected.push(item);
  }

  return shuffled(selected).map(cloneItem);
}

function upsertMissedRecord(records: MissedQuestionRecord[], item: Item, now: string): MissedQuestionRecord[] {
  return [
    ...records.map((record) => ({ ...record, item: cloneItem(record.item) })),
    {
      version: MISSED_STORAGE_VERSION,
      item: cloneItem(item),
      consecutiveCorrect: 0,
      addedAt: now,
      updatedAt: now,
    },
  ];
}

function reconcileStoredMisses(records: MissedQuestionRecord[], items: Item[]): MissedQuestionRecord[] {
  if (!items.length) return records;
  const currentById = new Map(items.map((item) => [item.id, item]));

  return records
    .filter((record) => record.item?.id)
    .map((record) => {
      const current = currentById.get(record.item.id);
      return current ? { ...record, version: MISSED_STORAGE_VERSION, item: cloneItem(current) } : record;
    });
}

export default function HabitStudyEngine({ items, seedMissedItems = [] }: Props) {
  const [mode, setMode] = useState<Mode>("burndown");
  const [missed, setMissed] = useState<MissedQuestionRecord[]>([]);
  const [masteredIds, setMasteredIds] = useState<Set<string>>(() => new Set<string>());
  const [ready, setReady] = useState(false);
  const [index, setIndex] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<Feedback | null>(null);
  const [blitzItems, setBlitzItems] = useState<Item[]>([]);
  const [blitzAnswers, setBlitzAnswers] = useState<AnswerRow[]>([]);
  const [secondsLeft, setSecondsLeft] = useState(BLITZ_MINUTES * 60);
  const [sessionComplete, setSessionComplete] = useState(false);
  const [busy, setBusy] = useState(false);
  const doneRef = useRef(false);

  const currentMissedItems = useMemo(() => missed.map((record) => record.item), [missed]);
  const sessionItems = mode === "burndown" ? currentMissedItems : blitzItems;
  const item = sessionItems[index];
  const blitzProgress = Math.min(index + (picked == null ? 0 : 1), BLITZ_LENGTH);

  const persistMissed = useCallback((next: MissedQuestionRecord[]) => {
    setMissed(next);
    safeWriteMissed(next);
  }, []);

  useEffect(() => {
    const mastered = safeReadMastered();
    const stored = reconcileStoredMisses(safeReadMissed(), items).filter((record) => !mastered.has(record.item.id));
    const known = new Set(stored.map((record) => record.item.id));
    const now = new Date().toISOString();
    const seeded = seedMissedItems
      .filter((item) => !known.has(item.id) && !mastered.has(item.id))
      .map((item) => ({
        version: MISSED_STORAGE_VERSION,
        item: cloneItem(item),
        consecutiveCorrect: 0,
        addedAt: now,
        updatedAt: now,
      }));
    const initial = [...stored, ...seeded];
    setMissed(initial);
    setMasteredIds(mastered);
    safeWriteMissed(initial);
    safeWriteMastered(mastered);
    setReady(true);
    void syncPendingTelemetry();

    const onOnline = () => {
      void syncPendingTelemetry();
    };
    window.addEventListener("online", onOnline);

    return () => window.removeEventListener("online", onOnline);
  }, [items, seedMissedItems]);

  const startBurndown = useCallback(() => {
    const next = shuffled(missed);
    setMode("burndown");
    setBlitzItems([]);
    setIndex(0);
    setPicked(null);
    setFeedback(null);
    setSessionComplete(false);
    setBusy(false);
    doneRef.current = false;
    setMissed(next);
    safeWriteMissed(next);
  }, [missed]);

  const startBlitz = useCallback(() => {
    setMode("blitz");
    setBlitzItems(pickBlitzItems(items));
    setBlitzAnswers([]);
    setIndex(0);
    setPicked(null);
    setFeedback(null);
    setSecondsLeft(BLITZ_MINUTES * 60);
    setSessionComplete(false);
    setBusy(false);
    doneRef.current = false;
  }, [items]);

  const finishBlitz = useCallback(
    async (rows: AnswerRow[], timedOut: boolean) => {
      if (doneRef.current) return;
      doneRef.current = true;
      setSessionComplete(true);
      setFeedback({
        kind: "complete",
        message: timedOut ? "Blitz time expired." : "Rapid Blitz complete.",
        detail: `${rows.filter((row) => row.correct).length} of ${BLITZ_LENGTH} questions answered correctly.`,
      });

      const correct = rows.filter((row) => row.correct).length;
      const pct = Math.round((correct / Math.max(rows.length, 1)) * 100);
      const domainAcc: Record<number, { ok: number; n: number }> = {};
      for (const row of rows) {
        const domain = row.domain ?? 0;
        if (!domain) continue;
        domainAcc[domain] ??= { ok: 0, n: 0 };
        domainAcc[domain].n += 1;
        if (row.correct) domainAcc[domain].ok += 1;
      }
      const domainScores: Record<number, number> = {};
      for (const [key, value] of Object.entries(domainAcc)) {
        domainScores[Number(key)] = value.n ? (value.ok / value.n) * 100 : 0;
      }

      try {
        await fetch("/api/gym", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            gym: "today-blitz",
            slug: new Date().toISOString().slice(0, 10),
            length: rows.length,
            score: pct,
            answers: rows,
            domainScores,
          }),
          keepalive: true,
        });
      } catch {
        // Individual answer telemetry is already queued/retried separately.
      }
    },
    [],
  );

  useEffect(() => {
    if (mode !== "blitz" || !blitzItems.length || sessionComplete) return;

    const timer = window.setInterval(() => {
      setSecondsLeft((current) => {
        if (current <= 1) {
          window.clearInterval(timer);
          const unanswered = blitzItems.slice(index + (picked == null ? 0 : 1));
          const answeredRows = [...blitzAnswers];
          for (const unansweredItem of unanswered) {
            if (!answeredRows.some((row) => row.questionId === unansweredItem.id)) {
              // Unanswered questions are intentionally omitted from /api/attempts: they are not attempts.
            }
          }
          void finishBlitz(answeredRows, true);
          return 0;
        }
        return current - 1;
      });
    }, 1000);

    return () => window.clearInterval(timer);
  }, [blitzAnswers, blitzItems, finishBlitz, index, mode, picked, sessionComplete]);

  const recordAnswerTelemetry = useCallback(async (itemToRecord: Item, selected: number, correct: boolean) => {
    const payload: PendingAttemptTelemetry = {
      questionId: itemToRecord.id,
      selected,
      correct,
      queuedAt: new Date().toISOString(),
    };

    if (!navigator.onLine) {
      queuePendingAttempt(payload);
      return;
    }

    const delivered = await postAttempt(payload);
    if (!delivered) queuePendingAttempt(payload);
  }, []);

  const submit = useCallback(
    async (choice: number) => {
      if (!item || picked !== null || busy || sessionComplete) return;

      setBusy(true);
      setPicked(choice);

      const correct = choice === item.answerIndex;
      const now = new Date().toISOString();
      void recordAnswerTelemetry(item, choice, correct);

      const existing = missed.find((record) => record.item.id === item.id);

      if (correct) {
        if (existing) {
          const nextStreak = existing.consecutiveCorrect + 1;
          if (nextStreak >= BURNDOWN_TARGET) {
            const next = missed.filter((record) => record.item.id !== item.id);
            const nextMastered = new Set(masteredIds);
            nextMastered.add(item.id);
            setMasteredIds(nextMastered);
            safeWriteMastered(nextMastered);
            persistMissed(next);
            setFeedback({
              kind: "correct",
              message: "Mastered — removed from the missed queue.",
              detail: "Two consecutive correct answers completed this question’s burndown requirement.",
            });
          } else {
            const next = missed.map((record) =>
              record.item.id === item.id
                ? { ...record, consecutiveCorrect: nextStreak, updatedAt: now }
                : record,
            );
            persistMissed(next);
            setFeedback({
              kind: "correct",
              message: `Correct — ${nextStreak}/${BURNDOWN_TARGET} consecutive.`,
              detail: "One more correct answer is required to permanently remove this question.",
            });
          }
        } else {
          setFeedback({
            kind: "correct",
            message: "Correct.",
            detail: mode === "blitz" ? "This item was not currently in the missed queue, so no burndown streak needed updating." : "Keep going — the next missed item is ready.",
          });
        }
      } else {
        const nextMastered = new Set(masteredIds);
        nextMastered.delete(item.id);
        setMasteredIds(nextMastered);
        safeWriteMastered(nextMastered);

        const next = existing
          ? missed.map((record) =>
              record.item.id === item.id
                ? { ...record, consecutiveCorrect: 0, updatedAt: now }
                : record,
            )
          : upsertMissedRecord(missed, item, now);
        persistMissed(next);
        setFeedback({
          kind: "incorrect",
          message: mode === "burndown" ? "Incorrect — consecutive streak reset to 0/2." : "Incorrect — added to the missed queue at 0/2.",
          detail: "This question stays in the missed queue until it earns two consecutive correct answers.",
        });
      }

      if (mode === "blitz") {
        const row: AnswerRow = {
          questionId: item.id,
          selected: choice,
          correct,
          domain: item.domain,
          classId: item.classId,
        };
        const nextRows = [...blitzAnswers, row];
        setBlitzAnswers(nextRows);
      }

      setBusy(false);
    },
    [blitzAnswers, busy, item, masteredIds, missed, mode, persistMissed, picked, recordAnswerTelemetry, sessionComplete],
  );

  const advance = useCallback(() => {
    if (picked === null || busy) return;

    if (mode === "burndown") {
      const nextLength = missed.length;
      if (!nextLength) {
        setSessionComplete(true);
        return;
      }
      setIndex((current) => (current + 1) % nextLength);
      setPicked(null);
      setFeedback(null);
      return;
    }

    if (index + 1 >= blitzItems.length) {
      void finishBlitz(blitzAnswers, false);
      setPicked(null);
      return;
    }

    setIndex((current) => current + 1);
    setPicked(null);
    setFeedback(null);
  }, [blitzAnswers, blitzItems.length, busy, finishBlitz, index, missed.length, mode, picked]);

  if (!ready) {
    return (
      <section className="card p-6">
        <p className="kicker">Daily mastery engine</p>
        <p className="mt-2 text-sm text-muted">Loading your persisted study queue…</p>
      </section>
    );
  }

  return (
    <section className="card p-5 md:p-6" aria-label="Daily mastery study engine">
      <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="kicker">Daily mastery engine</p>
          <h2 className="mt-2 text-2xl font-semibold tracking-tight">Study what will stick</h2>
          <p className="mt-2 max-w-2xl text-sm text-muted">
            Missed questions require two consecutive correct answers before they leave the queue. Rapid Blitz gives you ten randomized CSP-11 questions across the blueprint in ten minutes.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            className={mode === "burndown" ? "btn-primary tap" : "btn-ghost tap"}
            onClick={startBurndown}
          >
            Missed Burndown ({missed.length})
          </button>
          <button
            type="button"
            className={mode === "blitz" ? "btn-primary tap" : "btn-ghost tap"}
            onClick={startBlitz}
            disabled={!items.length}
          >
            10-Minute Rapid Blitz
          </button>
        </div>
      </div>

      {mode === "burndown" && !missed.length ? (
        <div className="mt-6 rounded-xl border border-dashed p-5">
          <p className="font-semibold">Your missed queue is clear.</p>
          <p className="mt-2 text-sm text-muted">
            Answer questions incorrectly in this engine to build the burndown queue, or use Rapid Blitz for a mixed daily sprint.
          </p>
          <button type="button" className="btn-primary tap mt-4" onClick={startBlitz} disabled={!items.length}>
            Start Rapid Blitz
          </button>
        </div>
      ) : null}

      {mode === "blitz" && !sessionComplete && blitzItems.length ? (
        <div className="mt-5 flex flex-wrap items-center justify-between gap-3 rounded-xl border p-4">
          <div>
            <p className="kicker">Rapid Blitz</p>
            <p className="mt-1 text-sm">
              Question {Math.min(index + 1, BLITZ_LENGTH)} / {BLITZ_LENGTH}
              {blitzProgress ? ` · ${blitzAnswers.filter((row) => row.correct).length} correct` : ""}
            </p>
          </div>
          <p className="font-mono text-lg font-semibold" aria-live="polite">
            {formatClock(secondsLeft)}
          </p>
        </div>
      ) : null}

      {!sessionComplete && item ? (
        <div className="mt-6">
          <div className="mb-4 flex flex-wrap items-center gap-2 text-xs text-muted">
            <span className="rounded-full border px-2 py-1">D{item.domain ?? "–"}</span>
            {item.classId != null ? <span className="rounded-full border px-2 py-1">Class {item.classId}</span> : null}
            {mode === "burndown" ? (
              <span className="rounded-full border px-2 py-1">
                Current mastery: {missed.find((record) => record.item.id === item.id)?.consecutiveCorrect ?? 0}/{BURNDOWN_TARGET}
              </span>
            ) : null}
          </div>

          <h3 className="text-lg font-semibold leading-relaxed">{item.stem}</h3>

          <div className="mt-5 grid gap-3">
            {item.options.slice(0, 4).map((option, optionIndex) => {
              const selected = picked === optionIndex;
              const answered = picked !== null;
              const correct = optionIndex === item.answerIndex;

              return (
                <button
                  key={`${item.id}-${optionIndex}`}
                  type="button"
                  className={`option-row text-left ${selected ? "border-amber ring-1 ring-amber" : ""} ${
                    answered && correct ? "border-emerald-400 ring-1 ring-emerald-400" : ""
                  } ${answered && selected && !correct ? "border-red-400 ring-1 ring-red-400" : ""}`}
                  onClick={() => void submit(optionIndex)}
                  disabled={answered || busy}
                >
                  <span className="font-semibold">{String.fromCharCode(65 + optionIndex)}.</span>
                  <span>{option}</span>
                </button>
              );
            })}
          </div>

          {feedback ? (
            <div
              className={`mt-5 rounded-xl border p-4 ${
                feedback.kind === "correct" ? "border-emerald-400/60" : feedback.kind === "incorrect" ? "border-red-400/60" : ""
              }`}
              aria-live="polite"
            >
              <p className="font-semibold">{feedback.message}</p>
              {feedback.detail ? <p className="mt-1 text-sm text-muted">{feedback.detail}</p> : null}
              {mode === "burndown" && picked !== null ? (
                <p className="mt-3 text-sm">
                  <span className="font-semibold">Correct key:</span> {String.fromCharCode(65 + item.answerIndex)}. {item.options[item.answerIndex]}
                </p>
              ) : null}
              <p className="mt-3 text-sm text-muted">{item.explanation}</p>
              <button type="button" className="btn-primary tap mt-4" onClick={advance}>
                {mode === "blitz" && index + 1 >= blitzItems.length ? "Finish Blitz" : "Next"}
              </button>
            </div>
          ) : null}
        </div>
      ) : null}

      {sessionComplete ? (
        <div className="mt-6 rounded-xl border p-5">
          <p className="kicker">Session complete</p>
          {mode === "burndown" ? (
            <>
              <h3 className="mt-2 text-xl font-semibold">Burndown queue: {missed.length} remaining</h3>
              <p className="mt-2 text-sm text-muted">
                A correct answer never clears a miss by itself. Each question must earn two consecutive correct answers; an incorrect answer resets that question to 0/2.
              </p>
              <button type="button" className="btn-primary tap mt-4" onClick={startBlitz} disabled={!items.length}>
                Run Today’s Rapid Blitz
              </button>
            </>
          ) : (
            <>
              <h3 className="mt-2 text-xl font-semibold">Rapid Blitz finished</h3>
              <p className="mt-2 text-sm text-muted">
                {blitzAnswers.filter((row) => row.correct).length} of {BLITZ_LENGTH} correct across {new Set(blitzItems.map((entry) => entry.domain).filter(Boolean)).size} blueprint domains represented.
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                <button type="button" className="btn-primary tap" onClick={startBlitz} disabled={!items.length}>
                  Run Again
                </button>
                {missed.length ? (
                  <button type="button" className="btn-ghost tap" onClick={startBurndown}>
                    Work Missed Queue ({missed.length})
                  </button>
                ) : null}
              </div>
            </>
          )}
        </div>
      ) : null}

      <p className="mt-5 text-xs text-muted">
        Offline study state is stored locally in <code>{MISSED_STORAGE_KEY}</code>; mastered IDs are kept as local tombstones so a 2/2 question is not resurrected by stale server telemetry. Answer telemetry uses the existing attempts endpoint and is retried after connectivity returns, so the existing attempt-based streak system can continue to count study activity.
      </p>
    </section>
  );
}
