"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { formatClock } from "@/lib/gym";
import {
  demoHasFlag,
  isDemoClient,
  recordDemoAttempt,
  toggleDemoFlag,
} from "@/lib/demo-store";

export type ItemMath = {
  formula: string;
  variables: Record<string, string>;
  derivationSteps: string[];
  ti30KeystrokeSequence: string;
};

export type Item = {
  id: string;
  stem: string;
  options: string[];
  answerIndex: number;
  explanation: string;
  errorCode: string;
  taskCode: string;
  difficulty: string;
  classId?: number;
  classTitle?: string;
  domain?: number;
  kind?: string;
  distractors?: string[];
  /** Per-option trap analysis (study / post-answer only — never mid ExamSitting). */
  optionTraps?: string[];
  scenarioText?: string;
  standardReference?: string;
  fieldTakeaway?: string;
  stepByStepMath?: ItemMath;
  /** Internal only — never shown during the attempt. Excluded from displayed exam score. */
  pretest?: boolean;
};

export type AnswerRow = {
  questionId: string;
  selected: number;
  correct: boolean;
  domain?: number;
  classId?: number;
  classTitle?: string;
  errorCode?: string;
  flagged?: boolean;
  pretest?: boolean;
};


function itemSymbol(item: Item) {
  const text = `${item.taskCode} ${item.stem}`.toLowerCase();
  if (item.stepByStepMath || /math|noise|rigging|wbgt|ventilat|twa|formula|force|dose|volume/.test(text)) return "⚡";
  if (/toxic|hygiene|exposure|sds|radiation|noise|heat|ventilation/.test(text)) return "🔬";
  if (/law|legal|standard|osha|ansi|iso|regulation/.test(text)) return "⚖️";
  if (/ergo|lifting|human factor|fatigue/.test(text)) return "🦾";
  if (/process safety|moc|hazop|fmea|fta|psm/.test(text)) return "🛡️";
  return "🎯";
}

function difficultyLabel(value: string) {
  const v = value.toLowerCase();
  if (v.includes("expert") || v.includes("advanced")) return { icon: "🔴", label: "Expert Math Lab" };
  if (v.includes("exam") || v.includes("scenario")) return { icon: "🟡", label: "Advanced Scenario" };
  return { icon: "🟢", label: "Core Practice" };
}

export type PlayResult = {
  pct: number;
  correct: number;
  total: number;
  /** Non-pretest items used for displayed % */
  scoredTotal?: number;
  answers: AnswerRow[];
  domainScores: Record<number, number>;
  timedOut?: boolean;
  flaggedWrong?: number;
  errorCounts?: Record<string, number>;
  pretestExcluded?: number;
  elapsedSeconds?: number;
};

export function QuestionPlayer({
  items,
  persistUrl,
  showCards,
  showCalculator,
  seedNote,
  examMode,
  timerMinutes,
  showDomainBreakdown,
  onComplete,
  sprintMode,
  showFlag = true,
  teachMode = false,
  readinessMode = false,
}: {
  items: Item[];
  persistUrl?: string;
  showCards?: boolean;
  showCalculator?: boolean;
  seedNote?: string;
  examMode?: boolean;
  timerMinutes?: number;
  showDomainBreakdown?: boolean;
  onComplete?: (result: PlayResult) => void;
  sprintMode?: boolean;
  showFlag?: boolean;
  teachMode?: boolean;
  readinessMode?: boolean;
}) {
  const [i, setI] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [pending, setPending] = useState<number | null>(null);
  const [instant, setInstant] = useState(!teachMode);
  const [correctCount, setCorrectCount] = useState(0);
  const [done, setDone] = useState(false);
  const [timedOut, setTimedOut] = useState(false);
  const [answers, setAnswers] = useState<AnswerRow[]>([]);
  const [flagged, setFlagged] = useState(false);
  const [remain, setRemain] = useState<number | null>(
    timerMinutes != null ? Math.round(timerMinutes * 60) : null,
  );
  const item = items[i];
  const letters = ["A", "B", "C", "D"];
  const doneRef = useRef(false);
  const startedAtRef = useRef(Date.now());
  const snapshot = useRef({ i: 0, picked: null as number | null, correctCount: 0, answers: [] as AnswerRow[] });
  snapshot.current = { i, picked, correctCount, answers };

  const progress = useMemo(() => {
    if (sprintMode) return `Item ${i + 1}`;
    return `${i + 1} / ${items.length}`;
  }, [i, items.length, sprintMode]);

  useEffect(() => {
    if (!item) return;
    if (isDemoClient()) {
      setFlagged(demoHasFlag(item.id));
      return;
    }
    let ignore = false;
    fetch("/api/flags")
      .then((r) => r.json())
      .then((d: { ids?: string[] }) => {
        if (!ignore) setFlagged(Boolean(d.ids?.includes(item.id)));
      })
      .catch(() => {
        if (!ignore) setFlagged(false);
      });
    return () => {
      ignore = true;
    };
  }, [item?.id]);

  function domainScoresFrom(rows: AnswerRow[]): Record<number, number> {
    const acc: Record<number, { ok: number; n: number }> = {};
    for (const row of rows) {
      const d = row.domain ?? 0;
      if (!d) continue;
      acc[d] = acc[d] ?? { ok: 0, n: 0 };
      acc[d].n += 1;
      if (row.correct) acc[d].ok += 1;
    }
    const out: Record<number, number> = {};
    for (const [k, v] of Object.entries(acc)) {
      out[Number(k)] = v.n ? (v.ok / v.n) * 100 : 0;
    }
    return out;
  }

  function finish(rows: AnswerRow[], ok: number, timeout: boolean) {
    if (doneRef.current) return;
    doneRef.current = true;
    const total = sprintMode ? Math.max(rows.length, 1) : items.length || 1;
    const pct = Math.round((ok / total) * 100);
    const result: PlayResult = {
      pct,
      correct: ok,
      total: sprintMode ? rows.length : items.length,
      answers: rows,
      domainScores: domainScoresFrom(rows),
      timedOut: timeout,
      elapsedSeconds: Math.max(1, Math.round((Date.now() - startedAtRef.current) / 1000)),
    };
    setTimedOut(timeout);
    setAnswers(rows);
    setCorrectCount(ok);
    setDone(true);
    onComplete?.(result);
  }

  useEffect(() => {
    if (remain == null || doneRef.current) return;
    if (remain <= 0) {
      const snap = snapshot.current;
      if (sprintMode) {
        const rows = [...snap.answers];
        if (snap.picked != null) {
          const q = items[snap.i];
          if (q && !rows.some((r) => r.questionId === q.id)) {
            rows.push({
              questionId: q.id,
              selected: snap.picked,
              correct: snap.picked === q.answerIndex,
              domain: q.domain,
              classId: q.classId,
            });
          }
        }
        const ok = rows.filter((r) => r.correct).length;
        finish(rows, ok, true);
        return;
      }
      const leftover: AnswerRow[] = [];
      for (let k = snap.i; k < items.length; k++) {
        const q = items[k]!;
        leftover.push({
          questionId: q.id,
          selected: k === snap.i && snap.picked != null ? snap.picked : -1,
          correct: k === snap.i && snap.picked === q.answerIndex,
          domain: q.domain,
          classId: q.classId,
          classTitle: q.classTitle,
        });
      }
      const rows = [...snap.answers, ...leftover.filter((r) => !snap.answers.some((a) => a.questionId === r.questionId))];
      const ok = rows.filter((r) => r.correct).length;
      finish(rows, ok, true);
      return;
    }
    const t = setTimeout(() => setRemain((r) => (r == null ? r : r - 1)), 1000);
    return () => clearTimeout(t);
  }, [remain, items, sprintMode]);

  async function commitAnswer(idx: number) {
    if (picked != null || !item || doneRef.current) return;
    setPicked(idx);
    setPending(null);
    const ok = idx === item.answerIndex;
    if (ok) setCorrectCount((c) => c + 1);
    const row: AnswerRow = {
      questionId: item.id,
      selected: idx,
      correct: ok,
      domain: item.domain,
      classId: item.classId,
      classTitle: item.classTitle,
    };
    setAnswers((a) => [...a, row]);
    if (isDemoClient()) {
      recordDemoAttempt({
        questionId: item.id,
        selected: idx,
        correct: ok,
        domain: item.domain,
        classId: item.classId,
        difficulty: item.difficulty,
        at: new Date().toISOString(),
        item: ok ? undefined : item,
      });
    }
    if (persistUrl) {
      await fetch(persistUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ questionId: item.id, selected: idx, correct: ok }),
      });
    }
  }

  async function choose(idx: number) {
    if (picked != null || !item || doneRef.current) return;
    if (teachMode && !instant) {
      setPending(idx);
      return;
    }
    await commitAnswer(idx);
  }

  async function toggleFlag() {
    if (!item) return;
    if (isDemoClient()) {
      const on = toggleDemoFlag({
        questionId: item.id,
        stemPreview: item.stem.slice(0, 140),
        domain: item.domain,
        classId: item.classId,
        difficulty: item.difficulty,
      });
      setFlagged(on);
      return;
    }
    const method = flagged ? "DELETE" : "POST";
    const res = await fetch("/api/flags", {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ questionId: item.id }),
    });
    const data = (await res.json().catch(() => ({}))) as { ok?: boolean; flagged?: boolean };
    if (data.ok) setFlagged(Boolean(data.flagged));
    else setFlagged((f) => !f);
  }

  function next() {
    const snap = snapshot.current;
    if (snap.i + 1 >= items.length) {
      finish(snap.answers, snap.correctCount, false);
      return;
    }
    setI(snap.i + 1);
    setPicked(null);
    setPending(null);
  }

  if (!item) {
    return (
      <div className="card p-6">
        <p className="kicker">Empty bank</p>
        <p className="mt-2">No items in this gym yet. Open a class or another practice desk.</p>
        <Link href="/practice" className="btn-primary mt-4">
          Open practice
        </Link>
      </div>
    );
  }

  if (done) {
    const total = sprintMode ? answers.length || 1 : items.length || 1;
    const pct = Math.round((correctCount / total) * 100);
    const ds = domainScoresFrom(answers);
    const elapsedSeconds = Math.max(1, Math.round((Date.now() - startedAtRef.current) / 1000));
    const expectedSecondsPerItem = items.length ? (timerMinutes ? (timerMinutes * 60) / items.length : 0) : 0;
    const avgSecondsPerItem = answers.length ? elapsedSeconds / answers.length : 0;
    const domainValues = [1, 2, 3, 4, 5, 6, 7].map((d) => ds[d]).filter((v): v is number => v != null);
    const weakestDomain = domainValues.length ? [1, 2, 3, 4, 5, 6, 7].sort((a, b) => (ds[a] ?? 101) - (ds[b] ?? 101))[0] : null;
    const weakCount = domainValues.filter((v) => v < 60).length;
    const classAcc: Record<number, { ok: number; n: number; title: string }> = {};
    for (const row of answers) {
      if (!row.classId) continue;
      classAcc[row.classId] ??= { ok: 0, n: 0, title: row.classTitle || `Module ${row.classId}` };
      classAcc[row.classId].n += 1;
      if (row.correct) classAcc[row.classId].ok += 1;
    }
    const weakModules = Object.entries(classAcc)
      .map(([id, v]) => ({ id: Number(id), title: v.title, score: (v.ok / v.n) * 100, n: v.n }))
      .filter((m) => m.score < 60)
      .sort((a, b) => a.score - b.score)
      .slice(0, 3);
    const pacingConcern = Boolean(timerMinutes && answers.length && avgSecondsPerItem > expectedSecondsPerItem * 1.15);
    const readiness = pct >= 75 && weakCount === 0 && !timedOut ? { label: "Ready for Exam", tone: "text-safepath-lime", blurb: "Strong overall performance with no domain below the focused-review threshold." }
      : pct >= 65 && weakCount <= 2 && !timedOut ? { label: "Borderline", tone: "text-amber", blurb: "You have a workable base, but targeted domain repair is recommended before exam day." }
      : { label: "Requires Focused Review", tone: "text-bad", blurb: "Use the weakest domains and math desk to close the largest gaps before another sitting." };
    return (
      <div className="readiness-hero space-y-5">
        <div className="flex flex-wrap items-center gap-5">
          <div className="score-orb"><div className="text-center"><div className="text-2xl font-black">{pct}%</div><div className="text-[10px] uppercase tracking-wide text-muted">score</div></div></div>
          <div><p className="kicker">{readinessMode ? "🎯 Diagnostic complete" : "🏁 Session complete"}</p><h2 className="mt-1 text-2xl font-bold">{readinessMode ? "Your readiness snapshot" : "Nice work — debrief time"}</h2><p className="mt-1 text-sm text-muted">{correctCount} of {sprintMode ? answers.length : items.length} correct · {Math.round(avgSecondsPerItem)} sec/item</p></div>
        </div>
        {readinessMode ? (
          <section className="rounded-2xl border border-line bg-panel-2/70 p-5">
            <p className="text-xs uppercase tracking-[0.16em] text-muted">SafePath diagnostic readiness</p>
            <p className={`mt-1 text-2xl font-semibold ${readiness.tone}`}>{readiness.label}</p>
            <p className="mt-2 text-sm text-muted">{readiness.blurb}</p>
            <div className="mt-3 grid gap-2 text-sm sm:grid-cols-3">
              <div><span className="text-muted">Pacing</span><br />{Math.round(avgSecondsPerItem)} sec/item{pacingConcern ? " · review speed" : " · on track"}</div>
              <div><span className="text-muted">Weak domains</span><br />{weakCount ? `${weakCount} below 60%` : "None below 60%"}</div>
              <div><span className="text-muted">Focus next</span><br />{weakestDomain ? `D${weakestDomain}` : "Maintain all domains"}</div>
            </div>
          </section>
        ) : null}
        <p>
          {correctCount} of {sprintMode ? answers.length : items.length} correct.
          {timedOut
            ? sprintMode
              ? " Time expired — score is based on items you finished."
              : " Time expired — unanswered items counted as incorrect."
            : ""}
        </p>
        {readinessMode && weakModules.length ? (
          <section className="rounded-xl border border-line bg-panel-2 p-4">
            <p className="font-semibold">Weak curriculum modules</p>
            <p className="mt-1 text-sm text-muted">These modules were below 60% in this sitting. Reopen them before your next diagnostic.</p>
            <div className="mt-3 space-y-2">
              {weakModules.map((m) => (
                <div key={m.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-line bg-ink p-3">
                  <div><span className="font-semibold">{m.title}</span><span className="ml-2 text-xs text-muted">{Math.round(m.score)}% · {m.n} item{m.n === 1 ? "" : "s"}</span></div>
                  <Link href={`/learn/${m.id}`} className="text-sm text-amber underline-offset-4 hover:underline">Open module →</Link>
                </div>
              ))}
            </div>
            <Link href="/math" className="mt-3 inline-block text-sm text-amber underline-offset-4 hover:underline">Open math practice desk →</Link>
          </section>
        ) : null}
        {showDomainBreakdown ? (
          <section className="space-y-2">
            <p className="font-semibold">Domain performance</p>
            <div className="grid gap-2 sm:grid-cols-2">
              {[1, 2, 3, 4, 5, 6, 7].map((d) => {
                const score = ds[d];
                const weak = score != null && score < 60;
                return (
                  <div key={d} className={`rounded-lg border p-3 ${weak ? "border-bad/40 bg-bad/5" : "border-line bg-panel-2"}`}>
                    <div className="flex items-center justify-between gap-2">
                      <span>Domain {d}</span>
                      <span className={weak ? "font-semibold text-bad" : "font-semibold"}>{score == null ? "Not sampled" : `${Math.round(score)}%`}</span>
                    </div>
                    {readinessMode && weak ? (
                      <div className="mt-2 flex flex-wrap gap-2 text-xs">
                        <Link href={`/domains?d=${d}`} className="text-amber underline-offset-4 hover:underline">Review D{d} gym</Link>
                        <Link href="/math" className="text-amber underline-offset-4 hover:underline">Math desk</Link>
                      </div>
                    ) : null}
                  </div>
                );
              })}
            </div>
          </section>
        ) : null}
        <p className="text-sm text-muted">
          {examMode ? "Exam mode hid cards. Calculator stayed available." : "Drill mode keeps the card in view."}
        </p>
        <div className="flex flex-wrap gap-2">
          <button type="button" className="btn-primary" onClick={() => location.reload()}>
            Run again
          </button>
          <Link href="/practice" className="btn-ghost tap">
            Practice hub
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {seedNote ? (
        <p className="rounded-lg border border-line bg-panel-2 px-3 py-2 text-sm text-muted">{seedNote}</p>
      ) : null}
      <div className="flex flex-wrap items-center justify-between gap-2 text-sm text-muted">
        <span>{progress}</span>
        {remain != null ? (
          <span className={`rounded-full border px-3 py-1 font-mono ${remain <= 60 ? "border-bad/40 bg-bad/10 text-bad" : "border-gold/30 bg-gold/5 text-gold"}`} aria-live="polite">⏱ {formatClock(remain)}</span>
        ) : null}
        <div className="flex flex-wrap items-center gap-2">
          <span className="rounded-full border border-line bg-panel-2 px-2.5 py-1 text-xs">{itemSymbol(item)} {examMode && picked == null ? "Exam item" : item.taskCode}</span>
          {!examMode || picked != null ? <span className="rounded-full border border-line bg-panel-2 px-2.5 py-1 text-xs">{difficultyLabel(item.difficulty).icon} {difficultyLabel(item.difficulty).label}</span> : null}
          {!examMode || picked != null ? <span className="hidden rounded-full border border-line bg-panel-2 px-2.5 py-1 text-xs sm:inline">{item.errorCode}</span> : null}
        </div>
      </div>
      <div className="card p-5 space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div className="flex-1 space-y-2">
            {item.scenarioText && item.scenarioText !== item.stem ? (
              <p className="text-sm text-muted leading-relaxed">{item.scenarioText}</p>
            ) : null}
            <p className="text-lg leading-relaxed">{item.stem}</p>
          </div>
          {showFlag ? (
            <button type="button" className="btn-ghost tap text-sm" onClick={toggleFlag} aria-pressed={flagged}>
              {flagged ? "Flagged" : "Flag"}
            </button>
          ) : null}
        </div>
        {teachMode ? (
          <label className="flex items-center gap-2 text-sm text-muted">
            <input
              type="checkbox"
              checked={instant}
              onChange={(e) => setInstant(e.target.checked)}
              disabled={picked != null}
            />
            Instant feedback (off = pick, then check for rationale)
          </label>
        ) : null}
        <div className="grid gap-2" role="radiogroup" aria-label="Answer choices">
          {item.options.map((opt, idx) => {
            const show = picked != null;
            const isAns = idx === item.answerIndex;
            const isPick = idx === picked;
            const isPending = pending === idx;
            let cls = "option-row";
            if (show && isAns) cls += " is-correct";
            if (show && isPick && !isAns) cls += " is-wrong";
            return (
              <label key={idx} className={cls}>
                <input
                  type="radio"
                  name={`study-${item.id}`}
                  checked={isPick || isPending}
                  disabled={picked != null}
                  onChange={() => choose(idx)}
                />
                <span className="option-letter">{letters[idx]}</span>
                <span>{opt}</span>
              </label>
            );
          })}
        </div>
        {teachMode && !instant && picked == null ? (
          <button
            type="button"
            className="btn-primary tap"
            disabled={pending == null}
            onClick={() => pending != null && commitAnswer(pending)}
          >
            Check answer
          </button>
        ) : null}
        {picked != null ? (
          <div className="space-y-3 rounded-lg bg-ink p-3 text-sm">
            <p>{picked === item.answerIndex ? "Correct." : "Not this one."}</p>
            {item.scenarioText ? <p className="text-muted">Scenario framing: {item.scenarioText}</p> : null}
            <p>{item.explanation}</p>
            {(item.optionTraps?.length === 4 || item.distractors?.length === 4) ? (
              <div className="space-y-1">
                <p className="font-medium text-amber">Option trap analysis</p>
                <ul className="space-y-1 text-muted">
                  {(item.optionTraps?.length === 4 ? item.optionTraps : item.distractors)!.map((why, idx) => (
                    <li key={idx}>
                      <span className="font-mono text-amber">{letters[idx]}.</span>{" "}
                      {idx === item.answerIndex ? <span className="text-amber">Key — </span> : null}
                      {why}
                    </li>
                  ))}
                </ul>
              </div>
            ) : picked !== item.answerIndex && item.distractors?.[picked] ? (
              <p className="text-muted">Why this option misses: {item.distractors[picked]}</p>
            ) : null}
            {item.stepByStepMath ? (
              <div className="space-y-1 rounded-md border border-line bg-panel-2 p-2">
                <p className="font-medium text-amber">Worked math (TI-30XS)</p>
                <div className="rounded-lg border border-safepath-lime/15 bg-[#07101b] p-3 font-mono text-sm shadow-inner">
                  <p className="text-safepath-lime"><span className="text-muted">FORMULA ➔ </span>{item.stepByStepMath.formula}</p>
                </div>
                <ul className="text-muted">
                  {Object.entries(item.stepByStepMath.variables).map(([k, v]) => (
                    <li key={k}>
                      <span className="font-mono text-amber">{k}</span> = {v}
                    </li>
                  ))}
                </ul>
                <ol className="space-y-1 pl-0 text-muted">
                  {item.stepByStepMath.derivationSteps.map((step, idx) => (
                    <li key={idx} className="font-mono text-xs"><span className="mr-2 text-safepath-lime">➔</span>{step}</li>
                  ))}
                </ol>
                <div className="rounded-lg border border-line bg-[#07101b] p-3 font-mono text-xs leading-relaxed text-amber">
                  <span className="text-muted">TI-30XS (DEG) ➔ </span>{item.stepByStepMath.ti30KeystrokeSequence}
                </div>
              </div>
            ) : null}
            {item.fieldTakeaway ? (
              <p>
                <span className="font-medium text-amber">Field takeaway:</span> {item.fieldTakeaway}
              </p>
            ) : null}
            {item.standardReference ? (
              <p className="text-muted">
                <span className="font-medium">Reference:</span> {item.standardReference}
              </p>
            ) : null}
            <p className="text-muted">
              Error code {item.errorCode}.{" "}
              <Link href="/errors" className="text-amber underline-offset-4 hover:underline">
                Meanings
              </Link>
            </p>
            <button type="button" className="btn-primary tap" onClick={next}>
              {i + 1 >= items.length ? "Finish" : "Next"}
            </button>
          </div>
        ) : null}
      </div>
      {showCards && item.classId ? (
        <p className="text-sm">
          Card on.{" "}
          <Link className="text-amber underline-offset-4 hover:underline" href={`/learn/${item.classId}`}>
            Open the class card
          </Link>
        </p>
      ) : null}
      {showCalculator ? (
        <p className="text-sm">
          Calculator on.{" "}
          <Link className="text-amber underline-offset-4 hover:underline" href="/calculator">
            Open practice calculator
          </Link>
        </p>
      ) : null}
    </div>
  );
}
