import { DOMAIN_NAMES } from "@/lib/constants";
import { formatSittingDate } from "@/lib/certificate";

export function CertificateView({
  candidateName,
  date,
  length,
  score,
  domainScores,
  demo,
}: {
  candidateName: string;
  date: string | Date;
  length: number;
  score: number;
  domainScores: Record<number, number>;
  demo?: boolean;
}) {
  return (
    <article className="certificate-sheet">
      <p className="certificate-watermark" aria-hidden="true">
        PRACTICE RESULT — NOT A BCSP CREDENTIAL
      </p>
      <p className="certificate-kicker">Independent study aid</p>
      <h1 className="certificate-title">Safepath CSP Practice Examination — Result of Completion</h1>
      <p className="certificate-sub">PRACTICE RESULT — NOT A BCSP CREDENTIAL</p>
      <dl className="certificate-meta">
        <div>
          <dt>Candidate</dt>
          <dd>{candidateName || "Candidate"}</dd>
        </div>
        <div>
          <dt>Date</dt>
          <dd>{formatSittingDate(date)}</dd>
        </div>
        <div>
          <dt>Length</dt>
          <dd>{length} items</dd>
        </div>
        <div>
          <dt>Score</dt>
          <dd>{Math.round(score)}%</dd>
        </div>
      </dl>
      <table className="certificate-table">
        <thead>
          <tr>
            <th>Domain</th>
            <th>Name</th>
            <th>Score</th>
          </tr>
        </thead>
        <tbody>
          {[1, 2, 3, 4, 5, 6, 7].map((d) => (
            <tr key={d}>
              <td>{d}</td>
              <td>{DOMAIN_NAMES[d]}</td>
              <td>{domainScores[d] == null ? "—" : `${Math.round(domainScores[d])}%`}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="certificate-body">
        This document records a Safepath CSP practice sitting aligned to the public CSP-11 blueprint. It is not issued
        by the Board of Certified Safety Professionals. It does not confer the CSP credential. It is not a Pearson
        VUE score report. It is for study only.
      </p>
      {demo ? (
        <p className="certificate-body">
          Demo sitting — this practice result is shown for this session only and was not saved.
        </p>
      ) : null}
    </article>
  );
}
