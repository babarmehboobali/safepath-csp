"use client";

import { useEffect, useMemo, useState } from "react";

export type LessonNoteRow = {
  id: string;
  content: string;
  createdAt: string;
  updatedAt?: string;
};

function formatStamp(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Saved note";
  return new Intl.DateTimeFormat(undefined, {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(date);
}

function localKey(classId: number) {
  return `safepath-lesson-notes:${classId}`;
}

export function LessonNotesDrawer({
  classId,
  title,
  compact = false,
  isDemo = false,
}: {
  classId: number;
  title: string;
  compact?: boolean;
  isDemo?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [notes, setNotes] = useState<LessonNoteRow[]>([]);
  const [draft, setDraft] = useState("");
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [loaded, setLoaded] = useState(false);

  const loadNotes = async () => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`/api/lesson-notes?classId=${classId}`, { cache: "no-store" });
      const payload = (await res.json().catch(() => ({}))) as { notes?: LessonNoteRow[]; error?: string };
      if (res.ok) {
        setNotes(payload.notes ?? []);
      } else {
        setError(payload.error || "Could not load notes.");
      }
    } catch {
      setError("Could not load notes. Check your local server.");
    } finally {
      setLoading(false);
      setLoaded(true);
    }
  };

  useEffect(() => {
    if (!open || loaded) return;
    void loadNotes();
  }, [open, loaded]);

  const demoNotes = useMemo(() => {
    if (!isDemo || !open) return [];
    try {
      const raw = window.localStorage.getItem(localKey(classId));
      if (!raw) return [];
      const parsed = JSON.parse(raw) as unknown;
      return Array.isArray(parsed) ? (parsed as LessonNoteRow[]) : [];
    } catch {
      return [];
    }
  }, [classId, isDemo, open]);

  useEffect(() => {
    if (!open || !isDemo || demoNotes.length === 0 || notes.length > 0) return;
    setNotes(demoNotes);
  }, [demoNotes, isDemo, notes.length, open]);

  async function saveNote() {
    const content = draft.trim();
    if (!content || saving) return;
    setSaving(true);
    setError("");
    try {
      const res = await fetch("/api/lesson-notes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ classId, content }),
      });
      const payload = (await res.json().catch(() => ({}))) as { note?: LessonNoteRow; error?: string; skipped?: boolean };
      if (!res.ok || !payload.note) {
        setError(payload.error || "Could not save note.");
        return;
      }
      setNotes((current) => [payload.note!, ...current]);
      setDraft("");
      if (payload.skipped) {
        const current = demoNotes;
        try {
          window.localStorage.setItem(localKey(classId), JSON.stringify([payload.note, ...current]));
        } catch {
          // Local storage is optional.
        }
      }
    } catch {
      setError("Could not save note. Check your local server.");
    } finally {
      setSaving(false);
    }
  }

  async function deleteNote(note: LessonNoteRow) {
    try {
      const res = await fetch("/api/lesson-notes", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: note.id }),
      });
      if (res.ok) {
        const payload = (await res.json().catch(() => ({}))) as { skipped?: boolean };
        setNotes((current) => current.filter((row) => row.id !== note.id));
        if (payload.skipped) {
          try {
            const next = notes.filter((row) => row.id !== note.id);
            window.localStorage.setItem(localKey(classId), JSON.stringify(next));
          } catch {
            // Local storage is optional.
          }
        }
      }
    } catch {
      // Deleting is best-effort; keep the note visible when offline.
    }
  }

  return (
    <>
      <button
        type="button"
        className={`${compact ? "tap h-10 px-3 text-xs" : "tap px-3.5 py-2 text-sm"} inline-flex items-center gap-2 rounded-xl border border-[var(--user-accent-strong)] bg-[var(--user-accent-soft)] font-semibold text-[var(--theme-text)] transition hover:-translate-y-0.5 hover:border-[var(--user-accent)] hover:shadow-[0_8px_24px_var(--user-accent-soft)]`}
        onClick={() => setOpen(true)}
        aria-haspopup="dialog"
        aria-expanded={open}
      >
        📝 {notes.length ? `${notes.length} note${notes.length === 1 ? "" : "s"}` : "Personal notes"}
      </button>

      {open ? (
        <div className="fixed inset-0 z-[60]" role="dialog" aria-modal="true" aria-label={`Personal notes for ${title}`}>
          <button className="absolute inset-0 bg-black/60 backdrop-blur-[2px]" aria-label="Close notes" onClick={() => setOpen(false)} />
          <aside className="absolute right-0 top-0 flex h-full w-[min(430px,94vw)] flex-col border-l border-[var(--theme-border)] bg-[var(--theme-bg)] shadow-[-20px_0_70px_rgba(0,0,0,.42)]">
            <div className="border-b border-[var(--theme-border)] bg-[var(--theme-panel)] px-4 py-4 sm:px-5">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="kicker">📝 Personal Study Notes</p>
                  <h2 className="mt-1 line-clamp-2 font-serif text-xl font-bold">{title}</h2>
                  <p className="mt-1 text-xs text-[var(--theme-muted)]">Notes are private to your account and tied to Class {classId}.</p>
                </div>
                <button type="button" className="tap rounded-lg border border-[var(--theme-border)] px-3 text-sm font-semibold" onClick={() => setOpen(false)}>Close</button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-5">
              <div className="rounded-2xl border border-[var(--theme-border)] bg-[var(--theme-panel)] p-4">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <p className="text-sm font-bold">Capture the idea while it is fresh</p>
                    <p className="mt-1 text-xs text-[var(--theme-muted)]">Use this for formulas, traps, examples, or questions you want to revisit.</p>
                  </div>
                  <span className="rounded-full border border-[var(--theme-border)] bg-[var(--theme-panel-2)] px-2 py-1 text-[10px] font-mono text-[var(--theme-muted)]">{draft.length}/5000</span>
                </div>
                <textarea
                  value={draft}
                  onChange={(event) => setDraft(event.target.value.slice(0, 5000))}
                  className="mt-3 min-h-32 w-full resize-y rounded-xl border border-[var(--theme-border)] bg-[var(--theme-bg)] p-3 text-sm text-[var(--theme-text)] outline-none transition focus:border-[var(--user-accent)]"
                  placeholder="Write your own takeaway, a worked step, a memory cue, or a question..."
                />
                {error ? <p className="mt-2 text-xs font-semibold text-bad">{error}</p> : null}
                <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
                  <span className="text-[11px] text-[var(--theme-muted)]">Saved with a timestamp</span>
                  <button type="button" className="btn-primary tap text-sm" onClick={saveNote} disabled={saving || !draft.trim()}>
                    {saving ? "Saving…" : "Save note"}
                  </button>
                </div>
              </div>

              <div className="mt-5 flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-bold">Your notes</p>
                  <p className="text-xs text-[var(--theme-muted)]">Newest first</p>
                </div>
                <span className="chip">{notes.length}</span>
              </div>

              {loading ? (
                <div className="mt-4 rounded-xl border border-[var(--theme-border)] bg-[var(--theme-panel)] p-4 text-sm text-[var(--theme-muted)]">Loading notes…</div>
              ) : notes.length ? (
                <div className="mt-4 space-y-3">
                  {notes.map((note) => (
                    <article key={note.id} className="rounded-2xl border border-[var(--theme-border)] bg-[var(--theme-panel)] p-4 shadow-sm">
                      <div className="flex items-start justify-between gap-3">
                        <time className="text-[11px] font-semibold text-[var(--user-accent)]">{formatStamp(note.createdAt)}</time>
                        <button type="button" className="text-[11px] font-semibold text-[var(--theme-muted)] underline-offset-4 hover:text-bad hover:underline" onClick={() => deleteNote(note)}>Delete</button>
                      </div>
                      <p className="mt-2 whitespace-pre-wrap text-sm leading-7 text-[var(--theme-text)]">{note.content}</p>
                    </article>
                  ))}
                </div>
              ) : (
                <div className="mt-4 rounded-2xl border border-dashed border-[var(--theme-border)] bg-[var(--theme-panel)] p-6 text-center">
                  <div className="text-3xl">🧠</div>
                  <p className="mt-2 text-sm font-bold">No personal notes yet</p>
                  <p className="mt-1 text-xs leading-6 text-[var(--theme-muted)]">Save the first thing you want future-you to remember.</p>
                </div>
              )}
            </div>
          </aside>
        </div>
      ) : null}
    </>
  );
}
