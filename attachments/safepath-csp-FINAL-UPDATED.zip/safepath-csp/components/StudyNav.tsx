"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";

const NAV = [
  ["Dashboard", "/dashboard"],
  ["Learn", "/plan"],
  ["Gyms", "/practice"],
  ["Mock", "/mock"],
  ["Cards", "/cards"],
  ["Account", "/settings"],
  ["Eligibility", "/eligibility"],
] as const;

const PRACTICE_PREFIXES = [
  "/sessions",
  "/domains",
  "/drill",
  "/challenge",
  "/assess",
  "/math",
  "/tox",
  "/bank",
  "/flags",
  "/today",
  "/formulas",
  "/calculator",
  "/errors",
  "/exam-day",
];

function linkActive(path: string, href: string) {
  if (href === "/cards") return path === "/cards" || path.startsWith("/cards/");
  const on = href === "/dashboard" ? path === href : path === href || path.startsWith(`${href}/`);
  const planOn = href === "/plan" && path.startsWith("/learn");
  const practiceOn = href === "/practice" && PRACTICE_PREFIXES.some((p) => path === p || path.startsWith(`${p}/`));
  return on || planOn || practiceOn;
}

export function StudyNav() {
  const path = usePathname() || "";
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setOpen(false);
  }, [path]);

  useEffect(() => {
    if (!open) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") setOpen(false);
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  const navLinks = (
    <>
      <Link href="/assess" className={`site-nav-link assess ${linkActive(path, "/assess") ? "is-active" : ""}`}>🎯 Self-Assessment</Link>
      {NAV.map(([label, href]) => {
        const active = linkActive(path, href);
        const icon = href === "/dashboard" ? "⌂" : href === "/plan" ? "📚" : href === "/practice" ? "⚡" : href === "/mock" ? "⏱" : href === "/cards" ? "🧠" : href === "/settings" ? "⚙" : "✅";
        return (
          <Link key={href} href={href} className={`site-nav-link ${active ? "is-active" : ""}`}>
            <span aria-hidden className="mr-1.5 text-sm opacity-90">{icon}</span>{label}
          </Link>
        );
      })}
    </>
  );

  return (
    <>
      <nav className="ml-2 hidden flex-1 items-center gap-1 lg:flex" aria-label="Primary">
        {navLinks}
        <form action="/api/auth/logout" method="post" className="ml-auto">
          <button type="submit" className="site-nav-link ml-auto">
            Log out
          </button>
        </form>
      </nav>

      <button
        type="button"
        className="ml-auto inline-flex h-11 w-11 items-center justify-center rounded-lg border border-line text-cream lg:hidden"
        aria-label={open ? "Close menu" : "Open menu"}
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
      >
        <span className="sr-only">Menu</span>
        <span aria-hidden className="flex flex-col gap-1.5">
          <span className="block h-0.5 w-5 bg-cream" />
          <span className="block h-0.5 w-5 bg-cream" />
          <span className="block h-0.5 w-5 bg-cream" />
        </span>
      </button>

      {open ? (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="Site menu">
          <button type="button" className="absolute inset-0 bg-black/55" aria-label="Dismiss menu" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-0 flex h-full w-[min(20rem,88vw)] flex-col gap-1 overflow-y-auto border-l border-line bg-panel p-4 shadow-2xl">
            <div className="mb-3 flex items-center justify-between">
              <p className="text-sm font-semibold text-cream">Menu</p>
              <button type="button" className="btn-ghost tap text-sm" onClick={() => setOpen(false)}>
                Close
              </button>
            </div>
            {navLinks}
            <form action="/api/auth/logout" method="post" className="mt-4 border-t border-line pt-4">
              <button type="submit" className="site-nav-link w-full justify-start">
                Log out
              </button>
            </form>
          </div>
        </div>
      ) : null}
    </>
  );
}
