import Link from "next/link";
import Image from "next/image";
import { APP_NAME, DISCLAIMER, NAV_SHORT } from "@/lib/constants";
import type { SessionUser } from "@/lib/auth";
import { StudyNav } from "./StudyNav";
import { StreakView } from "./StreakView";
import { prisma } from "@/lib/prisma";
import { FloatingCalculator } from "./FloatingCalculator";
import { ThemeProvider, type ThemePreset, type Density, type LayoutStyle } from "./ThemeProvider";

export function SiteFooter() {
  return (
    <footer className="mt-auto border-t border-line px-6 py-8 text-sm text-muted">
      <div className="mx-auto max-w-6xl space-y-3">
        <p>
          <Link href="/disclaimer" className="underline-offset-4 hover:underline">
            Disclaimer
          </Link>
        </p>
        <p className="leading-relaxed whitespace-pre-line">{DISCLAIMER}</p>
      </div>
    </footer>
  );
}

export async function AppShell({
  user,
  children,
}: {
  user: SessionUser | null;
  children: React.ReactNode;
}) {
  const account = user && !user.isDemo
    ? await prisma.user.findUnique({
        where: { id: user.id },
        select: { xp: true, level: true, currentStreak: true, themePreset: true, accentColor: true, density: true, layoutStyle: true },
      })
    : null;

  const progression = account ? { xp: account.xp, level: account.level, currentStreak: account.currentStreak } : null;
  const theme = account ? { themePreset: account.themePreset, accentColor: account.accentColor, density: account.density, layoutStyle: account.layoutStyle } : null;

  return (
    <ThemeProvider storageKey={`safepath-theme:${user?.id ?? "guest"}`} initial={{ themePreset: (theme?.themePreset as ThemePreset) || "midnight", accentColor: theme?.accentColor || "#7cdb3a", density: (theme?.density as Density) || "comfortable", layoutStyle: (theme?.layoutStyle as LayoutStyle) || "focus" }}>
    <div className="app-shell flex min-h-full flex-col" {...(user?.isDemo ? { "data-demo": "1" } : {})}>
      <header className="sticky top-0 z-30 border-b border-line bg-navy/92 backdrop-blur-xl shadow-[0_10px_40px_rgba(0,0,0,.22)]">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-3 px-3 py-3 sm:px-5 lg:px-6">
          <Link href={user ? "/dashboard" : "/"} className="flex items-center gap-2 font-semibold tracking-tight" title={APP_NAME} aria-label={APP_NAME}>
            <Image src="/logo-mark.png" alt="Safepath CSP" width={36} height={36} className="h-9 w-9 object-contain" priority />
            <span className="hidden md:inline text-lg">{APP_NAME}</span>
            <span className="md:hidden text-lg">{NAV_SHORT}</span>
          </Link>
          {user ? (
            <>
              <StudyNav />
              {progression ? <StreakView xp={progression.xp} level={progression.level} streak={progression.currentStreak} /> : null}
            </>
          ) : (
            <div className="ml-auto flex items-center gap-3">
              <Link href="/login" className="text-[15px] text-cream/80 hover:text-cream">
                Log in
              </Link>
              <Link href="/login?demo=1" className="btn-primary text-sm">
                Start free demo
              </Link>
            </div>
          )}
        </div>
        {user?.isDemo ? (
          <p className="border-t border-line px-6 py-2 text-center text-sm text-muted">
            Demo session — plan, attempts, scores, flags, streak, and card reviews are not stored.
          </p>
        ) : null}
      </header>
      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-6 sm:px-6 sm:py-8">{children}</main>
      <SiteFooter />
      {user ? <FloatingCalculator /> : null}
    </div>
    </ThemeProvider>
  );
}
