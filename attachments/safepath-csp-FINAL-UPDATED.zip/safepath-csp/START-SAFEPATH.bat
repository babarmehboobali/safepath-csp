@echo off
setlocal
cd /d "%~dp0"
title SafePath CSP - Local Server
color 0B

echo.
echo ===============================================
echo       SAFEPATH CSP - LOCAL STARTUP
echo ===============================================
echo.
echo Project: %CD%
echo.

where powershell.exe >nul 2>&1
if errorlevel 1 (
  echo ERROR: Windows PowerShell was not found.
  pause
  exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\start-local.ps1"
set "EXITCODE=%ERRORLEVEL%"

if not "%EXITCODE%"=="0" (
  echo.
  echo ===============================================
  echo SafePath CSP failed to start. Error: %EXITCODE%
  echo ===============================================
  echo.
  pause
)

endlocal & exit /b %EXITCODE%
