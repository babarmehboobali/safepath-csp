from pathlib import Path
import re
ROOT = Path("/workspace/safepath-csp/content/classes")
fails=[]
ok=[]
for n in range(1,131):
    ps=list(ROOT.glob("%d-*.ts"%n)) or list(ROOT.glob("%02d-*.ts"%n))
    if not ps:
        fails.append((n,"missing")); continue
    t=ps[0].read_text()
    def w(key, src=t):
        m=re.search(key+r":\s*`([\s\S]*?)`", src)
        return len(m.group(1).split()) if m else 0
    sw, dw = w("standard"), w("deep")
    reasons=[]
    if "mustScoreJson" not in t: reasons.append("nomust")
    if sw<300: reasons.append("std%d"%sw)
    if dw<500: reasons.append("deep%d"%dw)
    if reasons: fails.append((n, ",".join(reasons)))
    else: ok.append(n)
print("ok", len(ok), "fails", len(fails))
for item in fails: print("FAIL", item)
