#!/usr/bin/env python3
"""Attach EnhancedCSP fields to exam() calls without mangling good stems.

- Leaves scenario-quality stems intact; only expands clearly rote/short stems.
- Always inserts difficulty before the enhanced object for TS typing.
- Skips calls that already have fieldTakeaway/optionTraps.
"""
from __future__ import annotations
import argparse, re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CLASSES = ROOT / "content/classes"
GYM = ROOT / "content/gym"
BEATS = [
  "a plastics compounding turnaround",
  "a Gulf Coast chemical terminal",
  "a refinery coker outage",
  "a bridge deck pour laydown yard",
  "a pharma suite changeover",
  "a warehouse second-shift startup",
  "a grain elevator maintenance day",
  "a hospital utility plant shutdown",
  "a food packaging SKU change",
  "a semiconductor tool install",
  "an offshore fabrication night shift",
  "a municipal water-plant retrofit",
]
ROTE = re.compile(
  r"^(what is|which of the following|best described as|primarily is|means:|"
  r"is defined as|NIOSH .+ is best|EMR primarily|least consistent with|"
  r".+ is best described as:?$)",
  re.I,
)
DIFFS = {"Foundation", "Exam", "Expert"}

def decode(s: str) -> str:
  out=[]; i=0
  while i < len(s):
    if s[i]=="\\" and i+1 < len(s):
      n=s[i+1]
      mapping={"n":"\n","t":"\t",'"':'"',"\\":"\\"}
      if n in mapping: out.append(mapping[n]); i+=2; continue
      out.append(n); i+=2; continue
    out.append(s[i]); i+=1
  return "".join(out)

def esc(s: str) -> str:
  return s.replace("\\","\\\\").replace('"','\\"').replace("\n","\\n")

def class_id(p: Path) -> int:
  m=re.match(r"(\d+)-", p.name)
  return int(m.group(1)) if m else 0

def rule_of(src: str) -> str:
  m=re.search(r'rule:\s*"((?:\\.|[^"\\])*)"', src)
  if m: return decode(m.group(1))
  m=re.search(r"rule:\s*`([\s\S]*?)`", src)
  return m.group(1).strip() if m else "Prefer higher hierarchy and verify the critical step."

def ref_of(cid: int) -> str:
  refs={
    1:"NIOSH Prevention through Design; hierarchy of controls",
    2:"Hierarchy of controls (NIOSH / OSHA training materials)",
    3:"OSHA 29 CFR 1910.119 Process Safety Management",
    4:"NFPA 70E; OSHA 1910 Subpart S",
    5:"OSHA 1910.147 Control of Hazardous Energy",
    6:"OSHA 1910.28 / 1926 Subpart M",
    7:"OSHA 1926 Subpart P Excavations",
    8:"OSHA 1910.212 machine guarding",
    9:"OSHA 1910.146 permit-required confined spaces",
    10:"OSHA walking-working surfaces",
    11:"NFPA 101 Life Safety Code egress concepts",
    12:"OSHA powered industrial trucks / fleet safety practice",
    13:"OSHA 1910.178; ANSI/SAIA A92 aerial concepts",
    14:"OSHA 1926 Subpart CC; ASME B30 rigging concepts",
    15:"NIOSH lifting / manual handling guidance",
    16:"OSHA 1910 Subpart O machinery and machine guarding",
  }
  if cid in refs: return refs[cid]
  if 17<=cid<=38: return "Management-system PDCA / ISO 45001 public concepts"
  if 39<=cid<=46: return "Risk assessment, JHA/PHA public practice"
  if 47<=cid<=54: return "Emergency planning, ICS, NFPA fire protection public concepts"
  if 55<=cid<=60: return "EPA RCRA/SPCC/EPCRA; OSHA HazCom"
  if 61<=cid<=72: return "OSHA PELs; NIOSH methods; public IH / formula practice"
  if 73<=cid<=78: return "ANSI/ASSP Z490.1 training criteria (public)"
  return "Applicable OSHA / NFPA / ANSI / NIOSH public practice for the stem"

def find_calls(src: str):
  for m in re.finditer(r"\bexam\s*\(", src):
    start=m.start(); i=m.end(); depth=1; in_str=False; esc_ch=False
    while i < len(src) and depth:
      c=src[i]
      if in_str:
        if esc_ch: esc_ch=False
        elif c=="\\": esc_ch=True
        elif c=='"': in_str=False
      else:
        if c=='"': in_str=True
        elif c=="(": depth+=1
        elif c==")": depth-=1
      i+=1
    yield start, i, src[start:i]

def parse_trailing_difficulty(block: str) -> str | None:
  # look near the end for "Foundation"|"Exam"|"Expert" before optional array/object
  matches=list(re.finditer(r'"(Foundation|Exam|Expert)"', block))
  if matches:
    return matches[-1].group(1)
  return None

def extract_stem(block: str):
  m=re.match(r'exam\(\s*(T|"(?:\\.|[^"\\])*")\s*,\s*"((?:\\.|[^"\\])*)"', block, re.S)
  return m

def should_expand(stem: str) -> bool:
  s=stem.strip()
  if ROTE.match(s): return True
  if len(s) < 70 and "?" not in s and ":" in s: return True
  if len(s) < 55: return True
  return False

def upgrade_stem(stem: str, cid: int, idx: int, rule: str):
  beat=BEATS[(cid+idx)%len(BEATS)]
  scenario=f"You are the CSP reviewing a live decision at {beat}."
  if should_expand(stem):
    focus=stem.rstrip("?").rstrip(".")
    new=(
      f"{scenario} Operations proposes a convenience path. "
      f"Using the class rule, which option is strongest? Focus: {focus}."
    )
    return new, scenario
  return stem, scenario

def process(path: Path, dry: bool=False) -> int:
  src=path.read_text()
  if "exam(" not in src: return 0
  cid=class_id(path)
  rule=rule_of(src)
  ref=ref_of(cid)
  takeaway=rule if len(rule)<=220 else rule[:217].rstrip()+"..."
  takeaway=f"{takeaway} Verify the critical step before accepting a lower-tier control."
  pieces=[]; last=0; changed=0; idx=0
  for start,end,block in find_calls(src):
    if "fieldTakeaway:" in block or "optionTraps:" in block:
      idx+=1
      continue
    sm=extract_stem(block)
    if not sm:
      idx+=1
      continue
    stem=decode(sm.group(2))
    new_stem, scenario = upgrade_stem(stem, cid, idx, rule)
    difficulty=parse_trailing_difficulty(block) or "Exam"
    # Rebuild block: replace stem, ensure difficulty present, append enhanced object
    rebuilt = block[:sm.start(2)] + esc(new_stem) + block[sm.end(2):]
    # Strip trailing )
    core=rebuilt[:-1].rstrip().rstrip(",")
    enh = (
      "{\n"
      f'      scenarioText: "{esc(scenario)}",\n'
      f'      standardReference: "{esc(ref)}",\n'
      f'      fieldTakeaway: "{esc(takeaway)}",\n'
      "    }"
    )
    # If no difficulty string in call, insert one before enhanced
    if not re.search(r'"(Foundation|Exam|Expert)"', core):
      core = core + f',\n    "{difficulty}"'
    core = core.rstrip().rstrip(",") + ",\n    " + enh
    rebuilt = core + "\n  )"
    pieces.append(src[last:start])
    pieces.append(rebuilt)
    last=end
    changed+=1
    idx+=1
  if not changed: return 0
  pieces.append(src[last:])
  if not dry:
    path.write_text("".join(pieces))
  return changed

def main():
  ap=argparse.ArgumentParser()
  ap.add_argument("--ids")
  ap.add_argument("--gym", action="store_true")
  ap.add_argument("--dry", action="store_true")
  a=ap.parse_args()
  ids=None
  if a.ids:
    ids=set()
    for part in a.ids.split(","):
      part=part.strip()
      if "-" in part:
        x,y=part.split("-",1); ids.update(range(int(x), int(y)+1))
      else: ids.add(int(part))
  total=0
  for p in sorted(CLASSES.glob("*.ts")):
    if p.name in ("types.ts","index.ts","coverage-map.ts"): continue
    cid=class_id(p)
    if ids is not None and cid not in ids: continue
    n=process(p, a.dry)
    if n: print(f"{p.name}: {n}"); total+=n
  if a.gym:
    for p in sorted(GYM.glob("*.ts")):
      if p.name in ("types.ts","index.ts","session-map.ts","topic-map.ts","extra-cards.ts","extra-formulas.ts","why-wrong.ts"):
        continue
      if "exam(" not in p.read_text(): continue
      n=process(p, a.dry)
      if n: print(f"gym/{p.name}: {n}"); total+=n
  print("TOTAL", total)

if __name__=="__main__":
  main()
