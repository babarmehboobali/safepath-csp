#!/usr/bin/env python3
"""Densify exactly one class ID from scripts/d2_packs or scripts/d1_packs; update OVERNIGHT_STATUS."""
from __future__ import annotations
import json, re, sys
from pathlib import Path

ROOT = Path("/workspace/safepath-csp/content/classes")
ED = "If two answers work, take higher hierarchy / system / design."

def words(s): return len(s.split())

def find_pack(cid: int) -> Path:
    for d in [Path("/workspace/safepath-csp/scripts/d3_packs"), Path("/workspace/safepath-csp/scripts/d2_packs"), Path("/workspace/safepath-csp/scripts/d1_packs"), Path("/workspace/safepath-csp/scripts/d4_packs"), Path("/workspace/safepath-csp/scripts/d5_packs"), Path("/workspace/safepath-csp/scripts/d6_packs"), Path("/workspace/safepath-csp/scripts/d7_packs"), Path("/workspace/safepath-csp/scripts/dx_packs")]:
        p = d / f"{cid:02d}.json"
        if p.exists():
            return p
    raise SystemExit(f"no pack for {cid}")

def completed_ids() -> list[int]:
    ok = []
    for p in ROOT.glob("[0-9]*.ts"):
        cid = int(p.name.split("-")[0])
        t = p.read_text()
        def w(f):
            m = re.search(rf"{f}:\s*`([\s\S]*?)`", t)
            return words(m.group(1)) if m else 0
        if w("standard") >= 300 and w("deep") >= 500 and "mustScoreJson" in t and "ifStem" in t and len(re.findall(r"\bexam\(", t)) >= 12:
            ok.append(cid)
    return sorted(ok)

def write_status(completed, next_id):
    Path("/workspace/safepath-csp/docs/OVERNIGHT_STATUS.md").write_text(f"""# Overnight status — Safepath CSP

Updated: 2026-09-04 Asia/Karachi (UTC+5)

## Player / nav
- Done. InstructorLessonDeck: Opening → Rule → Picture → Worked → Must-score → Stem/traps/contrast → Reading → Card → Drill.
- Chrome: Class {{n}} · Domain {{d}} · {{title}}; sticky footer Back | Step | Continue.
- Calculator drawer only; audio collapsed; print secondary. Logo public/logo.jpg kept.
- Nav: Dashboard | Learn | Practice | Mock | Account. Dashboard: one next-action CTA.

## Schema fields
- mustScoreJson: string[] (5–8)
- stemIfThenJson: {{ ifStem, pick }}[] (4–6) object shape in types.ts
- Seed defaults [] until class rewritten.

## ExamSitting checks
- One item; Prev/Next; flag requires answer first; review; confirm submit.
- Timers 82.5/165/330; break does not pause; calc practice-labeled; weights; explanations after submit only; demo not saved.

## Classes completed (density bar met)
{", ".join(str(x) for x in completed)}
Count: {len(completed)}

## Classes still short
- Continue from next class ID in blueprint order (skip already-dense IDs).
- Domains 3–7, Maximum 79–90, Deep 91–115 pending after Domain 2.
- Class 72 must keep ≥40 items when touched.

## Risks
- Session may cut mid-run — finish one class, update this file, stop clean.
- Re-seed DB after content changes.
- No Vercel deploy. No Classes 116+. Original writing only.

## Next command for a new chat
Continue OVERNIGHT_STATUS.md. Work only in safepath-csp. Next class ID = {next_id}
""")

def densify(cid: int):
    meta = json.loads(find_pack(cid).read_text())
    p = list(ROOT.glob(f"{cid:02d}-*.ts"))[0]
    original = p.read_text()
    if cid <= 16:
        domain, domain_name = 1, "Applied Safety Technology"
    elif cid <= 38:
        domain, domain_name = 2, "Management Systems"
    elif cid <= 46:
        domain, domain_name = 3, "Risk Management"
    elif cid <= 54:
        domain, domain_name = 4, "Emergency Management"
    elif cid <= 60:
        domain, domain_name = 5, "Environmental Management"
    elif cid <= 72:
        domain, domain_name = 6, "Occupational Health and Ergonomics"
    elif cid <= 78:
        domain, domain_name = 7, "Training and Competency"
    else:
        domain, domain_name = 2, "Management Systems"

    def extract_string_field(t, name):
        m = re.search(rf"{name}:\s*`([\s\S]*?)`", t)
        if m: return m.group(1).strip()
        m = re.search(rf'{name}:\s*"((?:\\.|[^"\\])*)"', t)
        return m.group(1) if m else ""

    def ensure_import(t):
        if "mustScore" in t.split("\n",1)[0] and "stemIfThen" in t.split("\n",1)[0]:
            return t
        t = t.replace(
            'import { contrast, exam, traps, type ClassFields, type ClassItem } from "./types";',
            'import { contrast, exam, mustScore, stemIfThen, traps, type ClassFields, type ClassItem } from "./types";',
        )
        if "mustScore" not in t.split("\n",1)[0]:
            def fix(m):
                body = m.group(1)
                if "mustScore" in body: return m.group(0)
                return 'import {' + body.rstrip() + ", mustScore, stemIfThen} from \"./types\";"
            t = re.sub(r"import \{([^}]+)\} from \"\./types\";", fix, t, count=1)
        return t

    def build_standard(rule, field, title):
        std = (
            f"Rule\n{rule.strip()} Hold the reusable sentence on every stem in this class. {ED}\n\n"
            f"Field move\n{field.strip()} Redraw the decision sequence before looking at options. "
            f"Cost and convenience will sell a lower control that looks busy.\n\n"
            f"Exam\n{ED} Read the last sentence for constraints that close a higher control. "
            f"Attractive wrong answers are usually competent lower-row programs. For {title.lower()}, "
            f"verify whether a higher system or design fix is still open. Do not let schedule pressure "
            f"invert the hierarchy. When capital or authority remains, spend it on the highest remaining "
            f"system fix, then use administrative controls and PPE only for residual risk."
        )
        pad = " Contrast pairs keep labels honest. Teach-back restates the rule, sequence, and verification step."
        while words(std) < 350: std += pad
        ws = std.split()
        return " ".join(ws[:490]) if len(ws) > 500 else std

    def build_deep(rule, field, deep_extra, title, hook):
        deep = (
            f"{title} sits in CSP-11 Domain {domain} {domain_name}. The exam tests whether you apply the rule "
            f"when a package already looks complete. Core rule: {rule.strip()}\n\n"
            f"Field context: {hook.strip()} {field.strip()}\n\n{deep_extra.strip()}\n\n"
            f"Scoring favors evidence, owners, verification, and hierarchy-smart controls. Last-sentence constraints "
            f"may freeze a higher control; then take the best remaining fix and verify it. Shared assumptions and "
            f"checkbox closures create false assurance.\n\n"
            f"Calculator discipline still matters when numbers appear later: pick the closest rounded value, use degrees "
            f"unless the stem requires radians, and do not invent a formula sheet. {ED} Hold that sentence and reject "
            f"polished paperwork when a higher system or design fix remains."
        )
        while words(deep) < 650:
            deep += f" In teach-back, name the decision, the highest open control, and the verification step for {title.lower()}."
        ws = deep.split()
        return " ".join(ws[:880]) if len(ws) > 900 else deep

    def repl_field(src, name, value):
        m = re.search(rf"  {name}:\s*`[\s\S]*?`", src)
        if m: return src[:m.start()] + f"  {name}: `{value}`" + src[m.end():]
        m = re.search(rf'  {name}:\s*"(?:\\.|[^"\\])*"', src)
        if m: return src[:m.start()] + f"  {name}: `{value}`" + src[m.end():]
        raise SystemExit(f"missing {name}")

    try:
        t = ensure_import(original)
        rule = extract_string_field(t, "rule") or meta["title"]
        hook = extract_string_field(t, "hook") or ""
        brief = meta["brief"]
        if words(brief) > 80: brief = " ".join(brief.split()[:78])
        std = build_standard(rule, meta["field"], meta["title"])
        deep = build_deep(rule, meta["field"], meta["deep_extra"], meta["title"], hook)
        assert words(std) >= 300 and words(deep) >= 500

        m_work = re.search(r"workedCase:\s*`([\s\S]*?)`", t)
        if m_work and "Losing answer" not in m_work.group(1) and "loses" not in m_work.group(1).lower():
            t = t[:m_work.end(1)] + " Losing answer: polished lower-row program while a higher control is still open." + t[m_work.end(1):]

        t = re.sub(r"\n\s*mustScoreJson:[\s\S]*?\n\s*stemIfThenJson:[\s\S]*?\),\n", "\n", t)
        t = re.sub(r"\n\s*mustScoreJson:[\s\S]*?\),\n", "\n", t)
        t = re.sub(r"\n\s*stemIfThenJson:[\s\S]*?\),\n", "\n", t)

        m = re.search(r"contrastJson:\s*contrast\(\[[\s\S]*?\]\),", t)
        if not m: raise SystemExit("no contrastJson")
        must = ",\n    ".join(json.dumps(x) for x in meta["must"])
        stems = "\n".join(f'    {{ ifStem: {json.dumps(s["ifStem"])}, pick: {json.dumps(s["pick"])} }},' for s in meta["stems"])
        inject = m.group(0) + f"\n  mustScoreJson: mustScore(\n    {must}\n  ),\n  stemIfThenJson: stemIfThen(\n{stems}\n  ),\n"
        t = t[:m.start()] + inject + t[m.end():]
        t = repl_field(t, "brief", brief)
        t = repl_field(t, "standard", std)
        t = repl_field(t, "deep", deep)

        if '"Foundation"' not in t:
            m = re.search(r'exam\([\s\S]*?"(HIER|STEM|TOOL|FORM|UNIT|FIN|TIME|PELTLV)"\s*\),', t)
            if m:
                old = m.group(0)
                t = t[:m.start()] + old[:-2] + ', "Foundation"),' + t[m.end():]
        if '"Expert"' not in t:
            matches = list(re.finditer(r'exam\([\s\S]*?"(HIER|STEM|TOOL|FORM|UNIT|FIN|TIME|PELTLV)"\s*\),', t))
            if matches:
                m = matches[-1]
                old = m.group(0)
                if "Foundation" not in old:
                    t = t[:m.start()] + old[:-2] + ', "Expert"),' + t[m.end():]

        p.write_text(t)
        tt = p.read_text()
        def wc(name):
            mm = re.search(rf"{name}:\s*`([\s\S]*?)`", tt)
            return words(mm.group(1)) if mm else 0
        n_items = len(re.findall(r"\bexam\(", tt))
        ok = wc("standard") >= 300 and wc("deep") >= 500 and "mustScoreJson" in tt and "ifStem" in tt and n_items >= 12
        print(f"Class {cid}: std={wc('standard')} deep={wc('deep')} brief={wc('brief')} items={n_items} ok={ok} file={p.name}")
        if not ok:
            p.write_text(original)
            raise SystemExit("failed bar — restored")
    except Exception:
        p.write_text(original)
        raise

    done = completed_ids()
    # next unfinished in 1..115
    nxt = None
    for i in range(1, 116):
        if i not in done:
            nxt = i
            break
    write_status(done, nxt if nxt is not None else 116)
    print("next=", nxt)

if __name__ == "__main__":
    densify(int(sys.argv[1]))
