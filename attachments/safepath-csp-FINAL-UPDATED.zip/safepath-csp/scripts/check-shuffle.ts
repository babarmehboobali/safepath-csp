/**
 * Unit-less check: after serve-time shuffle, keys must mix A/B/C/D.
 * Run: npx tsx scripts/check-shuffle.ts
 */
import { readFileSync, existsSync } from "node:fs";
import { resolve } from "node:path";
import { PrismaClient } from "@prisma/client";
import { letterCounts, shuffleOptions } from "../lib/shuffle-options";

function loadLocalEnv() {
  const path = resolve(process.cwd(), ".env");
  if (!existsSync(path)) return;
  for (const line of readFileSync(path, "utf8").split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const eq = trimmed.indexOf("=");
    if (eq < 0) continue;
    const key = trimmed.slice(0, eq).trim();
    let val = trimmed.slice(eq + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }
    if (process.env[key] === undefined) process.env[key] = val;
  }
}
loadLocalEnv();

function assertMix(label: string, indexes: number[], n: number) {
  const c = letterCounts(indexes);
  const letters = ["A", "B", "C", "D"] as const;
  const lines = letters.map((L) => {
    const pct = n ? (c[L] / n) * 100 : 0;
    return `${L}:${c[L]} (${pct.toFixed(1)}%)`;
  });
  console.log(label, lines.join("  "));
  for (const L of letters) {
    const pct = n ? (c[L] / n) * 100 : 0;
    if (pct < 12 || pct > 40) {
      throw new Error(`${label}: letter ${L} is ${pct.toFixed(1)}% — expected roughly ~25% each`);
    }
  }
}

function synthetic() {
  const indexes: number[] = [];
  for (let i = 0; i < 200; i++) {
    const sh = shuffleOptions({
      id: `synth-${i}-csp11`,
      options: ["optA", "optB", "optC", "optD"],
      answerIndex: 1,
      distractors: ["wa", "wb", "wc", "wd"],
    });
    if (sh.options.length !== 4) throw new Error("options length");
    if (sh.options[sh.answerIndex] !== "optB") throw new Error("remap failed — key is not original B");
    if (sh.distractors?.[sh.answerIndex] !== "wb") throw new Error("distractor remap failed");
    indexes.push(sh.answerIndex);
  }
  const allB = indexes.every((i) => i === 1);
  if (allB) throw new Error("synthetic 200 still all B on the wire");
  assertMix("synthetic 200 (stored key B)", indexes, 200);
}

async function fromDb() {
  const url = process.env.DATABASE_URL;
  if (!url) {
    console.log("skip DB check (no DATABASE_URL)");
    return;
  }
  const prisma = new PrismaClient();
  try {
    const rows = await prisma.question.findMany({
      select: { id: true, optionsJson: true, answerIndex: true, distractorsJson: true },
    });
    if (rows.length < 40) {
      console.log(`skip DB mix assert (${rows.length} items)`);
      return;
    }
    const stored: number[] = [];
    const served: number[] = [];
    for (const q of rows) {
      stored.push(q.answerIndex);
      let options: string[] = [];
      try {
        const parsed = JSON.parse(q.optionsJson) as unknown;
        if (Array.isArray(parsed)) options = parsed.map(String);
      } catch {
        continue;
      }
      let distractors: string[] | undefined;
      if (q.distractorsJson) {
        try {
          const d = JSON.parse(q.distractorsJson) as unknown;
          if (Array.isArray(d)) distractors = d.map(String);
        } catch {
          distractors = undefined;
        }
      }
      const sh = shuffleOptions({
        id: q.id,
        options,
        answerIndex: q.answerIndex,
        distractors,
      });
      served.push(sh.answerIndex);
    }
    const storedCounts = letterCounts(stored);
    console.log(
      "stored keys",
      `A:${storedCounts.A} B:${storedCounts.B} C:${storedCounts.C} D:${storedCounts.D}`,
    );
    const sample = served.slice(0, 200);
    assertMix(`served first ${sample.length} items`, sample, sample.length);
    const allB = sample.every((i) => i === 1);
    if (allB) throw new Error("served sample still all B");
  } finally {
    await prisma.$disconnect();
  }
}

synthetic();
fromDb()
  .then(() => {
    console.log("shuffle check ok");
  })
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
