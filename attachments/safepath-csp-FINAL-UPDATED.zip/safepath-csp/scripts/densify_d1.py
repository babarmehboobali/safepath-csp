#!/usr/bin/env python3
"""Densify Domain 1 classes 3,4,6-16. Original Safepath writing only."""
from __future__ import annotations
import re
from pathlib import Path

ROOT = Path("/workspace/safepath-csp/content/classes")
ED = "Exam default: if two answers work, take higher hierarchy / system / design."

def words(s: str) -> int:
    return len(s.split())

PACKS: dict[int, dict] = {}

def P(cid, must, stems, std, deep, brief):
    assert words(std) >= 300, (cid, "std", words(std))
    assert words(deep) >= 500, (cid, "deep", words(deep))
    assert 5 <= len(must) <= 8
    assert 4 <= len(stems) <= 6
    PACKS[cid] = dict(must=must, stems=stems, std=std.strip(), deep=deep.strip(), brief=brief.strip())

P(3,
["Inherent safety first: minimize, substitute, moderate, simplify.",
 "Independent protection layers must fail differently — shared transmitters are not independent.",
 "Detectors and the fire team are outer rings, not a substitute for inventory and relief.",
 "SIS sensors must be independent of the BPCS that is already failing.",
 "Relief and dikes are passive layers; they still need sizing and independence.",
 "Calling more LEL heads process safety while inventory can drop is the trap.",
 "A same-PLC control-and-trip design shares failure modes.",
 ED],
[{"ifStem":"inventory can still be cut or chemistry substituted","pick":"inherent safety before more detectors"},
 {"ifStem":"the same transmitter feeds control and SIS","pick":"reject — not independent"},
 {"ifStem":"operations wants a bigger fire team only","pick":"fund inner layers first"},
 {"ifStem":"solvent remains after minimize","pick":"relief, SIS, and dike before ERT expansion"},
 {"ifStem":"two answers work","pick":"higher hierarchy / system / design"}],
"""Rule
Inherent safety comes first: minimize, substitute, moderate, simplify. Then stack independent protection layers that fail differently. Basic process control, alarms, safety instrumented systems, relief and passive barriers, and emergency response form an onion. Each outer ring must still work if the inner ring fails. Detectors and the fire team are outer rings — they are not a substitute for inventory reduction, relief sizing, and an independent SIS.

Field move
On a P&ID review for a 4,000-gal solvent reactor, operations will ask for more gas detectors and a bigger fire team. Ask first whether that inventory must sit in the building. Cut batch size or move to aqueous chemistry when the drawing still allows it. If solvent remains, size relief independent of the BPCS, add SIS on independent sensors, and dike the pad. Only then expand detection and emergency response. A transmitter shared between control and trip is not an independent layer. A fire brigade without timing and capacity analysis is not a credited IPL.

Exam
If two answers work, take higher hierarchy / system / design. The stem that sells more LEL heads while inventory can still drop is testing inherent safety. The stem that puts control and SIS on the same PLC is testing independence. Moderate by lower temperature or diluted concentration when substitution is closed. Simplify by removing unnecessary hose connections that create leak points. Brownfield constraints shrink options; they do not authorize skipping remaining independent engineered layers.""",
"""Process safety on the CSP exam is less about memorizing every PSM element title and more about whether you still choose inherent safety and independent layers when the plant wants detection and response. Center of the onion is the process itself: how much hazardous inventory, which chemistry, how severe the operating conditions, how complex the piping. Minimize inventory. Substitute a less hazardous material. Moderate conditions. Simplify so fewer things can go wrong in surprising combinations.

Independent protection layers must be independent, specific, dependable, and auditable. Independence fails when the same transmitter, same wiring, same utility, or same human action is credited twice. A BPCS that is already drifting cannot also be the SIS without separate sensors and logic. Relief devices and dikes are passive layers; they still need correct sizing, installation, and inspection. Alarms and administrative responses buy time; they do not replace a trip that must work without a perfect operator.

Emergency response is the outermost ring. Expanding the fire team while a 4,000-gal batch can become a 400-gal batch is the classic distractor. Gas detectors find leaks; they do not reduce the mass that can leak. Fireproofing and dikes limit consequences after loss of containment; they still sit outside inherent safety. When the last sentence freezes chemistry, take the best remaining engineered layers — dedicated SIS, correctly sized relief, secondary containment — before you fund more turnout gear.

Tool choice matters. A HAZOP or what-if that cannot change inventory or independence is theater. Layers of protection analysis is useful when it honestly scores independence and demand rate; it is not a license to stack weak administrative claims. Shared instrument loops fail both control and trip together. Exam default: if two answers work, take higher hierarchy / system / design. Hold the onion drawing on the page and ask which ring the stem left open.""",
"Shrink the hazard first. Then stack independent layers: control, alarm, SIS, relief, dike, emergency. Shared instruments are not independent. Detectors are outer rings. Exam default: if two answers work, take higher hierarchy / system / design.")

P(4,
["De-energize is the primary electrical control — energized work is an exception.",
 "Justification, shock/arc boundaries, PPE, and a written permit do not outrank isolation.",
 "Establish an electrically safe work condition: isolate, lock, verify, ground when required.",
 "Approach boundaries are not a reason to skip LOTO when de-energizing is feasible.",
 "Qualified person status does not authorize routine live work for convenience.",
 "Arc-rated clothing is PPE around energy you could still remove.",
 "Design lower voltage or remote racking while the drawing is open.",
 ED],
[{"ifStem":"de-energizing is feasible","pick":"establish an electrically safe work condition"},
 {"ifStem":"operations wants live troubleshooting for schedule","pick":"reject convenience — energized is the exception"},
 {"ifStem":"only rubber gloves are offered","pick":"isolation and verification first"},
 {"ifStem":"the drawing can still specify remote racking or lower voltage","pick":"design out exposure"},
 {"ifStem":"two answers work","pick":"higher hierarchy / system / design"}],
"""Rule
De-energize is the primary electrical control. Energized work is an exception with justification, shock and arc-flash analysis, boundaries, appropriate PPE, and a written permit — not a habit because production is behind. Establish an electrically safe work condition: identify sources, isolate, lock, verify absence of voltage, and ground when required. Qualified-person status means competence for the task; it does not authorize routine live work for convenience.

Field move
A motor control center needs troubleshooting. Ask whether the circuit can be de-energized and verified. If yes, LOTO and prove zero energy beat arc-rated suits as the primary answer. If true energized diagnostics are justified, document why, set boundaries, use the rated PPE, and keep the exposure as short as the task requires. While design is open, specify remote racking, finger-safe terminals, lower control voltage, and maintenance access that does not require live probing. A laminated shock poster is administrative theater next to an open bus.

Exam
If two answers work, take higher hierarchy / system / design. Approach boundaries and PPE categories appear as distractors when isolation is still feasible. We always troubleshoot live is not justification. Arc flash labels inform PPE selection for justified energized work; they are not permission to skip de-energizing. Cord-and-plug equipment under exclusive control is a narrow exception pattern — hard-wired gear does not borrow it because someone is in a hurry.""",
"""Electrical safety on CSP-11 sits at the intersection of hierarchy and LOTO. The primary control is removing the energy. An electrically safe work condition is a verification sequence, not a hope that the breaker handle looks down. Identify all sources, isolate each, apply personal locks, verify with an adequately rated tester on a known live source then on the circuit then on the known live source again, and apply grounds when the procedure requires them.

Energized work survives only as a documented exception: additional hazard created by de-energizing, infeasibility, or specific diagnostic need that truly requires voltage present. Schedule pressure is not an additional hazard. A qualified person has the skills and knowledge for the equipment and the hazards; the title does not create a blanket live-work license. Shock protection boundaries and arc-flash boundaries organize distance and PPE once energized work is justified — they do not replace the decision to de-energize.

Design still matters. Remote racking, insulated bus, finger-safe components, 24 V controls, and interlocked doors reduce exposure before anyone reaches for an arc-rated hood. Maintenance access planned without live measurement ports in cramped gear is Prevention through Design applied to electrical. When the stem offers better PPE versus isolation, take isolation if feasible. When isolation is honestly closed, take the engineering that shortens or removes exposure, then PPE as residual. Temporary protective grounds, insulated tools, and stand-by persons support justified energized tasks; they do not convert convenience live work into a best practice. Exam default: if two answers work, take higher hierarchy / system / design.""",
"De-energize first. Energized work is a documented exception, not a habit. Verify zero energy. Design out exposure when drawings are open. Exam default: if two answers work, take higher hierarchy / system / design.")

P(6,
["Eliminate the height or the opening when the drawing still allows it.",
 "Guardrail, cover, or restraint that prevents the fall beats arrest that catches it.",
 "PFAS is last among fall options when prevention is still open.",
 "Hole covers must support intended loads and be marked — cardboard is not a cover.",
 "Travel restraint keeps the worker from the edge; arrest engages after the fall starts.",
 "Leading-edge and swing-fall geometry can make a harness the wrong primary answer.",
 "Scaffold and aerial decisions still follow prevent-then-arrest logic.",
 ED],
[{"ifStem":"the work can move to grade or the hole can be covered","pick":"elimination or a proper cover/guardrail"},
 {"ifStem":"the stem offers harnesses while a guardrail is still buildable","pick":"guardrail or restraint that prevents the fall"},
 {"ifStem":"only PFAS is proposed for a permanent floor opening","pick":"reject — engineer the opening closed or guarded"},
 {"ifStem":"swing fall or clearance is inadequate","pick":"redesign anchorage/geometry before issuing harnesses"},
 {"ifStem":"two answers work","pick":"higher hierarchy / system / design"}],
"""Rule
Eliminate the height or the opening. Then use guardrail, covers, or travel restraint that prevents the fall. Personal fall arrest systems catch a worker who is already falling — useful residual protection, not the first choice when prevention is still open. Covers must carry the intended load and be secured and marked. Anchorage, free-fall distance, swing fall, and rescue plan matter once arrest is truly required.

Field move
A mezzanine valve at height with no platform is still a design problem: relocate to grade or add a fixed platform. A floor opening needs a marked, load-rated cover or guardrail, not caution tape and a harness cart. Roof work that can be done from a completed guarded walkway beats tying off along an open edge. When arrest is required, select anchorage that limits free fall, control swing, confirm clearance to the lower level, and plan rescue — a harness alone is not a program.

Exam
If two answers work, take higher hierarchy / system / design. One hundred percent tie-off sounds strong and still loses to a guardrail that prevents the fall. Controlled decking zones and monitoring are temporary construction methods with strict limits — they are not a general excuse to skip rails. Warning lines alone do not protect workers in all roof situations the stem may describe. Calculate clearance before you trust arrest.""",
"""Falls remain a leading cause of serious injury, which is why CSP stems push prevention over heroic catch systems. Hierarchy for falls: eliminate the exposure, prevent the fall, then arrest the fall, then administrative controls and PPE details. Moving the task to grade, prefabricating at ground level, or closing the opening permanently is elimination. Guardrails and load-rated covers prevent the fall without depending on perfect harness use. Travel restraint uses a short tether so the edge cannot be reached. Fall arrest assumes the fall begins and must stop before striking a lower level.

Common traps include calling a harness engineering, using cardboard or unmarked scrap as a hole cover, ignoring swing-fall into structures, and forgetting rescue after a fall is arrested. Construction stems may mention residential fall protection options or controlled access zones; read the last sentence for which method is actually authorized for that activity. General industry fixed ladders, platforms, and skylights have their own prevention expectations — skylight screens and rails beat we told them not to sit there.

Design reviews should relocate valves, sample points, and filters to grade before accepting permanent ladder-and-harness cultures. Aerial lifts and scaffolds still require fall prevention appropriate to the configuration; a lift with a defective gate is not fixed by a better hard hat. Free-fall distance, deceleration distance, harness stretch, and safety factor must fit under the walking-working surface. Exam default: if two answers work, take higher hierarchy / system / design. Draw the edge, the opening, and the prevention method before you look at the PPE options.""",
"Eliminate height/openings. Guardrail or cover before PFAS. Covers must be load-rated and marked. Arrest needs clearance and rescue. Exam default: if two answers work, take higher hierarchy / system / design.")

print("packs loaded", sorted(PACKS))
