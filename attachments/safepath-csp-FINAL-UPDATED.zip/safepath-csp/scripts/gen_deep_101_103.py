
#!/usr/bin/env python3
"""Generate Safepath CSP deep masterclasses 101-115."""
from __future__ import annotations
from pathlib import Path
import textwrap

ROOT = Path("/workspace/safepath-csp/content/classes")

def esc(s: str) -> str:
    return s.replace("\\", "\\\\").replace("`", "\\`").replace("${", "\\${")

def q(s: str) -> str:
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n") + '"'

def emit_item(task, stem, options, answer, explanation, err, difficulty="Exam", distractors=None):
    opts = ",\n      ".join(q(o) for o in options)
    lines = [
        "  exam(",
        f"    {q(task)},",
        f"    {q(stem)},",
        "    [",
        f"      {opts},",
        "    ],",
        f"    {answer},",
        f"    {q(explanation)},",
        f"    {q(err)},",
        f"    {q(difficulty)},",
    ]
    if distractors:
        d = ",\n      ".join(q(x) for x in distractors)
        lines.append("    [")
        lines.append(f"      {d},")
        lines.append("    ],")
    lines.append("  ),")
    return "\n".join(lines)

def emit_class(filename, task, fields, items):
    traps = fields["traps"]
    contrast = fields["contrast"]
    body = []
    body.append('import { contrast, exam, traps, type ClassFields, type ClassItem } from "./types";')
    body.append("")
    body.append(f"const T = {q(task)};")
    body.append("")
    body.append("export const classFields: ClassFields = {")
    for key in ["hook","hookOilGas","hookConstruction","rule","modelCaption","workedCase"]:
        body.append(f"  {key}:")
        body.append(f"    {q(fields[key])},")
    body.append("  trapsJson: traps(")
    body.append(f"    {q(traps[0])},")
    body.append(f"    {q(traps[1])},")
    body.append(f"    {q(traps[2])},")
    body.append("  ),")
    body.append("  contrastJson: contrast([")
    for looks, actually in contrast:
        body.append(f"    {{ looksLike: {q(looks)}, actually: {q(actually)} }},")
    body.append("  ]),")
    for key in ["brief","standard","deep","cardFront","cardBack","teachBackKey"]:
        body.append(f"  {key}:")
        body.append(f"    {q(fields[key])},")
    slug = fields.get("formulaSlug")
    body.append(f"  formulaSlug: {q(slug) if slug else 'null'},".replace('"null"', 'null') if not slug else f"  formulaSlug: {q(slug)},")
    if not slug:
        body[-1] = "  formulaSlug: null,"
    body.append("};")
    body.append("")
    body.append("export const items: ClassItem[] = [")
    for it in items:
        body.append(emit_item(**it))
    body.append("];")
    body.append("")
    path = ROOT / filename
    path.write_text("\n".join(body) + "\n")
    print(f"wrote {filename} items={len(items)} bytes={path.stat().st_size}")

def rationale(core, calc, standards, why):
    return f"Core Rule: {core} Calculation Steps: {calc} Standards Cited: {standards} Why Each Distractor Fails: {why}"

def dist(a,b,c,d):
    return [a,b,c,d]

# ========== 101 Ventilation Advanced ==========
emit_class(
  "101-ventilation-engineering.ts",
  "CSP-11 D6.01",
  {
    "hook": "A lab hood is 12 inches off the plume. Operations wants Q = VA at the face only. You need the simple unflanged Dalla Valle / ACGIH-style teaching form Q = V(10X^2 + A), dilution time with natural log, and velocity pressure VP = (V/4005)^2 — without inventing a table from memory.",
    "hookOilGas": "A hot-work bay on a skid has a capture hood a foot off the plume. The superintendent quotes Q = VA. You still need distance tax 10X^2, dilution purge math with ln, and duct VP for fan sizing — units first.",
    "hookConstruction": "A welding tent uses a round hood held a foot from the plume. The GC says any moving air is capture. You apply Q = V(10X^2 + A) when the stem specifies that form, dilution ln for purge, and VP = (V/4005)^2 in US teaching units.",
    "rule": "At a face use Q = V x A with consistent units. For a simple unflanged round/rect hood along the axis when the stem gives the teaching form, Q = V(10X^2 + A) with X in feet and A in ft^2. Flanged teaching form often uses Q = V(7.5X^2 + A) when the stem says flanged. Dilution purge: t = -(V/Q) ln(C2/C1) with natural log, not log10. Velocity pressure (US teaching): VP = (V/4005)^2 in inches of water when V is fpm. Convert inches to feet before squaring. Capture beats dilution; substitution still beats a bigger fan.",
    "modelCaption": "Face: Q=VA. Distance hood: Q=V(10X^2+A). Flanged tax drop: 7.5X^2. Dilution clock: t=-(V/Q)ln(C2/C1). Duct: VP=(V/4005)^2.",
    "workedCase": "Unflanged: V=100 fpm, X=1 ft, A=0.5 ft^2. 10X^2+A = 10(1)+0.5 = 10.5; Q = 100 x 10.5 = 1,050 cfm. Flanged teaching form with same inputs: 7.5(1)+0.5 = 8.0; Q = 100 x 8.0 = 800 cfm. Dilution: room V=10,000 ft^3, Q=2,000 cfm, C1=200 ppm to C2=20 ppm. t = -(10000/2000) ln(20/200) = -5 ln(0.10) = 5 x 2.302585 = 11.5129 min ≈ 11.51 min. VP at 2,000 fpm: (2000/4005)^2 = 0.249376 ≈ 0.249 in. wg.",
    "traps": [
      "Using log10 instead of ln on dilution time (halves the answer to ~5 min).",
      "Dropping the 10X^2 distance term and treating a remote hood as Q=VA at the face.",
      "Treating VP=(V/4005) without squaring, or mixing SP with VP.",
    ],
    "contrast": [
      ("Q = VA at the face", "Face/duct area only — no distance tax"),
      ("Q = V(10X^2+A)", "Unflanged simple hood along axis when stem specifies"),
      ("Q = V(7.5X^2+A)", "Flanged teaching form when stem specifies"),
      ("Dilution t = -(V/Q)ln(C2/C1)", "Natural log purge — not log10"),
      ("VP = (V/4005)^2", "Velocity pressure in in. wg (US teaching)"),
      ("Wall fan moving air", "Dilution — not capture"),
    ],
    "brief": "Q=V(10X^2+A) when stem says so; flanged often 7.5X^2; dilution uses ln; VP=(V/4005)^2. Inches to feet first.",
    "standard": "Industrial ventilation teaching (ACGIH-style equations as named in the stem) sits beside OSHA substance-specific rules that may require local exhaust. The equations do not replace hierarchy: substitution and enclosure beat a distant hood. VERIFY: VP constant 4005 and flange coefficient against the handbook edition you study — treat as illustrative if the stem does not give the constant.",
    "deep": "VERIFY leftovers: exact ACGIH plate coefficients and flange factors by edition; do not invent paragraph numbers. Dilution assumes perfect mixing — real rooms are imperfect; exam stems usually ignore that. Make-up air still matters: 1,050 cfm out needs a path in. Transport velocity in ducts is a different V from capture velocity.",
    "cardFront": "Q=V(10X^2+A); dilution ln; VP=(V/4005)^2?",
    "cardBack": "100 fpm, X=1, A=0.5 → 1,050 cfm unflanged; dilution 10k/2k from 200→20 ppm ≈ 11.51 min; VP@2000 fpm ≈ 0.249 in. wg. Study only.",
    "teachBackKey": "Pass if learner states unflanged Q=V(10X^2+A) with X in feet, uses ln not log10 for dilution, and squares V/4005 for VP.",
    "formulaSlug": "ventilation-advanced",
  },
  [
    dict(task="CSP-11 D6.01", stem="Unflanged simple hood: V=100 fpm, X=1 ft, A=0.5 ft^2. Stem gives Q=V(10X^2+A). Closest Q (cfm)?",
      options=["500 because Q=VA only (100x0.5).","1,050 because 10(1)^2+0.5=10.5 and 100x10.5=1,050.","800 using the flanged 7.5X^2 form without the stem saying flanged.","10,500 treating X in inches."],
      answer=1, err="FORM",
      explanation=rationale("Use the stem form Q=V(10X^2+A).","10(1)^2+0.5=10.5; 100x10.5=1,050.","IH ventilation teaching equations as specified in the stem; hierarchy still applies.","A=drops distance tax; B=correct; C=wrong flange form; D=unit disaster."),
      distractors=dist("Fails: Q=VA ignores the 10X^2 term the stem required.","Correct: 1,050 cfm.","Fails: Flanged coefficient without stem authority.","Fails: X must be feet.")),
    dict(task="CSP-11 D6.01", stem="Same geometry but stem says flanged teaching form Q=V(7.5X^2+A). V=100, X=1, A=0.5. Q?",
      options=["1,050.","800 because 7.5+0.5=8.0 and 100x8=800.","75.","8,000."],
      answer=1, err="STEM",
      explanation=rationale("Use the flanged form only when the stem specifies it.","7.5(1)^2+0.5=8; 100x8=800.","Stem-specified ventilation teaching form.","A=unflanged; B=correct; C=forgot V; D=scaled wrong."),
      distractors=dist("Fails: That is the unflanged 10X^2 result.","Correct: 800 cfm.","Fails: Multiplied coefficients without V.","Fails: Extra zero.")),
    dict(task="CSP-11 D6.01", stem="Room 10,000 ft^3, exhaust 2,000 cfm, perfect mixing. Drop 200 ppm to 20 ppm. t = -(V/Q)ln(C2/C1). Closest minutes?",
      options=["5.0 using log10(0.1)=-1.","11.51 because -5 ln(0.1)=5x2.302585≈11.51.","50 using (V/Q)(C1/C2).","2.3 ignoring the 5 factor."],
      answer=1, err="FORM",
      explanation=rationale("Dilution purge uses natural log.","V/Q=5; ln(0.1)=-2.302585; t=5x2.302585≈11.51.","Mixing-model IH teaching equation.","A=log10 trap; B=correct; C=ratio without ln; D=incomplete."),
      distractors=dist("Fails: log10 halves the magnitude vs ln.","Correct: ≈11.51 min.","Fails: Omits the logarithm.","Fails: Missing V/Q multiplier.")),
    dict(task="CSP-11 D6.01", stem="Duct velocity 2,000 fpm. Stem gives VP=(V/4005)^2. Closest VP (in. wg)?",
      options=["0.499 (forgot to square root idea / doubled).","0.249 because (2000/4005)^2≈0.2494.","2000/4005≈0.499 without squaring.","4005/2000≈2.0."],
      answer=1, err="FORM",
      explanation=rationale("Square the ratio.","2000/4005≈0.499376; square ≈0.2494.","US VP teaching constant — VERIFY 4005 in your handbook.","A/C=unsquared; B=correct; D=inverted."),
      distractors=dist("Fails: Not the squared result.","Correct: ≈0.249 in. wg.","Fails: Must square.","Fails: Inverted ratio.")),
    dict(task="CSP-11 D6.01", stem="X is given as 12 inches. For Q=V(10X^2+A) what must you do first?",
      options=["Use X=12 in the equation directly.","Convert to X=1.0 ft before squaring.","Square 12 then divide by 12.","Treat X as dimensionless."],
      answer=1, err="UNIT",
      explanation=rationale("X and A must be in feet / ft^2.","12 in = 1 ft.","Unit consistency for the teaching equation.","A=inch trap; B=correct; C=wrong order; D=nonsense."),
      distractors=dist("Fails: Inches break the coefficient.","Correct: Convert first.","Fails: Wrong conversion order.","Fails: X has length.")),
    dict(task="CSP-11 D6.01", stem="A wall fan moves 1,050 cfm past a welder. The stem still leaves an enclosing booth open. Best CSP move?",
      options=["Call the wall fan local exhaust because cfm matches the hood calc.","Prefer the enclosing booth / higher hierarchy over dilution.","Add a respirator and keep the wall fan as primary.","Ignore make-up air."],
      answer=1, err="HIER",
      explanation=rationale("Hierarchy: enclose/capture beats dilution; substitution/enclosure beat PPE.","Same cfm does not make dilution into capture.","Hierarchy of controls; ventilation type ranking.","A=label trap; B=correct; C=PPE first; D=system miss."),
      distractors=dist("Fails: Moving air is not capture.","Correct: Take the higher control.","Fails: PPE is last if engineering is open.","Fails: Make-up air matters but is not the hierarchy answer.")),
    dict(task="CSP-11 D6.01", stem="Dilution: V=5,000 ft^3, Q=1,000 cfm, C2/C1=0.05. Closest t (min)?",
      options=["15.0 using log10.","14.98 because -5 ln(0.05)=5x2.9957≈14.98.","100 using ratio 20.","2.995."],
      answer=1, err="FORM",
      explanation=rationale("t=-(V/Q)ln(C2/C1).","V/Q=5; ln(0.05)≈-2.9957; t≈14.98.","Dilution teaching model.","A=log10; B=correct; C=no ln; D=missing factor."),
      distractors=dist("Fails: log10 path.","Correct: ≈14.98 min.","Fails: Ratio without ln.","Fails: Incomplete.")),
    dict(task="CSP-11 D6.01", stem="Which pair is correctly contrasted?",
      options=["VP is static pressure in the room.","Capture hood at the source vs dilution wall fan.","Q=VA always includes 10X^2.","ln and log10 are interchangeable on the exam."],
      answer=1, err="TOOL",
      explanation=rationale("Capture ≠ dilution; VP ≠ SP.","Contrast the physical meaning.","Ventilation classification.","A=wrong; B=correct; C=false; D=false."),
      distractors=dist("Fails: VP is velocity pressure.","Correct contrast.","Fails: 10X^2 is the distance form.","Fails: Bases differ.")),
    dict(task="CSP-11 D6.01", stem="V=4,005 fpm. VP=(V/4005)^2 equals?",
      options=["0.5.","1.0.","4005.","2.0."],
      answer=1, err="UNIT",
      explanation=rationale("Ratio=1; square=1.","(4005/4005)^2=1.","VP teaching equation.","A=half; B=correct; C=raw; D=double."),
      distractors=dist("Fails.","Correct: 1.0 in. wg.","Fails.","Fails.")),
    dict(task="CSP-11 D6.01", stem="Stem gives unflanged form but options include a respirator while a flanged hood redesign is open. Pick?",
      options=["Respirator because dilution failed.","Flanged/closer hood redesign (engineering) over PPE.","Increase dilution time only.","Ignore X entirely."],
      answer=1, err="HIER",
      explanation=rationale("If engineering redesign is open, do not lead with PPE.","Flange/closer reduces the distance tax.","Hierarchy.","A=PPE; B=correct; C=weak; D=FORM."),
      distractors=dist("Fails: PPE last.","Correct.","Fails: Not best remaining.","Fails.")),
    dict(task="CSP-11 D6.01", stem="A=π(0.5)^2≈0.785 ft^2 at X=0 (face). Unflanged Q=V(10X^2+A) with V=100 equals?",
      options=["1,000.","78.5 because 10(0)+0.785=0.785; 100x0.785=78.5.","785.","7.85."],
      answer=1, err="FORM",
      explanation=rationale("At X=0 the form collapses toward VA.","100x0.785=78.5.","Consistency check.","A=invented; B=correct; C=x10; D=/10."),
      distractors=dist("Fails.","Correct: 78.5 cfm.","Fails: Extra factor 10.","Fails.")),
    dict(task="CSP-11 D6.01", stem="Why is 5.0 min wrong for the 10,000 ft^3 / 2,000 cfm / 200→20 ppm dilution item?",
      options=["Because V/Q should be 10.","Because that path used log10(0.1)=-1 instead of ln.","Because C2/C1 was inverted wrongly to 10.","Because VP was mixed in."],
      answer=1, err="FORM",
      explanation=rationale("ln(0.1)≈-2.3026 not -1.","log10 trap.","Dilution math hygiene.","A=wrong; B=correct; C=different error; D=irrelevant."),
      distractors=dist("Fails.","Correct diagnosis.","Fails: Different mistake.","Fails.")),
  ],
)
print("101 done")


# ========== 102 NFPA 101 occupant / egress ==========
emit_class(
  "102-life-safety-occupant-egress.ts",
  "CSP-11 D1.04",
  {
    "hook": "A gymnasium conversion lists 4,500 ft^2 without fixed seats. Someone multiplies by a remembered factor from the wrong occupancy. You need occupant load from the stem-supplied factor, egress capacity thinking, and the half-diagonal remoteness idea — without pirating NFPA tables.",
    "hookOilGas": "A training room inside a plant admin building is being reclassified as assembly for an all-hands. Occupant load and exit remoteness decide whether two doors suffice.",
    "hookConstruction": "A temporary indoor exhibit hall on a job uses bleacher-free floor area. The GC quotes a travel distance from another occupancy. Stem factor and half-diagonal remoteness matter.",
    "rule": "Occupant load = floor area / occupant-load factor when the stem gives the factor for that occupancy/edition. Do not import a factor from memory against a different occupancy. Distinguish exit access, exit, and exit discharge. Remoteness: exits too close fail the half-diagonal concept when the stem invokes it — measure diagonal of the area and require separation on the order of half that diagonal (VERIFY exact code path for the edition named). Travel distance and door ratings are occupancy- and protection-dependent — refuse universal numbers.",
    "modelCaption": "Area → divide by stem factor → occupant load → check exit width/capacity → check remoteness (half diagonal) → protect the exit path.",
    "workedCase": "Stem: 4,500 ft^2 assembly without fixed seats; factor = 15 ft^2/person (stem-supplied, illustrative). Occupant load = 4500/15 = 300 persons. Room diagonal for a 90 ft x 50 ft rectangle: sqrt(90^2+50^2)=sqrt(8100+2500)=sqrt(10600)≈102.96 ft; half-diagonal ≈ 51.5 ft. If two exits are only 20 ft apart along the wall, remoteness likely fails the half-diagonal idea the stem is testing. VERIFY: actual NFPA 101 factors and remoteness exceptions for the edition named in the stem.",
    "traps": [
      "Using a memorized occupant-load factor from the wrong occupancy or edition.",
      "Treating exit access corridor as the exit itself.",
      "Placing two doors adjacent and calling remoteness satisfied.",
    ],
    "contrast": [
      ("Exit access", "Path to an exit — still in the room/corridor system"),
      ("Exit", "Protected way of travel (stair enclosure, etc. as applicable)"),
      ("Exit discharge", "From exit to public way"),
      ("Occupant-load factor", "Stem/edition/occupancy specific — not universal"),
      ("Half-diagonal remoteness", "Separation concept — VERIFY exceptions"),
      ("Sprinklered travel distance", "May differ — do not invent numbers"),
    ],
    "brief": "Load = area/factor from stem. Exit access ≠ exit ≠ discharge. Remoteness ≈ half diagonal when stem says so. VERIFY edition.",
    "standard": "NFPA 101 is consensus life safety; OSHA has related egress rules (e.g., 1910 Subpart E). Jurisdiction adopts an edition — VERIFY. This class uses stem-supplied factors only.",
    "deep": "VERIFY leftovers: specific occupant-load factors by occupancy; exact half-diagonal exceptions (e.g., sprinkler allowances) by edition; door swing and force requirements. Never hard-code a universal travel distance.",
    "cardFront": "Occupant load? Exit vs access? Half-diagonal?",
    "cardBack": "4500/15=300 when stem gives 15. Access≠exit≠discharge. Half of ~103 ft diagonal ≈51.5 ft separation idea. Study only.",
    "teachBackKey": "Pass if learner computes load from stem factor, names three egress parts, and explains half-diagonal remoteness without inventing table values.",
    "formulaSlug": "occupant-load",
  },
  [
    dict(task="CSP-11 D1.04", stem="Stem gives 4,500 ft^2 and 15 ft^2/person. Occupant load?",
      options=["15.","300 because 4500/15=300.","4,500.","67 using 67 ft^2/person from another occupancy."],
      answer=1, err="FORM",
      explanation=rationale("Load=area/factor from stem.","4500/15=300.","NFPA 101 life safety concepts; use stem factor.","A=factor alone; B=correct; C=area; D=wrong factor."),
      distractors=dist("Fails.","Correct: 300.","Fails.","Fails: Wrong occupancy factor.")),
    dict(task="CSP-11 D1.04", stem="Which is exit discharge?",
      options=["Aisle inside the room.","Path from the exit door to the public way.","Protected stair enclosure.","Occupant-load calculation."],
      answer=1, err="TOOL",
      explanation=rationale("Discharge is after the exit toward public way.","Access→exit→discharge sequence.","NFPA 101 egress parts.","A=access; B=correct; C=often the exit; D=unrelated."),
      distractors=dist("Fails: That is exit access.","Correct.","Fails: Enclosure is typically the exit.","Fails.")),
    dict(task="CSP-11 D1.04", stem="90 ft by 50 ft room. Approx. half-diagonal for remoteness teaching?",
      options=["45 ft (half the length only).","About 51.5 ft because diagonal≈103 ft.","70 ft.","20 ft because doors are on one wall."],
      answer=1, err="FORM",
      explanation=rationale("Diagonal=sqrt(90^2+50^2)≈102.96; half≈51.5.","Use Pythagorean diagonal.","Remoteness teaching concept — VERIFY code exceptions.","A=wrong; B=correct; C=guess; D=wishful."),
      distractors=dist("Fails: Not half-length.","Correct: ≈51.5 ft.","Fails.","Fails.")),
    dict(task="CSP-11 D1.04", stem="Two exits are 18 ft apart; half-diagonal requirement from stem is 51 ft. Best evaluation?",
      options=["OK because two exits exist.","Likely fails remoteness the stem is testing.","OK if sprinklers exist without stem saying so.","OK if occupant load <50 always."],
      answer=1, err="STEM",
      explanation=rationale("Separation must meet the stem remoteness idea.","18 << 51.","Life safety arrangement.","A=count≠arrangement; B=correct; C=invented exception; D=false universal."),
      distractors=dist("Fails.","Correct.","Fails: Need stem authority.","Fails.")),
    dict(task="CSP-11 D1.04", stem="Corridor leading to a stair: classify the corridor typically as?",
      options=["Exit discharge.","Exit access.","Public way.","Occupant load factor."],
      answer=1, err="TOOL",
      explanation=rationale("Corridor path to the exit is exit access.","Parts of means of egress.","NFPA 101 terminology.","A=wrong stage; B=correct; C=outside; D=unrelated."),
      distractors=dist("Fails.","Correct.","Fails.","Fails.")),
    dict(task="CSP-11 D1.04", stem="Stem omits the occupant-load factor. What should you refuse?",
      options=["Computing with any memorized universal 15.","Asking for the factor/occupancy/edition.","Using area alone as load.","Both A and C are refusals — pick the best exam behavior: refuse memorized universal factor."],
      answer=3, err="STEM",
      explanation=rationale("No factor, no load — do not invent.","Stem must supply or name the table basis.","VERIFY edition factors.","D best states refusal of invented universals; A is also right but D is complete."),
      distractors=dist("Partially right but incomplete vs D.","Fails: You need data, but the trap is inventing.","Fails: Area is not load.","Correct: Refuse invented universals.")),
    dict(task="CSP-11 D1.04", stem="3,000 ft^2; stem factor 7 ft^2/person (standing assembly teaching). Load?",
      options=["21.","about 429 because 3000/7≈428.6.","3,000.","7."],
      answer=1, err="FORM",
      explanation=rationale("Divide area by stem factor.","3000/7≈428.57→≈429.","Stem-supplied factor only.","A=multiplied; B=correct; C=area; D=factor."),
      distractors=dist("Fails.","Correct.","Fails.","Fails.")),
    dict(task="CSP-11 D1.04", stem="OSHA egress rules vs NFPA 101 on an exam stem that asks for consensus detail?",
      options=["Always pick OSHA numbers for door ratings.","Recognize 101 as consensus detail; OSHA as legal floor — follow the stem authority.","They are identical always.","Ignore both and use IBC only without stem."],
      answer=1, err="PELTLV",
      explanation=rationale("Legal vs consensus reflex.","Answer to the authority the stem names.","OSHA vs NFPA.","A=wrong authority; B=correct; C=false; D=invented."),
      distractors=dist("Fails.","Correct.","Fails.","Fails.")),
    dict(task="CSP-11 D1.04", stem="Protected stair enclosure serving as a way of travel out is typically which egress part?",
      options=["Exit access only.","Exit.","Exit discharge only.","Public way."],
      answer=1, err="TOOL",
      explanation=rationale("Protected way is the exit.","Means of egress parts.","NFPA 101.","A=before; B=correct; C=after; D=outside."),
      distractors=dist("Fails.","Correct.","Fails.","Fails.")),
    dict(task="CSP-11 D1.04", stem="Why refuse a universal 250 ft travel distance answer?",
      options=["Because travel distance is never limited.","Because limits depend on occupancy/protection/edition — stem must govern.","Because only metric is allowed.","Because occupant load replaces travel distance."],
      answer=1, err="STEM",
      explanation=rationale("No universal travel number.","VERIFY by edition/occupancy.","Life safety variability.","A=false; B=correct; C=false; D=false."),
      distractors=dist("Fails.","Correct.","Fails.","Fails.")),
    dict(task="CSP-11 D1.04", stem="6,000 ft^2 office; stem factor 100 ft^2/person. Load?",
      options=["100.","60.","6,000.","600."],
      answer=1, err="FORM",
      explanation=rationale("6000/100=60.","Simple division.","Stem factor.","A=factor; B=correct; C=area; D=x10."),
      distractors=dist("Fails.","Correct: 60.","Fails.","Fails.")),
    dict(task="CSP-11 D1.04", stem="Half-diagonal concept primarily tests which design idea?",
      options=["Sprinkler density.","Exit remoteness / separation so one fire does not block both exits.","Occupant-load factor tables.","Fire pump churn."],
      answer=1, err="TOOL",
      explanation=rationale("Remoteness keeps exits from a common fire block.","Arrangement of exits.","NFPA 101 arrangement concepts.","A=unrelated; B=correct; C=load; D=fire protection."),
      distractors=dist("Fails.","Correct.","Fails.","Fails.")),
  ],
)
print("102 done")


