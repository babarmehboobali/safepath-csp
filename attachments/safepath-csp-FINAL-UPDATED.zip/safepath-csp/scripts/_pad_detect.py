#!/usr/bin/env python3
import re
from pathlib import Path
from collections import Counter
ROOT = Path("/workspace/safepath-csp/content/classes")
PAD_SENTS = ["Contrast pairs keep labels honest.", "Teach-back restates the rule, sequence, and verification step."]
PAD_PREFIX = "In teach-back, name the decision, the highest open control, and the verification step"
clean=[]; padded=[]
for n in range(1,116):
    ps=list(ROOT.glob("%02d-*.ts"%n)) or list(ROOT.glob("%d-*.ts"%n))
    t=ps[0].read_text()
    std=re.search(r"standard:\s*`([\s\S]*?)`", t).group(1)
    deep=re.search(r"deep:\s*`([\s\S]*?)`", t).group(1)
    pad_n=sum(std.count(s)+deep.count(s) for s in PAD_SENTS)+deep.count(PAD_PREFIX)
    sents=[s.strip() for s in re.split(r"(?<=[.!?])\s+", std+"\n"+deep) if len(s.strip())>40]
    maxr=max(Counter(sents).values()) if sents else 0
    (padded if pad_n>=3 or maxr>=3 else clean).append(n if pad_n<3 and maxr<3 else (n,max(pad_n,maxr)))
print("clean", clean)
print("padded", len(padded))
print("ids", [p[0] if isinstance(p,tuple) else p for p in padded])
