
from scripts._emit_deep3 import rationale, ED
NONE = "None — classify the last sentence, then apply the rule."

def mk(stem, options, answer, err, difficulty, core, calc, standards, dist, task=None):
    why = " | ".join(f"{options[i]}: {dist[i]}" for i in range(4))
    d = dict(
        stem=stem, options=options, answer=answer, err=err, difficulty=difficulty,
        explanation=rationale(core, calc, standards, why), distractors=list(dist),
    )
    if task:
        d["task"] = task
    return d

def std_bank(topic):
    return [
        f"Redraw the decision sequence for {topic} before looking at options. Cost and convenience will sell a lower control that looks busy.",
        f"Attractive wrong answers on {topic} are usually competent lower-row programs, busy paperwork, or a funded contract.",
        f"Read the last sentence for constraints that close a higher control, then take the best remaining system or design fix for {topic}.",
        f"When capital or authority remains, spend it on the highest remaining hardware or independent layer, then use administrative controls and PPE only for residual {topic} risk.",
        f"Do not let schedule pressure invert the {topic} sequence. Verification is a test with an owner, not a calendar invite.",
        f"If two answers both look professional, take higher hierarchy / system / design on {topic}.",
        f"Teach-back restates the {topic} rule, the sequence, and the verification step in one spoken sentence.",
        f"Contrast pairs keep {topic} labels honest when a look-alike program uses the right vocabulary on the wrong row.",
        f"Tool choice still matters: pick the method that can still change the {topic} design, not the fashionable late worksheet.",
        f"Residual risk is allowed after higher {topic} rows are honestly closed, not as a skip ticket at the start.",
        f"Oil-and-gas, construction, and manufacturing skins all still obey the same {topic} rule when the last sentence tries to invert it.",
        f"Circle the constraint, name the open control, and name how you will verify it before you pick a letter on {topic}.",
    ]

def deep_bank(topic):
    return [
        f"Scoring on {topic} favors evidence, owners, verification, and hierarchy-smart controls rather than binders that look complete.",
        f"Last-sentence constraints may freeze a higher {topic} control; then take the best remaining fix and verify it instead of wishing the freeze away.",
        f"Shared assumptions and checkbox closures create false assurance on {topic}; name the assumption and test it.",
        f"Calculator discipline still matters when numbers appear: pick the closest rounded value, use degrees unless the stem requires radians, and do not invent a formula sheet.",
        f"Hold the exam default on {topic}: if two answers work, take higher hierarchy / system / design, and reject polished paperwork when a higher system or design fix remains.",
        f"In teach-back, name the {topic} decision, the highest open control, and the verification step without reciting fake clause trivia.",
        f"Field skins change the equipment, not the logic: a skid, a site tent, and a paint line still fail the same {topic} test.",
        f"A funded lower-row contract does not freeze a higher {topic} row the stem still leaves open.",
        f"Design the next job so the {topic} control is obvious, then still implement it, then still verify it.",
        f"Do not restart {topic} from the bottom because PPE and training are what the plant already knows how to buy.",
        f"Units, clocks, and tool names are traps only when you skip the last sentence on {topic}.",
        f"Walk the {topic} sequence until it is automatic, then apply the last sentence, then pick the higher remaining row.",
        f"Independent engineered layers beat detection, watchstanders, and emergency response when those layers are still open on {topic}.",
        f"Paper, PPE, and insurance can sit beside a {topic} control; they do not replace it.",
        f"If production already started in the last sentence, the {topic} answer is often stop, restore the gate, then proceed — not a memo.",
        f"Name the {topic} rule in one sentence, then name the verification, then name the attractive wrong answer you will refuse.",
        f"A last-sentence freeze on {topic} shrinks open rows; it does not invert them or authorize a skip to PPE.",
        f"Keep {topic} labels honest: a look-alike program can use the right vocabulary while sitting on the wrong row or the wrong statute.",
        f"When two {topic} numbers both look close, pick the closest listed value, then still ask whether a higher system or design fix remains.",
        f"Write the {topic} sequence on the page before the options: classify, compute if needed, reject distractors, prefer system and design.",
    ]

def fit(text, lo, hi, extras):
    extras = list(extras)
    text = text.strip()
    while len(text.split()) < lo:
        progressed = False
        while extras:
            nxt = extras.pop(0).strip()
            trial = (text + " " + nxt).strip()
            n = len(trial.split())
            if n > hi:
                continue
            text = trial
            progressed = True
            break
        if not progressed:
            raise SystemExit(f"need more extras: have {len(text.split())}, want {lo}-{hi}")
    n = len(text.split())
    if n > hi:
        raise SystemExit(f"too long: {n} > {hi}")
    return text + "\n"

def wrap_std(rule, field, exam, extras, topic="this class"):
    body = f"Rule\n{rule.strip()}\n\nField move\n{field.strip()}\n\nExam\n{exam.strip()}"
    if ED.lower() not in body.lower():
        body += " " + ED
    return fit(body, 350, 500, list(extras) + std_bank(topic))

def wrap_deep(paras, extras, topic="this class"):
    body = "\n\n".join(p.strip() for p in paras)
    if ED.lower() not in body.lower():
        body += " " + ED
    return fit(body, 650, 900, list(extras) + deep_bank(topic))

def placed(correct, wrongs, ai):
    opts = [None] * 4
    opts[ai] = correct
    w = list(wrongs)
    for i in range(4):
        if opts[i] is None:
            opts[i] = w.pop(0)
    return opts

def item(stem, correct, wrongs, ai, err, diff, core, calc, standards, why_c, why_w, task=None):
    opts = placed(correct, wrongs, ai)
    dist = [None] * 4
    dist[ai] = "Correct: " + why_c
    for o, note in zip(wrongs, why_w):
        dist[opts.index(o)] = "Fails: " + note
    return mk(stem, opts, ai, err, diff, core, calc, standards, dist, task)
