
from pathlib import Path
ROOT = Path("/workspace/safepath-csp/content/classes")

def q(s):
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n") + '"'

def rationale(core, calc, standards, why):
    return f"Core Rule: {core} Calculation Steps: {calc} Standards Cited: {standards} Why Each Distractor Fails: {why}"

def place(correct, wrongs, ai):
    opts=[None]*4; opts[ai]=correct; w=list(wrongs)
    for i in range(4):
        if opts[i] is None: opts[i]=w.pop(0)
    return opts

def emit_class(filename, task, fields, items_src):
    traps=fields["traps"]; contrast=fields["contrast"]
    lines=['import { contrast, exam, traps, type ClassFields, type ClassItem } from "./types";','',f"const T = {q(task)};",'','export const classFields: ClassFields = {']
    for key in ["hook","hookOilGas","hookConstruction","rule","modelCaption","workedCase"]:
        lines.append(f"  {key}: {q(fields[key])},")
    lines += ["  trapsJson: traps(", f"    {q(traps[0])},", f"    {q(traps[1])},", f"    {q(traps[2])},", "  ),", "  contrastJson: contrast(["]
    for a,b in contrast:
        lines.append(f"    {{ looksLike: {q(a)}, actually: {q(b)} }},")
    lines.append("  ]),")
    for key in ["brief","standard","deep","cardFront","cardBack","teachBackKey"]:
        lines.append(f"  {key}: {q(fields[key])},")
    slug=fields.get("formulaSlug")
    lines.append(f"  formulaSlug: {q(slug)}," if slug else "  formulaSlug: null,")
    lines += ["};", "", "export const items: ClassItem[] = ["]
    answers=[]
    for it in items_src:
        answers.append(it["answer"])
        opts=place(it["correct"], it["wrongs"], it["answer"])
        distractors=[it["dmap"][o] for o in opts]
        opts_s=",\n      ".join(q(o) for o in opts)
        dist_s=",\n      ".join(q(d) for d in distractors)
        tcode=it.get("task", task)
        lines.append(f"  exam(\n    {q(tcode)},\n    {q(it['stem'])},\n    [\n      {opts_s},\n    ],\n    {it['answer']},\n    {q(it['explanation'])},\n    {q(it['err'])},\n    \"Exam\",\n    [\n      {dist_s},\n    ],\n  ),")
    lines += ["];", ""]
    path=ROOT/filename
    path.write_text("\n".join(lines)+"\n")
    print(f"wrote {filename} answers={answers} uniq={sorted(set(answers))} bytes={path.stat().st_size}")

def mk(stem, correct, wrongs, answer, err, core, calc, standards, dmap):
    why=" | ".join(f"{k}: {v}" for k,v in dmap.items())
    return dict(stem=stem, correct=correct, wrongs=wrongs, answer=answer, err=err,
                explanation=rationale(core,calc,standards,why), dmap=dmap)

def D(c,w1,w2,w3,cn,n1,n2,n3):
    return {c:"Correct: "+cn, w1:"Fails: "+n1, w2:"Fails: "+n2, w3:"Fails: "+n3}

def F(**k): return k
