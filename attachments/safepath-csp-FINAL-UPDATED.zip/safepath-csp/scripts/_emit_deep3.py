#!/usr/bin/env python3
"""Emit Safepath CSP class packs 116+ (mustScore + stemIfThen + exam items)."""
from __future__ import annotations
from pathlib import Path

ROOT = Path("/workspace/safepath-csp/content/classes")
ED = "If two answers work, take higher hierarchy / system / design."

def q(s: str) -> str:
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n") + '"'

def bq(s: str) -> str:
    return "`" + s.replace("\\", "\\\\").replace("`", "\\`").replace("${", "\\${") + "`"

def rationale(core: str, calc: str, standards: str, why: str) -> str:
    return (
        f"Core Rule: {core} Calculation Steps: {calc} "
        f"Standards Cited: {standards} Why Each Distractor Fails: {why}"
    )

def emit_item(task, stem, options, answer, explanation, err, difficulty="Exam", distractors=None):
    opts = ",\n      ".join(q(o) for o in options)
    lines = [
        "  exam(",
        f"    {q(task)},",
        f"    {q(stem)},",
        "    [",
        f"      {opts},",
        "    ],",
        f"    {answer},",
        f"    {q(explanation)},",
        f"    {q(err)},",
        f"    {q(difficulty)},",
    ]
    if distractors:
        d = ",\n      ".join(q(x) for x in distractors)
        lines.append("    [")
        lines.append(f"      {d},")
        lines.append("    ],")
    lines.append("  ),")
    return "\n".join(lines)

def emit_class(filename: str, task: str, fields: dict, items: list[dict]) -> Path:
    traps = fields["traps"]
    contrast = fields["contrast"]
    must = fields["mustScore"]
    sif = fields["stemIfThen"]
    body = []
    body.append('import { contrast, exam, mustScore, stemIfThen, traps, type ClassFields, type ClassItem } from "./types";')
    body.append("")
    body.append(f"const T = {q(task)};")
    body.append("")
    body.append("export const classFields: ClassFields = {")
    for key in ["hook", "hookOilGas", "hookConstruction", "rule", "modelCaption", "workedCase"]:
        body.append(f"  {key}: {q(fields[key])},")
    body.append("  trapsJson: traps(")
    body.append(f"    {q(traps[0])},")
    body.append(f"    {q(traps[1])},")
    body.append(f"    {q(traps[2])},")
    body.append("  ),")
    body.append("  contrastJson: contrast([")
    for looks, actually in contrast:
        body.append(f"    {{ looksLike: {q(looks)}, actually: {q(actually)} }},")
    body.append("  ]),")
    body.append("  mustScoreJson: mustScore(")
    for i, m in enumerate(must):
        comma = "," if i < len(must) - 1 else ""
        body.append(f"    {q(m)}{comma}")
    body.append("  ),")
    body.append("  stemIfThenJson: stemIfThen(")
    for i, pair in enumerate(sif):
        comma = "," if i < len(sif) - 1 else ""
        body.append(f"    {{ ifStem: {q(pair[0])}, pick: {q(pair[1])} }}{comma}")
    body.append("  ),")
    for key in ["brief", "standard", "deep"]:
        body.append(f"  {key}: {bq(fields[key])},")
    body.append(f"  cardFront: {q(fields['cardFront'])},")
    body.append(f"  cardBack: {q(fields['cardBack'])},")
    body.append(f"  teachBackKey: {q(fields['teachBackKey'])},")
    slug = fields.get("formulaSlug")
    body.append(f"  formulaSlug: {q(slug)}," if slug else "  formulaSlug: null,")
    body.append("};")
    body.append("")
    body.append("export const items: ClassItem[] = [")
    answers = []
    diffs = []
    for it in items:
        answers.append(it["answer"])
        diffs.append(it.get("difficulty", "Exam"))
        body.append(emit_item(
            it.get("task", task),
            it["stem"],
            it["options"],
            it["answer"],
            it["explanation"],
            it["err"],
            it.get("difficulty", "Exam"),
            it.get("distractors"),
        ))
    body.append("];")
    body.append("")
    path = ROOT / filename
    path.write_text("\n".join(body) + "\n")
    std_w = len(fields["standard"].split())
    deep_w = len(fields["deep"].split())
    brief_w = len(fields["brief"].split())
    print(
        f"wrote {filename} items={len(items)} ans={answers} diffs={diffs} "
        f"brief={brief_w} std={std_w} deep={deep_w} bytes={path.stat().st_size}"
    )
    if not (5 <= len(must) <= 8):
        raise SystemExit(f"{filename}: mustScore {len(must)}")
    if not (4 <= len(sif) <= 6):
        raise SystemExit(f"{filename}: stemIfThen {len(sif)}")
    if len(contrast) < 4:
        raise SystemExit(f"{filename}: contrast {len(contrast)}")
    if len(items) < 12:
        raise SystemExit(f"{filename}: items {len(items)}")
    if brief_w > 80:
        raise SystemExit(f"{filename}: brief {brief_w} > 80")
    if std_w < 350 or std_w > 500:
        raise SystemExit(f"{filename}: standard {std_w} not in 350-500")
    if deep_w < 650 or deep_w > 900:
        raise SystemExit(f"{filename}: deep {deep_w} not in 650-900")
    if "Foundation" not in diffs or "Expert" not in diffs:
        raise SystemExit(f"{filename}: need Foundation+Expert, got {set(diffs)}")
    if len(set(answers)) < 3:
        raise SystemExit(f"{filename}: answerIndex not varied {set(answers)}")
    if ED.lower() not in fields["standard"].lower():
        raise SystemExit(f"{filename}: missing exam default sentence in standard")
    return path
