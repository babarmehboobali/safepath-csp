#!/usr/bin/env python3
from __future__ import annotations
import json, re
from pathlib import Path

ROOT = Path("/workspace/safepath-csp/content/classes")
PACK_DIR = Path("/workspace/safepath-csp/scripts/d1_packs")
ED = "If two answers work, take higher hierarchy / system / design."

def words(s: str) -> int:
    return len(s.split())

def extract_string_field(t: str, name: str) -> str:
    m = re.search(rf"{name}:\s*`([\s\S]*?)`", t)
    if m:
        return m.group(1).strip()
    m = re.search(rf'{name}:\s*"((?:\\.|[^"\\])*)"', t)
    if m:
        return m.group(1)
    return ""

def ensure_import(t: str) -> str:
    first = t.split("\n", 1)[0]
    if "mustScore" in first and "stemIfThen" in first:
        return t
    t = t.replace(
        'import { contrast, exam, traps, type ClassFields, type ClassItem } from "./types";',
        'import { contrast, exam, mustScore, stemIfThen, traps, type ClassFields, type ClassItem } from "./types";',
    )
    if "mustScore" not in t.split("\n", 1)[0]:
        def fix(m):
            body = m.group(1)
            if "mustScore" in body:
                return m.group(0)
            return 'import {' + body.rstrip() + ", mustScore, stemIfThen} from \"./types\";"
        t = re.sub(r"import \{([^}]+)\} from \"\./types\";", fix, t, count=1)
    return t

def build_standard(rule: str, field: str, title: str) -> str:
    std = (
        f"Rule\n{rule.strip()} Hold the reusable sentence on every stem in this class. {ED}\n\n"
        f"Field move\n{field.strip()} Redraw the decision sequence before looking at options. "
        f"Cost and convenience will sell a lower control that looks busy.\n\n"
        f"Exam\n{ED} Read the last sentence for constraints that close a higher control. "
        f"Attractive wrong answers are usually competent lower-row programs. For {title.lower()}, "
        f"verify the control type and whether a higher control is still open in the stem. "
        f"Do not let schedule pressure invert the hierarchy. Brownfield limits shrink options; "
        f"they do not authorize skipping remaining engineered controls. When capital remains, "
        f"spend it on the highest remaining hardware, then use administrative controls and PPE "
        f"only for residual risk."
    )
    pad = (
        " Contrast pairs keep labels honest: what looks like engineering may be administrative paper,"
        " and what looks like a management program may still be PPE. Teach-back should restate the rule,"
        " the field sequence, and the verification step without inventing a new hierarchy."
    )
    while words(std) < 350:
        std += pad
    ws = std.split()
    if len(ws) > 500:
        std = " ".join(ws[:490])
    return std

def build_deep(rule: str, field: str, deep_extra: str, title: str, hook: str) -> str:
    deep = (
        f"{title} sits in CSP-11 Domain 1 Applied Safety Technology. The exam tests whether you apply "
        f"hierarchy and system thinking when a field package already looks complete. Core rule: {rule.strip()}\n\n"
        f"Field context: {hook.strip()} {field.strip()}\n\n"
        f"{deep_extra.strip()}\n\n"
        f"Across Domain 1, the scoring pattern repeats. If a higher control is still open in the stem, that is the answer. "
        f"Permits, training, detectors, and PPE can be necessary residual controls, but they lose when elimination, "
        f"substitution, or engineering is still available. Last-sentence constraints may freeze a higher row; then take "
        f"the best remaining engineered control and say so. Shared instruments, shared keys, and shared assumptions create "
        f"false independence. Verification beats assertion: try-out, atmosphere tests, load charts, stop-time distance, "
        f"and clear egress paths are how you prove the control.\n\n"
        f"Calculator discipline still matters when numbers appear later in the catalog: pick the closest rounded value, "
        f"use degrees unless the stem requires radians, and do not invent a formula sheet. For this class the primary "
        f"\"math\" is which control the stem left open. Tool choice must still be able to change the decision — "
        f"after-the-fact observation cards do not climb the pyramid. {ED} Hold that sentence, redraw the model, and "
        f"reject the polished lower-row program when a higher row remains."
    )
    while words(deep) < 650:
        deep += (
            f" In teach-back, name the hazard, the highest open control, and the verification step for {title.lower()}."
            " If you cannot say what would falsify the control, you are not ready for the drill items."
        )
    ws = deep.split()
    if len(ws) > 900:
        deep = " ".join(ws[:880])
    return deep

def fmt_must(must):
    lines = ",\n    ".join(json.dumps(x) for x in must)
    return f"  mustScoreJson: mustScore(\n    {lines}\n  ),\n"

def fmt_stems(stems):
    parts = [f'    {{ ifStem: {json.dumps(s["ifStem"])}, pick: {json.dumps(s["pick"])} }},' for s in stems]
    return "  stemIfThenJson: stemIfThen(\n" + "\n".join(parts) + "\n  ),\n"

def repl_field(src: str, name: str, value: str) -> str:
    m = re.search(rf"  {name}:\s*`[\s\S]*?`", src)
    if m:
        return src[: m.start()] + f"  {name}: `{value}`" + src[m.end() :]
    m = re.search(rf'  {name}:\s*"(?:\\.|[^"\\])*"', src)
    if m:
        return src[: m.start()] + f"  {name}: `{value}`" + src[m.end() :]
    raise SystemExit(f"missing {name}")

def densify(cid: int) -> None:
    meta = json.loads((PACK_DIR / f"{cid:02d}.json").read_text())
    paths = list(ROOT.glob(f"{cid:02d}-*.ts"))
    if not paths:
        raise SystemExit(f"missing class {cid}")
    p = paths[0]
    t = ensure_import(p.read_text())
    rule = extract_string_field(t, "rule") or meta["title"]
    hook = extract_string_field(t, "hook") or ""
    brief = meta["brief"]
    bw = brief.split()
    if len(bw) > 80:
        brief = " ".join(bw[:78])
    std = build_standard(rule, meta["field"], meta["title"])
    deep = build_deep(rule, meta["field"], meta["deep_extra"], meta["title"], hook)
    assert words(std) >= 300, (cid, "std", words(std))
    assert words(deep) >= 500, (cid, "deep", words(deep))

    m_work = re.search(r"workedCase:\s*`([\s\S]*?)`", t)
    if m_work and "Losing answer" not in m_work.group(1) and "loses" not in m_work.group(1).lower():
        t = t[: m_work.end(1)] + " Losing answer: the polished lower-row program while a higher control is still open." + t[m_work.end(1) :]

    t = re.sub(r"\n\s*mustScoreJson:[\s\S]*?\n\s*stemIfThenJson:[\s\S]*?\),\n", "\n", t)
    t = re.sub(r"\n\s*mustScoreJson:[\s\S]*?\),\n", "\n", t)
    t = re.sub(r"\n\s*stemIfThenJson:[\s\S]*?\),\n", "\n", t)

    m = re.search(r"contrastJson:\s*contrast\(\[[\s\S]*?\]\),", t)
    if not m:
        raise SystemExit(f"no contrastJson in {p}")
    inject = m.group(0) + "\n" + fmt_must(meta["must"]) + fmt_stems(meta["stems"])
    t = t[: m.start()] + inject + t[m.end() :]

    t = repl_field(t, "brief", brief)
    t = repl_field(t, "standard", std)
    t = repl_field(t, "deep", deep)

    if '"Foundation"' not in t:
        m = re.search(r'exam\([\s\S]*?"(HIER|STEM|TOOL|FORM|UNIT|FIN|TIME|PELTLV)"\s*\),', t)
        if m:
            old = m.group(0)
            t = t[: m.start()] + old[:-2] + ', "Foundation"),' + t[m.end() :]
    if '"Expert"' not in t:
        matches = list(re.finditer(r'exam\([\s\S]*?"(HIER|STEM|TOOL|FORM|UNIT|FIN|TIME|PELTLV)"\s*\),', t))
        if matches:
            m = matches[-1]
            old = m.group(0)
            if "Foundation" not in old:
                t = t[: m.start()] + old[:-2] + ', "Expert"),' + t[m.end() :]
            elif len(matches) >= 2:
                m = matches[-2]
                old = m.group(0)
                t = t[: m.start()] + old[:-2] + ', "Expert"),' + t[m.end() :]

    p.write_text(t)
    tt = p.read_text()

    def wc(name: str) -> int:
        mm = re.search(rf"{name}:\s*`([\s\S]*?)`", tt)
        return words(mm.group(1)) if mm else 0

    n_items = len(re.findall(r"\bexam\(", tt))
    ok = wc("standard") >= 300 and wc("deep") >= 500 and "mustScoreJson" in tt and "ifStem" in tt and n_items >= 12
    print(f"Class {cid}: std={wc('standard')} deep={wc('deep')} brief={wc('brief')} items={n_items} ok={ok}")
    if not ok:
        raise SystemExit(f"Class {cid} failed density bar")

if __name__ == "__main__":
    for cid in [4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]:
        densify(cid)
    print("apply_d1_packs complete")
