@echo off
setlocal
cd /d "%~dp0"
title SafePath CSP - Stop Local Server
color 0C

echo.
echo ===============================================
echo       SAFEPATH CSP - LOCAL STOP
echo ===============================================
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\stop-local.ps1"

pause
endlocal
