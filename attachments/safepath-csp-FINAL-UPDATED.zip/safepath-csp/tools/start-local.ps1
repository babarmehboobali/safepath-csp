$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)

Write-Host "" 
Write-Host "===============================================" -ForegroundColor Cyan
Write-Host " SafePath CSP - Permanent Local Launcher" -ForegroundColor Cyan
Write-Host "===============================================" -ForegroundColor Cyan
Write-Host ""

function Require-Command($name, $hint) {
  if (-not (Get-Command $name -ErrorAction SilentlyContinue)) {
    Write-Host "Missing: $name" -ForegroundColor Red
    Write-Host $hint -ForegroundColor Yellow
    exit 1
  }
}

Require-Command "node" "Install Node.js 20+ and restart this terminal."
Require-Command "npm" "Install Node.js 20+ and restart this terminal."
Require-Command "docker" "Install Docker Desktop, start it, then run this launcher again."

$nodeMajor = [int]((node -p "process.versions.node.split('.')[0]") | Out-String).Trim()
if ($nodeMajor -lt 20) {
  Write-Host "Node.js 20+ is required. Detected Node.js $nodeMajor." -ForegroundColor Red
  exit 1
}

# Docker Desktop must be running before compose can start PostgreSQL.
try {
  docker info *> $null
} catch {
  Write-Host "Docker Desktop is not running. Start Docker Desktop and retry." -ForegroundColor Red
  exit 1
}

Write-Host "[1/6] Starting persistent PostgreSQL..." -ForegroundColor Green
docker compose up -d db

Write-Host "[2/6] Waiting for PostgreSQL..." -ForegroundColor Green
$ready = $false
for ($i = 1; $i -le 30; $i++) {
  $status = docker compose exec -T db pg_isready -U cspcoach -d cspcoach 2>$null
  if ($LASTEXITCODE -eq 0) { $ready = $true; break }
  Start-Sleep -Seconds 2
}
if (-not $ready) {
  Write-Host "PostgreSQL did not become ready in time." -ForegroundColor Red
  docker compose logs --tail=80 db
  exit 1
}

# Create .env once. Never overwrite an existing local environment.
if (-not (Test-Path ".env")) {
  Write-Host "[3/6] Creating .env..." -ForegroundColor Green
  Copy-Item ".env.example" ".env"

  $secret = node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
  $cron = node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
  $envText = Get-Content ".env" -Raw
  $envText = $envText -replace 'AUTH_SECRET="replace-with-a-long-random-secret"', ('AUTH_SECRET="' + $secret.Trim() + '"')
  $envText = $envText -replace 'CRON_SECRET="replace-with-another-random-secret"', ('CRON_SECRET="' + $cron.Trim() + '"')
  Set-Content ".env" $envText -NoNewline
} else {
  Write-Host "[3/6] Existing .env preserved." -ForegroundColor Green
}

if (-not (Test-Path "node_modules")) {
  Write-Host "[4/6] Installing Node dependencies (first run only)..." -ForegroundColor Green
  npm ci
} else {
  Write-Host "[4/6] Node dependencies already installed." -ForegroundColor Green
}

Write-Host "[5/6] Preparing Prisma database and SafePath content..." -ForegroundColor Green
npx prisma generate
npx prisma db push
npm run db:seed

Write-Host "[6/6] Starting Next.js..." -ForegroundColor Green
Write-Host ""
Write-Host "SafePath CSP is starting at: http://localhost:3000" -ForegroundColor Cyan
Write-Host "Database persists in Docker volume: cspcoach_postgres" -ForegroundColor DarkCyan
Write-Host "Press Ctrl+C to stop the Next.js server." -ForegroundColor Yellow
Write-Host ""

Start-Process "http://localhost:3000"
npm run dev
