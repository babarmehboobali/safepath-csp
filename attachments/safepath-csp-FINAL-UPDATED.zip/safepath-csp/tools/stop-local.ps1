$ErrorActionPreference = 'Continue'
Set-Location (Split-Path -Parent $PSScriptRoot)
Write-Host "Stopping SafePath CSP Next.js and PostgreSQL..." -ForegroundColor Yellow
Get-Process node -ErrorAction SilentlyContinue | Stop-Process -Force
if (Get-Command docker -ErrorAction SilentlyContinue) {
  docker compose stop db
}
Write-Host "Done. PostgreSQL data remains stored in the persistent Docker volume." -ForegroundColor Green
