import Link from "next/link";
import { AppShell } from "@/components/AppShell";
import { EligibilityWizard } from "@/components/EligibilityWizard";
import { getSession, readDemoProfileCookie } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import type { Metadata } from "next";
import type { EligibilityInput } from "@/lib/eligibility";

export const metadata: Metadata = {
  title: "CSP Eligibility Checker — Education, Experience & Credential Pathway | Safepath CSP",
  description: "Interactive CSP eligibility screening for education, SH&E experience, preventative professional work, and qualifying credential pathways. Independent guidance, not an official BCSP decision.",
  keywords: [
    "CSP eligibility", "CSP eligibility requirements", "Certified Safety Professional eligibility", "CSP requirements",
    "CSP experience requirement", "CSP education requirement", "CSP qualifying credential", "BCSP CSP pathway",
    "NEBOSH CSP eligibility", "ASP to CSP", "GSP to CSP", "TSP to CSP", "CSP experience 4 years",
  ],
  alternates: { canonical: "/eligibility" },
};

export default async function EligibilityPage() {
  const session = await getSession();
  let initial: Partial<EligibilityInput> = {};

  if (session && !session.isDemo) {
    const user = await prisma.user.findUnique({
      where: { id: session.id },
      select: {
        eligibilityEducation: true,
        eligibilityExperienceYears: true,
        eligibilityPreventativePct: true,
        eligibilityCredential: true,
      },
    });
    initial = {
      education: user?.eligibilityEducation || undefined,
      experienceYears: typeof user?.eligibilityExperienceYears === "number" ? user.eligibilityExperienceYears : undefined,
      preventativePct: typeof user?.eligibilityPreventativePct === "number" ? user.eligibilityPreventativePct : undefined,
      credential: user?.eligibilityCredential || undefined,
    };
  } else if (session?.isDemo) {
    const cookie = await readDemoProfileCookie();
    const experience = Number(cookie?.eligibilityExperienceYears);
    const preventative = Number(cookie?.eligibilityPreventativePct);
    initial = {
      education: typeof cookie?.eligibilityEducation === "string" ? cookie.eligibilityEducation : undefined,
      experienceYears: Number.isFinite(experience) ? experience : undefined,
      preventativePct: Number.isFinite(preventative) ? preventative : undefined,
      credential: typeof cookie?.eligibilityCredential === "string" ? cookie.eligibilityCredential : undefined,
    };
  }

  return (
    <AppShell user={session}>
      <main className="mx-auto max-w-5xl space-y-7">
        <section className="readiness-hero overflow-hidden">
          <div className="flex flex-wrap items-start justify-between gap-5">
            <div className="max-w-3xl">
              <p className="kicker">🎯 CSP pathway check</p>
              <h1 className="page-title mt-1">BCSP CSP Eligibility Wizard</h1>
              <p className="page-lead">Answer four quick screens, see which core eligibility gates you appear to meet, and then move directly into your study plan.</p>
            </div>
            <Link href="https://www.bcsp.org/certified-safety-professional-csp" target="_blank" rel="noreferrer" className="btn-ghost tap">Official BCSP requirements ↗</Link>
          </div>
          <div className="mt-6 grid gap-3 sm:grid-cols-3">
            <div className="planner-stat"><div className="text-2xl">🎓</div><p className="mt-2 font-semibold">Education</p><p className="text-xs text-muted">Bachelor's degree minimum</p></div>
            <div className="planner-stat"><div className="text-2xl">🦺</div><p className="mt-2 font-semibold">Experience</p><p className="text-xs text-muted">4+ years, with 50%+ preventative professional work</p></div>
            <div className="planner-stat"><div className="text-2xl">🏅</div><p className="mt-2 font-semibold">Credential</p><p className="text-xs text-muted">BCSP-qualified credential/pathway</p></div>
          </div>
        </section>

        <section className="card p-5 sm:p-7">
          <EligibilityWizard initial={initial} canSave={Boolean(session)} />
        </section>

        <section className="card p-5 sm:p-7">
          <p className="kicker">Why this matters</p>
          <h2 className="mt-1 font-serif text-2xl">Eligibility first. Then study with purpose.</h2>
          <p className="mt-3 max-w-3xl text-sm leading-relaxed text-muted">BCSP currently lists a minimum bachelor's degree, four years of qualifying SH&E experience, and a BCSP-qualified credential for the CSP pathway. SafePath uses those requirements for a screening experience, but final eligibility remains with BCSP's application review.</p>
        </section>
      </main>
    </AppShell>
  );
}
