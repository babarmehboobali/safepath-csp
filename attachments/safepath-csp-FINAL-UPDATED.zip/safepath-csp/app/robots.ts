import type { MetadataRoute } from "next";

const base = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: "*",
        allow: ["/", "/csp-prep/"],
        disallow: [
          "/dashboard",
          "/learn",
          "/practice",
          "/mock",
          "/cards",
          "/settings",
          "/plan",
          "/assess",
          "/sessions",
          "/bank",
          "/flags",
          "/today",
          "/calculator",
          "/math",
          "/tox",
          "/ergo",
          "/formulas",
          "/exam-day",
          "/api/",
        ],
      },
    ],
    sitemap: `${base}/sitemap.xml`,
  };
}
