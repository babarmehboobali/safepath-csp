import Link from "next/link";
import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { GymPersist } from "@/components/GymPersist";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { sampleWithoutReplacement } from "@/lib/sample";
import { toItem } from "@/lib/gym";
import { DOMAIN_NAMES, DOMAIN_WEIGHTS } from "@/lib/constants";
import { BLUEPRINT_TASKS } from "@/content/classes/coverage-map";
import { CATALOG } from "@/lib/catalog";
import { DOMAIN_ICONS } from "@/lib/assessment";

export default async function DomainsPage({
  searchParams,
}: {
  searchParams: Promise<{ d?: string }>;
}) {
  const user = await getSession();
  if (!user) redirect("/login");
  const sp = await searchParams;
  const d = Number(sp.d || 0);

  const classes = await prisma.class.findMany({
    select: { id: true, domain: true, _count: { select: { questions: true } } },
  });
  const byDomain: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0, 7: 0 };
  for (const c of classes) {
    byDomain[c.domain] = (byDomain[c.domain] ?? 0) + c._count.questions;
  }

  const lastBySlug: Record<string, number> = {};
  if (!user.isDemo) {
    const runs = await prisma.gymRun.findMany({
      where: { userId: user.id, gym: "domain" },
      orderBy: { createdAt: "desc" },
    });
    for (const r of runs) {
      if (lastBySlug[r.slug] == null) lastBySlug[r.slug] = r.score;
    }
  }

  if (![1, 2, 3, 4, 5, 6, 7].includes(d)) {
    return (
      <AppShell user={user}>
        <p className="kicker">Domain portal · official weights</p>
        <h1 className="mt-2 font-serif text-3xl">Practice by CSP-11 domain</h1>
        <p className="mt-2 mb-6 text-muted">
          Scenario items grouped by the seven CSP-11 blueprint domains (names and weights from app constants). Start a
          30-item gym. Teach mode asks you to pick, then check for rationale — turn on instant feedback if you want
          immediate reveal. Last score is stored for real accounts only. Not a claimed 360-item sample bank.
        </p>
        <div className="grid gap-3 md:grid-cols-2">
          {[1, 2, 3, 4, 5, 6, 7].map((n) => {
            const tasks = BLUEPRINT_TASKS.filter((task) => task.domain === n);
            return (
            <article key={n} className="card p-5">
              <p className="kicker">
                Domain {n} · {DOMAIN_WEIGHTS[n]}% of the exam
              </p>
              <div className="mt-2 flex items-start gap-3"><span className="text-2xl" aria-hidden>{DOMAIN_ICONS[n as keyof typeof DOMAIN_ICONS]}</span><h2 className="font-serif text-xl">{DOMAIN_NAMES[n]}</h2></div>
              <p className="mt-2 text-sm text-muted">{byDomain[n]} items in the bank · {tasks.length} blueprint tasks mapped</p>
              <p className="mt-1 text-sm">
                Last score:{" "}
                {user.isDemo
                  ? "not stored on demo"
                  : lastBySlug[String(n)] == null
                    ? "none yet"
                    : `${Math.round(lastBySlug[String(n)])}%`}
              </p>
              <Link href={`/domains?d=${n}`} className="btn-primary mt-3 tap">
                Start 30-item gym
              </Link>
            </article>
            );
          })}
        </div>

        <section className="card mt-6 p-5">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <p className="kicker">Blueprint coverage</p>
              <h2 className="mt-2 font-serif text-2xl">Where the curriculum maps to CSP-11 tasks</h2>
            </div>
            <p className="text-sm text-muted">100 curriculum modules · official task codes</p>
          </div>
          <div className="mt-5 grid gap-3 lg:grid-cols-2">
            {BLUEPRINT_TASKS.map((task) => (
              <article key={task.code} className="rounded-xl border border-line bg-ink p-4">
                <div className="flex items-start justify-between gap-3">
                  <span className="font-mono text-sm text-amber">{task.code}</span>
                  <span className="text-xs text-muted">{task.classIds.length} module{task.classIds.length === 1 ? "" : "s"}</span>
                </div>
                <p className="mt-2 text-sm leading-relaxed">{task.title}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {task.classIds.map((id) => {
                    const entry = CATALOG.find((item) => item.id === id);
                    return entry ? (
                      <Link key={id} href={`/learn/${id}`} className="rounded-full border border-line px-2.5 py-1 text-xs text-muted hover:text-amber">
                        {id} · {entry.title}{entry.isDeep ? " · Deep" : ""}
                      </Link>
                    ) : null;
                  })}
                </div>
              </article>
            ))}
          </div>
        </section>
      </AppShell>
    );
  }

  const bank = await prisma.question.findMany({
    where: { class: { domain: d } },
    include: { class: true },
  });
  const picked = sampleWithoutReplacement(bank, 30);
  const items = picked.items.map(toItem);
  const note = picked.withReplacement
    ? `Domain ${d} gym. Bank was under 30 unique items, so a few may repeat.`
    : `Domain ${d} gym. 30 original scenario items. Sampled without replacement.`;

  return (
    <AppShell user={user}>
      <p className="kicker">
        Domain {d} · {DOMAIN_NAMES[d]} · {DOMAIN_WEIGHTS[d]}%
      </p>
      <h1 className="mt-2 font-serif text-3xl">{DOMAIN_NAMES[d]} gym</h1>
      <p className="mt-2 mb-6 text-muted">{byDomain[d]} items available. Pick, then check for rationale (or enable instant feedback). Score at the end.</p>
      <GymPersist
        items={items}
        gym="domain"
        slug={String(d)}
        examMode
        teachMode
        showCalculator
        showDomainBreakdown
        seedNote={note}
      />
    </AppShell>
  );
}
