import type { MetadataRoute } from "next";
import { CATALOG } from "@/lib/catalog";

const base = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";

export default function sitemap(): MetadataRoute.Sitemap {
  const staticRoutes = ["/", "/csp-prep", "/eligibility", "/login", "/register", "/disclaimer"];
  const domains = [1,2,3,4,5,6,7].map((d) => `/csp-prep/domain/${d}`);
  const classes = CATALOG.map((entry) => `/csp-prep/class/${entry.id}`);
  return [...staticRoutes, ...domains, ...classes].map((path) => ({
    url: `${base}${path}`,
    lastModified: new Date(),
    changeFrequency: path === "/csp-prep" ? "weekly" : "monthly",
    priority: path === "/csp-prep" ? 0.9 : path.startsWith("/csp-prep/domain/") ? 0.8 : 0.7,
  }));
}
