import { AppShell } from "@/components/AppShell";
import { getSession } from "@/lib/auth";
import { DISCLAIMER, HONESTY_CLOSER, HONESTY_LEGAL, HONESTY_PRIMARY } from "@/lib/constants";

export default async function DisclaimerPage() {
  const user = await getSession();
  return (
    <AppShell user={user}>
      <p className="kicker">Disclaimer</p>
      <h1 className="mt-2 font-serif text-3xl">Independent study aid</h1>
      <div className="mt-6 max-w-2xl space-y-4 text-lg leading-relaxed whitespace-pre-line">{HONESTY_PRIMARY}</div>
      <p className="mt-6 max-w-2xl text-base leading-relaxed text-muted">{HONESTY_LEGAL}</p>
      <p className="mt-4 max-w-2xl text-base font-medium leading-relaxed">{HONESTY_CLOSER}</p>
      <p className="mt-8 max-w-2xl text-sm leading-relaxed text-muted whitespace-pre-line">{DISCLAIMER}</p>
      <p className="mt-4 max-w-2xl text-sm leading-relaxed text-muted">
        Practice items are aligned to the publicly posted CSP-11 Examination Blueprint. Completing the catalog addresses
        every official blueprint task; it does not reproduce live examination items. Demo activity is not stored.
      </p>
    </AppShell>
  );
}
