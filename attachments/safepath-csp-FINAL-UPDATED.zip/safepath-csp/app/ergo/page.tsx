import Link from "next/link";
import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { ErgoDesk } from "@/components/ErgoDesk";
import { getSession } from "@/lib/auth";

export default async function ErgoPage() {
  const user = await getSession();
  if (!user) redirect("/login");

  return (
    <AppShell user={user}>
      <p className="kicker">Ergonomics lab · RULA / REBA</p>
      <h1 className="mt-2 font-serif text-3xl">Posture estimators</h1>
      <p className="mt-2 mb-6 max-w-3xl text-muted">
        Interactive RULA and REBA teaching desks with visible step traces. Linked from practice and math.{" "}
        <Link href="/math" className="text-amber underline-offset-2 hover:underline">
          Open math solvers
        </Link>
        {" · "}
        <Link href="/practice" className="text-amber underline-offset-2 hover:underline">
          Practice hub
        </Link>
      </p>
      <ErgoDesk />
    </AppShell>
  );
}
