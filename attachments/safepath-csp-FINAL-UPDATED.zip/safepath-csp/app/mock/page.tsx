import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { MockForm } from "@/components/MockForm";
import { getSession } from "@/lib/auth";
import { getStudyProfile } from "@/lib/profile";
import { prisma } from "@/lib/prisma";
import { weightedSample } from "@/lib/sample";
import { toItem } from "@/lib/gym";

export default async function MockPage({
  searchParams,
}: {
  searchParams: Promise<{ length?: string }>;
}) {
  const user = await getSession();
  if (!user) redirect("/login");
  const profile = await getStudyProfile();
  const sp = await searchParams;
  const length = ([50, 100, 200].includes(Number(sp.length)) ? Number(sp.length) : 0) as 0 | 50 | 100 | 200;
  const bank = await prisma.question.findMany({ include: { class: true } });
  const sampled = length === 0 ? { items: [], withReplacement: false } : weightedSample(bank, length);
  const items = sampled.items.map(toItem);
  const candidateName = profile?.name || user.name || "Candidate";

  if (length === 0) {
    return (
      <AppShell user={user}>
        <p className="kicker">Mock examination</p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight">Computer-based practice sitting</h1>
        <p className="mt-3 mb-8 max-w-2xl text-lg text-muted">
          50 (82.5 min) / 100 (165 min) / 200 (5.5 h) at official weights. Exam mode: one item at a time, review
          list, practice calculator only, cards and formula library hidden, no explanations until submit. Practice
          only — navigation can match a CBT pattern; this is not Pearson VUE software.
        </p>
        <MockForm
          length={50}
          items={[]}
          started={false}
          candidateName={candidateName}
          isDemo={user.isDemo}
        />
      </AppShell>
    );
  }

  return (
    <MockForm
      length={length}
      items={items}
      started
      withReplacement={sampled.withReplacement}
      candidateName={candidateName}
      isDemo={user.isDemo}
    />
  );
}
