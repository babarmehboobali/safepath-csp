import { Suspense } from "react";
import Link from "next/link";
import { AppShell } from "@/components/AppShell";
import { AuthForm } from "@/components/AuthForm";
import { getSession } from "@/lib/auth";
import { DEMO_EMAIL, DEMO_PASSWORD } from "@/lib/constants";
import { redirect } from "next/navigation";

export default async function LoginPage() {
  const user = await getSession();
  if (user) redirect("/dashboard");
  return (
    <AppShell user={null}>
      <p className="kicker">Log in</p>
      <h1 className="mt-2 font-serif text-3xl">Continue your plan</h1>
      <p className="mt-2 mb-6 text-muted">
        Prefer a throwaway session?{" "}
        <Link href="/login?demo=1" className="text-amber underline-offset-4 hover:underline">
          Start free demo
        </Link>{" "}
        ({DEMO_EMAIL} / {DEMO_PASSWORD} — progress is discarded).{" "}
        <Link href="/register" className="text-amber underline-offset-4 hover:underline">
          Create a real account
        </Link>{" "}
        to keep scores.
      </p>
      <Suspense>
        <AuthForm mode="login" />
      </Suspense>
    </AppShell>
  );
}
