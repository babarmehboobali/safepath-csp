import Link from "next/link";
import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { GymPersist } from "@/components/GymPersist";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { sampleWithoutReplacement } from "@/lib/sample";
import { toItem } from "@/lib/gym";
import { SESSION_MAP } from "@/content/gym/session-map";

export default async function SessionsPage({
  searchParams,
}: {
  searchParams: Promise<{ id?: string }>;
}) {
  const user = await getSession();
  if (!user) redirect("/login");
  const sp = await searchParams;
  const id = Number(sp.id || 0);
  const session = SESSION_MAP.find((s) => s.id === id);

  const lastBySlug: Record<string, number> = {};
  if (!user.isDemo) {
    const runs = await prisma.gymRun.findMany({
      where: { userId: user.id, gym: "session" },
      orderBy: { createdAt: "desc" },
    });
    for (const r of runs) {
      if (lastBySlug[r.slug] == null) lastBySlug[r.slug] = r.score;
    }
  }

  if (!session) {
    return (
      <AppShell user={user}>
        <p className="kicker">Session resource portal · {SESSION_MAP.length} blocks · 20 items · 30:00</p>
        <h1 className="mt-2 font-serif text-3xl">Session gym</h1>
        <p className="mt-2 mb-6 text-muted">
          Curriculum cards deep-link into the real timed gym (seeded original items — not HTML sample banks). Core
          plan is sessions 1–14; later blocks reinforce deep / maximum track. Timer auto-submits. Instant score after
          the last item. Demo scores are not stored.
        </p>
        <div className="grid gap-3 md:grid-cols-2">
          {SESSION_MAP.map((s) => (
            <article key={s.id} className="card p-5">
              <p className="kicker">
                Session {s.id} · D{s.domains.join(" / D")}
              </p>
              <h2 className="mt-2 font-serif text-xl">{s.title}</h2>
              <p className="mt-2 text-sm text-muted">{s.blurb}</p>
              <p className="mt-2 text-sm text-muted">Classes {s.classIds[0]}–{s.classIds[s.classIds.length - 1]}</p>
              <p className="mt-1 text-sm">
                Last score:{" "}
                {user.isDemo
                  ? "not stored on demo"
                  : lastBySlug[String(s.id)] == null
                    ? "none yet"
                    : `${Math.round(lastBySlug[String(s.id)])}%`}
              </p>
              <Link href={`/sessions?id=${s.id}`} className="btn-primary mt-3 tap">
                Start 20 / 30:00
              </Link>
            </article>
          ))}
        </div>
      </AppShell>
    );
  }

  const bank = await prisma.question.findMany({
    where: { classId: { in: session.classIds } },
    include: { class: true },
  });
  const picked = sampleWithoutReplacement(bank, 20);
  const items = picked.items.map(toItem);
  const note = picked.withReplacement
    ? "This class group was short of 20 unique items, so a few may repeat."
    : "20 original items from this class group. 30-minute timer. Sampled without replacement.";

  return (
    <AppShell user={user}>
      <p className="kicker">Session {session.id} · 20 items · 30:00</p>
      <h1 className="mt-2 font-serif text-3xl">{session.title}</h1>
      <p className="mt-2 mb-6 text-muted">{session.blurb}</p>
      <GymPersist
        items={items}
        gym="session"
        slug={String(session.id)}
        timerMinutes={30}
        examMode
        showCalculator
        seedNote={note}
      />
    </AppShell>
  );
}
