import Link from "next/link";
import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { GymPersist } from "@/components/GymPersist";
import { MathSolvers } from "@/components/MathSolvers";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { sampleWithoutReplacement } from "@/lib/sample";
import { MATH_TOPICS, toItem } from "@/lib/gym";

export default async function MathPage({
  searchParams,
}: {
  searchParams: Promise<{ topic?: string }>;
}) {
  const user = await getSession();
  if (!user) redirect("/login");
  const sp = await searchParams;
  const topic = MATH_TOPICS.find((t) => t.id === sp.topic);

  if (!topic) {
    return (
      <AppShell user={user}>
        <p className="kicker">Math practice · solvers + worked topics</p>
        <h1 className="mt-2 font-serif text-3xl">Formula gym</h1>
        <p className="mt-2 mb-6 text-muted">
          Live solvers with step traces, then topic drills with a worked example and original calculation items.
          Calculator stays on.{" "}
          <Link href="/ergo" className="text-amber underline-offset-2 hover:underline">
            Ergo RULA/REBA
          </Link>
        </p>
        <div className="mb-10">
          <MathSolvers />
        </div>
        <h2 className="mb-3 font-serif text-2xl">Topic drills</h2>
        <div className="grid gap-3">
          {MATH_TOPICS.map((t) => (
            <article key={t.id} className="card p-5">
              <h2 className="font-serif text-xl">{t.label}</h2>
              <p className="mt-2 text-sm text-muted">{t.blurb}</p>
              <Link href={`/math?topic=${t.id}`} className="btn-primary mt-3 tap">
                Open topic
              </Link>
            </article>
          ))}
        </div>
      </AppShell>
    );
  }

  const formula = await prisma.formula.findUnique({ where: { slug: topic.formulaSlug } });
  const bank = await prisma.question.findMany({
    where: { kind: "math", taskCode: { startsWith: `MATH.${topic.id}` } },
    include: { class: true },
  });
  const n = Math.min(12, Math.max(8, bank.length || 8));
  const picked = sampleWithoutReplacement(bank, n);
  const items = picked.items.map(toItem);

  return (
    <AppShell user={user}>
      <p className="kicker">Math · {topic.label}</p>
      <h1 className="mt-2 font-serif text-3xl">{topic.label}</h1>
      <p className="mt-2 mb-4 text-sm text-muted">
        <Link href="/math" className="text-amber underline-offset-2 hover:underline">
          ← Solvers and all topics
        </Link>
      </p>
      {formula ? (
        <article className="card mt-4 p-5 space-y-2">
          <p className="kicker">Worked example</p>
          <p className="font-mono text-amber">{formula.expression}</p>
          <p className="text-sm">{formula.workedExample}</p>
          <p className="text-sm text-muted">Units: {formula.units}</p>
          <p className="text-sm text-muted">Pitfall ({formula.pitfallCode}): {formula.pitfall}</p>
          <Link href="/calculator" className="btn-ghost tap">
            Open calculator
          </Link>
        </article>
      ) : null}
      <div className="mt-6">
        <GymPersist
          items={items}
          gym="math"
          slug={topic.id}
          showCalculator
          seedNote={
            picked.withReplacement
              ? "Fewer than 8 unique items in this topic, so a problem may repeat."
              : `${items.length} original problems. Work the example first, then the items.`
          }
        />
      </div>
    </AppShell>
  );
}
