import { AppShell } from "@/components/AppShell";
import { getSession } from "@/lib/auth";
import { ERROR_CODES } from "@/lib/constants";

export default async function ErrorsPage() {
  const user = await getSession();
  return (
    <AppShell user={user}>
      <p className="kicker">Error codes</p>
      <h1 className="mt-2 font-serif text-3xl">Why the attractive wrong answer won</h1>
      <div className="mt-6 overflow-x-auto">
        <table className="contrast">
          <thead>
            <tr>
              <th>Code</th>
              <th>Meaning</th>
            </tr>
          </thead>
          <tbody>
            {ERROR_CODES.map((e) => (
              <tr key={e.code}>
                <td className="font-mono text-amber">{e.code}</td>
                <td>{e.meaning}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AppShell>
  );
}
