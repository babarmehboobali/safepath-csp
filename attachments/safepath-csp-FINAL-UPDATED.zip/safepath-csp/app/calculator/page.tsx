import { AppShell } from "@/components/AppShell";
import { Calculator } from "@/components/Calculator";
import { getSession } from "@/lib/auth";

export default async function CalculatorPage() {
  const user = await getSession();
  return (
    <AppShell user={user}>
      <p className="kicker">Practice calculator</p>
      <h1 className="mt-2 font-serif text-3xl">TI-30XS look-alike</h1>
      <p className="mt-2 mb-6 max-w-2xl text-muted">
        This is a practice look-alike, not Pearson software and not TI firmware.
      </p>
      <Calculator />
      <section className="card mt-8 space-y-3 p-5 text-[1.05rem] leading-relaxed">
        <p className="kicker">Exam facts (current BCSP Pearson sittings)</p>
        <ul className="list-disc space-y-2 pl-5">
          <li>On-screen calculator emulating TI-30XS; generally no personal calculator.</li>
          <li>Whiteboard provided. No formula sheet. Formula often in the stem; sometimes the item tests formula choice.</li>
          <li>Closed book. Some items may be pretest.</li>
          <li>Pick the closest rounded value. DEG not RAD. Learn fraction-decimal toggle.</li>
          <li>Site calculator is a practice look-alike, not Pearson software.</li>
        </ul>
      </section>
    </AppShell>
  );
}
