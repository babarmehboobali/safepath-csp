import Link from "next/link";
import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { PlannerControls } from "@/components/PlannerControls";
import { getSession } from "@/lib/auth";
import { getStudyProfile } from "@/lib/profile";
import { buildPlanner, PLANNER_MODES, type PlannerMode, isClassUnlocked } from "@/lib/planner";
import { domainScoresForUser } from "@/lib/progress";
import { CATALOG } from "@/lib/catalog";
import { DOMAIN_ICONS, CSP_DOMAIN_NAMES, CSP_DOMAIN_WEIGHTS } from "@/lib/assessment";

function safeMode(value: string | undefined): PlannerMode {
  return value && PLANNER_MODES.includes(value as PlannerMode) ? (value as PlannerMode) : "adaptive";
}

function humanDate(value: string | null) {
  if (!value) return "Set a date";
  return new Intl.DateTimeFormat("en", { month: "short", day: "numeric", year: "numeric" }).format(new Date(`${value}T00:00:00`));
}

export default async function PlanPage({
  searchParams,
}: {
  searchParams: Promise<{ mode?: string; domains?: string; order?: string; weights?: string }>;
}) {
  const user = await getSession();
  if (!user) redirect("/login");
  const profile = await getStudyProfile();
  if (!profile) redirect("/login");
  const scores = await domainScoresForUser(user.id, user.isDemo);
  const sp = await searchParams;
  const mode = safeMode(sp.mode);
  const selectedDomains = (sp.domains || "")
    .split(",")
    .map((x) => Number(x))
    .filter((x) => x >= 1 && x <= 7);
  const choiceOrder = (sp.order || "")
    .split(",")
    .map((x) => Number(x))
    .filter((x) => x >= 1 && x <= 7);
  const choiceWeights: Record<number, number> = {};
  for (const pair of (sp.weights || "").split(",")) {
    const [domainRaw, weightRaw] = pair.split(":");
    const domain = Number(domainRaw);
    const weight = Number(weightRaw);
    if (domain >= 1 && domain <= 7 && Number.isFinite(weight)) choiceWeights[domain] = Math.max(0, Math.min(100, weight));
  }
  const plan = buildPlanner(
    profile,
    scores,
    mode,
    selectedDomains.length ? selectedDomains : [1, 2, 3, 4, 5, 6, 7],
    Object.keys(choiceWeights).length ? choiceWeights : undefined,
    choiceOrder.length ? choiceOrder : undefined,
  );
  const elapsed = Math.max(0, plan.daysTotal - plan.daysRemaining);
  const progress = Math.min(100, Math.round((elapsed / Math.max(1, plan.daysTotal)) * 100));

  const modeDescription = {
    adaptive: "Your latest self-assessment drives extra attention toward weak domains while the blueprint remains visible.",
    mix: "All active domains are blended every week according to the SafePath CSP blueprint distribution.",
    domain: "True domain blocks: Week 1 stays inside D1, then the next week continues D1 if needed, and only after D1 is exhausted does the plan advance to D2.",
    choice: `Custom sequence: ${plan.selectedDomains.map((d, index) => `#${index + 1} D${d} (${Math.round(plan.choiceWeights[d] ?? 0)}%)`).join(" · ")}.`,
  }[mode];

  return (
    <AppShell user={user}>
      <div className="space-y-7">
        <section className="readiness-hero overflow-hidden">
          <div className="flex flex-wrap items-start justify-between gap-5">
            <div className="max-w-3xl">
              <p className="kicker">📅 Study Command Center</p>
              <h1 className="page-title mt-1">Your path to exam day</h1>
              <p className="page-lead">{modeDescription}</p>
            </div>
            <Link href="/settings" className="btn-ghost tap">⚙ Tune dates & hours</Link>
          </div>

          <div className="mt-7 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[
              ["Course start", humanDate(plan.courseStart), "🚩"],
              ["Exam target", humanDate(plan.examDate), "🎯"],
              ["Days remaining", String(plan.daysRemaining), "⏳"],
              ["Daily study", `${plan.dailyHours.toFixed(1)} h`, "🔥"],
            ].map(([label, value, icon]) => (
              <div key={label} className="planner-stat">
                <div className="text-xl" aria-hidden>{icon}</div>
                <p className="mt-2 text-xs font-semibold uppercase tracking-wide text-muted">{label}</p>
                <p className="mt-1 text-lg font-bold">{value}</p>
              </div>
            ))}
          </div>

          <div className="mt-5">
            <div className="mb-2 flex items-center justify-between text-xs text-muted">
              <span>Course timeline</span><span>{progress}% elapsed · {plan.weeksUntilExam} weeks</span>
            </div>
            <div className="domain-meter"><span style={{ width: `${progress}%` }} /></div>
          </div>
        </section>

        <PlannerControls
          selectedDomains={plan.selectedDomains}
          mode={plan.mode}
          choiceOrder={plan.selectedDomains}
          choiceWeights={plan.choiceWeights}
        />

        {plan.underHours ? (
          <div className="rounded-2xl border border-amber/50 bg-amber/10 p-4 text-amber">
            <strong>⚠️ Pace check:</strong> {plan.hoursBudget} total scheduled hours is below the {plan.hoursNeeded}-hour planning threshold. Increase weekly hours or move the target date.
          </div>
        ) : null}

        <section className="card overflow-hidden">
          <div className="border-b border-line bg-panel-2/55 p-5 sm:p-6">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div>
                <p className="kicker">🧭 Domain command map</p>
                <h2 className="mt-1 font-serif text-2xl">See the whole CSP path at a glance</h2>
                <p className="mt-2 max-w-3xl text-sm text-muted">Every domain remains visible in the plan. Click a domain to open its curriculum hub, regardless of whether the current strategy schedules a class there this week.</p>
              </div>
              <span className="chip">Strategy · {mode === "adaptive" ? "Self-assessment adaptive" : mode === "mix" ? "Blueprint mix" : mode === "domain" ? "Strict domain blocks" : "Custom order + material shares"}</span>
            </div>
          </div>
          <div className="p-4 sm:p-5">
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7">
              {[1,2,3,4,5,6,7].map((d) => {
                const domainClasses = CATALOG.filter((c) => c.domain === d);
                const scheduled = plan.weeks.reduce((sum, week) => sum + (week.domains.find((item) => item.domain === d)?.plannedCount ?? 0), 0);
                const score = scores[d];
                const active = plan.selectedDomains.includes(d);
                const icon = DOMAIN_ICONS[d as keyof typeof DOMAIN_ICONS];
                const scoreTone = score == null ? "no-score" : score < 60 ? "weak" : score < 75 ? "watch" : "strong";
                return (
                  <Link key={d} href={`/domains?d=${d}`} className={`domain-map-card ${active ? "is-active" : ""} ${scoreTone}`}>
                    <div className="flex items-center justify-between gap-2">
                      <span className="domain-map-icon" aria-hidden>{icon}</span>
                      <span className="domain-map-code">D{d}</span>
                      <span className="ml-auto domain-weight">{CSP_DOMAIN_WEIGHTS[d as keyof typeof CSP_DOMAIN_WEIGHTS]}%</span>
                    </div>
                    <p className="mt-3 line-clamp-2 text-sm font-semibold">{CSP_DOMAIN_NAMES[d as keyof typeof CSP_DOMAIN_NAMES]}</p>
                    <div className="mt-3 flex items-center justify-between gap-2 text-[11px] text-muted"><span>{scheduled} scheduled</span><span>{domainClasses.length} classes</span></div>
                    <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-panel-2"><span className="block h-full rounded-full bg-[var(--user-accent)]" style={{ width: `${score == null ? 0 : Math.max(3, Math.min(100, score))}%` }} /></div>
                    <p className="mt-2 text-xs font-semibold">{score == null ? "No diagnostic yet" : `${Math.round(score)}% latest diagnostic`}</p>
                    <span className={`mt-3 inline-flex rounded-full px-2 py-1 text-[10px] font-bold uppercase tracking-wide ${active ? "bg-[var(--user-accent-soft)] text-[var(--user-accent)]" : "bg-panel-2 text-muted"}`}>{active ? "Scheduled" : "Awareness"}</span>
                  </Link>
                );
              })}
            </div>
          </div>
        </section>

        <section>
          <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
            <div><p className="kicker">Weekly missions</p><h2 className="mt-1 font-serif text-2xl">Every domain stays visible</h2></div>
            <span className="chip">{plan.unlockedIds.length} scheduled classes</span>
          </div>

          <div className="space-y-5">
            {plan.weeks.map((week) => (
              <article key={week.week} className={`card overflow-hidden ${week.week === 1 ? "ring-1 ring-[var(--user-accent)]" : ""}`}>
                <div className="border-b border-line bg-panel-2/35 p-5 sm:p-6">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <p className="kicker">Week {week.week}</p>
                      <h3 className="mt-1 text-xl font-bold">{humanDate(week.start)} → {humanDate(week.end)}</h3>
                    </div>
                    <span className="rounded-full border border-line bg-panel px-3 py-1 text-xs font-semibold">{week.hours} h target</span>
                  </div>
                  {mode === "domain" ? (
                    <div className="mt-4 flex flex-wrap items-center gap-2">
                      {week.focusDomains.length ? week.focusDomains.map((d) => (
                        <Link key={d} href={`/domains?d=${d}`} className="inline-flex items-center gap-2 rounded-full border border-[var(--user-accent)]/40 bg-[var(--user-accent-soft)] px-3 py-1.5 text-xs font-bold text-[var(--user-accent)]">
                          <span aria-hidden>{DOMAIN_ICONS[d as keyof typeof DOMAIN_ICONS]}</span> D{d} active block
                        </Link>
                      )) : (
                        <span className="chip">🔁 Review / recovery week</span>
                      )}
                    </div>
                  ) : null}
                  <p className="mt-4 rounded-xl border border-line bg-ink/40 p-3 text-sm">🏁 {week.milestone}</p>
                  <div className="mt-4 flex gap-2 overflow-x-auto pb-1">
                    {week.studyDays.map((day) => (
                      <div key={`${week.week}-${day.date}`} className="shrink-0 rounded-xl border border-line bg-panel px-3 py-2">
                        <p className="text-[10px] font-bold uppercase tracking-wide text-muted">{day.label}</p>
                        <p className="mt-1 text-xs font-semibold">{humanDate(day.date)}</p>
                        <p className="mt-1 font-mono text-[11px] text-[var(--user-accent)]">{day.hours.toFixed(1)} h target</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="p-5 sm:p-6">
                  <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                    {week.domains.map((domain) => {
                      const score = domain.score;
                      const active = plan.selectedDomains.includes(domain.domain);
                      const icon = DOMAIN_ICONS[domain.domain as keyof typeof DOMAIN_ICONS];
                      const classes = domain.classIds
                        .map((id) => CATALOG.find((x) => x.id === id))
                        .filter(Boolean);
                      return (
                        <section key={domain.domain} className={`domain-lane ${active && classes.length ? "is-scheduled" : ""}`}>
                          <div className="flex items-start justify-between gap-2">
                            <div className="min-w-0">
                              <div className="flex items-center gap-2">
                                <span className="domain-lane-icon" aria-hidden>{icon}</span>
                                <Link href={`/domains?d=${domain.domain}`} className="text-sm font-bold hover:text-[var(--user-accent)]">D{domain.domain}</Link>
                                <span className="domain-weight">{CSP_DOMAIN_WEIGHTS[domain.domain as keyof typeof CSP_DOMAIN_WEIGHTS]}%</span>
                              </div>
                              <p className="mt-1 line-clamp-2 text-xs font-medium text-muted">{CSP_DOMAIN_NAMES[domain.domain as keyof typeof CSP_DOMAIN_NAMES]}</p>
                            </div>
                            <span className={`shrink-0 rounded-full border px-2 py-1 text-[11px] font-bold ${score == null ? "border-line text-muted" : score < 60 ? "border-bad/50 bg-bad/10 text-bad" : "border-ok/40 bg-ok/10 text-ok"}`}>
                              {score == null ? "No score" : `${Math.round(score)}%`}
                            </span>
                          </div>

                          <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-panel-2">
                            <span className="block h-full rounded-full bg-[var(--user-accent)]" style={{ width: `${score == null ? 0 : Math.max(4, Math.min(100, score))}%` }} />
                          </div>

                          <div className="mt-3 space-y-2">
                            {classes.length ? classes.map((entry) => (
                              <Link key={entry!.id} href={`/learn/${entry!.id}`} className="planner-class-link">
                                <span className="planner-class-icon" aria-hidden>{icon}</span>
                                <span className="min-w-0 flex-1"><span className="block text-[11px] font-bold text-muted">D{entry!.domain} · Class {entry!.id}</span><span className="block truncate text-sm font-semibold">{entry!.title}</span></span>
                                <span aria-hidden>→</span>
                              </Link>
                            )) : (
                              <div className="rounded-xl border border-dashed border-line p-3 text-xs text-muted">{active ? "No new class scheduled this week. Review misses, cards, or the domain gym." : "Awareness only — not scheduled in this strategy."}</div>
                            )}
                          </div>
                        </section>
                      );
                    })}
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="card p-5 sm:p-6">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div><p className="kicker">Curriculum map</p><h2 className="mt-1 font-serif text-2xl">130-class path</h2></div>
            <span className="chip">{plan.unlockedIds.length}/130 unlocked in this strategy</span>
          </div>
          <p className="mt-2 text-sm text-muted">Locked modules stay visible. Adaptive mode can bring targeted advanced material into the schedule when your latest diagnostic shows a weak domain.</p>
          <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[1,2,3,4,5,6,7].map((d) => {
              const domainClasses = CATALOG.filter((c) => c.domain === d);
              const unlocked = domainClasses.filter((c) => isClassUnlocked(c.id, profile.track, scores)).length;
              const score = scores[d];
              return (
                <Link key={d} href={`/domains?d=${d}`} className="curriculum-domain-card">
                  <div className="flex items-center gap-2"><span className="text-xl" aria-hidden>{DOMAIN_ICONS[d as keyof typeof DOMAIN_ICONS]}</span><span className="font-bold">D{d}</span><span className="ml-auto chip">{CSP_DOMAIN_WEIGHTS[d as keyof typeof CSP_DOMAIN_WEIGHTS]}%</span></div>
                  <p className="mt-2 line-clamp-2 text-sm font-semibold">{CSP_DOMAIN_NAMES[d as keyof typeof CSP_DOMAIN_NAMES]}</p>
                  <div className="mt-3 flex items-center justify-between text-xs text-muted"><span>{unlocked}/{domainClasses.length} unlocked</span><span>{score == null ? "No score" : `${Math.round(score)}%`}</span></div>
                  <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-panel-2"><span className="block h-full rounded-full bg-[var(--user-accent)]" style={{ width: `${domainClasses.length ? (unlocked/domainClasses.length)*100 : 0}%` }} /></div>
                </Link>
              );
            })}
          </div>
        </section>
      </div>
    </AppShell>
  );
}
