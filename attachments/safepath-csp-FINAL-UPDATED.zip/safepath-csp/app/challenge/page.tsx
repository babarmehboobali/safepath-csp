import Link from "next/link";
import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { GymPersist } from "@/components/GymPersist";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { sampleWithoutReplacement } from "@/lib/sample";
import { toItem } from "@/lib/gym";

export default async function ChallengePage({
  searchParams,
}: {
  searchParams: Promise<{ n?: string; d?: string }>;
}) {
  const user = await getSession();
  if (!user) redirect("/login");
  const sp = await searchParams;
  const n = ([10, 25].includes(Number(sp.n)) ? Number(sp.n) : 0) as 0 | 10 | 25;
  const d = [1, 2, 3, 4, 5, 6, 7].includes(Number(sp.d)) ? Number(sp.d) : 0;

  if (!n) {
    return (
      <AppShell user={user}>
        <p className="kicker">Challenge deck · Expert only · cards off</p>
        <h1 className="mt-2 font-serif text-3xl">Harder than the class set</h1>
        <p className="mt-2 mb-6 text-muted">
          Original Expert items spread across seven domains. Not a copy of any paid challenge bank. Calculator on.
          Demo scores are not stored.
        </p>
        <div className="flex flex-wrap gap-2">
          <Link href="/challenge?n=10" className="btn-primary tap">
            10 mixed
          </Link>
          <Link href="/challenge?n=25" className="btn-primary tap">
            25 mixed
          </Link>
        </div>
        <p className="mt-6 text-sm text-muted">Or a single domain:</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {[1, 2, 3, 4, 5, 6, 7].map((dom) => (
            <Link key={dom} href={`/challenge?n=10&d=${dom}`} className="btn-ghost tap">
              D{dom} · 10
            </Link>
          ))}
        </div>
        <p className="mt-6 text-sm text-muted">
          Environmental freeboard stems (including SPCC-style containment) live in Domain 5 challenge and{" "}
          <Link href="/learn/107" className="text-amber underline-offset-2 hover:underline">
            class 107
          </Link>
          .
        </p>
      </AppShell>
    );
  }

  const bank = await prisma.question.findMany({
    where: {
      kind: "challenge",
      ...(d ? { class: { domain: d } } : {}),
    },
    include: { class: true },
  });
  const picked = sampleWithoutReplacement(bank, n);
  const items = picked.items.map(toItem);

  return (
    <AppShell user={user}>
      <p className="kicker">
        Challenge · {n} Expert items{d ? ` · domain ${d}` : ""} · cards off
      </p>
      <h1 className="mt-2 font-serif text-3xl">Expert gym</h1>
      <GymPersist
        items={items}
        gym="challenge"
        slug={d ? `d${d}-${n}` : `mix-${n}`}
        examMode
        showCalculator
        showDomainBreakdown
        seedNote={
          picked.withReplacement
            ? "Bank was short, so an item may repeat."
            : "Original Expert items. Sampled without replacement. Cards off."
        }
      />
    </AppShell>
  );
}
