import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { GymPersist } from "@/components/GymPersist";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { weightedSample } from "@/lib/sample";
import { mockTimerMinutes, toItem } from "@/lib/gym";

export default async function PostTestPage() {
  const user = await getSession();
  if (!user) redirect("/login");
  const bank = await prisma.question.findMany({ include: { class: true } });
  const sampled = weightedSample(bank, 50);
  const items = sampled.items.map(toItem);
  return (
    <AppShell user={user}>
      <p className="kicker">Post-test · 50 items · cards off</p>
      <h1 className="mt-2 font-serif text-3xl">After-study sitting</h1>
      <p className="mt-2 mb-6 text-muted">
        Same weights as the pre-test. Dashboard shows the delta. Demo scores are not stored.
      </p>
      <GymPersist
        items={items}
        gym="assess"
        slug="post"
        timerMinutes={mockTimerMinutes(50)}
        examMode
        showCalculator
        showDomainBreakdown
        seedNote={
          sampled.withReplacement
            ? "A domain was short, so an item may repeat."
            : "50 original items, sampled without replacement. Cards off."
        }
      />
    </AppShell>
  );
}
