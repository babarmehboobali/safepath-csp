import Link from "next/link";
import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { GymPersist } from "@/components/GymPersist";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { weightedSample } from "@/lib/sample";
import { mockTimerMinutes, toItem } from "@/lib/gym";
import { DOMAIN_NAMES, DOMAIN_WEIGHTS } from "@/lib/constants";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export default async function SelfAssessmentPage({
  searchParams,
}: {
  searchParams: Promise<{ sitting?: string }>;
}) {
  const user = await getSession();
  if (!user) redirect("/login");

  const sp = await searchParams;
  const sitting = sp.sitting === "50" ? 50 : sp.sitting === "100" ? 100 : 0;

  if (!sitting) {
    return (
      <AppShell user={user}>
        <div className="space-y-8">
          <section className="card overflow-hidden p-6 sm:p-8">
            <p className="kicker">🎯 Self-Assessment · CSP diagnostic</p>
            <div className="mt-2 max-w-3xl">
              <h1 className="font-serif text-4xl">Know where you stand before exam day.</h1>
              <p className="mt-4 text-lg leading-relaxed text-muted">
                SafePath’s Self-Assessment is a diagnostic sitting modeled on the purpose of the official BCSP Self-Assessment: evaluate strengths and weaknesses across the exam blueprint and use the result to build a smarter study plan.
              </p>
              <p className="mt-3 text-sm leading-relaxed text-muted">
                BCSP describes its official Self-Assessments as blueprint-based, with practice questions written using exam-writing practices, and says results help identify strengths, weaknesses, and test-taking pace. SafePath uses its own original question bank; this is not a BCSP product or official BCSP score.
              </p>
            </div>
            <div className="mt-6 grid gap-3 md:grid-cols-3">
              <div className="rounded-xl border border-line bg-panel-2 p-4">
                <p className="text-lg font-semibold">01 · Weighted diagnostic</p>
                <p className="mt-2 text-sm text-muted">Questions are sampled across Domains 1–7 using the CSP blueprint weights used by SafePath.</p>
              </div>
              <div className="rounded-xl border border-line bg-panel-2 p-4">
                <p className="text-lg font-semibold">02 · Pacing check</p>
                <p className="mt-2 text-sm text-muted">Timed sittings show your average seconds per item and flag unusually slow pacing.</p>
              </div>
              <div className="rounded-xl border border-line bg-panel-2 p-4">
                <p className="text-lg font-semibold">03 · Readiness report</p>
                <p className="mt-2 text-sm text-muted">Finish with an overall percentage, all seven domain scores, weak-domain links, and a SafePath readiness status.</p>
              </div>
            </div>
          </section>

          <section>
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div>
                <p className="kicker">Choose your sitting</p>
                <h2 className="mt-1 font-serif text-2xl">Two ways to diagnose</h2>
              </div>
              <div className="flex flex-wrap gap-3 text-sm"><Link href="/assess/pre" className="text-amber underline-offset-4 hover:underline">Pre-test</Link><Link href="/assess/post" className="text-amber underline-offset-4 hover:underline">Post-test</Link></div>
            </div>
            <div className="mt-4 grid gap-4 md:grid-cols-2">
              <article className="card p-6">
                <p className="text-sm font-semibold text-amber">FULL SELF-ASSESSMENT</p>
                <h3 className="mt-2 text-2xl font-semibold">100-item sitting</h3>
                <p className="mt-2 text-muted">The deeper blueprint-weighted diagnostic. Use this when you want the clearest baseline across all seven domains.</p>
                <ul className="mt-4 space-y-2 text-sm text-muted">
                  <li>• 100 original SafePath questions</li>
                  <li>• CSP domain-weighted sampling</li>
                  <li>• 165-minute pacing window</li>
                  <li>• Full seven-domain readiness report</li>
                </ul>
                <Link href="/assess/self?sitting=100" className="btn-primary mt-5 tap">Launch 100-item assessment →</Link>
              </article>
              <article className="card p-6">
                <p className="text-sm font-semibold text-amber">QUICK DIAGNOSTIC</p>
                <h3 className="mt-2 text-2xl font-semibold">50-item sitting</h3>
                <p className="mt-2 text-muted">A faster diagnostic for frequent check-ins, study-plan recalibration, or a quick readiness pulse.</p>
                <ul className="mt-4 space-y-2 text-sm text-muted">
                  <li>• 50 original SafePath questions</li>
                  <li>• Same domain weighting</li>
                  <li>• 82.5-minute pacing window</li>
                  <li>• Full seven-domain readiness report</li>
                </ul>
                <Link href="/assess/self?sitting=50" className="btn-primary mt-5 tap">Launch 50-item diagnostic →</Link>
              </article>
            </div>
          </section>

          <section className="card p-5">
            <p className="kicker">Blueprint weighting</p>
            <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
              {[1, 2, 3, 4, 5, 6, 7].map((d) => (
                <div key={d} className="rounded-lg border border-line bg-panel-2 p-3 text-sm">
                  <span className="font-semibold">D{d}</span> · {DOMAIN_WEIGHTS[d]}%<br />
                  <span className="text-muted">{DOMAIN_NAMES[d]}</span>
                </div>
              ))}
            </div>
          </section>

          <p className="text-xs leading-relaxed text-muted">
            SafePath is an independent study system. The readiness labels are SafePath diagnostic heuristics, not BCSP pass/fail determinations. BCSP’s official Self-Assessment is available through its own certification platform.
          </p>
        </div>
      </AppShell>
    );
  }

  const bank = await prisma.question.findMany({ include: { class: true } });
  const sampled = weightedSample(bank, sitting);
  const items = sampled.items.map(toItem);
  const note = sampled.withReplacement
    ? `${sitting}-item sitting · a domain had fewer unique items than its quota, so an item may repeat.`
    : `${sitting}-item weighted sitting · sampled without replacement. Cards are off; calculator is available.`;

  return (
    <AppShell user={user}>
      <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="kicker">🎯 Self-Assessment · {sitting} items</p>
          <h1 className="mt-1 font-serif text-3xl">{sitting === 100 ? "Full diagnostic sitting" : "Quick diagnostic sitting"}</h1>
          <p className="mt-2 max-w-3xl text-muted">Answer under the clock. Your completion screen will calculate the overall score, Domains 1–7, pacing, and a SafePath readiness status.</p>
        </div>
        <Link href="/assess/self" className="btn-ghost tap">Change sitting</Link>
      </div>
      <GymPersist
        items={items}
        gym="self-assessment"
        slug={String(sitting)}
        timerMinutes={mockTimerMinutes(sitting)}
        examMode
        showCalculator
        showDomainBreakdown
        selfAssessment
        seedNote={note}
      />
    </AppShell>
  );
}
