import { redirect } from "next/navigation";

export default function AssessHub() {
  redirect("/assess/self");
}
