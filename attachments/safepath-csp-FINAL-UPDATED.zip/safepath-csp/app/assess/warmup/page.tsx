import Link from "next/link";
import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { GymPersist } from "@/components/GymPersist";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { toItem } from "@/lib/gym";

export default async function AssessWarmupPage() {
  const user = await getSession();
  if (!user) redirect("/login");
  const bank = await prisma.question.findMany({
    where: { taskCode: { startsWith: "DIAG." } },
    include: { class: true },
  });
  const items = bank.map(toItem);
  return (
    <AppShell user={user}>
      <p className="kicker">Diagnostic warm-up · {items.length} original items</p>
      <h1 className="mt-2 font-serif text-3xl">Short baseline sample</h1>
      <p className="mt-2 mb-6 text-muted">
        Short original warm-up sample (parallel reliability, OSHA noise duration, HAZOP, General Duty, sling
        tension, PtD timing, SPCC freeboard). For the full weighted 50, use the main pre-test.{" "}
        <Link href="/assess" className="text-amber underline-offset-2 hover:underline">
          Assess hub
        </Link>
      </p>
      <GymPersist
        items={items}
        gym="assess"
        slug="warmup"
        examMode
        teachMode
        showCalculator
        seedNote={
          items.length
            ? `${items.length} original diagnostic extras. Pick, then check (or enable instant feedback).`
            : "Warm-up bank empty — run db:seed after pull."
        }
      />
    </AppShell>
  );
}
