import Link from "next/link";
import Image from "next/image";
import { APP_NAME } from "@/lib/constants";

export default function NotFound() {
  return (
    <main className="mx-auto flex min-h-full w-full max-w-lg flex-col items-center justify-center px-6 py-16 text-center">
      <Image src="/logo-mark.png" alt="Safepath CSP" width={48} height={48} className="h-12 w-12 object-contain" />
      <p className="kicker mt-8">404</p>
      <h1 className="mt-2 font-serif text-3xl font-semibold tracking-tight">{APP_NAME}</h1>
      <p className="mt-3 text-muted">That page is not in the catalog. Head back to study or the public landing.</p>
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <Link href="/" className="btn-primary">
          Home
        </Link>
        <Link href="/dashboard" className="btn-ghost">
          Dashboard
        </Link>
      </div>
    </main>
  );
}
