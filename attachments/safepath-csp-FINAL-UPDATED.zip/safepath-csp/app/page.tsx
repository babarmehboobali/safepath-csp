import { redirect } from "next/navigation";
import { MarketingShell } from "@/components/MarketingShell";
import { LandingPage } from "@/components/landing/LandingPage";
import { getSession } from "@/lib/auth";

export default async function HomePage() {
  const user = await getSession();
  if (user) redirect("/dashboard");
  return (
    <MarketingShell>
      <LandingPage />
    </MarketingShell>
  );
}
