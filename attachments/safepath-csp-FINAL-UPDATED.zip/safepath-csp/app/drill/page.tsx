import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { QuestionPlayer } from "@/components/QuestionPlayer";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { sampleWithoutReplacement } from "@/lib/sample";
import { toItem } from "@/lib/gym";

export default async function DrillPage() {
  const user = await getSession();
  if (!user) redirect("/login");
  const bank = await prisma.question.findMany({ include: { class: true } });
  const picked = sampleWithoutReplacement(bank, 8);
  const items = picked.items.map(toItem);
  return (
    <AppShell user={user}>
      <p className="kicker">Drill · cards on</p>
      <h1 className="mt-2 font-serif text-3xl">Practice with the card in reach</h1>
      <p className="mt-2 mb-6 text-muted">
        Eight items from the full 100-class curriculum bank. Sampled without replacement when the bank is large enough. Cards stay
        on. Demo attempts are not stored.
      </p>
      <QuestionPlayer
        items={items}
        persistUrl="/api/attempts"
        showCards
        seedNote={
          picked.withReplacement
            ? "Bank was short, so an item may repeat."
            : "Original items from the catalog and gym banks. Sampled without replacement."
        }
      />
    </AppShell>
  );
}
