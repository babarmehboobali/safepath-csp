import Link from "next/link";
import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { GymPersist } from "@/components/GymPersist";
import { CardReviewer } from "@/components/CardReviewer";
import { TermSearch } from "@/components/TermSearch";
import { ToxStudyPanels } from "@/components/ToxStudyPanels";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { shuffle } from "@/lib/sample";
import { toItem } from "@/lib/gym";

export default async function ToxPage({
  searchParams,
}: {
  searchParams: Promise<{ quiz?: string }>;
}) {
  const user = await getSession();
  if (!user) redirect("/login");
  const sp = await searchParams;
  const quiz = sp.quiz === "foundation" || sp.quiz === "exam" ? sp.quiz : "";

  if (quiz) {
    const prefix = quiz === "foundation" ? "TOX.foundation" : "TOX.exam";
    const bank = await prisma.question.findMany({
      where: { kind: "tox", taskCode: { startsWith: prefix } },
      include: { class: true },
    });
    const items = shuffle(bank).slice(0, 25).map(toItem);
    return (
      <AppShell user={user}>
        <p className="kicker">Toxicology lab · {quiz} · 25 items</p>
        <h1 className="mt-2 font-serif text-3xl">
          {quiz === "foundation" ? "Foundation / ASP-flavored tox quiz" : "Exam / CSP-flavored tox quiz"}
        </h1>
        <p className="mt-2 mb-6 text-muted">Original items. PEL vs TLV traps use PELTLV. Instant score.</p>
        <GymPersist
          items={items}
          gym="tox"
          slug={quiz}
          examMode
          showCalculator
          seedNote="25 original toxicology items. Calculator on. Cards off."
        />
      </AppShell>
    );
  }

  const defs = await prisma.referenceTerm.findMany({ where: { kind: "def" }, orderBy: { term: "asc" } });
  const abbrs = await prisma.referenceTerm.findMany({ where: { kind: "abbr" }, orderBy: { term: "asc" } });
  const toxCards = await prisma.card.findMany({ where: { deck: "tox" }, orderBy: { front: "asc" } });

  return (
    <AppShell user={user}>
      <p className="kicker">Toxicology lab</p>
      <h1 className="mt-2 font-serif text-3xl">Dose, limits, and the alphabet of OELs</h1>
      <p className="mt-2 mb-6 text-muted">
        Study panels, searchable glossary (including Ames, sensitizer, teratogen, mutagen, Ceiling, STEL), memory
        cards, and two graded quizzes. Original study objects — not a vendor bank. Demo reviews and scores are not
        stored.
      </p>

      <section className="mb-8">
        <ToxStudyPanels />
      </section>

      <section className="grid gap-3 md:grid-cols-2 mb-8">
        <article className="card p-5">
          <h2 className="font-serif text-xl">Foundation quiz</h2>
          <p className="mt-2 text-sm text-muted">25 items. Routes, LD50 vs OEL, PEL vs TLV, clocks.</p>
          <Link href="/tox?quiz=foundation" className="btn-primary mt-3 tap">
            Start foundation 25
          </Link>
        </article>
        <article className="card p-5">
          <h2 className="font-serif text-xl">Exam quiz</h2>
          <p className="mt-2 text-sm text-muted">25 items. Citation basis, conversions, mixture unity.</p>
          <Link href="/tox?quiz=exam" className="btn-primary mt-3 tap">
            Start exam 25
          </Link>
        </article>
      </section>

      <TermSearch title={`Definitions (${defs.length})`} terms={defs} />
      <div className="mt-8">
        <TermSearch title={`Abbreviations (${abbrs.length})`} terms={abbrs} />
      </div>

      <section className="mt-8">
        <h2 className="font-serif text-2xl">Tox cards ({toxCards.length})</h2>
        <p className="mt-2 mb-4 text-sm text-muted">1 / 3 / 7 / 21 schedule. Demo grades are not stored.</p>
        <CardReviewer
          cards={toxCards.map((c) => ({
            cardId: c.id,
            classId: c.classId ?? undefined,
            title: "Toxicology",
            front: c.front,
            back: c.back,
            deck: "tox",
          }))}
        />
      </section>
    </AppShell>
  );
}
