import Link from "next/link";
import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { DemoFlagsList } from "@/components/DemoMissedPlayer";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export default async function FlagsPage() {
  const user = await getSession();
  if (!user) redirect("/login");

  if (user.isDemo) {
    return (
      <AppShell user={user}>
        <p className="kicker">Flags · demo session</p>
        <h1 className="mt-2 font-serif text-3xl">Bookmarks for this sitting</h1>
        <p className="mt-2 mb-6 text-muted">Demo flags live in sessionStorage and disappear on logout.</p>
        <DemoFlagsList />
      </AppShell>
    );
  }

  const rows = await prisma.flag.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "asc" },
    include: {
      question: { select: { id: true, stem: true, classId: true, class: { select: { domain: true } } } },
    },
  });

  return (
    <AppShell user={user}>
      <p className="kicker">Flags · {rows.length}</p>
      <h1 className="mt-2 font-serif text-3xl">Bookmarked items</h1>
      <p className="mt-2 mb-6 text-muted">Stem preview only. Open one to practice. Toggle Flag on the player to remove.</p>
      {!rows.length ? (
        <div className="card p-5">
          <p>Nothing flagged yet. Use Flag on any item in the player.</p>
          <Link href="/practice" className="btn-primary mt-3 tap">
            Practice hub
          </Link>
        </div>
      ) : (
        <ul className="space-y-2">
          {rows.map((r) => (
            <li key={r.id} className="card p-4">
              <p className="text-sm text-muted">
                D{r.question.class.domain} · Class {r.question.classId}
              </p>
              <p className="mt-1">
                {r.question.stem.length > 160 ? `${r.question.stem.slice(0, 160)}…` : r.question.stem}
              </p>
              <Link href={`/practice?mode=one&qid=${encodeURIComponent(r.question.id)}`} className="btn-ghost mt-3 tap text-sm">
                Practice this item
              </Link>
            </li>
          ))}
        </ul>
      )}
    </AppShell>
  );
}
