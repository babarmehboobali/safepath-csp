import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Log in first." }, { status: 401 });
  if (session.isDemo) return NextResponse.json({ ids: [], skipped: true });
  const rows = await prisma.flag.findMany({
    where: { userId: session.id },
    orderBy: { createdAt: "asc" },
    select: { questionId: true },
  });
  return NextResponse.json({ ids: rows.map((r) => r.questionId) });
}

export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Log in first." }, { status: 401 });
  if (session.isDemo) return NextResponse.json({ ok: true, skipped: true, flagged: true });
  const body = await req.json().catch(() => ({}));
  const questionId = String(body.questionId || "");
  if (!questionId) return NextResponse.json({ error: "questionId required." }, { status: 400 });
  await prisma.flag.upsert({
    where: { userId_questionId: { userId: session.id, questionId } },
    update: {},
    create: { userId: session.id, questionId },
  });
  return NextResponse.json({ ok: true, flagged: true });
}

export async function DELETE(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Log in first." }, { status: 401 });
  if (session.isDemo) return NextResponse.json({ ok: true, skipped: true, flagged: false });
  const body = await req.json().catch(() => ({}));
  const questionId = String(body.questionId || "");
  if (!questionId) return NextResponse.json({ error: "questionId required." }, { status: 400 });
  await prisma.flag.deleteMany({ where: { userId: session.id, questionId } });
  return NextResponse.json({ ok: true, flagged: false });
}
