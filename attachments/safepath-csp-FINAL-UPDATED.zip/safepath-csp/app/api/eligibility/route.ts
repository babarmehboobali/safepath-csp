import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession, readDemoProfileCookie, setDemoProfileCookie } from "@/lib/auth";
import { evaluateEligibility, type EligibilityInput } from "@/lib/eligibility";

function sanitize(body: Record<string, unknown>): EligibilityInput {
  return {
    education: String(body.education || "none"),
    experienceYears: Math.max(0, Number(body.experienceYears || 0)),
    preventativePct: Math.max(0, Math.min(100, Number(body.preventativePct ?? 0))),
    credential: String(body.credential || "OTHER"),
  };
}

export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Log in first to save your eligibility check." }, { status: 401 });
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const input = sanitize(body);
  const report = evaluateEligibility(input);

  if (session.isDemo) {
    const existing = (await readDemoProfileCookie()) || {};
    await setDemoProfileCookie({
      ...existing,
      eligibilityEducation: input.education,
      eligibilityExperienceYears: input.experienceYears,
      eligibilityPreventativePct: input.preventativePct,
      eligibilityCredential: input.credential,
      eligibilityCheckedAt: new Date().toISOString(),
    });
    return NextResponse.json({ ok: true, report, skipped: true });
  }

  await prisma.user.update({
    where: { id: session.id },
    data: {
      eligibilityEducation: input.education,
      eligibilityExperienceYears: input.experienceYears,
      eligibilityPreventativePct: input.preventativePct,
      eligibilityCredential: input.credential,
      eligibilityCheckedAt: new Date(),
    },
  });

  return NextResponse.json({ ok: true, report });
}
