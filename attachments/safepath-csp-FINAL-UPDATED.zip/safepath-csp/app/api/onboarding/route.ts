import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession, setDemoProfileCookie } from "@/lib/auth";

function profileFromBody(body: Record<string, unknown>) {
  const days = Array.isArray(body.availableDays) ? body.availableDays.map(String) : [];
  return {
    name: String(body.name || ""),
    credential: String(body.credential || "ASP"),
    applicationStatus: String(body.applicationStatus || "Not started"),
    courseStartDate: body.courseStartDate ? new Date(String(body.courseStartDate)) : null,
    examDate: body.examDate ? new Date(String(body.examDate)) : null,
    hoursPerWeek: Number(body.hoursPerWeek || 8),
    availableDays: JSON.stringify(days),
    track: String(body.track || "recommended"),
    depth: String(body.depth || "standard"),
    difficulty: String(body.difficulty || "exam"),
    industrySkin: String(body.industrySkin || "manufacturing"),
    onboardingComplete: true,
  };
}

export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Log in first." }, { status: 401 });
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const data = profileFromBody(body);
  if (session.isDemo) {
    await setDemoProfileCookie({
      ...data,
      courseStartDate: data.courseStartDate ? data.courseStartDate.toISOString().slice(0, 10) : null,
      examDate: data.examDate ? data.examDate.toISOString().slice(0, 10) : null,
      availableDays: JSON.parse(data.availableDays),
    });
    return NextResponse.json({ ok: true, skipped: true, redirect: "/dashboard" });
  }
  await prisma.user.update({
    where: { id: session.id },
    data,
  });
  return NextResponse.json({ ok: true, redirect: "/dashboard" });
}
