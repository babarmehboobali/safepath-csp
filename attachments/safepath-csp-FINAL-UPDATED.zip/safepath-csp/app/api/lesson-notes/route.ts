import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";

function parseClassId(value: string | null) {
  const classId = Number(value);
  return Number.isInteger(classId) && classId > 0 ? classId : null;
}

export async function GET(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Log in first." }, { status: 401 });
  const url = new URL(req.url);
  const classId = parseClassId(url.searchParams.get("classId"));
  if (!classId) return NextResponse.json({ error: "A valid classId is required." }, { status: 400 });

  if (session.isDemo) return NextResponse.json({ notes: [] });

  const notes = await prisma.lessonNote.findMany({
    where: { userId: session.id, classId },
    orderBy: { createdAt: "desc" },
    take: 40,
    select: { id: true, content: true, createdAt: true, updatedAt: true },
  });
  return NextResponse.json({ notes });
}

export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Log in first." }, { status: 401 });
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const classId = Number(body.classId);
  const content = String(body.content ?? "").trim();
  if (!Number.isInteger(classId) || classId <= 0) return NextResponse.json({ error: "A valid classId is required." }, { status: 400 });
  if (!content) return NextResponse.json({ error: "Write a note before saving." }, { status: 400 });
  if (content.length > 5000) return NextResponse.json({ error: "Note is too long." }, { status: 400 });

  const cls = await prisma.class.findUnique({ where: { id: classId }, select: { id: true } });
  if (!cls) return NextResponse.json({ error: "Lesson not found." }, { status: 404 });
  if (session.isDemo) {
    return NextResponse.json({
      ok: true,
      skipped: true,
      note: { id: `demo-${Date.now()}`, content, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
    });
  }

  const note = await prisma.lessonNote.create({
    data: { userId: session.id, classId, content },
    select: { id: true, content: true, createdAt: true, updatedAt: true },
  });
  return NextResponse.json({ ok: true, note });
}

export async function DELETE(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Log in first." }, { status: 401 });
  if (session.isDemo) return NextResponse.json({ ok: true, skipped: true });
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const id = String(body.id || "");
  if (!id) return NextResponse.json({ error: "Note id is required." }, { status: 400 });
  await prisma.lessonNote.deleteMany({ where: { id, userId: session.id } });
  return NextResponse.json({ ok: true });
}
