import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import { levelForXp, nextActivityStreak, XP_PER_CORRECT } from "@/lib/streak";

export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Log in first." }, { status: 401 });
  if (session.isDemo) return NextResponse.json({ ok: true, skipped: true });
  const body = await req.json().catch(() => ({}));
  const correct = Boolean(body.correct);
  const result = await prisma.$transaction(async (tx) => {
    const attempt = await tx.attempt.create({ data: { userId: session.id, questionId: String(body.questionId), selected: Number(body.selected), correct } });
    const user = await tx.user.findUnique({ where: { id: session.id }, select: { xp: true, currentStreak: true, bestStreak: true, lastActivityDate: true } });
    if (!user) return { attempt, xp: 0, level: 1, streak: 0 };
    const xp = user.xp + (correct ? XP_PER_CORRECT : 0);
    const streak = nextActivityStreak(user.lastActivityDate, user.currentStreak);
    const bestStreak = Math.max(user.bestStreak, streak);
    const updated = await tx.user.update({ where: { id: session.id }, data: { xp, level: levelForXp(xp), currentStreak: streak, bestStreak, lastActivityDate: new Date().toLocaleDateString("en-CA") }, select: { xp: true, level: true, currentStreak: true } });
    return { attempt, ...updated };
  });
  return NextResponse.json({ ok: true, xp: result.xp, level: result.level, streak: result.currentStreak });
}
