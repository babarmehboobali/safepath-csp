import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import { levelForXp, nextActivityStreak, XP_PER_ASSESSMENT, XP_PER_LESSON } from "@/lib/streak";

export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Log in first." }, { status: 401 });
  if (session.isDemo) return NextResponse.json({ ok: true, skipped: true });
  const body = await req.json().catch(() => ({}));
  const event = String(body.event || "activity");
  const classId = Number(body.classId || 0);
  const now = new Date();

  const result = await prisma.$transaction(async (tx) => {
    const user = await tx.user.findUnique({ where: { id: session.id }, select: { xp: true, level: true, currentStreak: true, bestStreak: true, lastActivityDate: true } });
    if (!user) throw new Error("USER_NOT_FOUND");
    let bonus = 0;
    if (event === "lesson_complete" && classId > 0) {
      const created = await tx.lessonCompletion.createMany({ data: [{ userId: session.id, classId }], skipDuplicates: true });
      bonus = created.count ? XP_PER_LESSON : 0;
    } else if (event === "assessment_complete") {
      bonus = XP_PER_ASSESSMENT;
    }
    const streak = nextActivityStreak(user.lastActivityDate, user.currentStreak, now);
    const best = Math.max(user.bestStreak, streak);
    const xp = user.xp + bonus;
    const level = levelForXp(xp);
    const updated = await tx.user.update({ where: { id: session.id }, data: { xp, level, currentStreak: streak, bestStreak: best, lastActivityDate: now.toLocaleDateString("en-CA") }, select: { xp: true, level: true, currentStreak: true, bestStreak: true } });
    return { ...updated, bonus };
  });
  return NextResponse.json({ ok: true, ...result });
}
