import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";

export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Log in first." }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const length = Number(body.length || 50);
  const score = Number(body.score || 0);
  const domainScores = body.domainScores || {};
  if (session.isDemo) return NextResponse.json({ ok: true, skipped: true, score });
  const run = await prisma.mockRun.create({
    data: {
      userId: session.id,
      length,
      score,
      domainScores: JSON.stringify(domainScores),
      answersJson: JSON.stringify(body.answers || []),
    },
  });
  return NextResponse.json({ ok: true, score, runId: run.id });
}
