import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { createSession, hashPassword } from "@/lib/auth";

// In-memory per-IP limit: 5 signups / 15 min. Fine for a single Node
// instance. Serverless instances do not share this Map. Production should
// use Upstash Redis (or similar) later.
const WINDOW_MS = 15 * 60 * 1000;
const MAX_SIGNUPS = 5;
const hits = new Map<string, number[]>();

function clientIp(req: Request) {
  const forwarded = req.headers.get("x-forwarded-for");
  if (forwarded) return forwarded.split(",")[0]!.trim() || "unknown";
  return req.headers.get("x-real-ip") || "unknown";
}

function rateLimited(ip: string) {
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter((t) => now - t < WINDOW_MS);
  if (recent.length >= MAX_SIGNUPS) {
    hits.set(ip, recent);
    return true;
  }
  recent.push(now);
  hits.set(ip, recent);
  return false;
}

export async function POST(req: Request) {
  const ip = clientIp(req);
  if (rateLimited(ip)) {
    return NextResponse.json(
      { error: "Too many signups from this network. Try again in 15 minutes." },
      { status: 429, headers: { "Retry-After": "900" } },
    );
  }
  const body = await req.json().catch(() => ({}));
  const name = String(body.name || "").trim();
  const email = String(body.email || "").trim().toLowerCase();
  const password = String(body.password || "");
  if (!name || !email || password.length < 8) {
    return NextResponse.json({ error: "Name, email, and an 8+ character password are required." }, { status: 400 });
  }
  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    return NextResponse.json({ error: "That email already has an account. Log in instead." }, { status: 409 });
  }
  const user = await prisma.user.create({
    data: {
      email,
      name,
      passwordHash: await hashPassword(password),
      isDemo: false,
    },
  });
  await createSession({
    id: user.id,
    email: user.email,
    name: user.name,
    isDemo: false,
  });
  return NextResponse.json({ ok: true, redirect: "/onboarding" });
}
