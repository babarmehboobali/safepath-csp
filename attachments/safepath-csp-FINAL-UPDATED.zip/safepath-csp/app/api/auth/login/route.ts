import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { createSession, verifyPassword } from "@/lib/auth";
import { levelForXp, nextActivityStreak } from "@/lib/streak";

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const email = String(body.email || "").trim().toLowerCase();
  const password = String(body.password || "");
  if (!email || !password) return NextResponse.json({ error: "Email and password required." }, { status: 400 });
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user || !(await verifyPassword(password, user.passwordHash))) return NextResponse.json({ error: "Email or password is not right." }, { status: 401 });

  if (!user.isDemo) {
    const now = new Date();
    const currentStreak = nextActivityStreak(user.lastActivityDate, user.currentStreak, now);
    await prisma.user.update({ where: { id: user.id }, data: { currentStreak, bestStreak: Math.max(user.bestStreak, currentStreak), level: levelForXp(user.xp), lastActivityDate: now.toLocaleDateString("en-CA") } });
  }

  await createSession({ id: user.id, email: user.email, name: user.name, isDemo: user.isDemo });
  const redirect = user.isDemo || user.onboardingComplete ? "/dashboard" : "/onboarding";
  return NextResponse.json({ ok: true, redirect });
}
