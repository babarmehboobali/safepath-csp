import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";

export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Log in first." }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const gym = String(body.gym || "session");
  const slug = String(body.slug || "open");
  const length = Number(body.length || 0);
  const score = Number(body.score || 0);
  if (session.isDemo) return NextResponse.json({ ok: true, skipped: true, score });
  await prisma.gymRun.create({
    data: {
      userId: session.id,
      gym,
      slug,
      length,
      score,
      answersJson: JSON.stringify({ answers: body.answers || [], domainScores: body.domainScores || {} }),
    },
  });
  return NextResponse.json({ ok: true, score });
}
