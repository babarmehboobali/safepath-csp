import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import { nextCardInterval } from "@/lib/progress";

export async function POST(req: Request) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Log in first." }, { status: 401 });
  if (session.isDemo) return NextResponse.json({ ok: true, skipped: true });
  const body = await req.json().catch(() => ({}));
  const remembered = Boolean(body.remembered);
  const cardId = body.cardId ? String(body.cardId) : null;
  const classIdRaw = body.classId;
  const classId =
    classIdRaw == null || classIdRaw === "" || Number.isNaN(Number(classIdRaw)) ? null : Number(classIdRaw);

  if (cardId) {
    const existing = await prisma.cardReview.findUnique({
      where: { userId_cardId: { userId: session.id, cardId } },
    });
    const intervalDays = nextCardInterval(existing?.intervalDays ?? 0, remembered);
    const dueAt = new Date(Date.now() + intervalDays * 86400000);
    await prisma.cardReview.upsert({
      where: { userId_cardId: { userId: session.id, cardId } },
      create: {
        userId: session.id,
        cardId,
        classId,
        intervalDays,
        dueAt,
        lastResult: remembered ? "good" : "again",
        reviewCount: 1,
      },
      update: {
        intervalDays,
        dueAt,
        lastResult: remembered ? "good" : "again",
        reviewCount: { increment: 1 },
      },
    });
    return NextResponse.json({ ok: true, intervalDays, dueAt });
  }

  if (classId == null) {
    return NextResponse.json({ error: "Need a class or study card." }, { status: 400 });
  }

  const existing = await prisma.cardReview.findUnique({
    where: { userId_classId: { userId: session.id, classId } },
  });
  const intervalDays = nextCardInterval(existing?.intervalDays ?? 0, remembered);
  const dueAt = new Date(Date.now() + intervalDays * 86400000);
  await prisma.cardReview.upsert({
    where: { userId_classId: { userId: session.id, classId } },
    create: {
      userId: session.id,
      classId,
      intervalDays,
      dueAt,
      lastResult: remembered ? "good" : "again",
      reviewCount: 1,
    },
    update: {
      intervalDays,
      dueAt,
      lastResult: remembered ? "good" : "again",
      reviewCount: { increment: 1 },
    },
  });
  return NextResponse.json({ ok: true, intervalDays, dueAt });
}
