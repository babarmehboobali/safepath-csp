import Link from "next/link";
import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { GymPersist } from "@/components/GymPersist";
import { QuestionSearchDesk, type QuestionSearchRow } from "@/components/QuestionSearchDesk";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { toItem } from "@/lib/gym";
import { CLASS_PACKS } from "@/content/classes";
import { CHALLENGE_QUESTIONS, EXTRA_QUESTIONS } from "@/content/gym";
import type { ClassItem } from "@/content/classes/types";
import type { GymQuestion } from "@/content/gym/types";
import { DOMAIN_NAMES } from "@/lib/constants";
import { CATALOG } from "@/lib/catalog";

function itemKind(item: ClassItem | GymQuestion): string {
  return "kind" in item ? item.kind : "class";
}

function humanDomainFromTaskCode(taskCode: string): string {
  const match = /\bD(\d+)\b/i.exec(taskCode);
  if (!match) return "Unmapped";
  const number = Number(match[1]);
  return DOMAIN_NAMES[number] ? `D${number} · ${DOMAIN_NAMES[number]}` : `D${number}`;
}

function hasStepwiseMath(item: ClassItem | GymQuestion, formulaSlug: string | null | undefined): boolean {
  if (itemKind(item) === "math") return true;
  if (formulaSlug) return true;
  if (/Calculation Steps:/i.test(item.explanation)) return true;
  if (/\b(?:TWA|TRIR|RWL|ppm|mg\/m3|MTBF|lambda|reliab|probab|mean|median|ROI|payback)\b/i.test(item.stem)) return true;
  return /(?:=|×|÷|\^|Σ|π|\bexp\b|\d+\s*[*/+\-]\s*\d+)/i.test(item.explanation);
}

function makeFormulaBreakdown(
  item: ClassItem | GymQuestion,
  classRule: string,
  workedCase: string,
  formulaSlug: string | null | undefined,
): string {
  const parts: string[] = [];
  if (formulaSlug) parts.push(`Formula: ${formulaSlug}.`);
  if (/Calculation Steps:/i.test(item.explanation)) {
    const calc = /Calculation Steps:\s*(.*?)(?=\s+Standards Cited:|\s+Why Each Distractor Fails:|$)/i.exec(item.explanation)?.[1]?.trim();
    if (calc) parts.push(calc);
  }
  if (parts.length) return parts.join(" ");
  if (hasStepwiseMath(item, formulaSlug) && classRule) return classRule;
  return workedCase || "No formula-specific breakdown is stored for this item.";
}

function toSearchRow(
  item: ClassItem | GymQuestion,
  classId: number,
  classTitle: string,
  classStandard: string,
  classRule: string,
  workedCase: string,
  formulaSlug: string | null | undefined,
  id: string,
  source: QuestionSearchRow["source"],
  topic?: string,
): QuestionSearchRow {
  const options: [string, string, string, string] = item.options.length === 4
    ? [item.options[0] ?? "", item.options[1] ?? "", item.options[2] ?? "", item.options[3] ?? ""]
    : ["", "", "", ""];
  const distractors = item.distractors?.length === 4 ? item.distractors as [string, string, string, string] : undefined;
  const domain = humanDomainFromTaskCode(item.taskCode);
  const isMath = hasStepwiseMath(item, formulaSlug);
  const formulaBreakdown = makeFormulaBreakdown(item, classRule, workedCase, formulaSlug);
  const keywords = Array.from(new Set([
    ...item.taskCode.split(/[^A-Za-z0-9./-]+/).filter(Boolean),
    item.errorCode,
    item.difficulty,
    itemKind(item),
    topic ?? "",
    classTitle,
    domain,
    classStandard,
    formulaSlug ?? "",
    ...item.stem.split(/[^A-Za-z0-9%./-]+/).filter((word) => word.length >= 4).slice(0, 20),
  ].filter(Boolean)));

  return {
    id,
    classId,
    classTitle,
    domain,
    kind: source === "class" ? "class" : itemKind(item),
    topic,
    taskCode: item.taskCode,
    difficulty: item.difficulty,
    errorCode: item.errorCode,
    stem: item.stem,
    options,
    answerIndex: item.answerIndex as 0 | 1 | 2 | 3,
    explanation: item.explanation,
    distractors,
    standard: classStandard,
    formulaSlug: formulaSlug ?? null,
    formulaBreakdown,
    keywords,
    isMath,
    source,
    classHref: `/learn/${classId}`,
  };
}

const CLASS_TITLES = new Map(CATALOG.map((entry) => [entry.id, entry.title]));

function aggregateStaticQuestions(): QuestionSearchRow[] {
  const classRows = Object.entries(CLASS_PACKS).flatMap(([classIdText, pack]) => {
    const classId = Number(classIdText);
    return pack.items.map((item, index) =>
      toSearchRow(
        item,
        classId,
        CLASS_TITLES.get(classId) ?? `Class ${classId}`,
        pack.classFields.standard,
        pack.classFields.rule,
        pack.classFields.workedCase,
        pack.classFields.formulaSlug,
        `C${classId}-Q${index + 1}-${item.taskCode}`,
        "class",
      ),
    );
  });

  const gymRows = EXTRA_QUESTIONS.map((item, index) => {
    const pack = CLASS_PACKS[item.classId];
    return toSearchRow(
      item,
      item.classId,
      CLASS_TITLES.get(item.classId) ?? `Class ${item.classId}`,
      pack?.classFields.standard ?? "",
      pack?.classFields.rule ?? "",
      pack?.classFields.workedCase ?? "",
      pack?.classFields.formulaSlug,
      `G-${item.kind}-${item.classId}-${index + 1}-${item.taskCode}`,
      "gym",
      item.topic,
    );
  });

  const challengeRows = CHALLENGE_QUESTIONS.map((item, index) => {
    const pack = CLASS_PACKS[item.classId];
    return toSearchRow(
      item,
      item.classId,
      CLASS_TITLES.get(item.classId) ?? `Class ${item.classId}`,
      pack?.classFields.standard ?? "",
      pack?.classFields.rule ?? "",
      pack?.classFields.workedCase ?? "",
      pack?.classFields.formulaSlug,
      `C-${item.kind}-${item.classId}-${index + 1}-${item.taskCode}`,
      "challenge",
      item.topic,
    );
  });

  const byId = new Map<string, QuestionSearchRow>();
  for (const row of [...classRows, ...gymRows, ...challengeRows]) {
    if (!byId.has(row.id)) byId.set(row.id, row);
  }

  return Array.from(byId.values());
}

export default async function BankPage({
  searchParams,
}: {
  searchParams: Promise<{ play?: string }>;
}) {
  const user = await getSession();
  if (!user) redirect("/login");
  const sp = await searchParams;

  if (sp.play) {
    const q = await prisma.question.findUnique({ where: { id: sp.play }, include: { class: true } });
    return (
      <AppShell user={user}>
        <p className="kicker">Question desk · one item</p>
        <h1 className="mt-2 font-serif text-3xl">Practice from the desk</h1>
        <p className="mt-2 mb-6 text-muted">
          Answers are revealed only inside the practice flow. {" "}
          <Link href="/bank" className="text-amber underline-offset-4 hover:underline">
            Back to desk
          </Link>
        </p>
        <GymPersist items={q ? [toItem(q)] : []} gym="bank" slug={sp.play} seedNote="Single original item." />
      </AppShell>
    );
  }

  const questions = aggregateStaticQuestions();
  const domainOptions = Array.from(new Set(questions.map((row) => row.domain))).sort((a, b) => a.localeCompare(b));

  return (
    <AppShell user={user}>
      <p className="kicker">Question & formula desk · {questions.length.toLocaleString()} indexed</p>
      <h1 className="mt-2 font-serif text-3xl">Research the CSP question bank</h1>
      <p className="mt-2 mb-6 max-w-4xl text-muted">
        Search across class definitions and gym sets in real time. Expand any item to review the key, rationale, standards, calculation logic, and distractor anatomy.
      </p>
      <QuestionSearchDesk questions={questions} domainOptions={domainOptions} />
    </AppShell>
  );
}
