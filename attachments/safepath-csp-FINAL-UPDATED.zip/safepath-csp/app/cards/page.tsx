import Link from "next/link";
import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { CardReviewer, type CardItem } from "@/components/CardReviewer";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const DECKS = ["all", "class", "tox", "formula", "vocab"] as const;

export default async function CardsPage({
  searchParams,
}: {
  searchParams: Promise<{ deck?: string }>;
}) {
  const user = await getSession();
  if (!user) redirect("/login");
  const sp = await searchParams;
  const deck = DECKS.includes(sp.deck as (typeof DECKS)[number]) ? (sp.deck as string) : "all";

  const classes = await prisma.class.findMany({ orderBy: { id: "asc" } });
  const extras = await prisma.card.findMany({
    where: deck === "all" ? {} : deck === "class" ? { id: "__none__" } : { deck },
    orderBy: { front: "asc" },
  });

  const due = user.isDemo
    ? []
    : await prisma.cardReview.findMany({
        where: { userId: user.id, dueAt: { lte: new Date() } },
      });
  const dueClass = new Set(due.filter((d) => d.classId != null).map((d) => d.classId as number));
  const dueStudy = new Set(due.filter((d) => d.cardId).map((d) => d.cardId as string));

  const classCards: CardItem[] =
    deck === "all" || deck === "class"
      ? classes
          .filter((c) => c.cardFront)
          .map((c) => ({
            classId: c.id,
            title: c.title,
            front: c.cardFront,
            back: c.cardBack,
            deck: "class",
          }))
      : [];
  const cards: CardItem[] = extras.map((c) => ({
    cardId: c.id,
    classId: c.classId ?? undefined,
    title: c.deck,
    front: c.front,
    back: c.back,
    deck: c.deck,
  }));

  let stack = [...classCards, ...cards];
  if (!user.isDemo && (dueClass.size || dueStudy.size)) {
    const dueStack = stack.filter(
      (c) => (c.classId != null && dueClass.has(c.classId)) || (c.cardId && dueStudy.has(c.cardId)),
    );
    if (dueStack.length) stack = dueStack;
  }

  return (
    <AppShell user={user}>
      <p className="kicker">Cards · 1 / 3 / 7 / 21 · {stack.length} in this stack</p>
      <h1 className="mt-2 font-serif text-3xl">Memory</h1>
      <p className="mt-2 mb-4 text-muted">
        {user.isDemo
          ? "Demo reviews are not stored. You can still flip cards in this session."
          : "Due cards first when any are waiting. Class cards plus tox, formula, and vocab decks."}
      </p>
      <div className="mb-6 flex flex-wrap gap-2">
        {DECKS.map((d) => (
          <Link key={d} href={d === "all" ? "/cards" : `/cards?deck=${d}`} className={d === deck ? "btn-primary tap" : "btn-ghost tap"}>
            {d}
          </Link>
        ))}
      </div>
      <CardReviewer cards={stack} />
    </AppShell>
  );
}
