import type { Metadata } from "next";
import { IBM_Plex_Sans, IBM_Plex_Serif, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";

const sans = IBM_Plex_Sans({
  variable: "--font-ibm-sans",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

const serif = IBM_Plex_Serif({
  variable: "--font-ibm-serif",
  subsets: ["latin"],
  weight: ["500", "600", "700"],
});

const mono = IBM_Plex_Mono({
  variable: "--font-ibm-mono",
  subsets: ["latin"],
  weight: ["400", "500", "600"],
});

export const metadata: Metadata = {
  title: { default: "Safepath CSP — CSP Exam Preparation", template: "%s | Safepath CSP" },
  description:
    "Safepath CSP — independent CSP exam preparation with blueprint-aligned classes, practice questions, study guides, domain gyms, math labs, flashcards, calculator practice and exam-mode mocks.",
  keywords: [
    "CSP exam prep", "Certified Safety Professional exam", "CSP practice questions", "CSP practice test",
    "CSP study guide", "CSP exam preparation", "CSP 11 study", "CSP certification preparation",
    "CSP Domain 1", "CSP Domain 2", "CSP Domain 3", "CSP Domain 4", "CSP Domain 5", "CSP Domain 6", "CSP Domain 7",
    "safety professional exam", "CSP mock exam", "CSP flashcards", "CSP study plan", "CSP calculator",
    "CSP eligibility", "CSP eligibility checker", "CSP experience requirement", "CSP education requirement",
    "CSP Domain 1 practice", "CSP Domain 2 practice", "CSP Domain 3 practice", "CSP Domain 4 practice",
    "CSP Domain 5 practice", "CSP Domain 6 practice", "CSP Domain 7 practice", "CSP math practice",
    "CSP industrial hygiene", "CSP process safety", "CSP risk management", "CSP emergency management",
    "CSP environmental management", "CSP training and professional conduct", "CSP study planner",
    "CSP self assessment", "CSP readiness assessment", "CSP diagnostic test", "CSP scenario questions",
    "CSP worked problems", "CSP TI-30XS calculator", "CSP noise calculations", "CSP ventilation calculations",
    "CSP rigging calculations", "CSP WBGT calculations", "CSP reliability calculations",
  ],
  icons: {
    icon: [
      { url: "/favicon.ico", sizes: "any" },
      { url: "/favicon-32.png", type: "image/png", sizes: "32x32" },
    ],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180" }],
  },
  openGraph: {
    title: "Safepath CSP",
    description:
      "Independent CSP-11 study system — blueprint-aligned classes, gyms, cards, calculator, and 5.5-hour mocks. Original items. Not affiliated with BCSP, Pearson VUE, or other prep vendors.",
    siteName: "Safepath CSP",
    images: [{ url: "/og.jpg", width: 1200, height: 630, alt: "Safepath CSP" }],
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Safepath CSP",
    description: "Independent CSP-11 study system — blueprint-aligned, original items.",
    images: ["/og.jpg"],
  },
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html
      lang="en"
      className={`${sans.variable} ${serif.variable} ${mono.variable} h-full scroll-smooth antialiased`}
    >
      <body className="min-h-full flex flex-col bg-navy text-cream font-sans">{children}</body>
    </html>
  );
}
