import { AppShell } from "@/components/AppShell";
import Link from "next/link";
import { FormulaDesk } from "@/components/FormulaDesk";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export default async function FormulasPage() {
  const user = await getSession();
  const formulas = await prisma.formula.findMany({ orderBy: { name: "asc" } });
  return (
    <AppShell user={user}>
      <p className="kicker">{formulas.length} equations · searchable desk</p>
      <h1 className="mt-2 font-serif text-3xl">Equation desk</h1>
      <p className="mt-2 mb-6 text-muted">
        Variables, units, a worked example, and a calculator link on every row. Study only — no formula sheet in the
        test center. Live noise, dilution, sling, and TRIR solvers live on{" "}
        <Link href="/math" className="text-amber underline-offset-2 hover:underline">
          /math
        </Link>
        .
      </p>
      <FormulaDesk formulas={formulas} />
    </AppShell>
  );
}
