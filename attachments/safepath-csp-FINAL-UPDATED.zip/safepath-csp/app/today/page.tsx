import Link from "next/link";
import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import HabitStudyEngine from "@/components/HabitStudyEngine";
import { StreakView } from "@/components/StreakView";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { toItem } from "@/lib/gym";
import { qotdIndex, utcDateKey } from "@/lib/qotd";

export default async function TodayPage() {
  const user = await getSession();
  if (!user) redirect("/login");

  const [bank, attempts] = await Promise.all([
    prisma.question.findMany({
      include: { class: { select: { domain: true } } },
      orderBy: [{ classId: "asc" }, { id: "asc" }],
    }),
    prisma.attempt.findMany({
      where: { userId: user.id },
      select: { questionId: true, correct: true, createdAt: true },
      orderBy: { createdAt: "desc" },
      take: 5000,
    }),
  ]);

  const items = bank.map(toItem);
  const key = utcDateKey();
  const idx = qotdIndex(items.length);
  const qotd = items[idx];
  const streakDates = attempts.map((attempt) => attempt.createdAt.toISOString());
  const latestAttemptByQuestion = new Map<string, (typeof attempts)[number]>();
  for (const attempt of attempts) {
    if (!latestAttemptByQuestion.has(attempt.questionId)) {
      latestAttemptByQuestion.set(attempt.questionId, attempt);
    }
  }
  const seedMissedItems = items.filter((item) => latestAttemptByQuestion.get(item.id)?.correct === false);

  return (
    <AppShell user={user}>
      <p className="kicker">Daily mastery · UTC {key}</p>
      <h1 className="page-title">Ten focused minutes beats passive scrolling.</h1>
      <p className="mt-2 max-w-3xl text-muted">
        Use the missed-question burndown until weak questions earn two consecutive correct answers, then run the 10-question Rapid Blitz for a mixed daily sprint.
      </p>

      <section className="card mt-5 p-5 md:flex md:items-center md:justify-between md:gap-6">
        <div>
          <p className="kicker">Study streak</p>
          <StreakView isoDates={streakDates} />
          <p className="mt-1 text-sm text-muted">
            The existing attempt-based streak counts completed answer telemetry, including this engine when you are online or once queued telemetry syncs after reconnect.
          </p>
        </div>
        <Link href="/bank" className="btn-ghost tap mt-4 md:mt-0">
          Open Question Desk
        </Link>
      </section>

      <div className="mt-5">
        <HabitStudyEngine items={items} seedMissedItems={seedMissedItems} />
      </div>

      <section className="card mt-6 p-5">
        <p className="kicker">Question of the Day</p>
        <h2 className="mt-2 text-xl font-semibold">One deterministic item for the date</h2>
        <p className="mt-2 text-sm text-muted">
          The original Question of the Day remains available below the mastery engine as a lightweight daily anchor.
        </p>
        {qotd ? (
          <div className="mt-4 rounded-xl border p-4">
            <p className="text-sm leading-relaxed">{qotd.stem}</p>
            <p className="mt-2 text-xs text-muted">Class {qotd.classId ?? "—"} · Domain {qotd.domain ?? "—"}</p>
          </div>
        ) : (
          <p className="mt-4 text-sm text-muted">No question is currently available.</p>
        )}
      </section>

      <p className="mt-6 text-sm">
        <Link href="/practice" className="text-amber underline-offset-4 hover:underline">
          More gyms on the practice hub
        </Link>
      </p>
    </AppShell>
  );
}
