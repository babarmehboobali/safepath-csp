import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { CertificateView } from "@/components/CertificateView";
import { PrintButton } from "@/components/PrintButton";
import { AppShell } from "@/components/AppShell";
import { getSession } from "@/lib/auth";
import { getStudyProfile } from "@/lib/profile";
import { prisma } from "@/lib/prisma";
import { practiceCertificateGate } from "@/lib/certificate";
import { DOMAIN_NAMES } from "@/lib/constants";

export default async function CertificatePage({
  params,
}: {
  params: Promise<{ runId: string }>;
}) {
  const user = await getSession();
  if (!user) redirect("/login");
  if (user.isDemo) {
    return (
      <AppShell user={user}>
        <p className="kicker">Practice certificate</p>
        <h1 className="mt-2 text-3xl font-semibold">Not saved on demo</h1>
        <p className="mt-3 max-w-xl text-muted">
          Demo sittings are not stored. Complete a mock on a real account to reopen a practice result of completion.
        </p>
        <Link href="/mock" className="btn-primary mt-6">
          Open mock
        </Link>
      </AppShell>
    );
  }
  const { runId } = await params;
  const run = await prisma.mockRun.findUnique({ where: { id: runId } });
  if (!run || run.userId !== user.id) notFound();
  const profile = await getStudyProfile();
  let domainScores: Record<number, number> = {};
  try {
    const parsed = JSON.parse(run.domainScores) as Record<string, number>;
    for (const [k, v] of Object.entries(parsed)) domainScores[Number(k)] = Number(v);
  } catch {
    domainScores = {};
  }
  const gate = practiceCertificateGate(run.score, domainScores);
  if (!gate.eligible) {
    const weak = [...gate.weakDomains, ...gate.missingDomains];
    return (
      <AppShell user={user}>
        <p className="kicker">Score report</p>
        <h1 className="mt-2 text-3xl font-semibold">No practice certificate for this sitting</h1>
        <p className="mt-3 max-w-xl text-muted">
          Score {Math.round(run.score)}% on a {run.length}-item mock. A practice result of completion requires 70% or
          higher and no domain below 60%.
        </p>
        {weak.length ? (
          <ul className="mt-4 space-y-1 text-sm">
            {weak.map((d) => (
              <li key={d}>
                Domain {d} {DOMAIN_NAMES[d]}:{" "}
                {domainScores[d] == null ? "not sampled" : `${Math.round(domainScores[d])}%`}
              </li>
            ))}
          </ul>
        ) : null}
        <div className="mt-6 flex flex-wrap gap-2">
          <Link href="/mock" className="btn-primary">
            Another mock
          </Link>
          <Link href="/practice" className="btn-ghost">
            Review on the practice hub
          </Link>
        </div>
      </AppShell>
    );
  }

  return (
    <div className="exam-root exam-results">
      <header className="exam-header no-print">
        <div className="exam-header-inner">
          <p className="exam-brand">Safepath CSP practice examination</p>
          <p className="exam-meta">Practice result of completion</p>
          <PrintButton className="exam-header-btn">Print</PrintButton>
        </div>
      </header>
      <main className="exam-intro">
        <CertificateView
          candidateName={profile?.name || user.name || "Candidate"}
          date={run.createdAt}
          length={run.length}
          score={run.score}
          domainScores={domainScores}
        />
        <div className="exam-intro-actions no-print">
          <PrintButton />
          <Link href="/dashboard" className="exam-btn-secondary">
            Dashboard
          </Link>
        </div>
      </main>
    </div>
  );
}
