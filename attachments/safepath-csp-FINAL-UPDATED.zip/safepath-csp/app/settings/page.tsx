import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { ProfileForm } from "@/components/ProfileForm";
import { getSession } from "@/lib/auth";
import { getStudyProfile } from "@/lib/profile";
import { ThemeStudio } from "@/components/ThemeStudio";

export default async function SettingsPage() {
  const user = await getSession();
  if (!user) redirect("/login");
  const profile = await getStudyProfile();
  if (!profile) redirect("/login");
  return (
    <AppShell user={user}>
      <p className="kicker">Account</p>
      <h1 className="page-title">Profile and industry skin</h1>
      <p className="mt-2 mb-6 text-muted">
        Industry skin rewrites only the hook sentence on a class. The syllabus does not change.
      </p>
      <ProfileForm profile={profile} endpoint="/api/settings" submitLabel="Save study settings" />
      <div className="mt-6 grid gap-4 lg:grid-cols-[1.25fr_.75fr]">
        <ThemeStudio profile={profile} />
        <section className="card p-5 sm:p-7">
          <p className="kicker">🎯 Pathway check</p>
          <h2 className="mt-1 font-serif text-2xl">CSP eligibility</h2>
          <p className="mt-2 text-sm leading-relaxed text-muted">Run the eligibility wizard to check education, qualifying SH&E experience, preventative professional work, and credential pathway before you lock in your exam plan.</p>
          <a href="/eligibility" className="btn-primary tap mt-5">Open Eligibility Wizard →</a>
        </section>
      </div>
    </AppShell>
  );
}
