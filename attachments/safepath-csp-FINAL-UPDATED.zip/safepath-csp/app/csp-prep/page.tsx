import type { Metadata } from "next";
import Link from "next/link";
import { CATALOG } from "@/lib/catalog";
import { CSP_DOMAIN_NAMES, CSP_DOMAIN_WEIGHTS, DOMAIN_ICONS } from "@/lib/assessment";
import { domainKeywordCluster, keywordCluster } from "@/lib/seo";

export const metadata: Metadata = {
  title: "CSP Exam Prep — Study Guides, Practice Questions & Domain Review | Safepath CSP",
  description:
    "Explore SafePath CSP exam preparation resources across all seven CSP domains: study guides, practice questions, worked examples, scenario drills, math practice and structured review.",
  keywords: [...new Set(CATALOG.flatMap(keywordCluster).concat([...
    "CSP exam prep",
    "Certified Safety Professional exam",
    "CSP certification preparation",
    "CSP practice test",
    "CSP study guide",
    "CSP practice questions",
    "CSP Domain 1",
    "CSP Domain 2",
    "CSP Domain 3",
    "CSP Domain 4",
    "CSP Domain 5",
    "CSP Domain 6",
    "CSP Domain 7",
  ]))].slice(0, 2500),
  alternates: { canonical: "/csp-prep" },
};

export default function CSPPrepHub() {
  return (
    <main className="seo-hub mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <section className="seo-hero">
        <p className="kicker">CSP exam preparation library</p>
        <h1 className="mt-2 font-serif text-4xl font-bold sm:text-5xl">CSP Exam Prep: Study Guides, Practice Questions & Domain Review</h1>
        <p className="seo-hero-lead">A searchable public study library covering the full SafePath CSP curriculum. Explore domain guides, class-level study pages, scenario practice, calculations and exam-oriented review.</p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Link href="/register" className="btn-primary tap">Start studying →</Link>
          <Link href="/login?demo=1" className="btn-ghost tap">Try free demo</Link>
        </div>
      </section>

      <section className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="seo-stat"><strong>7</strong><span>Domains</span></div>
        <div className="seo-stat"><strong>130</strong><span>Curriculum classes</span></div>
        <div className="seo-stat"><strong>2,400+</strong><span>Question-bank scale</span></div>
        <div className="seo-stat"><strong>72+</strong><span>Semantic terms per class page</span></div>
      </section>

      <section className="mt-10">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div><p className="kicker">Browse by domain</p><h2 className="mt-1 font-serif text-3xl">Seven study paths</h2></div>
          <Link href="/topics" className="text-sm font-semibold text-[var(--user-accent)]">Open learner topic map →</Link>
        </div>
        <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {[1, 2, 3, 4, 5, 6, 7].map((domain) => {
            const classes = CATALOG.filter((c) => c.domain === domain);
            return (
              <Link key={domain} href={`/csp-prep/domain/${domain}`} className="seo-domain-card">
                <div className="flex items-center gap-3"><span className="text-2xl" aria-hidden>{DOMAIN_ICONS[domain as keyof typeof DOMAIN_ICONS]}</span><span className="text-lg font-bold">D{domain}</span><span className="ml-auto chip">{CSP_DOMAIN_WEIGHTS[domain as keyof typeof CSP_DOMAIN_WEIGHTS]}%</span></div>
                <h3 className="mt-3 text-base font-bold">{CSP_DOMAIN_NAMES[domain as keyof typeof CSP_DOMAIN_NAMES]}</h3>
                <p className="mt-2 text-sm text-muted">{classes.length} curriculum classes · study guides · practice questions · review.</p>
                <p className="mt-3 text-xs font-semibold text-[var(--user-accent)]">Explore Domain {domain} →</p>
              </Link>
            );
          })}
        </div>
      </section>

      <section className="mt-10 card p-6 sm:p-8">
        <p className="kicker">Class library</p>
        <h2 className="mt-1 font-serif text-3xl">All 130 CSP study topics</h2>
        <p className="mt-2 max-w-3xl text-sm text-muted">Every class has a dedicated public study page with topic context, domain classification, task code, related search language and a direct route into the authenticated lesson experience.</p>
        <div className="mt-6 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {CATALOG.map((entry) => (
            <Link key={entry.id} href={`/csp-prep/class/${entry.id}`} className="seo-class-link">
              <span className="font-mono text-xs text-muted">{entry.taskCode}</span>
              <span className="mt-1 block font-semibold">{entry.title}</span>
              <span className="mt-1 block text-xs text-muted">D{entry.domain} · {keywordCluster(entry).length} topic signals</span>
            </Link>
          ))}
        </div>
      </section>

      <section className="mt-10 grid gap-6 lg:grid-cols-2">
        {[1,2,3,4,5,6,7].map((domain) => (
          <article key={domain} className="card p-6">
            <p className="kicker">Domain {domain} search topics</p>
            <h2 className="mt-1 text-xl font-bold">{CSP_DOMAIN_NAMES[domain as keyof typeof CSP_DOMAIN_NAMES]}</h2>
            <div className="mt-4 flex flex-wrap gap-2">
              {domainKeywordCluster(domain).slice(0, 30).map((kw) => <span key={kw} className="seo-keyword-chip">{kw}</span>)}
            </div>
          </article>
        ))}
      </section>

      <p className="mt-10 text-xs leading-relaxed text-muted">SafePath CSP is an independent preparation platform. Public study pages are created to help learners discover relevant curriculum topics and do not represent an official BCSP score, examination, or endorsement.</p>
    </main>
  );
}
