import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { CATALOG } from "@/lib/catalog";
import { CSP_DOMAIN_NAMES, CSP_DOMAIN_WEIGHTS, DOMAIN_ICONS } from "@/lib/assessment";
import { domainKeywordCluster } from "@/lib/seo";

export function generateStaticParams() {
  return [1,2,3,4,5,6,7].map((domain) => ({ domain: String(domain) }));
}

export async function generateMetadata({ params }: { params: Promise<{ domain: string }> }): Promise<Metadata> {
  const { domain: raw } = await params;
  const domain = Number(raw);
  if (!(domain >= 1 && domain <= 7)) return {};
  const name = CSP_DOMAIN_NAMES[domain as keyof typeof CSP_DOMAIN_NAMES];
  return {
    title: `CSP Domain ${domain}: ${name} — Study Guide & Practice | Safepath CSP`,
    description: `CSP Domain ${domain} review for ${name}: study topics, class pages, practice questions and exam-oriented review on SafePath CSP.`,
    keywords: domainKeywordCluster(domain),
    alternates: { canonical: `/csp-prep/domain/${domain}` },
  };
}

export default async function CSPDomainPage({ params }: { params: Promise<{ domain: string }> }) {
  const { domain: raw } = await params;
  const domain = Number(raw);
  if (!(domain >= 1 && domain <= 7)) notFound();
  const classes = CATALOG.filter((entry) => entry.domain === domain);
  const name = CSP_DOMAIN_NAMES[domain as keyof typeof CSP_DOMAIN_NAMES];
  const weight = CSP_DOMAIN_WEIGHTS[domain as keyof typeof CSP_DOMAIN_WEIGHTS];

  return (
    <main className="seo-hub mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <Link href="/csp-prep" className="text-sm font-semibold text-[var(--user-accent)]">← All CSP domains</Link>
      <section className="mt-5 seo-hero">
        <div className="flex items-center gap-3"><span className="text-4xl" aria-hidden>{DOMAIN_ICONS[domain as keyof typeof DOMAIN_ICONS]}</span><div><p className="kicker">CSP Domain {domain} · {weight}%</p><h1 className="mt-1 font-serif text-4xl font-bold">{name}</h1></div></div>
        <p className="seo-hero-lead">Explore the SafePath curriculum for Domain {domain}, including topic pages, study guidance, practice routes and direct links to the authenticated lesson system.</p>
      </section>
      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {classes.map((entry) => (
          <Link key={entry.id} href={`/csp-prep/class/${entry.id}`} className="seo-class-link block">
            <span className="font-mono text-xs text-muted">Class {entry.id} · {entry.taskCode}</span>
            <span className="mt-2 block text-lg font-bold">{entry.title}</span>
            <span className="mt-2 block text-sm text-muted">CSP practice · study guide · review · scenario work</span>
            <span className="mt-3 block text-xs font-semibold text-[var(--user-accent)]">Open topic page →</span>
          </Link>
        ))}
      </div>
      <section className="mt-8 card p-6"><p className="kicker">Search language</p><div className="mt-3 flex flex-wrap gap-2">{domainKeywordCluster(domain).map((kw) => <span key={kw} className="seo-keyword-chip">{kw}</span>)}</div></section>
    </main>
  );
}
