import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { CATALOG } from "@/lib/catalog";
import { CSP_DOMAIN_NAMES, CSP_DOMAIN_WEIGHTS, DOMAIN_ICONS } from "@/lib/assessment";
import { getCatalogEntry, keywordCluster } from "@/lib/seo";

export function generateStaticParams() {
  return CATALOG.map((entry) => ({ id: String(entry.id) }));
}

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
  const { id: raw } = await params;
  const entry = getCatalogEntry(Number(raw));
  if (!entry) return {};
  const domain = CSP_DOMAIN_NAMES[entry.domain as keyof typeof CSP_DOMAIN_NAMES];
  return {
    title: `${entry.title} — CSP Exam Prep, Study Guide & Practice | Safepath CSP`,
    description: `Study ${entry.title} for CSP exam preparation. Explore ${domain}, ${entry.taskCode}, practice questions, scenario review and a direct SafePath lesson route.`,
    keywords: keywordCluster(entry),
    alternates: { canonical: `/csp-prep/class/${entry.id}` },
    openGraph: { title: `${entry.title} — CSP Exam Prep`, description: `CSP Domain ${entry.domain} study page for ${entry.title}.`, type: "article" },
  };
}

export default async function CSPClassSEOPage({ params }: { params: Promise<{ id: string }> }) {
  const { id: raw } = await params;
  const entry = getCatalogEntry(Number(raw));
  if (!entry) notFound();
  const domain = CSP_DOMAIN_NAMES[entry.domain as keyof typeof CSP_DOMAIN_NAMES];
  const related = CATALOG.filter((c) => c.domain === entry.domain && c.id !== entry.id).slice(0, 6);
  const keywords = keywordCluster(entry);
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "LearningResource",
    name: `${entry.title} — CSP Exam Preparation`,
    description: `Independent CSP study resource for ${entry.title}.`,
    educationalLevel: "Professional certification preparation",
    learningResourceType: "Study guide",
    keywords,
    about: domain,
    isPartOf: { "@type": "Course", name: "SafePath CSP Independent Study System" },
  };

  return (
    <main className="seo-hub mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <div className="flex flex-wrap items-center gap-2 text-sm"><Link href="/csp-prep" className="text-[var(--user-accent)]">CSP Prep</Link><span className="text-muted">/</span><Link href={`/csp-prep/domain/${entry.domain}`} className="text-[var(--user-accent)]">Domain {entry.domain}</Link></div>
      <section className="mt-5 seo-hero">
        <div className="flex items-center gap-3"><span className="text-4xl" aria-hidden>{DOMAIN_ICONS[entry.domain as keyof typeof DOMAIN_ICONS]}</span><div><p className="kicker">Domain {entry.domain} · {CSP_DOMAIN_WEIGHTS[entry.domain as keyof typeof CSP_DOMAIN_WEIGHTS]}% · {entry.taskCode}</p><h1 className="mt-1 font-serif text-4xl font-bold">{entry.title}</h1></div></div>
        <p className="seo-hero-lead">A focused public study page for <strong>{entry.title}</strong>, mapped to {domain}. Use it to understand the topic, discover related study language, then open the full interactive lesson inside SafePath.</p>
        <div className="mt-6 flex flex-wrap gap-3"><Link href={`/learn/${entry.id}`} className="btn-primary tap">Open interactive lesson →</Link><Link href={`/domains?d=${entry.domain}`} className="btn-ghost tap">Open Domain {entry.domain} gym</Link><Link href="/assess/self?sitting=50" className="btn-ghost tap">Take a diagnostic</Link></div>
      </section>

      <section className="mt-8 grid gap-4 md:grid-cols-3">
        <div className="seo-stat"><strong>{entry.taskCode}</strong><span>Blueprint task code</span></div>
        <div className="seo-stat"><strong>D{entry.domain}</strong><span>{domain}</span></div>
        <div className="seo-stat"><strong>{keywords.length}+</strong><span>semantic search signals</span></div>
      </section>

      <section className="mt-8 card p-6">
        <p className="kicker">How to study this topic</p>
        <div className="mt-4 grid gap-4 md:grid-cols-3">
          <div className="seo-step"><span>01</span><div><strong>Learn</strong><p>Read the related class material and identify the governing rule, process, calculation or decision sequence.</p></div></div>
          <div className="seo-step"><span>02</span><div><strong>Apply</strong><p>Use scenario questions, worked examples, calculator practice or teach-back to convert recognition into judgment.</p></div></div>
          <div className="seo-step"><span>03</span><div><strong>Verify</strong><p>Review misses, compare distractor logic and revisit the linked curriculum module before retesting.</p></div></div>
        </div>
      </section>

      <section className="mt-8 card p-6"><p className="kicker">Related search topics</p><div className="mt-3 flex flex-wrap gap-2">{keywords.map((kw) => <span key={kw} className="seo-keyword-chip">{kw}</span>)}</div></section>

      <section className="mt-8"><p className="kicker">More Domain {entry.domain}</p><h2 className="mt-1 font-serif text-2xl">Related CSP study topics</h2><div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{related.map((item) => <Link key={item.id} href={`/csp-prep/class/${item.id}`} className="seo-class-link"><span className="text-xs text-muted">Class {item.id}</span><span className="mt-1 block font-semibold">{item.title}</span></Link>)}</div></section>

      <p className="mt-10 text-xs leading-relaxed text-muted">SafePath CSP is an independent study platform. This page is educational material and is not an official BCSP examination, score or endorsement.</p>
    </main>
  );
}
