import Link from "next/link";
import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { getSession } from "@/lib/auth";
import { readyGate } from "@/lib/progress";

export default async function ExamDayPage() {
  const user = await getSession();
  if (!user) redirect("/login");
  const gate = await readyGate(user.id, user.isDemo);

  return (
    <AppShell user={user}>
      <p className="kicker">Exam-day briefing · independent study notes</p>
      <h1 className="mt-2 font-serif text-3xl">What the sitting usually looks like</h1>
      <p className="mt-2 mb-6 text-muted">
        Original Safepath CSP briefing. Not BCSP, not Pearson VUE, not an official candidate handbook. Rules change —
        confirm with the current bulletin before you travel.
      </p>

      <section className="card space-y-3 p-5">
        <p className="kicker">Room and tools</p>
        <ul className="list-disc space-y-2 pl-5">
          <li>On-screen calculator modeled on a TI-30XS. Generally no personal calculator in the room.</li>
          <li>Whiteboard (or equivalent) is provided. No formula sheet. Formula often sits in the stem; sometimes the item tests whether you pick the right relationship.</li>
          <li>Closed book. Some items may be pretest and unscored — you will not be told which. Answer all of them.</li>
        </ul>
      </section>

      <section className="card mt-4 space-y-3 p-5">
        <p className="kicker">How to compute</p>
        <ul className="list-disc space-y-2 pl-5">
          <li>Pick the closest rounded listed value. Do not invent extra significant figures and then freeze.</li>
          <li>DEG, not RAD, unless a stem truly needs radians (almost never on this exam).</li>
          <li>Learn the fraction-decimal toggle on the practice calculator before test day.</li>
        </ul>
      </section>

      <section className="card mt-4 space-y-3 p-5">
        <p className="kicker">Shape of the exam</p>
        <ul className="list-disc space-y-2 pl-5">
          <li>200 questions, 5.5 hours (330 minutes). Scaled mocks: 100 @ 165 min, 50 @ 82.5 min.</li>
          <li>Domain weights 25 / 25 / 15 / 9 / 6 / 10 / 10 on /mock.</li>
          <li>One item at a time; Previous / Next / Flag / Review anytime; timer does not pause on break.</li>
          <li>Select an answer before you flag. If time ends, blanks stay blank.</li>
          <li>If two answers both work, take the higher hierarchy / system / design option.</li>
        </ul>
      </section>

      <section className="card mt-4 space-y-3 p-5">
        <p className="kicker">Ready-gate reminder</p>
        <p className="font-serif text-xl">{gate.ready ? "Ready" : "Not yet"}</p>
        <p className="text-sm text-muted">{gate.reason}</p>
        <p className="text-sm">Safepath CSP ready gate: two mocks at 70% or higher and no domain below 60%. Demo activity cannot earn the gate.</p>
        <div className="flex flex-wrap gap-2">
          <Link href="/dashboard" className="btn-primary tap">
            Dashboard
          </Link>
          <Link href="/mock?length=200" className="btn-ghost tap">
            200-item final
          </Link>
          <Link href="/calculator" className="btn-ghost tap">
            Practice calculator
          </Link>
        </div>
      </section>
    </AppShell>
  );
}
