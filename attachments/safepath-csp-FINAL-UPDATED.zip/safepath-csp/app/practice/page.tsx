import Link from "next/link";
import type { CSSProperties } from "react";
import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { BuildOwnForm } from "@/components/BuildOwnForm";
import { DemoMissedPlayer, DemoWeakestLaunch } from "@/components/DemoMissedPlayer";
import { GymPersist } from "@/components/GymPersist";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { sampleWithoutReplacement, weightedSample } from "@/lib/sample";
import { toItem } from "@/lib/gym";
import { DOMAIN_NAMES } from "@/lib/constants";
import { levelFromAttempts, missedQuestionIds, parseDomainList, weakestDomainFromAttempts } from "@/lib/practice";

const HUB_LINKS: [string, string, string][] = [
  ["/practice?mode=quick", "Quick 10", "Ten mixed items, cards on"],
  ["/practice?mode=missed", "Missed", "Items you last got wrong"],
  ["/practice?mode=weakest", "Weakest domain", "Lowest attempt accuracy"],
  ["/practice?mode=level", "Level up", "Foundation, then Exam, then Expert at 70%"],
  ["/practice?mode=timed&minutes=5", "Timed 5 min", "As many as you finish"],
  ["/practice?mode=timed&minutes=10", "Timed 10 min", "As many as you finish"],
  ["/practice?mode=mini", "Mini exam 25", "Official weights, cards off"],
  ["/today", "Question of the Day", "One item, UTC date"],
  ["/drill", "Drill", "Eight with cards on"],
  ["/challenge", "Challenge", "Expert deck"],
  ["/assess", "Assess", "Warm-up + pre/post"],
  ["/domains", "Domains", "Seven weighted gyms"],
  ["/topics", "Topic map", "Group classes by study topic"],
];

const ADVANCED_TOOLS: [string, string, string][] = [
  ["/sessions", "Sessions", "14+ blocks · 20 items · 30:00"],
  ["/math", "Math", "Live solvers + topic drills"],
  ["/ergo", "Ergo lab", "RULA / REBA teaching estimators"],
  ["/tox", "Tox lab", "Glossary, panels, quizzes"],
  ["/bank", "Question desk", "Search and sort the bank"],
  ["/flags", "Flagged", "Bookmarks from the player"],
  ["/exam-day", "Exam-day briefing", "Calculator, whiteboard, 200q / 5.5h"],
  ["/formulas", "Formulas", "Equation desk"],
  ["/calculator", "Calculator", "TI-30XS look-alike"],
  ["/errors", "Errors", "Why the trap won"],
  ["/cards", "Cards", "1 / 3 / 7 / 21 memory schedule"],
];

export default async function PracticePage({
  searchParams,
}: {
  searchParams: Promise<{
    mode?: string;
    minutes?: string;
    domains?: string;
    count?: string;
    qid?: string;
  }>;
}) {
  const user = await getSession();
  if (!user) redirect("/login");
  const sp = await searchParams;
  const mode = sp.mode || "";

  if (!mode) {
    return (
      <AppShell user={user}>
        <section className="readiness-hero mb-8">
          <div className="flex flex-wrap items-start justify-between gap-5">
            <div>
              <p className="kicker">⚡ Training Center</p>
              <h1 className="page-title mt-1">Train. Test. Level up.</h1>
              <p className="page-lead">Switch between short wins, deep domain work, timed pressure and specialist labs without leaving your study workspace.</p>
            </div>
            <Link href="/assess/self" className="btn-primary tap">🎯 Run self-assessment</Link>
          </div>
          <div className="mt-6 grid grid-cols-3 gap-2 sm:grid-cols-6">
            {[['7','Domains'],['130','Classes'],['2.4K+','Questions'],['⚡','Math'],['🧠','Cards'],['⏱','Timed']].map(([v,l]) => <div key={l} className="rounded-xl border border-line bg-panel-2/70 p-3 text-center"><div className="text-lg font-bold">{v}</div><div className="text-[10px] uppercase tracking-wide text-muted">{l}</div></div>)}
          </div>
        </section>
        <div className="mb-3 flex items-end justify-between gap-3"><div><p className="kicker">Missions</p><h2 className="mt-1 font-serif text-2xl">Choose your training mode</h2></div><span className="chip">No boredom · one action at a time</span></div>
        <div className="mission-grid">
          {HUB_LINKS.map(([href, label, blurb], idx) => {
            const icons = ['⚡','🔁','🎯','🏆','⏱️','🔥','📝','🧩','⚔️','🎯','🗺️','🧭','🧠'];
            const accents = ['#31c5f4','#fb7185','#7cdb3a','#f5c451','#a78bfa','#fb923c','#72d572'];
            return <Link key={href} href={href} className="mission-card" style={{'--mission-accent': accents[idx % accents.length]} as CSSProperties}><div className="flex items-start justify-between"><span className="mission-icon">{icons[idx % icons.length]}</span><span className="text-xs font-semibold text-muted">MISSION {String(idx+1).padStart(2,'0')}</span></div><h3 className="mt-5 text-xl font-bold">{label}</h3><p className="mt-1 text-sm text-muted">{blurb}</p><span className="mt-5 inline-block text-sm font-semibold text-[var(--user-accent)]">Launch →</span></Link>;
          })}
        </div>
        <div className="mt-10 mb-3"><p className="kicker">Specialist labs</p><h2 className="mt-1 font-serif text-2xl">Go deeper when you are ready</h2></div>
        <div className="mission-grid">
          {ADVANCED_TOOLS.map(([href,label,blurb],idx) => { const icons=['🧭','⚡','🦾','🔬','🔎','🚩','🚨','📐','🧮','🧯','🧠']; return <Link key={href} href={href} className="mission-card" style={{'--mission-accent': idx===1?'#31c5f4':idx===2?'#a78bfa':'#f5c451'} as CSSProperties}><div className="mission-icon">{icons[idx % icons.length]}</div><h3 className="mt-4 text-lg font-bold">{label}</h3><p className="mt-1 text-sm text-muted">{blurb}</p><span className="mt-4 inline-block text-sm font-semibold text-[var(--user-accent)]">Open desk →</span></Link>; })}
        </div>
        <section className="card mt-6 p-5">
          <p className="kicker">Build your own</p>
          <h2 className="mt-2 text-xl">Domains and a count</h2>
          <div className="mt-4">
            <BuildOwnForm />
          </div>
        </section>
      </AppShell>
    );
  }

  if (mode === "missed" && user.isDemo) {
    return (
      <AppShell user={user}>
        <p className="kicker">Missed · demo session</p>
        <h1 className="mt-2 text-3xl">Retry what you missed this sitting</h1>
        <p className="mt-2 mb-6 text-muted">SessionStorage only. Demo does not persist.</p>
        <DemoMissedPlayer />
      </AppShell>
    );
  }

  if (mode === "weakest" && user.isDemo) {
    return (
      <AppShell user={user}>
        <p className="kicker">Weakest domain · demo session</p>
        <h1 className="mt-2 text-3xl">Lowest accuracy this sitting</h1>
        <p className="mt-2 mb-6 text-muted">SessionStorage only.</p>
        <DemoWeakestLaunch />
      </AppShell>
    );
  }

  if (mode === "one" && sp.qid) {
    const q = await prisma.question.findUnique({ where: { id: sp.qid }, include: { class: true } });
    const items = q ? [toItem(q)] : [];
    return (
      <AppShell user={user}>
        <p className="kicker">Single item</p>
        <h1 className="mt-2 text-3xl">Practice this question</h1>
        <p className="mt-2 mb-6 text-muted">Opened from the bank or a flag. Answers stay in the player, not the list.</p>
        <GymPersist items={items} gym="one" slug={sp.qid} seedNote="One original item from the bank." />
      </AppShell>
    );
  }

  const bank = await prisma.question.findMany({ include: { class: true } });

  if (mode === "quick") {
    const picked = sampleWithoutReplacement(bank, 10);
    return (
      <AppShell user={user}>
        <p className="kicker">Quick 10</p>
        <h1 className="mt-2 text-3xl">Ten mixed items</h1>
        <p className="mt-2 mb-6 text-muted">Sampled without replacement when the bank is large enough.</p>
        <GymPersist
          items={picked.items.map(toItem)}
          gym="practice"
          slug="quick"
          showCards
          seedNote={picked.withReplacement ? "Bank was short." : "Quick 10 from the original bank."}
        />
      </AppShell>
    );
  }

  if (mode === "missed") {
    const ids = await missedQuestionIds(user.id);
    const missed = bank.filter((q) => ids.includes(q.id));
    const ordered = ids.map((id) => missed.find((q) => q.id === id)).filter(Boolean);
    const take = ordered.slice(0, 20);
    if (!take.length) {
      return (
        <AppShell user={user}>
          <p className="kicker">Missed</p>
          <h1 className="mt-2 text-3xl">Nothing missed yet</h1>
          <p className="mt-2 mb-6 text-muted">Wrong answers on a real account land here.</p>
          <Link href="/practice?mode=quick" className="btn-primary tap">
            Quick 10
          </Link>
        </AppShell>
      );
    }
    return (
      <AppShell user={user}>
        <p className="kicker">Missed · {take.length} items</p>
        <h1 className="mt-2 text-3xl">Retry the misses</h1>
        <GymPersist
          items={take.map((q) => toItem(q!))}
          gym="practice"
          slug="missed"
          showCards
          seedNote="Items with a stored incorrect attempt. Unique, most recent first."
        />
      </AppShell>
    );
  }

  if (mode === "weakest") {
    const d = await weakestDomainFromAttempts(user.id);
    if (!d) {
      return (
        <AppShell user={user}>
          <p className="kicker">Weakest domain</p>
          <h1 className="mt-2 text-3xl">Need attempts first</h1>
          <Link href="/practice?mode=quick" className="btn-primary mt-4 tap">
            Quick 10
          </Link>
        </AppShell>
      );
    }
    const pool = bank.filter((q) => q.class.domain === d);
    const picked = sampleWithoutReplacement(pool, 10);
    return (
      <AppShell user={user}>
        <p className="kicker">
          Weakest · D{d} {DOMAIN_NAMES[d]}
        </p>
        <h1 className="mt-2 text-3xl">{DOMAIN_NAMES[d]}</h1>
        <GymPersist
          items={picked.items.map(toItem)}
          gym="practice"
          slug={`weakest-${d}`}
          showCards
          seedNote={`Lowest attempt accuracy is Domain ${d}. Ten original items.`}
        />
      </AppShell>
    );
  }

  if (mode === "level") {
    const diff = user.isDemo ? "Foundation" : await levelFromAttempts(user.id);
    const pool = bank.filter((q) => q.difficulty === diff);
    const picked = sampleWithoutReplacement(pool.length ? pool : bank, 10);
    return (
      <AppShell user={user}>
        <p className="kicker">Level up · {diff}</p>
        <h1 className="mt-2 text-3xl">{diff} band</h1>
        <p className="mt-2 mb-6 text-muted">
          Foundation until 70% on Foundation attempts, then Exam until 70%, then Expert. Demo starts at Foundation.
        </p>
        <GymPersist
          items={picked.items.map(toItem)}
          gym="practice"
          slug={`level-${diff}`}
          showCards
          seedNote={`${diff} items. Hit 70% on a band to unlock the next.`}
        />
      </AppShell>
    );
  }

  if (mode === "timed") {
    const minutes = Number(sp.minutes) === 10 ? 10 : 5;
    const picked = sampleWithoutReplacement(bank, 80);
    return (
      <AppShell user={user}>
        <p className="kicker">Timed sprint · {minutes}:00</p>
        <h1 className="mt-2 text-3xl">As many as you finish</h1>
        <p className="mt-2 mb-6 text-muted">
          Clock auto-submits. Score uses finished items only, not leftover unanswered.
        </p>
        <GymPersist
          items={picked.items.map(toItem)}
          gym="practice"
          slug={`timed-${minutes}`}
          timerMinutes={minutes}
          sprintMode
          showCalculator
          seedNote={`${minutes}-minute sprint. Finish what you can.`}
        />
      </AppShell>
    );
  }

  if (mode === "custom") {
    const domains = parseDomainList(sp.domains);
    const count = [10, 20, 40].includes(Number(sp.count)) ? Number(sp.count) : 10;
    if (!domains.length) redirect("/practice");
    const pool = bank.filter((q) => domains.includes(q.class.domain));
    const picked = sampleWithoutReplacement(pool, count);
    return (
      <AppShell user={user}>
        <p className="kicker">
          Custom · {count} · D{domains.join(" / D")}
        </p>
        <h1 className="mt-2 text-3xl">Build your own</h1>
        <GymPersist
          items={picked.items.map(toItem)}
          gym="practice"
          slug={`custom-${domains.join("-")}-${count}`}
          showCards
          seedNote={`Domains ${domains.join(", ")}. ${count} original items.`}
        />
      </AppShell>
    );
  }

  if (mode === "mini") {
    const sampled = weightedSample(bank, 25);
    return (
      <AppShell user={user}>
        <p className="kicker">Mini exam · 25 · official weights</p>
        <h1 className="mt-2 text-3xl">Short weighted sitting</h1>
        <GymPersist
          items={sampled.items.map(toItem)}
          gym="practice"
          slug="mini-25"
          examMode
          showCalculator
          showDomainBreakdown
          seedNote={
            sampled.withReplacement
              ? "Mini 25 at 25/25/15/9/6/10/10. A domain bank was short."
              : "Mini 25 at official domain weights. Cards off. Calculator on."
          }
        />
      </AppShell>
    );
  }

  redirect("/practice");
}
