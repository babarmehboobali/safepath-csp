import Link from "next/link";
import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { TopicMapDesk } from "@/components/TopicMapDesk";
import { TOPIC_MODULES } from "@/content/gym/topic-map";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export default async function LearnIndexPage() {
  const user = await getSession();
  if (!user) redirect("/login");
  const classes = await prisma.class.findMany({
    select: { id: true, title: true, domain: true },
    orderBy: { id: "asc" },
  });

  return (
    <AppShell user={user}>
      <p className="kicker">Curriculum explorer · {TOPIC_MODULES.length} topic cards</p>
      <h1 className="mt-2 font-serif text-3xl">Topic map</h1>
      <p className="mt-2 mb-6 max-w-3xl text-muted">
        Topic map of the 130-class catalog. Search study topics and jump into the Safepath classes and domain gyms
        they map to. Domain names come from app constants.{" "}
        <Link href="/practice" className="text-amber underline-offset-2 hover:underline">
          Practice hub
        </Link>
        {" · "}
        <Link href="/plan" className="text-amber underline-offset-2 hover:underline">
          Study plan
        </Link>
      </p>
      <TopicMapDesk modules={TOPIC_MODULES} classes={classes} />
    </AppShell>
  );
}
