import AudioClassPlayer from "@/components/AudioClassPlayer";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import InstructorLessonDeck from "@/components/InstructorLessonDeck";
import { type ArithmeticExample, type CaseStage } from "@/components/InteractiveClassBlocks";
import { getSession } from "@/lib/auth";
import { getStudyProfile } from "@/lib/profile";
import { prisma } from "@/lib/prisma";
import { isClassUnlocked } from "@/lib/planner";
import { domainScoresForUser } from "@/lib/progress";
import { EXAM_TIP } from "@/lib/constants";
import { toItem } from "@/lib/gym";
import { CATALOG, domainPathForClass } from "@/lib/catalog";

export default async function LearnPage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ quiz?: string }> }) {
  const user = await getSession();
  if (!user) redirect("/login");
  const profile = await getStudyProfile();
  if (!profile) redirect("/login");
  const { id } = await params;
  const sp = await searchParams;
  const quizMode = sp.quiz === "1";
  const classId = Number(id);
  if (!Number.isFinite(classId)) notFound();
  const cls = await prisma.class.findUnique({
    where: { id: classId },
    include: { questions: true },
  });
  if (!cls) notFound();
  const scores = await domainScoresForUser(user.id, user.isDemo);
  const open = isClassUnlocked(cls.id, profile.track, scores);

  const hook =
    profile.industrySkin === "oil-and-gas" && cls.hookOilGas
      ? cls.hookOilGas
      : profile.industrySkin === "construction" && cls.hookConstruction
        ? cls.hookConstruction
        : cls.hook;

  const traps: string[] = JSON.parse(cls.trapsJson || "[]");
  const contrast: { looksLike: string; actually: string }[] = JSON.parse(cls.contrastJson || "[]");
  const mustScore: string[] = JSON.parse(cls.mustScoreJson || "[]");
  const stemIfThenRaw: unknown = JSON.parse(cls.stemIfThenJson || "[]");
  const stemIfThen: { ifStem: string; pick: string }[] = Array.isArray(stemIfThenRaw)
    ? stemIfThenRaw.map((row) => {
        if (row && typeof row === "object" && "ifStem" in row && "pick" in row) {
          const o = row as { ifStem: unknown; pick: unknown };
          return { ifStem: String(o.ifStem ?? ""), pick: String(o.pick ?? "") };
        }
        const s = String(row ?? "");
        const m = s.match(/^If\s+(.+?),\s*(?:pick|take)\s+(.+)$/i);
        if (m) return { ifStem: m[1].trim(), pick: m[2].trim() };
        return { ifStem: s, pick: "the highest remaining control that fits the stem" };
      })
    : [];
  const path = domainPathForClass(cls.id);
  const items = cls.questions.map((q) => toItem({ ...q, class: { domain: cls.domain } }));
  const arithmeticExample: ArithmeticExample = (() => {
    switch (cls.formulaSlug) {
      case "dike-volume":
        return {
          title: "Containment volume",
          prompt: "A diked area is 20 ft × 12 ft × 2 ft. Convert the containment volume to gallons.",
          steps: [
            "Volume = 20 × 12 × 2 = 480 ft³.",
            "Convert cubic feet to gallons: 480 × 7.48 = 3,590.4 gal.",
          ],
          answer: "≈ 3,590 gal.",
        };
      case "niosh-rwl":
        return {
          title: "NIOSH RWL",
          prompt: "For a simplified check with LC = 51 lb and a composite multiplier of 0.50, calculate the RWL.",
          steps: [
            "RWL = 51 × 0.50.",
            "RWL = 25.5 lb.",
          ],
          answer: "25.5 lb.",
        };
      case "rpn":
        return {
          title: "Risk Priority Number",
          prompt: "Severity = 6, occurrence = 7, detection = 5. Calculate RPN.",
          steps: [
            "RPN = Severity × Occurrence × Detection.",
            "RPN = 6 × 7 × 5 = 210.",
          ],
          answer: "210.",
        };
      case "trir":
        return {
          title: "TRIR",
          prompt: "Three recordables occurred over 300,000 hours worked. Calculate TRIR.",
          steps: [
            "TRIR = (N × 200,000) ÷ hours worked.",
            "TRIR = (3 × 200,000) ÷ 300,000 = 2.0.",
          ],
          answer: "2.0.",
        };
      case "roi":
        return {
          title: "Return on investment",
          prompt: "A project gains $15,000 and costs $10,000. Calculate ROI.",
          steps: [
            "Net gain = 15,000 − 10,000 = $5,000.",
            "ROI = 5,000 ÷ 10,000 = 0.50 = 50%.",
          ],
          answer: "50%.",
        };
      case "mean":
        return {
          title: "Mean",
          prompt: "Four audit scores are 80, 90, 70, and 60. Calculate the arithmetic mean.",
          steps: [
            "Add the observations: 80 + 90 + 70 + 60 = 300.",
            "Divide by 4 observations: 300 ÷ 4 = 75.",
          ],
          answer: "75.",
        };
      case "twa":
        return {
          title: "8-hour TWA",
          prompt: "Exposure is 100 ppm for 2 hours and 20 ppm for 4 hours; treat the remaining 2 hours as 0 ppm for this example.",
          steps: [
            "Weighted exposure = (100 × 2) + (20 × 4) + (0 × 2) = 280 ppm·h.",
            "TWA = 280 ÷ 8 = 35 ppm.",
          ],
          answer: "35 ppm.",
        };
      case "osha-niosh-noise":
        return {
          title: "OSHA noise dose",
          prompt: "At 95 dBA under the OSHA 5 dB exchange, the allowable time is 4 hours. A worker receives 8 hours at that level. Calculate dose.",
          steps: [
            "Dose = 100 × (actual time ÷ allowable time).",
            "Dose = 100 × (8 ÷ 4) = 200%.",
          ],
          answer: "200%.",
        };
      case "ppm-mgm3":
        return {
          title: "ppm to mg/m³",
          prompt: "For a gas at 25 °C, convert 50 ppm with molecular weight 28 using the 24.45 factor.",
          steps: [
            "mg/m³ = (ppm × MW) ÷ 24.45.",
            "mg/m³ = (50 × 28) ÷ 24.45 ≈ 57.26.",
          ],
          answer: "≈ 57.3 mg/m³.",
        };
      case "q-va":
        return {
          title: "Airflow Q = VA",
          prompt: "A 12-inch round duct carries air at 2,000 fpm. Calculate airflow.",
          steps: [
            "12 in = 1 ft diameter, so r = 0.5 ft.",
            "Area = π × 0.5² ≈ 0.7854 ft².",
            "Q = V × A = 2,000 × 0.7854 ≈ 1,570.8 cfm.",
          ],
          answer: "≈ 1,571 cfm.",
        };
      default:
        return {
          title: "Worked percentage check",
          prompt: "A program closes 92 of 100 corrective actions on time. Calculate the closure percentage.",
          steps: [
            "Closure rate = completed ÷ total.",
            "Closure rate = 92 ÷ 100 = 0.92.",
            "Convert to percent: 0.92 × 100 = 92%.",
          ],
          answer: "92%.",
        };
    }
  })();

  const walkthroughStages: CaseStage[] = [
    {
      title: "Stage 1 · establish the decision",
      prompt: `The field team is working on “${cls.title}”. What should the CSP establish before choosing a control?`,
      choices: [
        {
          label: "Define the hazard, task, applicable requirement, and acceptance criteria first.",
          correct: true,
          explanation: "The decision starts with the actual hazard and governing requirement, not with a favorite control or a form checkbox.",
        },
        {
          label: "Choose PPE immediately because every field problem can be managed with the right equipment.",
          correct: false,
          explanation: "Starting with PPE skips source control and can leave the hazard unchanged.",
        },
        {
          label: "Start work because the task has been performed before without an incident.",
          correct: false,
          explanation: "Past incident history does not prove current risk is acceptable or that the current controls are adequate.",
        },
      ],
    },
    {
      title: "Stage 2 · choose the control direction",
      prompt: "The hazard is confirmed. Which response best reflects the CSP hierarchy decision?",
      choices: [
        {
          label: "Prefer elimination, substitution, or engineering before relying on administrative controls or PPE.",
          correct: true,
          explanation: "Higher-order controls address the hazard closer to the source and are generally less dependent on perfect worker behavior.",
        },
        {
          label: "Issue another toolbox talk and treat that as the primary control.",
          correct: false,
          explanation: "Training and reminders can support a control strategy but do not automatically outrank source or engineering controls.",
        },
        {
          label: "Use the easiest control to document so the audit trail looks complete.",
          correct: false,
          explanation: "Documentation is evidence of the process; it is not a substitute for an effective control.",
        },
      ],
    },
    {
      title: "Stage 3 · verify implementation",
      prompt: `What should the CSP verify before declaring the decision complete?`,
      choices: [
        {
          label: `Confirm the control is implemented and effective against the stated requirement: ${(cls.standard || cls.rule || "the class acceptance criterion").split(/\s+/).slice(0, 36).join(" ")}${(cls.standard || cls.rule || "").split(/\s+/).length > 36 ? "…" : ""}`,
          correct: true,
          explanation: "A signed form or verbal assurance is not the same as evidence that the control exists and performs as intended.",
        },
        {
          label: "Accept the control because the responsible person says it is complete.",
          correct: false,
          explanation: "The CSP should verify objective evidence, not only rely on an assertion of completion.",
        },
        {
          label: "Use the most favorable metric and ignore contrary field evidence.",
          correct: false,
          explanation: "Selective evidence creates false assurance and misses the actual barrier health or process weakness.",
        },
      ],
    },
    {
      title: "Stage 4 · calculate only after inputs are fixed",
      prompt: `The decision now requires a number. Use the stated units and formula, then compare the result with the acceptance criterion.`,
      choices: [
        {
          label: `Work the calculation step-by-step, preserve units, and select the closest defensible result.`,
          correct: true,
          explanation: "CSP arithmetic errors often come from unit mismatch, wrong denominator, wrong exchange rate, or choosing an attractive distractor before doing the math.",
        },
        {
          label: "Estimate from memory and choose the number that looks most familiar.",
          correct: false,
          explanation: "Familiar-looking values are common distractors when the stem requires a specific formula or unit conversion.",
        },
        {
          label: "Round the inputs before calculating to save time, even when the answer choices are close.",
          correct: false,
          explanation: "Premature rounding can push the result into the wrong option when the answers are close together.",
        },
      ],
    },
  ];

  return (
    <AppShell user={user}>
      <div className="space-y-4">
        {!open ? (
          <p className="rounded-xl border border-line bg-panel px-5 py-4 text-sm leading-relaxed text-muted">
            Locked unless your track is Maximum or Domain {cls.domain} is under 60%. The instructor deck remains visible so you can see the class title and lesson structure.
          </p>
        ) : null}
      </div>

      <div className="mt-8 space-y-8">
      <AudioClassPlayer
        title={cls.title}
        hook={hook}
        rule={cls.rule}
        standard={cls.standard}
        practiceItems={items.map((item) => ({ stem: item.stem, options: item.options }))}
      />

      <InstructorLessonDeck
        classId={cls.id}
        domain={cls.domain}
        domainCount={path.count}
        classIndex={path.index}
        taskCode={cls.taskCode}
        isMaximum={cls.isMaximum}
        title={cls.title}
        hook={hook || "Hook placeholder for this blueprint task."}
        rule={cls.rule || "Rule placeholder."}
        modelCaption={cls.modelCaption || "Model placeholder."}
        workedCase={cls.workedCase || "Worked case placeholder."}
        traps={traps}
        contrast={contrast}
        mustScore={mustScore}
        stemIfThen={stemIfThen}
        brief={cls.brief || "Placeholder notes for this class."}
        standard={cls.standard || "No standard note supplied."}
        deep={cls.deep || "No deep note supplied."}
        cardFront={cls.cardFront || "Card placeholder"}
        cardBack={cls.cardBack || "Back placeholder"}
        teachBackKey={cls.teachBackKey || "State the rule, decision sequence, and verification step."}
        formulaSlug={cls.formulaSlug}
        items={items}
        quizMode={quizMode}
        unlocked={open}
        isDemo={user.isDemo}
        examTip={EXAM_TIP}
        arithmeticExample={arithmeticExample}
        walkthroughStages={walkthroughStages}
      />

      </div>
      <div className="mt-10 flex flex-wrap gap-3 border-t border-line pt-8">
        {cls.id > 1 ? (
          <Link href={`/learn/${cls.id - 1}`} className="btn-ghost">
            ← Previous class
          </Link>
        ) : null}
        {cls.id < Math.max(...CATALOG.map((c) => c.id)) ? (
          <Link href={`/learn/${cls.id + 1}`} className="btn-ghost">
            Next class →
          </Link>
        ) : null}
      </div>
    </AppShell>
  );
}
