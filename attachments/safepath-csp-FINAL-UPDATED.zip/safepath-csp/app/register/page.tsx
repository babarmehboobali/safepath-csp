import { Suspense } from "react";
import Link from "next/link";
import { AppShell } from "@/components/AppShell";
import { AuthForm } from "@/components/AuthForm";
import { getSession } from "@/lib/auth";
import { redirect } from "next/navigation";

export default async function RegisterPage() {
  const user = await getSession();
  if (user) redirect("/dashboard");
  return (
    <AppShell user={null}>
      <p className="kicker">Register</p>
      <h1 className="mt-2 font-serif text-3xl">Keep the work you do</h1>
      <p className="mt-2 mb-6 text-muted">
        Real accounts store plan, attempts, mock scores, and card reviews.{" "}
        <Link href="/login" className="text-amber underline-offset-4 hover:underline">
          Log in
        </Link>
      </p>
      <Suspense>
        <AuthForm mode="register" />
      </Suspense>
    </AppShell>
  );
}
