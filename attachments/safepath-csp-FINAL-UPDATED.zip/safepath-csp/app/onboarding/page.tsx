import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { ProfileForm } from "@/components/ProfileForm";
import { getSession } from "@/lib/auth";
import { getStudyProfile } from "@/lib/profile";

export default async function OnboardingPage() {
  const user = await getSession();
  if (!user) redirect("/login");
  const profile = await getStudyProfile();
  if (!profile) redirect("/login");
  return (
    <AppShell user={user}>
      <p className="kicker">Onboarding</p>
      <h1 className="mt-2 font-serif text-3xl">Set the plan from your date and hours</h1>
      <p className="mt-2 mb-6 max-w-xl text-muted">
        The planner uses this exam date, weekly hours, and available days. You will see a warning if
        hours × weeks until the exam is under 120.
      </p>
      <ProfileForm profile={profile} endpoint="/api/onboarding" submitLabel="Save and open dashboard" />
    </AppShell>
  );
}
