import Link from "next/link";
import type { CSSProperties } from "react";
import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { getSession } from "@/lib/auth";
import { getStudyProfile } from "@/lib/profile";
import { buildPlanner } from "@/lib/planner";
import { domainScoresForUser, readyGate, upcomingReviews } from "@/lib/progress";
import { CATALOG } from "@/lib/catalog";
import { prisma } from "@/lib/prisma";
import { DOMAIN_NAMES } from "@/lib/constants";
import { parseGymPayload } from "@/lib/gym";
import { practiceCertificateGate } from "@/lib/certificate";

export default async function DashboardPage() {
  const user = await getSession();
  if (!user) redirect("/login");
  const profile = await getStudyProfile();
  if (!profile) redirect("/login");
  if (!profile.onboardingComplete && !user.isDemo) redirect("/onboarding");

  const scores = await domainScoresForUser(user.id, user.isDemo);
  const plan = buildPlanner(profile, scores);
  const gate = await readyGate(user.id, user.isDemo);
  const reviews = await upcomingReviews(user.id, user.isDemo);
  const dueNow = reviews.filter((r) => r.dueAt.getTime() <= Date.now());

  const nextId = plan.unlockedIds[0] ?? 1;
  const nextClass = CATALOG.find((c) => c.id === nextId);

  let ctaHref = "/learn/1";
  let ctaLabel = "Start Class 1 — Prevention through Design";
  let ctaWhy = "One next action. Finish this, then come back here.";
  if (!profile.onboardingComplete) {
    ctaHref = "/onboarding";
    ctaLabel = "Complete onboarding";
    ctaWhy = "The planner needs your exam date and hours.";
  } else if (dueNow.length) {
    ctaHref = "/cards";
    ctaLabel = `Review ${dueNow.length} due card${dueNow.length === 1 ? "" : "s"}`;
    ctaWhy = "Memory schedule is 1 / 3 / 7 / 21 days.";
  } else if (nextClass) {
    ctaHref = `/learn/${nextClass.id}`;
    ctaLabel = `Open Class ${nextClass.id} — ${nextClass.title}`;
    ctaWhy = "One next action. Do this class, then the rest of the week on Learn.";
  } else {
    ctaHref = "/mock?length=200";
    ctaLabel = "Start 200-item exam-mode mock";
    ctaWhy = "Classes are clear. Sit a 200-item / 5.5-hour CBT mock next.";
  }

  const qCount = await prisma.question.count();

  let preReport: { score: number; domainScores: Record<number, number> } | null = null;
  let postReport: { score: number; domainScores: Record<number, number> } | null = null;
  if (!user.isDemo) {
    const pre = await prisma.gymRun.findFirst({
      where: { userId: user.id, gym: "assess", slug: "pre" },
      orderBy: { createdAt: "desc" },
    });
    const post = await prisma.gymRun.findFirst({
      where: { userId: user.id, gym: "assess", slug: "post" },
      orderBy: { createdAt: "desc" },
    });
    if (pre) preReport = { score: pre.score, domainScores: parseGymPayload(pre.answersJson).domainScores };
    if (post) postReport = { score: post.score, domainScores: parseGymPayload(post.answersJson).domainScores };
  }
  const recentMocks = user.isDemo
    ? []
    : await prisma.mockRun.findMany({
        where: { userId: user.id },
        orderBy: { createdAt: "desc" },
        take: 5,
      });

  return (
    <AppShell user={user}>
      <div className="space-y-7">
        <section className="readiness-hero">
          <div className="flex flex-wrap items-start justify-between gap-5">
            <div>
              <p className="kicker">👋 Command center</p>
              <h1 className="page-title mt-1">Hello {profile.name.split(" ")[0]}</h1>
              <p className="page-lead">{profile.track} track · {profile.depth} depth · {profile.difficulty} difficulty · {profile.industrySkin} skin</p>
            </div>
            <Link href={ctaHref} className="btn-primary tap">{ctaLabel}</Link>
          </div>
          <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <div className="rounded-2xl border border-line bg-panel-2/70 p-4"><div className="text-xl">🔥</div><p className="mt-2 text-xs uppercase tracking-wide text-muted">Study streak</p><p className="mt-1 text-2xl font-bold">{user.isDemo ? "Demo" : "Keep going"}</p></div>
            <div className="rounded-2xl border border-line bg-panel-2/70 p-4"><div className="text-xl">⏳</div><p className="mt-2 text-xs uppercase tracking-wide text-muted">Exam countdown</p><p className="mt-1 text-2xl font-bold">{plan.daysRemaining} days</p></div>
            <div className="rounded-2xl border border-line bg-panel-2/70 p-4"><div className="text-xl">📚</div><p className="mt-2 text-xs uppercase tracking-wide text-muted">Unlocked path</p><p className="mt-1 text-2xl font-bold">{plan.unlockedIds.length}/130</p></div>
            <div className="rounded-2xl border border-line bg-panel-2/70 p-4"><div className="text-xl">🧠</div><p className="mt-2 text-xs uppercase tracking-wide text-muted">Question bank</p><p className="mt-1 text-2xl font-bold">{qCount.toLocaleString()}</p></div>
          </div>
        </section>

        <section className="grid gap-4 lg:grid-cols-3">
          <article className="mission-card lg:col-span-2" style={{"--mission-accent":"#7cdb3a"} as CSSProperties}>
            <div className="flex items-start justify-between gap-4"><div><p className="kicker">🎯 Next best action</p><h2 className="mt-1 text-2xl font-bold">{ctaLabel}</h2><p className="mt-2 max-w-2xl text-muted">{ctaWhy}</p></div><div className="mission-icon">→</div></div>
            <div className="mt-5 flex flex-wrap gap-2"><Link href={ctaHref} className="btn-primary tap">Start now</Link><Link href="/assess/self" className="btn-ghost tap">Check readiness</Link><Link href="/plan" className="btn-ghost tap">View plan</Link></div>
          </article>
          <article className="card p-5"><p className="kicker">🏁 Ready gate</p><p className="mt-2 text-2xl font-bold">{gate.ready ? "Ready" : "Building"}</p><p className="mt-2 text-sm text-muted">{gate.reason}</p><div className="mt-4 domain-meter"><span style={{width:`${Math.min(100, Math.round((gate.mockCountAt70/2)*100))}%`}} /></div><p className="mt-2 text-xs text-muted">Mocks ≥70%: {gate.mockCountAt70}/2</p></article>
        </section>

        <section className="grid gap-4 lg:grid-cols-2">
          <article className="card p-5"><div className="flex items-center justify-between"><div><p className="kicker">📅 Study load</p><h2 className="mt-1 text-xl font-bold">{plan.hoursBudget} planned hours</h2></div><span className="chip">{profile.hoursPerWeek} h/week</span></div>{plan.underHours ? <p className="mt-4 rounded-xl border border-amber/40 bg-amber/10 p-3 text-sm text-amber">⚠️ Your schedule is below the 120-hour planning floor.</p> : <p className="mt-4 rounded-xl border border-ok/30 bg-ok/10 p-3 text-sm text-ok">✓ Your current schedule clears the planning floor.</p>}<Link href="/plan" className="btn-ghost mt-4 tap">Open study command center</Link></article>
          <article className="card p-5"><p className="kicker">🧠 Memory queue</p><h2 className="mt-1 text-xl font-bold">{dueNow.length ? `${dueNow.length} reviews due` : "No urgent reviews"}</h2><p className="mt-2 text-sm text-muted">{user.isDemo ? "Demo reviews are not stored." : dueNow.length ? "Short recall sessions keep old material alive." : "Keep learning; the queue will surface when cards become due."}</p><Link href="/cards" className="btn-ghost mt-4 tap">Open cards</Link></article>
        </section>

        <section className="card p-5">
          <div className="flex flex-wrap items-end justify-between gap-3"><div><p className="kicker">📊 Domain pulse</p><h2 className="mt-1 font-serif text-2xl">Where your preparation stands</h2></div><Link href="/domains" className="text-sm font-semibold text-[var(--user-accent)]">Open domain map →</Link></div>
          <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[1,2,3,4,5,6,7].map((d) => { const score=scores[d]; return <div key={d} className="rounded-xl border border-line bg-panel-2/60 p-3"><div className="flex justify-between gap-2 text-sm"><span>D{d}</span><strong>{score == null ? "—" : `${Math.round(score)}%`}</strong></div><div className="mt-2 domain-meter"><span style={{width:`${score == null ? 0 : Math.max(3, Math.min(100, score))}%`}} /></div><p className="mt-2 text-xs text-muted line-clamp-1">{DOMAIN_NAMES[d]}</p></div>; })}
          </div>
        </section>

        <section className="card p-5">
          <div className="flex flex-wrap items-end justify-between gap-3"><div><p className="kicker">🧪 Diagnostics</p><h2 className="mt-1 font-serif text-2xl">Measure improvement</h2></div><Link href="/assess/self" className="btn-primary tap">Run self-assessment</Link></div>
          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            <div className="rounded-xl border border-line bg-panel-2/60 p-4"><p className="text-xs uppercase tracking-wide text-muted">Pre-test</p><p className="mt-1 text-2xl font-bold">{preReport ? `${Math.round(preReport.score)}%` : "—"}</p><p className="mt-1 text-xs text-muted">Baseline diagnostic</p></div>
            <div className="rounded-xl border border-line bg-panel-2/60 p-4"><p className="text-xs uppercase tracking-wide text-muted">Post-test</p><p className="mt-1 text-2xl font-bold">{postReport ? `${Math.round(postReport.score)}%` : "—"}</p><p className="mt-1 text-xs text-muted">After focused repair</p></div>
          </div>
        </section>

        {recentMocks.length ? <section className="card p-5"><p className="kicker">⏱ Recent mocks</p><div className="mt-4 grid gap-2 sm:grid-cols-2">{recentMocks.map((run) => <div key={run.id} className="rounded-xl border border-line bg-panel-2/60 p-3"><div className="flex justify-between"><span>{run.length} items</span><strong>{Math.round(run.score)}%</strong></div><p className="mt-1 text-xs text-muted">{new Date(run.createdAt).toLocaleDateString()}</p></div>)}</div></section> : null}
      </div>

    </AppShell>
  );
}
