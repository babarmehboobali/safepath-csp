# PostgreSQL setup

Safepath CSP is packaged for PostgreSQL with Prisma. Set `DATABASE_URL` to the PostgreSQL database used by the application.

## Local setup

Create `.env` from `.env.example`, then set:

`DATABASE_URL="postgresql://USER:PASSWORD@HOST:5432/cspcoach?schema=public"`

`AUTH_SECRET="a-long-random-secret"`

Apply the schema with:

`npx prisma db push`

Seed the catalog and demo account with:

`npm run db:seed`

## Prisma / Bun

The final package uses Prisma Client 6.x with PostgreSQL. Bun runs the scripts, while Prisma Client uses the PostgreSQL connection string through `DATABASE_URL`.

## Production

For a managed PostgreSQL provider such as Neon or Prisma Postgres, set `DATABASE_URL`, `AUTH_SECRET`, and `CRON_SECRET` in the hosting environment. Do not commit `.env` or database credentials.
