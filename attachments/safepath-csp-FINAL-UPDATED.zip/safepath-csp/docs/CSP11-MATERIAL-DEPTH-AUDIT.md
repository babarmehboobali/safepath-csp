# CSP-11 Material Depth Audit

## Scope

This curriculum pass uses the official BCSP CSP11 Examination Blueprint, version 2024.04.24, as the task-level map. The published blueprint defines seven domains and 47 task statements; internal curriculum class numbers are implementation IDs and may reinforce the same blueprint task more than once.

Official source:
- Board of Certified Safety Professionals, CSP11 Examination Blueprint, V.2024.04.24: https://www.bcsp.org/hubfs/Website/Blueprints-References/CSP-Blueprint.pdf
- BCSP CSP Reference List: https://www.bcsp.org/certifications/csp/reference-materials

## Curriculum state after depth pass

- 100 curriculum classes/modules are registered in `CLASS_PACKS` and `CATALOG`.
- 1,230 original class-level practice items are present across Classes 1–100.
- Classes 91–100 are marked as Deep Technical Masterclasses and are included in the Maximum track.
- All class task codes are constrained to the published CSP11 task-number ranges D1.01–D1.07, D2.01–D2.14, D3.01–D3.04, D4.01–D4.05, D5.01–D5.05, D6.01–D6.06, and D7.01–D7.06.

## Deep Technical Masterclasses

| Class | Topic | Blueprint task | Why it was added |
|---|---|---|---|
| 91 | System Reliability | D2.06 | Series/parallel reliability, MTBF, failure rate, exponential mission reliability, and reliability-block logic. |
| 92 | IH Sampling Statistics | D6.01 | 8-hour TWA, additive mixture calculations, SAE, UCL/LCL, and sampling-design interpretation. |
| 93 | Arc Flash Engineering | D1.03 | Energized-work decision logic, incident energy, boundary distinctions, maintenance condition, and engineering design-out. |
| 94 | Process Safety Engineering | D1.02 | PHA/LOPA-style reasoning, independence/common-cause thinking, relief scenarios, PSSR, MOC, and mechanical integrity. |
| 95 | Fire Protection Engineering | D4.03 | Sprinkler hydraulics, pump/supply logic, alarm/supervisory signals, ITM, storage hazards, and impairment thinking. |
| 96 | Ethics / Professional Judgment | D2.12 | BCSP Code of Ethics, competence, truthful statements, conflicts, misconduct, and correction of errors. |
| 97 | Benchmarking / Performance | D2.01 | Normalization, peer comparability, denominator discipline, leading/lagging context, and benchmark interpretation. |
| 98 | Cost / Economic Analysis | D2.11 | ROI, payback, NPV, recurring life-cycle cost, sensitivity, procurement, and the distinction between compliance and optional investment. |
| 99 | Public Health / Epidemiology | D6.02 | Incidence/prevalence, attack rates, RR, risk difference, case-control/OR concepts, bias, confounding, and causal interpretation. |
| 100 | Training Program Design | D7.02 | Needs-to-objectives-to-practice-to-assessment design, modality selection, competency evidence, transfer, and program evaluation. |

## Task coverage

### Domain 1 — Advanced Application of Safety Principles (25%)

D1.01: Classes 1, 2  
D1.02: Classes 3, 87, 94  
D1.03: Classes 4–10, 80, 82, 93  
D1.04: Class 11  
D1.05: Class 12  
D1.06: Classes 13–15  
D1.07: Classes 16, 79

### Domain 2 — Program Management (25%)

D2.01: Classes 17, 97  
D2.02: Class 18  
D2.03: Class 19  
D2.04: Classes 20–21  
D2.05: Class 22  
D2.06: Classes 23–25, 86, 91  
D2.07: Class 26  
D2.08: Classes 27–30  
D2.09: Class 31  
D2.10: Classes 32, 85  
D2.11: Classes 33, 98  
D2.12: Classes 34, 96  
D2.13: Class 35  
D2.14: Classes 36–38, 90

### Domain 3 — Risk Management (15%)

D3.01: Class 39  
D3.02: Classes 40–42  
D3.03: Classes 44–45  
D3.04: Classes 43, 46

### Domain 4 — Emergency Management (9%)

D4.01: Classes 47, 88  
D4.02: Classes 48, 49, 54  
D4.03: Classes 50, 51, 95  
D4.04: Class 52  
D4.05: Class 53

### Domain 5 — Environmental Management (6%)

D5.01: Class 55  
D5.02: Class 56  
D5.03: Classes 57–58  
D5.04: Class 59  
D5.05: Class 60

### Domain 6 — Occupational Health and Applied Science (10%)

D6.01: Classes 61–67, 81, 83, 84, 92  
D6.02: Class 99  
D6.03: Classes 68–69  
D6.04: Class 70  
D6.05: Class 71  
D6.06: Class 72

### Domain 7 — Training (10%)

D7.01: Class 73  
D7.02: Class 100  
D7.03: Classes 76, 89  
D7.04: Class 77  
D7.05: Classes 75, 78  
D7.06: Class 74

## Material-design rules used in the deep modules

Each Deep Technical Masterclass includes:

1. A field hook with a decision to make, rather than a definition-only opening.
2. A reusable core rule with explicit boundaries on when the rule applies.
3. A mental model / diagram caption suitable for the instructor slide flow.
4. A worked case with visible intermediate arithmetic where math is central.
5. Three common traps and contrast pairs.
6. A brief exam-ready synthesis and deeper technical notes.
7. A card front/back and teach-back key.
8. Twelve original scenario-based practice items.
9. Four-part item rationales: Core Rule, Calculation Steps, Standards Cited, and Why Each Distractor Fails.

## Technical caution

Simplified arithmetic in the reliability, fire-protection, economics, and epidemiology modules is clearly labeled as illustrative. Where a real-world engineering calculation depends on a detailed standard, adopted edition, equipment data, independence assumptions, design input, or sampling method, the module tells the learner not to substitute a classroom shortcut for the governing design/compliance procedure.

## Quality checks

- TypeScript compile of the class content, registry, catalog, and coverage map: passed.
- All Classes 1–100 registered: passed.
- All classes have an allowed CSP11 task code: passed.
- Classes 91–100: 12 items each: passed.
- Classes 91–100: four-part rationale structure present in each item set: passed.
