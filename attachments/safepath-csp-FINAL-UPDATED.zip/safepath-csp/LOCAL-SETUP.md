# SafePath CSP — Permanent Local Setup

## Requirements
- Windows 10/11
- Node.js 20 or newer
- Docker Desktop (running)

## First run
1. Extract this ZIP completely.
2. Open the `safepath-csp` folder.
3. Double-click **START-SAFEPATH.bat**.
4. The launcher starts persistent PostgreSQL, creates `.env` once, installs dependencies, prepares Prisma, seeds SafePath, and starts Next.js.
5. Browser opens at http://localhost:3000.

## Every later run
Double-click **START-SAFEPATH.bat** again. Existing `.env`, `node_modules`, and PostgreSQL data are preserved.

## Stop
Use **STOP-SAFEPATH.bat** when you want to stop the PostgreSQL container. Press Ctrl+C in the Next.js window to stop the web server.

## Persistent database
PostgreSQL uses the Docker volume `cspcoach_postgres`. Normal restarts do not delete SafePath users, progress, assessments, or other database data.

**Never run `docker compose down -v` unless you intentionally want to erase the local database.**

## Manual startup
```powershell
npm ci
npx prisma generate
npx prisma db push
npm run db:seed
npm run dev
```
