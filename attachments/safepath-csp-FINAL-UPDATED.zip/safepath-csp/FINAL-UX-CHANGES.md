# SafePath CSP — Final UX / Study Plan / SEO Upgrade

## Study planner
- Four scheduling strategies: Adaptive, Auto Mix, Domain by Domain, and My Choice.
- Adaptive mode prioritizes weak domains from the latest stored self-assessment diagnostic, falling back to recent mock domain history.
- Every week renders all seven domains; no scheduled class is hidden behind a "+ more" summary.
- Each domain lane shows icon, D1–D7, blueprint weight, score, progress, and every scheduled class with a direct lesson link.
- Domain-by-domain mode keeps the learner inside one domain until its scheduled queue is exhausted before moving to the next.

## Lesson UX
- Lesson sections use icon tabs for Opening, Rule, Picture, Worked, Must-score, Apply, Reading, Recall, and Drill.
- Domain identity and visual symbols are preserved across lesson surfaces.
- Study notes are rendered in readable layers with progressive disclosure and calculator/formula presentation where applicable.

## Personalization
- Existing theme studio remains the source for per-user visual presets, accent color, density, and layout.
- Theme settings continue to persist to the user record for registered accounts and local storage for fast loading.

## SEO
- Added a public CSP preparation hub at `/csp-prep`.
- Added indexable domain pages at `/csp-prep/domain/1` through `/csp-prep/domain/7`.
- Added indexable class pages at `/csp-prep/class/1` through `/csp-prep/class/130`.
- Each class page generates a semantic keyword cluster, metadata, internal links, and LearningResource JSON-LD.
- Added `sitemap.xml` and `robots.txt` through Next.js metadata routes.
- Private authenticated study routes are excluded from crawling while the public CSP study library remains indexable.
- Keyword generation intentionally uses topic + search-intent combinations rather than one global keyword-stuffing blob.

## Validation
- Global TypeScript compiler was used for a syntax/type-pass attempt; dependency type packages were not installed in this execution environment, so module/type-resolution failures remain until `npm ci` is run.
- The source tree was inspected for the final planner, SEO routes, lesson navigation, and theme changes.
