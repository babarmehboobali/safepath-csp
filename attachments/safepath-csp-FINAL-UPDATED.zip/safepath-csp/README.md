# Safepath CSP

Independent study website for the current BCSP CSP-11 exam. Stored classes, session and domain gyms, math and toxicology labs, a searchable equation desk, memory cards, a TI-30XS-style practice calculator, drills, weighted mocks including a 5.5-hour final, pre/post diagnostics, a blueprint-weighted Self-Assessment suite, persistent XP/levels/streaks, and an Expert challenge deck.

Practice items are original. Safepath CSP is not affiliated with BCSP, Pearson VUE, or any other prep vendor. Completing the catalog covers every publicly posted blueprint TASK; it does not reproduce live or secret examination items.

Safepath CSP is an independent study aid aligned to the publicly posted BCSP CSP-11 Examination Blueprint. It is not the Board of Certified Safety Professionals, Pearson VUE, or any other prep vendor. Practice items are original. Completing classes, gyms, and mocks does not guarantee that you will pass the CSP exam. Passing is not guaranteed. Demo activity is not stored.


## Current CSP-11 blueprint weighting

SafePath uses the published CSP11 blueprint distribution: Domain 1 25%, Domain 2 25%, Domain 3 15%, Domain 4 9%, Domain 5 6%, Domain 6 10%, Domain 7 10%. The source is the BCSP CSP11 Examination Blueprint (V.2024.04.24). SafePath is not affiliated with BCSP or Pearson VUE.

## Self-Assessment suite

`/assess/self` provides 50-item and 100-item blueprint-weighted diagnostic sittings. Each sitting randomizes the question pool by domain, records a GymRun for real users, reports overall and D1-D7 performance, checks pacing, and generates a SafePath readiness heuristic. Weak domains link to curriculum/domain practice and MathCORE.

## Gamification

Real accounts persist XP, level, current streak, best streak, and completed lessons in PostgreSQL. Correct answers award XP; completed lessons award a larger bonus. Demo activity remains non-persistent.

## Public landing

Logged-out visitors see a marketing page at `/` (hero, what you get, class flow, exam mode, domain catalog chips, interactive sample quiz, demo vs real). Logged-in users hitting `/` redirect to `/dashboard`.

- Primary CTA: **Start free demo** → `/login?demo=1` (prefill + one-click demo login)
- Secondary: Create account → `/register`
- Product name in UI: **Safepath CSP** / nav short **SafePath** (never "CSP Coach")

## What you need

- Node.js 20 or newer (in a terminal, type node -v and press Enter)
- A terminal (Terminal on a Mac, Command Prompt or PowerShell on Windows)
- PostgreSQL 16 (see Docker path below, or your own server)
- A free GitHub account when you want a public site
- A free Vercel account when you want a public site

## Local run with Compose Postgres

Beginners: from this folder, start the Postgres service in compose.yaml, copy the example env file to .env, then use the command list under Run it on your computer.

## Local run with a plain env Postgres URL

If Postgres is already running, skip Compose. Copy the example env file to .env. Keep the postgresql URL shape USER:PASSWORD@HOST:5432/cspcoach?schema=public, then use the same command list (install, db push, seed, dev).

## Run it on your computer

1. Open a terminal in this folder (safepath-csp).
2. Run these commands, one at a time:

```
npm install
cp .env.example .env
npx prisma db push
npm run db:seed
npm run dev
```

On Windows Command Prompt, if cp is not recognized, use this instead of the second command:

```
copy .env.example .env
```

3. Open http://localhost:3000 in your browser.

4. Demo login:

- Email: demo@cspcoach.app
- Password: Demo1234!

The copy step creates a .env file. DATABASE_URL should be a PostgreSQL URL (see .env.example). AUTH_SECRET can be a long random string on your computer; set a new one before you put the site on the internet.

npm install also runs prisma generate (the postinstall script). You do not need a separate generate command.

## Upgrade an existing local copy

New classes and the public landing appear only after you pull and refresh catalog content. **Seed is mandatory** or Classes 116–130 (and deep session blocks) will not appear in gyms.

```
git pull
npx prisma db push
npm run db:seed
npm run dev
```

Seed upserts class rows by catalog id and replaces class/gym questions. It does not require a database reset as the default path. Keep your .env file; AUTH_SECRET and DATABASE_URL stay. Real accounts are not deleted. Demo login remains demo@cspcoach.app / Demo1234!.

Open http://localhost:3000 logged out to see the marketing landing; log in to land on /dashboard.

Keep the Docker compose option: start the service in compose.yaml, then run the same four commands.

## Phone tests (must pass)

Use your phone on the same Wi-Fi as the computer that is running the dev server. On the phone browser, open http://YOUR-COMPUTER-IP:3000 (on a Mac, the computer IP is often under System Settings, Network; on Windows, type ipconfig in Command Prompt and use the IPv4 address). If that is awkward, run the same clicks on a phone-sized browser window on the computer (narrow the window).

### Demo does not save

1. Open the site. Tap Log in.
2. Email: demo@cspcoach.app / password: Demo1234!
3. Finish onboarding if asked (exam date, hours per week, days, track, depth, difficulty, industry skin). Demo onboarding stays only in this session.
4. Open Class 2. Step through must-score. Answer a drill item. Flip the card. Tap Got it.
5. Tap Log out.
6. Log in as demo again. Plan, attempts, scores, and card reviews must be gone.

### Real account does save

1. Tap Register. Use a new email you made up and an 8+ character password.
2. Complete onboarding (exam date, hours/week, days, track, depth, difficulty, industry skin).
3. Open Class 1, answer an item, flip the card, tap Got it.
4. Tap Log out, then log in with that same email.
5. The plan and the card review must still be there.

### Class 2 must-score + footer

Open Class 2 (address bar: /learn/2) on a phone-width screen. You should see:

- top chrome like Class 2 of 130 / Domain 1 / Hierarchy of Controls
- step bar plus sticky footer: Back, Step n/N, one primary Continue
- Print secondary, not beside Continue
- audio collapsed behind Listen
- a Must-score step and a stem-if-then list
- notes (brief / standard / deep) AFTER the worked case
- drill: one question per screen
- calculator only via a drawer, not always on screen

### 200-q flag / review

Open Mock, then the 200-item final (330 min / 5.5 h). One item on screen. Flag an item. Open Review. Previous/Next stay available. Break overlay does not pause the timer. Confirm submit before scoring. Demo sittings are not stored.

## Demo login

- Email: demo@cspcoach.app
- Password: Demo1234!

Demo activity is not stored. Register a real account to keep plan, attempts, scores, and card reviews.

## Put it on GitHub (repo name: safepath-csp)

You need this before Vercel can host the site. Do not upload .env or any .db files.

1. Create a free account at github.com if you do not have one.
2. Click New repository. Name it exactly safepath-csp. Leave it empty (no README).
3. In the safepath-csp folder, run:

```
git init
git add .
git commit -m "Safepath CSP"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/safepath-csp.git
git push -u origin main
```

Replace YOUR-USERNAME with your GitHub username. If git is not installed, install Git from git-scm.com, or on the GitHub website use Add file to upload this folder. Still skip .env and database files.

## Put it on the internet (Vercel)

SQLite (the local prisma/dev.db file) is only for your computer. A public Vercel site needs AUTH_SECRET and DATABASE_URL. DATABASE_URL on Vercel should be a hosted Postgres URL later (Vercel Postgres or Neon). See docs/POSTGRES.md. You can still import the project now and set the two names.

1. Go to vercel.com and sign in with GitHub.
2. Click Add New, then Project.
3. Import the safepath-csp repository.
4. Under Environment Variables, add:
   - AUTH_SECRET — paste a long random string (a password manager can generate one).
   - DATABASE_URL — PostgreSQL connection string (see .env.example and docs/POSTGRES.md). Until then, local study still uses SQLite.
   - CRON_SECRET — another long random string. Protects the nightly demo wipe at /api/cron/wipe-demo.
5. Click Deploy.

The production build command is next build (the build script). After install, postinstall already runs prisma generate.

Nightly demo wipe: vercel.json calls GET /api/cron/wipe-demo once a day (07:00 UTC). Vercel sends Authorization Bearer CRON_SECRET. You can also run the db:wipe-demo script on a machine that has .env.

Signup is limited to 5 new accounts per IP every 15 minutes (in-memory). That is enough for one computer. A busy production site should switch to Upstash Redis later.

## Scripts in package.json

- `npm run dev` — local site
- `npm run build` — production build
- `npm run start` — run the production build
- `npm run db:seed` — seed demo user and catalog
- `npm run db:wipe-demo` — delete leftover demo attempts/mocks/cards/sessions
- postinstall — prisma generate (runs automatically after install)

## Postgres notes

Phase 1 on your computer uses SQLite (prisma/dev.db). Do not change prisma/schema.prisma provider until you are ready. When you want the public Vercel database, follow docs/POSTGRES.md (Vercel Postgres or Neon). Never commit .env or database files.

## Gyms (original practice)

These desks cover the same *types* of paid prep tools without copying any vendor bank, names, or wording.

- `/sessions` — 14 timed sessions (20 items / 30:00) mapped to class groups across Domains 1–7
- `/domains` — seven domain portals with official weights and last-score tracking
- `/math` — worked example then 8–12 problems (TWA, RWL LC=51, TRIR/DART, Q=VA, dike/cylinder, stats, ppm↔mg/m³, ROI, 5 vs 3 dB)
- `/tox` — definitions, searchable abbreviations, tox cards, Foundation 25 and Exam 25 graded quizzes
- `/formulas` — searchable equation desk (variables, units, worked example, calculator link)
- `/mock` — 50 / 100 / 200, with a 200-item 5.5-hour (330 min) final, cards off, calculator on, domain breakdown
- `/assess/pre` and `/assess/post` — 50-item diagnostics at official weights; dashboard compares pre vs post
- `/challenge` — Expert-only gym (10 or 25)
- `/learn` and `/topics` — searchable topic map of the 130-class catalog (same TopicMapDesk)
- `/learn/[id]?quiz=1` — 5-item class topic exercise (teach-back stays on the class page)
- `/cards` — class cards plus tox / formula / vocab decks on a 1 / 3 / 7 / 21 schedule

Demo activity is not stored (plan, attempts, scores, card reviews, gym runs).

Items are original. Safepath CSP is an independent study aid — not BCSP, not Pearson VUE, and not another prep vendor's product. Completing the 130-class catalog addresses every official CSP-11 blueprint task; it does not ship secret exam items.

## Phase 1 vs later weeks

Catalog, gyms, calculator, cards, mocks, diagnostics, challenge deck, and planner are in this tree. Content packs live under content/classes and content/gym and are original study objects.


## Exam mode vs real Pearson

Safepath CSP exam-mode mocks (`/mock?length=50|100|200`) follow a computer-based testing *pattern*: one item at a time, Previous/Next, flag for review, a review list, an explicit submit confirm, a countdown that does not pause on a break overlay, domain-weighted sampling, and no study aids (cards, class notes, formula library) during the sitting. A TI-30XS-style **practice** calculator is available on demand and is labeled as practice — it is not Pearson software.

This is **not** official Pearson VUE or BCSP software. We do not copy Pearson UI chrome, logos, or tutorial text. Displayed scores use raw % and domain % (internal pretest items, about 12%, are excluded from the displayed total and are never labeled during the attempt). The ready gate for real users remains: two mocks ≥70% with no domain below 60%.

## Permanent Windows localhost launcher

For a persistent local development setup, use the included `START-SAFEPATH.bat`. It starts the PostgreSQL 16 Docker service, preserves the database in the `cspcoach_postgres` volume, creates `.env` only on first run, installs dependencies only when needed, runs Prisma schema preparation and the SafePath seed, then starts Next.js at `http://localhost:3000`. Use `STOP-SAFEPATH.bat` to stop the local services without deleting database data. See `LOCAL-SETUP.md` for details.

## Final lesson UX additions

- Lessons expose a movable TI-30XS practice calculator from the lesson header. Drag the dark calculator title bar to reposition it; the position is remembered locally per calculator mode.
- Lessons include a private Personal Study Notes drawer. Notes are timestamped and stored against the signed-in user's class/topic via `LessonNote`. Demo sessions use browser-local storage only.
- Study Reader delivery supports Focus-one-block and Scan-all modes, while preserving the underlying course reading content.
- On small screens, lesson section tabs are horizontally scrollable so labels remain legible and touch-friendly.
