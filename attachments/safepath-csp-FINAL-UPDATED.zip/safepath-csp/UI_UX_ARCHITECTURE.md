# SafePath CSP — UX Transformation Notes

## Product direction

SafePath is now treated as a study workspace rather than a collection of routes. The interface should repeatedly answer three questions:

1. What should I do next?
2. How am I improving?
3. What will make the next session easier or more effective?

## Anti-boredom loop

The shared experience now favors short feedback cycles: mission card → focused activity → immediate feedback → visible progress → next action. Long reading is broken into bounded blocks; dense content is progressively disclosed; assessment results point directly to remediation.

## Visual hierarchy

- Primary action: bright user accent, high contrast, strong depth.
- Secondary action: transparent/outlined, still readable.
- Diagnostic state: score orb + meters + clear status.
- Weakness: red/amber only where action is required; avoid painting the whole UI red.
- Learning state: green/cyan/lime accents; use icons as semantic anchors rather than decoration.

## Reading system

Study notes are intentionally constrained to a comfortable measure. Raw long-form strings are split into readable blocks and classified into core concept, field application, formula/calculation, must-score and common-trap patterns. Formula blocks use a terminal-style visual language to separate calculation content from prose.

## Personalization

The user can select:

- Visual template: Midnight Pro, Ocean Focus, Safety Forest, Slate Minimal, High Contrast.
- Accent color: six curated accents plus a custom color.
- Density: Comfortable or Compact.
- Layout: Focus, Wide, Cards.

Preferences are persisted for registered users in PostgreSQL and cached locally for instant application. Demo users receive session/local persistence without claiming database storage.

## Planner

The study planner uses a course start date and exam target date, calculates the total schedule window, days remaining, daily study load, weekly milestones, domain focus and module allocation. The plan is presented as missions rather than an undifferentiated list.

## Responsive behavior

The design collapses mission cards to one column on phones, keeps touch targets at least 44px, preserves readable line lengths, and uses a full-screen mobile menu instead of forcing a desktop navigation bar into a narrow viewport.

## Accessibility / motion

Focus-visible states remain explicit. Motion is restrained and disabled/reduced when the platform requests reduced motion. Color is paired with text/icons so status is not communicated by color alone.

## Technical approach

The transformation is implemented primarily in shared CSS tokens and reusable components so the visual system propagates across existing routes without rewriting every page. Existing Tailwind utility vocabulary is bridged to theme variables for background, panel, border, text and accent colors.
